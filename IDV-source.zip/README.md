# 第五人格 Companion API

Windows / Node.js 24 で動く非公式APIです。保存した自分のSDKセッションでゲームサーバーに直接接続するため、PCゲームの画面・プロセスを開いておく必要はありません。ゲーム内画像の初回読み込みには、インストール済みの素材ファイルを使います。PCとAPIは起動しておく必要があります。

モード名の訂正（2026-11-05）：以前「手記の加筆」と記載した`/v1/ugc/*`の作品ランキング・プレイ履歴は、正しくは「ペン先の空想」です。ゲーム内の`TID_NAME_TYPE_UGC`と、週・月ランキングの表示名で照合しました。手記の加筆の順位表と他人の個別戦績は別の調査対象で未確認です。自己個別戦績は専用RPCで1件の取得を確認しました。その後、ログイン時の自己データから段位と探索統計を取得し、`/v1/me/mojin`に追加しました。[公式のペン先の空想・クリアランキングの説明](https://www.identityvgame.com/jp/news/update/20250423/35356_1229790.html)と、[手記の加筆の実装告知](https://www.identityvgame.com/jp/news/update/20260617/35356_1304667.html)でも別モードとして案内されています。

2026-11-05、Asia版の実アカウントで独立認証と下記のHTTP取得を確認しました。

| 機能 | 確認内容 |
| --- | --- |
| フレンド | 実際のフレンド2件、状態、公開されているログイン・ログアウト時刻 |
| 検索 | ID検索・名前検索 |
| プロフィール | 自分とフレンドのプロフィール |
| 戦績 | 自分の戦績104件の受信・圧縮データの展開・ページ分割 |
| ランキング | サバイバー・ハンター、それぞれ全体上位100件 |
| キャラ別ランキング | 医師・復讐者で各100件。公開ID・認知ポイント・アイコン・枠 |
| ペン先の空想 | 週間20作品・月間50作品のランキング。作品内のチーム10組・個人1件のタイム記録も取得。自分のプレイ履歴は成功応答だが現在は空 |
| 手記の加筆の自己情報 | ログイン時の現在段位・最高段位・探索統計。累計2回中成功1回、詞章価値18,600。専用の公開順位表・他人の個別戦績は未取得。自己個別戦績は1件取得 |
| 全体チャット | 保存した地域の公開ルームへ接続し、実メッセージを受信 |
| 募集 | 通常対戦の実募集一覧 |
| 状態取得 | フレンドの状態更新と定期取得 |

非公開の戦績に対して `403 HISTORY_PRIVATE` が返ることも確認済みです。過去の無制限な全戦績を取得するAPIではありません。サーバーが返す範囲を表示します。ゲームの更新やSDKセッションの失効で再設定が必要になる場合があります。別地域は接続先・認証の個別検証が必要です。

## 起動

このPCでは依存関係、SDKセッション、接続先、API認証鍵を設定済みです。

```powershell
npm start
```

保存した接続情報がある場合、APIの起動時にゲーム接続を復元します。手動で切断した場合は、自動で接続を再開しません。接続し直す場合は別のターミナルで次を実行するか、iPhoneアプリの「接続する」を使います。

```powershell
npm run connect
```

PCゲームが同じアカウントでログイン中の場合、上記は `409 GAME_ALREADY_ONLINE` を返します。API側への切り替えには次を使います。PC側のログインは切り替わります。

```powershell
npm run connect -- --replace-existing
npm run status
```

データを読む例です。CLIはWindows DPAPIからAPI認証鍵を読み、Bearerヘッダーを付けます。認証鍵自体は表示しません。

```powershell
node src/cli.mjs get /v1/me
node src/cli.mjs get /v1/me/mojin
node src/cli.mjs get /v1/friends
node src/cli.mjs get '/v1/players?query=プレイヤー名'
node src/cli.mjs get '/v1/rankings?kind=survivor&limit=20'
node src/cli.mjs get '/v1/rankings?kind=survivor&character_id=14&limit=100'
node src/cli.mjs get '/v1/ugc/rankings?period=week&tag=1000'
node src/cli.mjs get '/v1/ugc/maps/1098305/rankings'
node src/cli.mjs get '/v1/ugc/play-history'
node src/cli.mjs get '/v1/chat/global?limit=20'
node src/cli.mjs get '/v1/recruitments?mode=normal&limit=20'
npm run disconnect
```

`/v1/me` の `player_id` を使い、`/v1/players/{player_id}/history?limit=20` で自分の戦績を取得できます。検索は連続要求によるサーバーの無応答を避けるため、5秒間隔で送信します。

## HTTP API

既定の接続先は `http://127.0.0.1:8787`。`/health` 以外には `Authorization: Bearer <API認証鍵>` が必要です。API認証鍵とゲームのSDKセッションは別です。

詳細な定義は認証付きの `GET /openapi.json`、ソースは [src/openapi.mjs](src/openapi.mjs) にあります。

| メソッド | パス | 内容 |
| --- | --- | --- |
| GET | `/health` | APIの稼働確認 |
| GET | `/v1/status` | 現在の接続、実接続確認、機能の検証状況 |
| POST | `/v1/session/connect` | 接続。任意のJSON `{"replace_existing":true}` で既存ログインから切り替え |
| POST | `/v1/session/disconnect` | 切断 |
| PUT | `/v1/session/credentials` | 完全なSDKセッションの暗号化保存。単独のトークンだけでは接続不可 |
| GET | `/v1/me` | 自分のID・プロフィール |
| GET | `/v1/me/mojin` | 手記の加筆の自分の現在／最高段位、累計・現シーズン・受信済み過去シーズンの探索統計。ログイン時のスナップショット。個別戦績は含まない |
| GET | `/v1/players?query=...` | ID・名前検索 |
| GET | `/v1/players/{id}` | プロフィール |
| GET | `/v1/players/{id}/history` | 戦績。`limit=1..100`、`cursor` に対応 |
| GET | `/v1/players/{id}/history/access` | 戦績の閲覧条件・非公開判定。戦績本体は返さない |
| GET | `/v1/players/{id}/badges/history` | キャラ別の過去徽章。受信後に過去徽章の公開設定を新しく取得して確認 |
| GET | `/v1/players/{id}/persona` | `character_id`で選んだキャラの現在の人格。受信後に最新の公開条件を確認し、元アイコン・名称・レベル・消費点を返す。非公開403・不明409 |
| GET | `/v1/players/{id}/presence` | 状態、公開されたサーバー時刻、観測時刻 |
| GET | `/v1/rankings` | `kind=survivor|hunter`、任意の`character_id`でキャラ別認知ランキング、`limit`、`cursor` |
| GET | `/v1/ugc/rankings` | ペン先の空想の週間・月間作品。`period=week|month`、`tag=1000`は全部、1〜14はゲーム内ジャンル |
| GET | `/v1/ugc/maps/{map_id}/rankings` | 公開作品IDの作品内ランキング。取得前後に`open_rank`を確認。順位・記録・公開参加者名とID・ゲーム内アイコン参照。非公開403、設定不明409 |
| GET | `/v1/ugc/play-history` | 自分がペン先の空想で遊んだ作品の履歴応答。現在のアカウントは空。勝敗・参加者付き戦績は未確認 |
| GET | `/v1/friends` | フレンド一覧 |
| GET | `/v1/chat/global` | 公開ルームの受信バッファ。`limit`、`cursor`、`channel` |
| GET | `/v1/recruitments` | `mode=normal|rank|custom`、`limit`、`cursor` |
| GET | `/v1/watches` | 状態を取得する対象 |
| PUT | `/v1/watches/{id}` | `{"notify":true}` で対象登録。最大100件 |
| DELETE | `/v1/watches/{id}` | 登録解除 |
| GET | `/v1/events` | 状態変化の保存履歴。`after`、`limit`、`player_id` |
| GET | `/v1/events/stream` | SSE通知。`Last-Event-ID` による再開 |
| POST | `/v1/devices` | APNsの `device_id`、`token`、`environment` を登録 |
| DELETE | `/v1/devices/{device_id}` | APNs登録解除 |

`/v1/status` の機能フラグは、そのプロセスで成功を確認した機能が `true` になります。再起動直後に未確認の機能は `false` です。

全体チャットは現在接続している公開ルームの受信分を最大500件保持します。初回は最新分、`cursor` 指定時はその続きです。切断中や過去すべてのメッセージを取得するものではありません。私信は返しません。

## 状態と通知

このPCでは確認したフレンド2件を取得対象に登録済みです。状態のプッシュ更新を処理し、30秒ごとにも再取得します。フレンド以外の登録対象は公開プロフィールを1回につき最大5件ずつ順番に確認します。人数・通信状況により確認間隔は延びます。

- `last_login_at` / `last_logout_at`：ゲームサーバーが公開した時刻。取得できない場合は `null`。
- `last_login_observed_at` / `last_logout_observed_at`：APIがオンライン・オフラインへの変化を観測した時刻。
- 初回取得をログイン扱いにはしません。通信切断をプレイヤーのログアウト扱いにもしません。
- 非表示状態は `unknown` とし、隠された実状態・内部ログアウト時刻を返しません。
- `fresh` はAPIとの接続状況と最終観測時刻から算出します。
- 非表示／表示のフラグが返る場合は、その切り替えも通知対象です。フラグが返らない場合の `visibility` は `unknown` とし、非表示を推測しません。

戦績の表示条件は「自分のアカウント」または「戦績応答の `show_battle_record` が明示的に `true`」です。`false` なら非公開、フラグ欠落・形式不明なら判定不明として戦績本体を返しません。他プレイヤーの戦績は要求ごとに権限を再確認し、以前の許可結果を再利用しません。非公開応答に戦績が含まれる場合も表示対象から除外します。

分析の `by_party_partner` は公開表示が許可された同一パーティーの相手、`by_teammate` は野良を含む同じチームの相手です。対戦回数と勝率を返します。相手陣営・BOT・公開ID不明の参加者を除外し、同じ試合と同じ相手の重複を除きます。勝率は勝利数÷勝利・引分・敗北数で、結果不明は分母から除きます。公開されていないパーティー関係は集計しません。内部パーティー識別子はAPIへ返さず、表示可能な本人との関係だけを使います。

過去徽章は `hide_history_badge` を独立して判定します。`field_access.history_badges` に `self` / `permitted` / `hidden` / `unknown` を返します。専用応答の受信後に他プレイヤーのプロフィールをキャッシュを使わず取得し、非公開・判定不明なら過去徽章を返しません。キャラごとの最高徽章・最高認知ポイント・等級別回数・日付と、ゲーム内の過去徽章専用画像を表示できます。

プロフィールは受信後に `setting_show_info` を確認し、統計・キャラクターデータ・バッジの非公開設定があるグループを返却対象から除外します。設定自体が取得できない場合も、他プレイヤーの該当グループを返しません。`field_access` に `self` / `permitted` / `hidden` / `unknown` を返すため、スマホ側で表示を分けられます。

状態変化はSQLiteへ保存し、SSEで配信します。APNs通知は端末ごとの永続キュー、再試行、無効トークンの削除を実装済みです。自動テストで確認しています。実際のiPhoneへの送信はApple側の設定がなく未検証です。

APNsを有効にする環境変数：

```text
APNS_KEY_ID
APNS_TEAM_ID
APNS_TOPIC
APNS_KEY_FILE
```

端末登録の `environment` は `sandbox` または `production`。未署名IPAをGitHub ActionsのmacOS/Xcodeで生成する構成です。実際のプッシュ通知には対応するアプリ署名とAPNs設定が必要です。

## スマホからの接続

開発中のソースは **0.1.26（ソースのビルド番号27・未ビルド）** です。PC用取得EXEと保存済みIPAは0.1.24です。新しい公開人格表示、星数、画面更新は次版ソースに含まれます。実APIの独立接続と他プレイヤーの公開情報取得は確認済みです。iPhoneの今回の変更はコンパイル・実機検証前です。

以前の **0.1.13（ビルド14）** では、次の機能を収録しました。戦績詳細の「行動記録」に両陣営の5項目を追加しました。プロフィール概要の「シーズン別の記録」から、受信した過去シーズンの段位・通常戦／ランク戦の対戦数を確認できます。通常ランク戦の戦績詳細から、対戦前後の段位と受信したポイント増減理由を確認できます。戦績詳細には本人・参加者の陣営別の得点内訳を追加しました。分析→「成績の推移」で直近10・20・50試合、連勝連敗、得点・判定取得分のMVP率、終了時刻の時間帯別成績を確認できます。`dist/IDV-unsigned.ipa` を手元のツールで署名して更新します。検索→ランキングに「段位／キャラ別」を追加し、陣営・キャラ選択、認知ポイント、公開状態、プロフィール移動に対応しました。アイコン・枠・キャラ画像はPCのAPIからゲーム内の元画像を読み込みます。

0.1.3では分析に「一緒に組んだ相手」を追加しました。「パーティー」と「同じチーム」を切り替え、相手別の回数・勝率・勝敗を回数順／勝率順で確認し、タップで相手のプロフィールへ移動できます。「徽章」タブでは現在／過去を切り替え、過去徽章をキャラ名・陣営で絞り込み、キャラごとの最高徽章・最高認知ポイント・S/A/B/Cの回数・最終獲得日を表示します。画面記録は `dist/iphone-se-party-analysis.png`、`dist/iphone16-historical-badges.png` 等です。

公開条件を確認できたプロフィールの対戦数・MVP回数・所持キャラ数・通常戦／ランク戦の集計を表示します。戦績には開始・終了日時、本人のキャラと得点、参加者の得点・MVP・試合当時の段位を追加しました。分析はモード別・マップ別・キャラ別の成績と平均対戦時間を表示します。非公開・判定不明のプロフィール統計は表示しません。チャット入力と戦績更新時の保持も引き続き検証しています。

API89テスト、iOS Core12テスト、iPhone SE（第3世代）・iPhone 16シミュレーターで計52回の画面テストが成功しました。画面テストはテスト用データで行い、実アカウントの数値・画像の取得確認はPCのAPIで別に実施しています。未署名・arm64・iPhone用バイナリ・リリースへのテスト用コード混入なしを検査済みです。実機へのインストールは未確認です。ビルド・ハッシュは `dist/release.json`、画面記録は `dist/iphone-se-character-ranking.png`、`dist/iphone16-match-details.png` 等に保存しています。ペン先の空想の作品ランキングと自分のプレイ履歴応答は、現時点ではAPIから利用できます。

0.1.3の生成後、稼働中のAPIにペン先の空想の作品内ランキングを追加しました。公開作品のチーム10組・個人1件のタイム記録と、非公開作品での403を実アカウントで確認済みです。この追加時点のAPIは55テスト成功。作品情報の再取得は5秒間隔とし、記録の取得後にも公開設定を確認します。タイムはゲームと同じ秒数から`分:秒.百分の一秒`で表示し、サーバーの順位を保持します。イベント系のスコア形式は静的処理と実装テストの確認にとどまり、実データでの取得は未確認です。この追加分のiPhone画面は未実装で、IPA 0.1.4にも含まれません。作品内の順位記録は、勝敗・参加者付きの全試合履歴を意味しません。

手記の加筆の自己情報は`GET /v1/me/mojin`で取得できます。ゲーム接続時の受信日時、現在・最高段位、総探索回数、探索成功率、累計詞章価値、平均探索時間を返します。受信した最高段位の記録からシーズンは特定できないため補いません。累計・現シーズン・過去シーズンを分け、未受信の値や矛盾した値は不明にします。自分の累計は2回・成功率50%・詞章価値18,600、S0に2回、S1に0回を実測しました。自己集計を追加した時点のAPIは60テスト成功。IPA 0.1.4（ビルド5）に、自分のプロフィールから開く探索情報画面を収録しました。2端末サイズの期間切替・未受信時の表示テストが成功し、画面記録は`dist/iphone-se-mojin-self.png`・`dist/iphone16-mojin-self.png`です。専用の公開ランキング要求は未応答です。自己戦績は1件の取得成功を確認しました。以前の「自己戦績要求がタイムアウト」は診断ログの処理名が更新されなかったための誤記で、実際のタイムアウト対象はその後のask_rank_dataでした。

ゲーム内の通常・差分日本語辞書から、キャラ112 ID・マップ105 ID・モード50 IDの名前を対応付けました。指定されたプレイヤー19806845の公開戦績200試合で名前の欠落がなく、モード別集計も確認済みです。「心の獣」「神童」を反映しています。報告されたマップID154はその200試合にも含まれず、推測による別名対応は追加していません。

`scripts/start-iphone-api.ps1` でLAN向けに起動できます。`node src/cli.mjs connection-info` でURLとAPI認証キーを `.private/iphone-connection.json` に保存します。iPhoneアプリの接続画面に入力してください。このファイルはGitHubへ送信しません。

`HOST` と `PORT` で待受先を指定でき、`TLS_CERT_FILE` と `TLS_KEY_FILE` の両方を指定するとHTTPSで起動します。スマホ側はAPI認証鍵をKeychainに保存し、ゲームのSDKセッションはPC側に置きます。接続情報が失効した場合は自分のゲームアカウントで再認証します。

CLIの接続先変更には `IDV_API_URL` を使います。独自CAを使う場合は `NODE_EXTRA_CA_CERTS` で公開CA証明書を指定できます。TLS証明書・端末への信頼設定・スマホ接続は未実施です。

## 保存と再認証

`.data/game-session.dpapi` と `.data/api-key.dpapi` はWindows CurrentUser DPAPIで暗号化して保存します。同じWindowsユーザーでのみ復号できます。認証情報はコマンドライン引数やAPI応答に出しません。

初回の認証情報は、許可された自分のPCゲームのセッションから取得しました。有効なセッションを保存した後はゲームを起動する必要がありません。セッションが失効した場合は、自分のゲームアカウントで再認証して情報を更新する必要があります。

通常の通信切断・要求タイムアウトからは、間隔を延ばしながら再接続します。再試行は5分間に最大5回です。自動接続では常に `replace_existing: false` を使い、ゲーム側のログインが確認された場合は停止します。明示的な切断も尊重します。切断理由・待機中の再接続は `/v1/status` の `session_recovery`、詳しいRPC名は暗号化した診断記録に保存します。接続が切り替わった場合、以前の接続で待機していた送信は自動で再送しません。

`.private/` と `.data/` は共有・公開しないローカル作業データです。`research/` は接続方式の調査用であり、API実行時の依存先ではありません。

## テスト

```powershell
npm test
```

151件成功（直近のAPI検証）：Bearer認証、SDK保存、フレームの分割・サイズ検査、暗号の既知ベクトル、数値キーを持つMessagePack、募集の汎用RPC、要求の直列化とタイムアウト、戦績・プロフィールの閲覧条件、状態・表示切り替えの記録、SSE再配信、APNs署名・再送キュー、徽章の公開条件と期限、戦績の集計、元画像の変換、チャットの送信重複・ルーム取り違え防止、自動接続・再接続の上限・他ログインの尊重・接続変更後の送信取り消しなど。iOS共通部分は14件で、保存済み0.1.24のビルドでは成功しました。今回変更したソースでは未実行です。UIテストはソース上48件。直前のビルドでは46件中3ケースが失敗し、2台目は未実行でした。GitHub上のSwiftで実行します。戦績更新の失敗時に前回分を保持し、公開許可が撤回された場合は消去する動作も含みます。チャットは小型・通常サイズのiPhoneシミュレーターで、100件の履歴・複数行入力・キーボード表示・下タブとの重なりをUIテストします。

APIサーバーを起動して自分のセッションで接続済みの場合、`node research/app-release-smoke.mjs` で読み取りだけのHTTP確認、`node research/verify-history-names.mjs` で戦績の反復取得と名前の欠落を確認できます。後者はプレイヤー名・IDを含まない検証結果を `dist/history-name-verification.json` に保存します。

<!-- source-refresh-2026-11-06:start -->
## 2026-11-06：他プレイヤーの人格・画面更新（次版ソース）

現在のソースは **0.1.25（ビルド26・未ビルド）**、保存済みIPAは **0.1.24（ビルド25）** です。直近のAPI検証は144件成功。今回の読み取り調査ではAPI・iPhoneの動作コードを変更していません。新しいIPA・EXEのビルドは、ユーザーの明示依頼まで行いません。

**iPhoneソースは0.1.25（26）、未ビルドです。** ユーザーの指示により、次に「ビルドして」と依頼されるまでIPA・EXEの新しいビルドは行いません。保存済みIPAは0.1.24（25）のままで、以下の新しい画面は含みません。PCのAPIソースと稼働確認、ネイティブ画面のソース実装、HTML配置プレビューを区別します。

| 追加・調査項目 | 確認できた内容 | 状態 |
| --- | --- | --- |
| ランキングからの他人の人格 | キャラごとの現在の選択ページ、人格名・レベル・元アイコン・消費人格点。19806845の曲芸師14項目・130点、21536583は15項目・130点。3595139は非公開403。 | 他人の実HTTP取得成功。iPhoneはソースのみ |
| 取得後の公開判定 | 通常のget_data_from_cacheで受信後、最新プロフィールのopen_talentを独立確認。非公開・不明は内容を返さず、相手違い・セッション変更も破棄。オフライン表示を理由に判定を省かない。 | 実取得＋拒否を確認、合成テスト済み |
| 人格の対象ページ | pid_to_geniusの通常ページ・キャラ別ページ。100〜10000の推奨ページは変換未確認のため未取得。試合当時の人格は対象外。 | 受信ページのみ。別ページで補わない |
| 元の人格素材 | ゲーム内80項目・144レベルの名称・説明・元PNG参照を追加。元画像の色や形は変更しない。 | 静的照合、元PNG読み込みと配置プレビュー確認 |
| 戦績の見やすさ | 屈強などの暗い元アイコンに明るい台紙。通常マップ132×80、探索マップ160×88。プロフィールと戦績の配置を整理し、既に受信していた参加者レベルを表示。 | ソース実装・配置プレビューのみ |
| ランキングの星数 | 七段以上は「★25」の形式、六段以下は「五段III」。星数未受信は未取得。 | ソース実装のみ |
| 観戦 | 原ゲームの世界描画と記録片の再生を利用する。通常の映像URLは未確認。映像を再生できないなら不要という指示で、観戦タブと仮の一覧APIを削除。 | 再生未対応・タブ削除済み（ソースのみ） |
| 他人の内部スコア | show_hide_scoreは他人のIDを渡さず、gm_show_hide_scoreのクライアント受信処理は空。サーバーの返答・通常権限・意味は未確認。 | 静的定義のみ確認。管理用要求は実行していない |
| 他人の全フレンド一覧 | 自分の一覧とは別。公開取得経路と閲覧条件は未確認。戦績の同伴者をフレンドと推定しない。 | 未確認 |

APIは144テスト成功。人格の追加UIテスト2件、変更したCore・画面テストは未実行です。人格画面は受信済みデータを更新開始時に消し、非公開へ変わった後に前回の人格を残しません。手記戦績の非公開エラーもキャッシュの表示を撤回します。

保存済み0.1.24のクラウドビルドは成功しましたが、iPhone SEのUI46ケース中3ケース（assertion失敗5件）が失敗しました。確認画像・AX階層では名称と値そのものはあり、親のaccessibilityIdentifierが子の識別子を上書きしていました。関連コンテナのソースは補完済みですが、再実行は次回ビルド時です。2台目のUI検証は最初の失敗で未実行。実機インストール・署名・APNs到達は未確認です。

IPA・EXE・検証ログをPCへ保存して受け渡した後、一時公開リポジトリmodule-kit-9246は、ユーザーのGitHub本人確認完了後に削除しました。最新のAPI・追加ソースや認証情報、抽出したゲームコードはそこへアップロードしていません。
<!-- source-refresh-2026-11-06:end -->

<!-- CAPABILITIES:START -->
## 取得情報一覧（2026-11-07T00:30:39.905Z）

[構造化した一覧](capabilities.json)を確認に合わせて更新します。実データでの成功、受信フィールド、テスト、静的な処理確認を区別します。静的確認は取得成功やアプリでの利用可能を意味しません。

| 情報 | 何の情報か | 確認状況 | 項目・取得条件 | 根拠 |
| --- | --- | --- | --- | --- |
| ゲーム画面を開かない独立ログイン | ゲーム画面を起動せず、PCのAPIからゲームサーバーに接続する。 | 実データで確認 | 保存した本人のSDKセッションが有効であること。以前の保存情報はSDK code=6で拒否されたが、2026-11-06に起動中の本人のゲームから新コードを取得・APIへ取り込み、PC版の通常終了後にreplace_existing=falseで独立ログインを再確認。自己プロフィール・フレンド9件・公開相手の新規HTTP取得に成功。PC版との同時ログインや既存ログインの置き換えは行っていない。有効期限と以前の認証拒否の正確な原因は未確認。 | GameSession.login → sdk_login_gas3 / on_login / Avatar。src/game/session.mjs、src/game/provider.mjs |
| 自分のID・名前・プロフィール | ログインした自分の名前、ID、プロフィール設定。 | 実データで確認 | ID、名前、アイコンID、アイコン枠ID、性別フィールド、いいね数、対戦数、MVP数、キャラクター数。ログインした自分のIDを対象に取得。公開表示と自己情報をprofileOfで区別。 | init_playerとask_player_cil_butcher_data / reply_cil_butcher_data、GET /v1/me。src/game/public-data.mjs のprofileOf |
| フレンド一覧 | ゲーム内で登録済みのフレンドと、その公開状態。 | 実データで確認 | ID、名前、アイコンID、枠ID、公開状態。実アカウントで2件取得 | notify_friends_info、request_friend_status_info / request_friend_status_info_cb。src/game/provider.mjs のgetFriends |
| IDでプロフィール検索 | 数字のプレイヤーIDからプロフィールの候補を取得する。 | 実データで確認 | 数字だけの検索語をsearch_uidに渡す。接続中のみ、検索は5秒間隔。 | search_uid / reply_friend_search。src/game/provider.mjs のsearchPlayers、GET /v1/players?query=数字ID |
| 名前でプロフィール検索 | プレイヤー名から候補を取得する。同名の場合は別人の可能性がある。 | 実データで確認 | 検索要求は5秒間隔。同名候補を返す場合あり | search_name / reply_friend_search。src/game/provider.mjs のsearchPlayersと5秒の送信間隔 |
| 他プレイヤーのプロフィール | 選んだ相手の個人資料。項目ごとに公開範囲が異なる。 | 実データで確認 | 取得後に公開設定を確認。統計・徽章の非公開または許可不明のグループは返さない | ask_player_cil_butcher_data / reply_cil_butcher_data、setting_show_infoのopen_char_data・hide_max_history_rank・hide_battle_page_info・hide_fre_used_role_info・hide_badge・hide_history_badge。src/game/public-data.mjs のprofileOf |
| 実際のゲーム内アイコン画像 | 相手がゲーム内で設定したプロフィール画像。 | 実データで確認 | 自分のface-8をAPI経由で読み込み確認 | プロフィールのface_id、src/game/presentation.mjs のappearance、GameAssets.image / GET /v1/assets/face-ID.png。元素材のMD5検証とPNG変換 |
| 実際のゲーム内アイコン枠画像 | 相手がゲーム内で設定したアイコン枠。 | 実データで確認 | frame-1をAPI経由で読み込み確認 | プロフィールのface_frame_id、src/game/presentation.mjs のappearance、GameAssets.image / GET /v1/assets/frame-ID.png。元素材のMD5検証とPNG変換 |
| ゲーム内素材のID対応表 | 画像やキャラ・マップのIDとゲーム内素材を結び付ける表。 | 実データで確認 | 3090素材の索引、332キャラクターID、290マップ場面ID。索引の件数。全画像を描画確認した件数ではない。手記の加筆の現設定・S0段位画像参照を追加し、rank-mojin-1のPNGを実読み込み確認。未対応画像形式は未取得扱い。 得点内訳の元画像8種類を追加してPNG読み込み確認。 戦績称号の元画像5種類を追加し、全5件のPNG読み込みと視認を確認。全索引画像の確認を意味しない。 手記の加筆のアイテム81ID（名前80件）を追加。選択した元画像2枚のみPNG読み込み・目視確認。全81素材や自己の所持・使用記録の取得確認ではない。 | research/build-app-catalog.mjs、src/game/assets.mjs のpublicCatalog / image、GET /v1/catalog。インストール済みゲーム内の設定・素材索引 |
| 両陣営の現在段位・段階・星・シーズン | サバイバーとハンターの今の段位。五段IIIの形式で表示する。 | 実データで確認 | 五段IIIの形式で表示。公開統計のみ | reply_cil_butcher_dataのcivilian_data / butcher_data、src/game/presentation.mjs のrankOf / presentProfile。part・part_lv・part_starと統計公開設定 |
| 最高段位と確認できたシーズン | 受信した範囲での自己最高段位。シーズンが特定できる場合は併記する。 | 実データで確認 | 過去データと最大記録から算出。シーズンが特定できない最大記録はシーズン未取得 最高段位のmax_part_record・season_max_part_recordは配列[4]の段位ポイントを星に変換するよう修正。[2]を星として扱わない。七段・星25の元画像への切り替えを実装テストで確認し、過去シーズン画面は自己受信データで照合。 | civilian_data / butcher_dataのmax_part_record・history_season_data・season_max_part_record、src/game/presentation.mjs のpeakOf。公開統計だけを集計 |
| プロフィールの過去シーズン情報 | プロフィールに含まれる過去シーズン別の記録段位・シーズン最高段位。全体ランキングの過去順位とは別。 | 実データで確認 | season_history.survivor / hunter[].season_id、recorded_rank / highest_rank: part / level / stars / label / asset。field_access.statisticsがselfまたはpermittedの場合だけ返す。自分のS35〜S43、両陣営各9件を確認。他の3プロフィールは統計がhiddenでseason_history=null、元の統計も非返却を確認。他人の許可された非空シーズン記録の実取得は今回未確認。受信した過去シーズンだけを対象とし、全期間を保証しない。現在のseason_idがある場合はそれ未満だけを並べ、新しい順に表示。highest_rankはseason_max_part_recordの第1・第2・第5要素から段位・段階・段位ポイントを読み、元のpart_star_scoreで星へ変換。第3要素を星として使わない。欠落時は未取得とし、現在段位で補わない。 | ask_player_cil_butcher_data / reply_cil_butcher_dataのcivilian_data / butcher_data.history_season_data、PartUtil.get_max_part_info（最高記録の配列[0],[1],[4]）、ゲームpart_data・part_icon。src/game/profile-seasons.mjs / presentation.mjs、ios/Sources/App/ProfileSeasonsView.swift |
| 通常対戦・ランクの集計フィールド | プロフィールに含まれる対戦数などの集計。個別試合の履歴とは別。 | 受信項目を確認 | 試合数、勝利数、敗北数、連勝・連敗関連、陣営別データ、キャラ別使用・戦績データ、経験点。項目によってモードや集計期間の意味は検証中。意味と公開条件が確認できた通常戦・ランク戦の対戦数／勝利数／敗北数はIPA 0.1.2で表示。未解析の集計は表示しない 通常戦・ランク戦のトップ階層の件数を現シーズン分と取り違えない。ゲームのget_now_season_cntはトップの累計からhistory_season_dataの合計を引く。現シーズン差分はprofile_current_season_countsとして追加確認・API表示。iPhoneの期間切り替えはソース実装のみ。 pid_cnt_allの常用キャラ選択はprofile_frequent_charactersで保存済み32キャラ分と原処理を追加照合。pid_data_rankのキャラ別成績・勝率は別のデータで、この使用回数から算出しない。 過去シーズンのpid_data_rankはprofile_season_character_rank_recordsで保存済み自己3キャラを追加照合。キャラ別の勝率は引分を除いた分母で、直近戦績の分析とは区別する。 | reply_cil_butcher_dataのcivilian_data / butcher_data、src/game/public-data.mjs のprofileOfによる統計公開判定、ios/Sources/App/ProfileDataViews.swift |
| 自分の過去戦績 | サーバーが返した自分の個別試合の履歴。全期間分とは限らない。 | 実データで確認 | 104件の受信・展開を確認。サーバーが返した範囲のみ。ページ分割対応 | request_self_battle_records / reply_request_self_battle_records、src/game/public-data.mjs のdecodeRecords、src/game/provider.mjs のfetchHistory |
| 他プレイヤーの戦績公開判定 | 相手が戦績を公開しているかの判定。未確認と非公開を分ける。 | 実データで確認 | 自分、またはshow_battle_recordが明示的にtrueの場合だけ返す。非公開403、判定不明409 | request_friend_battle_records / reply_request_friend_battle_recordsのshow_battle_record、src/game/history-access.mjs のhistoryAccess、test/api.test.mjs |
| 試合の基本情報 | いつ、どこで、どのモードを何分遊び、勝敗がどうなったか。 | 実データで確認 | 対戦ID、開始・終了時刻、対戦時間、マップID、モードID、勝利・引分・敗北、自分の陣営。閲覧が許可された戦績だけを展開・表示。モード・マップ名は対応が確認できたゲーム内設定を使用。 | battle_recordsのorigin_dataを展開したcommon_info・all_pl_info、src/game/public-data.mjs のdecodeRecords、src/game/presentation.mjs のpresentMatch |
| 試合参加者の情報 | 各試合に参加した人の表示名、使用キャラ、得点など。 | 受信項目を確認 | 公開プレイヤーID（応答にある場合）、プレイヤー名、使用キャラとゲーム内画像、アイコン・枠、陣営、得点、MVP・BOTフラグ、試合当時の段位。指定プレイヤーの公開戦績でunique_idとrank_infoを確認。ID受信時はプロフィールへ直接移動。内部entity IDをプロフィールIDに変換しない。 | request_friend_battle_records の公開許可された200試合、presentation.test.mjs |
| 詳細得点・行動記録など | 試合中の行動や詳細得点に関する生データ。全フィールドの意味は未解析。 | 受信項目を確認 | detail_score、action_recored、title_recored、res_type。detail_scoreのうち陣営別4項目は実データ・ゲームの表示処理・日本語名を照合し別項目で表示。action_recoredの両陣営5項目とtitle_recoredのサバイバー5称号は別項目で意味・表示を確認。res_typeはmatch_participant_resultsで個別結果の元表記を確認。残りの未解析データ・未知モードの意味は未確認。 追加受信確認：自己94試合570人分・公開対象100試合530人分でaction_recoredとtitle_recoredは辞書。非空は行動記録510/530人分、称号記録32/55人分。除外前の自分の戦績でcharacter_value_infoは延べ5人分（本人2・他参加者3）が非空。ori_character_value・dec_character_valueのキーを受信。過去の調査では公開対象は空だった。行動記録のうちゲームが表示する両陣営5項目はmatch_action_metricsとして照合・表示。その他の行動IDや旧新の内部補助キー、対象外モード・未知形式の称号には新しいラベルを付けない。character_value_infoは通報結果画面が参照する品性値の元データとして静的確認したが、実処分・一般公開条件は未確認なのでAPIから除外し、算出値も表示しない。 | 展開済みbattle_records内detail_score・action_recored・title_recored・res_type。src/game/public-data.mjs のdecodeRecords。意味の検証は受信確認と区別 |
| 取得した戦績の分析 | 取得できた試合だけを使う勝率、マップ別・キャラ別成績。 | 実データで確認 | 勝利・引分・敗北数、既知結果だけを分母にした勝率、平均試合時間、マップ別件数と勝率、キャラ別件数と勝率、モード別件数と勝率。サーバーから取得できた戦績だけを集計 | 閲覧を許可された戦績だけをsrc/game/presentation.mjs のanalyzeMatchesで集計。GET /v1/players/{id}/analysis、test/presentation.test.mjs |
| 公開パーティーの相手別回数・勝率 | 同じ公開パーティー識別子を持つ相手との対戦回数、勝利・引分・敗北・勝率。 | 実データで確認 | 相手の公開ID・名前・アイコン・枠、回数順・勝率順、相手別の勝利・引分・敗北・結果不明、勝率、最終対戦日時、集計対象の試合数。指定プレイヤーの公開戦績200件中、公開パーティーを確認できた80試合・相手13人。最多35試合、17勝8分10敗。team_uid一致とゲーム内のshow_team表示条件を確認。非表示・形式不明の関係は推測しない。IPA 0.1.3で表示し、iPhone SE・iPhone 16の画面テスト成功 | 公開戦績の実データ、PlayerInfoItemBase._update_team、GET /v1/players/{id}/analysis のby_party_partner、presentation.test.mjs |
| 現シーズンの全体ランキング | 現在のサバイバー・ハンターの段位ランキング。 | 実データで確認 | サバイバー上位100件、ハンター上位100件、順位、ID、名前、段位、星、アイコンID、枠ID。現シーズンについてサーバーが返した上位100件を確認。過去シーズンや全順位の取得成功を意味しない。 | ask_rank_data(show_tab=2, show_camp=rank_c / rank_b) / reply_rank_data。src/game/provider.mjs のgetRankings |
| ランキング掲載者の公開状態 | ランキングの相手が公開しているオンライン状態。 | 実データで確認 | 順位表のIDから公開プロフィールを取得し、状態を取得できることを確認。非表示は非表示、取得できない場合は不明。全員の状態が順位表に同時に含まれるわけではない | reply_rank_dataの公開ID→pollPresence / getProfile→presenceOf。src/game/provider.mjs、ios/Sources/App/RankingsView.swift のRankingPresenceModel |
| 過去シーズンの全体ランキング | 過去シーズンの全体順位表。過去段位のプロフィール情報とは別。 | 未確認 | 確認したask_rank_data要求にはシーズン引数なし。過去プロフィール情報と区別 | 現在確認できたsrc/game/provider.mjs のask_rank_data要求と、受信したプロフィールのhistory_season_dataを比較。過去順位表用RPCは未確認 |
| 募集一覧 | ゲーム内で募集しているチームと参加条件。 | 実データで確認 | 募集ID、募集主ID・名前、条件、モード、人数、期限。通常対戦で取得確認。ホームには表示しない | request_recruit_info_lst / request_recruit_info_lst_cb、server_client_gen_rpc_methodの読み取りコールバック。src/game/provider.mjs のgetRecruitments、src/game/session.mjs |
| 全体チャット受信 | 接続している全体・言語ルームの発言。 | 実データで確認 | 本文、発言者ID・名前、時刻、メッセージID、チャンネル、ルーム。接続中に受信した最大500件。切断中の全履歴は取得しない | request_enter_province_chatroom / reply_enter_province_chatroom、on_receive_region_chat_lst等の公開ルーム受信。src/game/provider.mjs のaddChats / getGlobalChat |
| 言語チャンネル一覧・切り替え | 全体チャットにある言語ルームのIDと表示名。 | 実データで確認 | 全体、中国語（繁体）、英語、日本語、タイ語、中国語（簡体）、韓国語、インドネシア語、マレー語、ベトナム語、スペイン語。ゲーム内設定で11種のIDと名称対応を確認。英語・日本語で実受信を確認。他の言語での受信は未確認 | ゲーム内チャットルーム・言語設定をresearch/build-app-catalog.mjsで照合したchat_rooms、GET /v1/chat/rooms。ルーム別の受信結果とは区別 |
| フレンドチャット取得 | フレンドとの個別チャット履歴。 | 実データで確認 | 取得要求の成功を確認。今回の実アカウント応答は0件。メッセージを含む表示は未検証 | fetch_friend_chat_info / reply_fetch_friend_chat_from_server、src/game/provider.mjs のgetFriendChat。フレンドの内部UIDで要求し公開IDと対応 |
| 全体・フレンドチャット送信 | 選択した言語ルームまたはフレンドへの発言要求。 | 実装・テスト済み | ゲーム内の送信処理に合わせて実装。重複送信防止・ルーム取り違え防止をテスト。iPhone SE・16シミュレーターで100件の模擬履歴、キーボード、複数行入力、送信ボタンを確認。実プレイヤーへの送信成功は未確認 | sendChatの自動テスト、GitHub Actions #8のChatLayoutTests（4実行、失敗0） |
| 現在の公開状態 | 相手が公開している現在の状態やログイン・ログアウト時刻。 | 実データで確認 | オンライン・オフライン、表示・非表示フラグ、公開ログイン時刻、公開ログアウト時刻。他プレイヤーはstate_info.stateが明示的な数値0・1・2の場合だけ公開状態の判定を進める。欠落・型不正・未知コードはstate=unknown / visibility=unknownとし、オンライン・対戦コードとサーバーのログイン／ログアウト時刻を返さない。非表示1はhide_showが配列で閲覧者IDを含む場合だけ例外とし、不正な例外リストで開示・例外停止しない。取り込み中2もbusy_showを配列として確認する。union_hide_show等の追加例外は実公開条件未検証のため採用しない。認証済み本人と同一のunique_idでは自己情報を維持するが、明示された非表示条件を一律に解除することはしない。キャッシュ済み状態でも公開不明／非表示なら状態とサーバー時刻を開示せず、最新の観測ログイン／ログアウト時刻も非返却にする。 | request_friend_status_info / request_friend_status_info_cb、notify_friend_on_off、notify_udpate_friend_info、公開プロフィール。state_info・online_stat・login_time・logout_timeをsrc/game/public-data.mjs のpresenceOfで判定。FriendLogic.get_friend_state / is_friend_hide / is_friend_busy、ComuKeys.PLAYER_STATE。src/store.mjs presenceDetails、src/notification-rules.mjs eventTypes |
| 状態コードの対応 | 対戦中、チーム参加中など、ゲーム内状態コードの意味。 | 処理・設定のみ確認 | 待機、対戦中、チーム参加、マッチング、予約、カスタムルーム、訪問、観戦、取り込み中。DEFAULT=0・HIDE=1・BUSY=2と、AVATAR_NOTICE_STATUSの1〜14の定数対応を静的確認。IDLE・TEAM・GAMING・TEAM_GAMING・MATCHING・TEAM_MATCHING・RESERVE・TEAM_RESERVE・CUSTOM_ROOM・CUSTOM_VISIT・CUSTOM_VISIT_OPEN・WATCHING・GAMING_FIREWORK・TEAM_WAIT。13のGAMING_FIREWORKはAPIでは単にオンラインとし通常の対戦中と同一視しない。全コードの実受信や実際の遷移を観測済みという意味ではない。 | ComuKeys.PLAYER_STATE / AVATAR_NOTICE_STATUS（patch 2a6aa19d9c8369e4c067fea7d2a0883b）、FriendLogicの状態・非表示・取り込み中判定。src/game/public-data.mjs presenceOf、.private/research/presence-state-enums.jsonl |
| 状態変化の履歴 | APIの接続中に観測した公開状態の変化。観測前の全履歴ではない。 | 実装・テスト済み | 前状態、新状態、観測時刻、表示設定の変化、観測したログイン・ログアウト時刻、鮮度。初回をログイン扱いにしない。APIの通信切断を相手のログアウト扱いにしない 公開範囲unknownを含む遷移からログイン・ログアウト・対戦開始終了を推定通知しない。hidden区間は既知の表示／非表示変更だけを通知条件にする。過去のイベント応答とSSEでもhidden／unknown区間の状態値はunknownとして返す。古い配信待ちイベントも送信時の通知条件再判定で除外する。 | src/monitor.mjs の観測処理、src/store.mjs のobserve / presenceDetails、test/api.test.mjs の初回・切断・表示設定変化テスト |
| 通知対象と通知条件の保存 | 誰の、どの状態変化を通知するかの設定。 | 実装・テスト済み | ログイン、ログアウト、対戦開始・終了、表示・非表示、チーム参加・退出、マッチング、観戦、取り込み中、その他公開状態。検索した相手で通知を有効にして追加。最大100件。フレンド以外は順番に公開プロフィールを確認 公開範囲unknownを含む遷移からログイン・ログアウト・対戦開始終了を推定通知しない。hidden区間は既知の表示／非表示変更だけを通知条件にする。過去のイベント応答とSSEでもhidden／unknown区間の状態値はunknownとして返す。古い配信待ちイベントも送信時の通知条件再判定で除外する。 | src/notification-rules.mjs のeventTypes / notificationRules、src/store.mjs の対象別設定・通知キュー、test/notification-rules.test.mjs |
| iPhoneバックグラウンド通知 | アプリを閉じている時にApple経由で届ける通知。 | 実装・テスト済み | APNs署名・キュー・再送処理の自動テスト済み。Apple側の設定・対応する署名がなく実通知は未確認 | src/apns.mjs のApns、src/store.mjs の暗号化デバイス・通知キュー、test/api.test.mjs の署名検証・再送・410処理。実配信は未確認 |
| 検索履歴からプロフィールを開く | 以前検索した相手を端末に残して再びプロフィールを開く機能。 | 実装・テスト済み | 端末に直近30人を重複なしで保存し、保存対象は名前・ID・画像IDだけ。検索履歴の並べ替えと遷移先をプレイヤーIDで分離し、プロフィールの最新取得成功後に履歴を一度だけ更新する。同じ先頭項目は再更新せず、画面表示時の履歴更新で取得タスクを繰り返さない。プロフィールは戦績を先読みせずに開き、失敗時は読み込みを終了して理由と再読み込みボタンを表示。別ID・古い要求の応答は採用しない。未署名IPA 0.1.8（ビルド9）に収録。iPhone SE・iPhone 16で履歴の並べ替え後の反復再表示とエラー後の再取得を含む各16件・計32件の画面テスト成功。画面はテスト用データ、実機は未確認。 | ios/Sources/App/SearchView.swiftのIDによるnavigationDestination、ProfileView.swiftの取得状態・要求ID確認・戦績の遅延取得、AppModel.rememberSearch、Core/SearchHistory.swiftの識別情報のみの安定した保存。ios/UITests/SearchHistoryTests.swift、ios/Tests/CoreTests.swift |
| 現在の徽章 | 今有効なキャラクター別のC・B・A・S徽章。 | 実装・テスト済み | カテゴリ50の等級・有効期限・公開条件を実装してテスト。実アカウントでは現在の徽章0件を確認。徽章を保有するプロフィールの画像表示は未検証 | time_limited_articleのカテゴリ50、setting_show_infoのhide_badge / hide_history_badge。src/game/public-data.mjs のprofileOf、src/game/presentation.mjs のpresentProfile、test/presentation.test.mjs |
| キャラ別の過去徽章 | 過去に獲得したキャラクター別の徽章情報。 | 実データで確認 | キャラ名・元のキャラ画像、最高徽章、ゲーム内の過去徽章用画像、最高認知ポイント、S/A/B/Cごとの獲得回数・最終獲得日。指定プレイヤーで9キャラ分を取得。受信後に新しいプロフィール応答からhide_history_badgeを再確認。非公開・判定不明なら返却しない。現在徽章の非公開設定とは独立して判定する。IPA 0.1.3で表示し、iPhone SE・iPhone 16の画面テスト成功 | ArticleLogic.get_history_badge / reply_get_history_badge、ShopLogic.reply_client_rpc、GET /v1/players/{id}/badges/history、ゲーム内のhistory_small_icon |
| マッチング開始・キャンセル | ゲーム内の対戦待ちを始める・取り消す要求。 | 処理・設定のみ確認 | request_match_game / cancel_match_gameを確認。サーバー受理・参加条件・成立後の接続は未確認。実マッチングは開始していない | ゲーム内処理のrequest_match_game / cancel_match_gameの静的確認。実行用HTTP APIは未追加、サーバー受理・成立条件は未確認 |
| API起動時のゲーム接続復元 | 保存した自分のセッションでAPI起動時にゲーム接続を復元する。 | 実データで確認 | 保存した自分の認証情報で起動時に接続。実際の自動接続とプロフィール・チャット取得を確認。手動切断した場合は停止を維持 保存済み認証のcode=6拒否を通信タイムアウトとして再試行し続ける問題を修正。現在はSDK_AUTH_REJECTEDで停止し、新しい自己SDKログインを待つ。新しい起動時ログイン成功は未確認。 | src/main.mjs のmonitor.restore、src/monitor.mjs の保存済み接続復元、test/session-recovery.test.mjs。replace_existingは自動指定しない |
| 通信切断時の再接続と切断理由 | 通信切断とログイン拒否を区別した復旧状況。SDK認証失敗の表示は期限切れやアカウント処分の判定ではない。 | 実装・テスト済み | 切断理由コード、タイムアウトしたRPC名、次回の再試行時刻、再接続の停止理由、session_recovery.login_failure.reason / server_code、last_error=SDK_AUTH_REJECTED / GAME_LOGIN_REJECTED / GAME_LOGIN_RESPONSE_INVALID。ネットワーク障害は5分間に最大5回。ゲーム側のログイン・手動切断を尊重し、自動でログインを置き換えない。古い接続の待機中メッセージは再送しない。ログイン拒否はネットワーク障害と区別して自動再試行しない。実受信した位置引数のon_login._[0]を読み、ゲームの定数に従い6をSDK認証失敗、7・8だけを成功応答とする。ただし7・8の応答だけでは接続成功とせずAvatar生成を必要とする。欠落・不正・曖昧な応答は未確認として停止。その他の拒否コードから独自の原因を推測しない。HTTP状態に出すのは固定reasonと整数server_codeだけで、元のmsg・extra・ban_code・SDK情報は返さない。自己のcode=6拒否と非再試行を実確認。SDK更新後の実復旧、ネットワーク障害からの実復旧は今回未確認。iPhoneのホーム・設定へ再ログインの案内をソース実装。新規共通2件・UI2件は未実行、ソース0.1.20ビルド21、最新IPA0.1.13ビルド14。 | src/game/session.mjs のGameSession.login / on_login、src/game/provider.mjs のlost、src/session-recovery.mjs、src/monitor.mjs、GET /v1/status。ClientBoot.on_login / handle_sauth_failed、ComuKeys.LOGIN_CODE。ios/Sources/Core/Models.swift・App/IDVViews.swift |
| キャラIDに対応するゲーム内日本語名 | 戦績、徽章、分析に使うキャラ番号を職業名へ変換する。 | 実データで確認 | 112件の名前対応、89＝曲芸師、154＝マイムアーティスト、155＝「心の獣」、157＝「神童」。最新の日本語差分辞書を反映。プレイヤー19806845の公開戦績200件でキャラ・マップ・モードの名前欠落なし。未収録IDは推測で命名しない。 | ゲーム内の通常・差分日本語TID辞書、player設定、公開戦績の読み取り照合 |
| マップIDに対応するゲーム内日本語名 | 戦績や分析のマップ番号をゲーム内のマップ名へ変換する。 | 実データで確認 | 105件の名前対応、54＝レオの思い出、81＝ホワイトサンド精神病院。プレイヤー19806845の公開戦績200件で名前欠落なし。場面ID83にも最新の日本語差分辞書を反映。 | ゲーム内の通常・差分日本語TID辞書、scene_config設定、公開戦績の照合 |
| モードIDに対応するゲーム内日本語名 | 通常戦以外のモードもゲーム内の名称で区別する。 | 実データで確認 | 50件の名前対応、ランク戦、協力狩り、カスタム・イベントの対応名称。自分の直近100試合でキャラ・マップ・モードすべての名前を解決できた。未収録のIDは推測で命名しない。IDごとの対応数であり異なる名称の総数とは限らない。 | インストール済みゲームの日本語TID辞書・player / scene_config / match_data設定 |
| 過去徽章の等級別獲得回数 | キャラごとにS・A・B・C徽章を獲得した回数。 | 実データで確認 | badge_info.S.num、badge_info.A.num、badge_info.B.num、badge_info.C.num。9キャラ分のbadge_info.<S/A/B/C>.numを受信。既知形式の等級欠落はゲーム内表示に合わせて0回、形式自体が未確認の場合は未取得。 | 過去徽章の実応答、UIHistoryBadgeDetail.update_view、presentation.test.mjs |
| 過去の最高徽章・最高認知ポイント | キャラクター別の徽章詳細画面で参照する自己最高値。 | 実データで確認 | highest_badge、hightest_rank_score（原データの綴り）。最高徽章highest_badge.gradeと最高認知ポイントhightest_rank_scoreを受信。例：「少女」A徽章・7335ポイント。最高値のシーズンは受信していないため推測しない。 | 過去徽章の実応答、UIHistoryBadgeDetail.update_view |
| 過去徽章の等級別最終獲得日 | キャラクターと徽章の等級ごとに、最後の獲得日として画面が参照する値。 | 実データで確認 | badge_info.<等級>.latest_date。等級別のlatest_dateをYYYY-MM-DD形式で受信。例：2025-06-16。日付に含まれない時刻やタイムゾーンを補わない。 | 過去徽章の実応答、UIHistoryBadgeDetail.update_view |
| キャラ別の現シーズン認知ランキング | 選択したキャラクターの認知ポイント順の公開ランキング。 | 実データで確認 | 順位、公開プレイヤーID、名前、アイコン・枠、認知ポイント。医師・復讐者で各100件を取得。iPhoneは検索→ランキング→キャラ別から陣営・キャラを選択。IPA 0.1.2で二つの画面サイズの切り替え・プロフィール移動画面テスト成功 | UICharRank.change_camp / FriendLogic.ask_char_rank_data → ask_rank_data(show_tab=2, show_camp=rank_PID)、reply_rank_data。GET /v1/rankings?character_id=ID&kind=survivor／hunter |
| ペン先の空想の週ランキング（作品） | 遊べる作品の週間ランキング。通常の段位ランキングとは別。 | 実データで確認 | 作品名・公開ID、作者名・作者ID、作者アイコン・枠、作品説明、作品カバー参照、プレイ数・プレイ人数、いいね・お気に入り数、ジャンル、作品内ランキング公開フラグ。Asiaで全部ジャンルの20作品を取得。現時点はAPIで利用可能。数値の意味が未検証の評価項目から独自の評価点を作らない。 | UGCLogic.get_ugc_rank_week_maps / UIUGCRank.get_data、GET /v1/ugc/rankings?period=week&tag=1000。モード名の根拠：TID_NAME_TYPE_UGC / TID_BATLLE_UGC_MODE（ペン先の空想モード）、TID_UGC_ROOM_CHOOSE_RANK_WEEKLY（週ランキング） |
| ペン先の空想の月ランキング（作品） | 遊べる作品の月間ランキング。 | 実データで確認 | 週間作品ランキングと同じ公開メタデータ。Asiaで全部ジャンルの50作品を取得。現時点はAPIで利用可能。 | UGCLogic.get_ugc_rank_month_maps、GET /v1/ugc/rankings?period=month&tag=1000。モード名の根拠：TID_NAME_TYPE_UGC / TID_BATLLE_UGC_MODE（ペン先の空想モード）、UIUGCRank.get_data、TID_UGC_ROOM_CHOOSE_RANK_MONTHLY（月ランキング） |
| ペン先の空想で自分が遊んだ作品の履歴 | 自分のプレイ記録専用の応答。勝敗付きの通常戦績と同一ではない。 | 受信項目を確認 | 自己スコープの応答。get_ugc_play_recordは成功応答だったが、現在のアカウントは空オブジェクト。履歴がある場合の中身・保持期間・勝敗や参加者の有無は未確認。他プレイヤーの履歴取得には使っていない。 | UGCLogic.get_ugc_play_record、GET /v1/ugc/play-history。モード名の根拠：TID_NAME_TYPE_UGC / TID_BATLLE_UGC_MODE（ペン先の空想モード） |
| ペン先の空想の作品内ランキング | 公開された作品ごとの個人・チームの順位と記録。作品の人気ランキングや全試合の詳細戦績とは別。 | 実データで確認 | 作品名・公開作品ID、順位（サーバーの返却順）、rank_type・rank_form・rank_title、タイム（秒数とゲームに合わせた表示）、公開参加者のID・名前・face_id・face_frame_id・face_vfx_id。Asiaの公開作品1098305でチーム10組・延べ参加者45件、1247210で個人1件のTIME_MINを取得。先頭の記録は54:41.98と01:38.63。作品1240857はopen_rank=falseのためランキングRPCを呼ばず403。作品情報は5秒間隔とし、順位取得後にも新しいopen_rankを確認。設定不明・応答不明・接続変更なら返却しない。現在は稼働中APIのみ。iPhone画面は未実装、配布済みIPAには未収録。TIME_MAX・EVENT_MAX・EVENT_MINの意味は静的確認、イベント形式の実取得は未確認。個人の展示設定を参照する別RPCは実行しない。 | UGCLogic.get_ugc_map_info / get_ugc_map_single_rank、UIUGCMapInfo.get_valid_tab / MapRank.update_rank_list / RankItemBase.set_text_time、ComuKeys.UGC_MAP_KEY(UUID=_id)・UGC_SINGLE_RANK_TYPE・UGC_SINGLE_RANK_FORM、UIUtils.get_time_str_with_ms。GET /v1/ugc/maps/{map_id}/rankings。モード名の根拠：TID_NAME_TYPE_UGC / TID_BATLLE_UGC_MODE（ペン先の空想モード） |
| ペン先の空想の勝敗・参加者付き詳細戦績 | 作品を遊んだ履歴と区別した、1試合ごとの詳細結果。 | 未確認 | 専用プレイ履歴の応答が空のため、勝敗・マップ・参加者を通常戦績のように取得できるか未確認。 | get_ugc_play_recordの空応答、UGCLogicの静的調査。モード名の根拠：TID_NAME_TYPE_UGC / TID_BATLLE_UGC_MODE（ペン先の空想モード） |
| 同じチームの相手別回数・勝率 | 同じ陣営で戦った相手との成績。野良の同じチームも含む。 | 実データで確認 | 相手の公開IDと表示情報、対戦回数、勝利・引分・敗北・結果不明、既知結果だけを分母にした勝率。通常・ランク・カスタム・協力狩り・五人ランクの確認できたモードを対象。200試合中143試合で相手を特定、154人を集計。相手側陣営・BOT・公開IDのない参加者を除外。同じ試合と同じ相手は重複計上しない。IPA 0.1.3で表示し、iPhone SE・iPhone 16の画面テスト成功 | GET /v1/players/{id}/analysis のby_teammate、公開戦績とpresentation.test.mjs |
| プロ選手・大会出場者の本人分類 | アカウントが本人のものと確認できた選手の所属・大会出場情報。 | 未確認 | 今回調べたプロフィール／名前表示／タグ／大会処理に、全員を判別できる共通フラグは未確認。応援・予測タグ、名前のチーム接頭辞、段位だけで分類しない。公式ロスターと本人確認済みゲームIDを対応させる方式を候補とする。 戦績で受信した「猛者対抗」「スーパープレー」等はポイントの加点理由で、プロ選手・大会参加の識別フラグとは扱わない。 | 個人資料・FriendLogic・EsportsLogic・tag_certificateの静的調査、公式ロスター例 https://zetadivision.com/news/2026/10/15/47905 |
| 作品内ランキングから参照する展示キャラ・衣装 | 個人形式の作品内ランキングで選んだ人の、プロフィール展示用キャラ・衣装・染色設定。現在使用中の装備や非公開の所持衣装一覧を意味しない。 | 処理・設定のみ確認 | setting_show_info.image_role.role、setting_show_info.image_role.cloth、setting_show_info.image_role.cloth_dyeing。MapRank.update_p_photoが展示設定を参照することを静的確認。チーム形式や結果画面ではモデル更新を行わない。値がない場合にゲームUIは既定キャラ・既定衣装を用いるが、取得済みの値として補完しない。get_ugc_map_single_rank_role_detailは今回実行しておらず、実受信・API・iPhone表示は未確認。 | UIUGCMapInfo.MapRank.refresh_p_photo / update_p_photo、UGCLogic.get_ugc_map_single_rank_role_detail（自己は自分のsetting_show_info、他人はuidを引数にした読み取り）。モード名の根拠：TID_NAME_TYPE_UGC / TID_BATLLE_UGC_MODE（ペン先の空想モード） |
| 手記の加筆のランキング | 手記の加筆モード内のプレイヤーランキング。ペン先の空想の作品ランキングとは別。 | 処理・設定のみ確認 | 段位ランキング（GOLDRUSH_PART=27）、詞章価値ランキング（GOLDRUSH_DELIVER_VALUE=28）、全サーバー／友達の切替処理、シーズンを含む順位表名。UIGoldRushRankListFrame.get_show_campとcommon_global_rank_name_by_idから、全サーバーはshow_tab=2・common_rank_1_group_27_season_1等を使うことを静的確認。自分の受信データでseason_id=1を確認したが、実際のask_rank_data要求は30秒以内に応答せず、順位表の取得成功は未確認。友達順位表も未取得。設定上のrank_show_num=100を実取得件数と扱わない。API・iPhoneの順位表は未実装。 | UIGoldRushRankListFrame.get_show_camp / refresh_ranking_data、ComuKeys.COMMON_GLOBAL_RANK_TYPE、cs_utils.common_global_rank_name_by_id / _get_rank_season_id、global_rank_dataの27・28（season_clear=2）。実要求の結果 .private/research/mojin-rank-request-timeout.json |
| 手記の加筆の自己個別戦績 | 専用の自己戦績RPCで返された、自分の探索結果と参加者。通常戦績・累計統計とは別。 | 実データで確認 | モード102・103、専用レベルIDとゲーム内マップ名・元画像、開始・終了日時、探索時間、参加者ID・名前・アイコン・枠・キャラ、職業と元画像、成功／失敗、詞章価値、生存時間。request_self_gold_rush_recordsで自分の1件を取得。モード102、災いの女、職業「智者」、失敗、探索時間43秒、生存時間約26秒、詞章価値0を実測。専用RPCのshared_dataを展開し、ゲームの結果定義Lose=1・Win=2を適用。先の「自己戦績要求がタイムアウト」は診断名の更新漏れによる誤記で、実際はその後のask_rank_dataがタイムアウト。自己戦績は既に保存されていた。サーバーが返した範囲のみで全期間の完全取得は未確認。 | GoldRushLogic.request_self_gold_rush_records、cs_utils._decompress_one_shared_record、GRDocDataMgr.format_record_for_list / get_map_name_by_level_id、GoldRushConst.GoldRushBattleResult、goldrush_map / goldrush_careerの日本語名。GET /v1/me/mojin/history、.private/research/mojin-history-verification.json |
| 手記の加筆の自分の段位・探索統計 | ゲーム接続時に受信した自分の段位、累計・現シーズン・受信済み過去シーズンの探索情報。 | 実データで確認 | 現段位・段位用の元画像・星、最高段位（シーズンは未取得）、S1-燐光症／S0-災いの女、総探索回数・探索成功率、累計詞章価値・平均探索時間、サバイバー／ハンター別の成功・失敗数、受信日時。自分のログイン時のgold_rush_common_data・gold_rush_data・gold_rush_butcher_dataから取得。S1で一段III・星0、累計2回中成功1回・成功率50%・詞章価値18600を確認。S0の値と累計を二重加算せず、現シーズンは累計から受信済み過去シーズンを差し引く。欠損や矛盾は不明として返す。APIは実アカウントで検証済み。IPA 0.1.4（ビルド5）に収録し、自分のプロフィール→手記の加筆から表示。iPhone SE・iPhone 16の画面テストはテスト用データで成功。実機インストールは未確認。 | init_playerの自己データ、GRDocDataMgr._build_rank_data / _build_max_rank_data、GoldRushPartUtil.get_rank_score_star、cs_utils_personal.get_gold_rush_career_stats / get_now_season_cnt、UIGRDocPageData._refresh_base_data、日本語TID_BATTLE_ADV_PERSONAL_DOCUMENT_DATA_1 / 2 / 5 / 6。GET /v1/me/mojin、test/mojin-data.test.mjs |
| 手記の加筆の個人データ・戦績などの表示設定 | 他人に見せる個人データ、戦績、展示詞章、武器洗練の非表示設定。 | 処理・設定のみ確認 | gr_hide_personal_data、gr_hide_battle_record、gr_hide_valuable_collect、gr_hide_weapon_refine。GRDocDataMgrに個別の判定があり、自分は自己情報として扱う。他人の設定値の実受信・公開条件の実照合は未確認。そのため他プレイヤーの手記の加筆データ取得・表示は未実装。 | ComuKeys.SETTING_SHOW_TYPE、GRDocDataMgr._get_setting_show_info / is_gr_hide_personal_data / is_gr_hide_battle_record / is_gr_hide_valuable_collect / is_gr_hide_weapon_refine |
| 手記の加筆のその他の自己受信項目 | ログイン時の自己データに含まれる追加項目。名前の印象だけで意味・期間を決めて表示しない。 | 受信項目を確認 | best_single_deliver_value、mega_gold_from_chest_count、max_win_streak・current_win_streak、weapon_kills、first_gold_item_timestamps・seen_monster_ids、display_magic_gold・display_skin_refine・display_relic。自己データのフィールド受信を確認。表示と期間の検証が終わった7つの加算項目は追加探索統計へ移動。max_win_streakは別項目mojin_season_streak_recordsで現S1=0・過去S0=1の読出と自己HTTP取得を確認。加減算はしない。累計の最長値としての意味とcurrent_win_streakは引き続き未確認。常用職業は自己HTTP取得・表示用の検証を終え、別の常用職業項目へ移動。得意武器は別項目mojin_favorite_weaponsへ追加調査。自己HTTPで3期間の空記録と設定の元画像2枚を確認。非空記録の実取得・全対象ID対応・実機表示は未確認。所持品一覧や他人の非公開情報の取得成功を意味しない。 展示枠・倉庫・専用図鑑の区別はmojin_document_display_slots / mojin_warehouse_slots / mojin_collection_guideへ追記。first_gold_item_timestamps・seen_monster_idsは保存時に空で、現行のgoldrush_collect_infoの代用とは未確認。 | init_player.gold_rush_common_data、cs_utils_personal.get_gold_rush_career_stats._scalar_top / _dict、goldrush_document_page_data_config、GRDocDataMgr。受信原本はローカルDPAPI保存のみ |
| 他プレイヤーの手記の加筆の個別戦績 | 相手の専用探索戦績。自己戦績の取得成功とは区別。 | 実データで確認 | request_friend_gold_rush_records(uid)、gr_hide_battle_record。専用RPCの相手ID・戦績の公開設定を取得前後に確認。新しい本人セッションから公開相手2人の戦績を各50件取得し、全100件の記録ID・元マップ名・モード名と計228参加者行を確認。別の相手は非公開403。mode=mojinのページ分割と分析HTTP200も確認。サーバーが返した範囲で、全過去戦績の完全性は未確認。iPhoneの新しい表示はソースのみ。 | src/game/mojin-public.mjs / mode-records.mjs、GRDocDataMgr.request_records / is_gr_hide_battle_record。 |
| ゲームモード別の戦績・組んだ相手の分析 | 選んだモードの戦績だけを表示し、勝率と組んだ相手の回数・勝率を再集計する。 | 実データで確認 | all／multi／rank／duo／mojin／custom／other、通常マルチ、通常・五人ランク、28、手記、カスタム、その他、カスタムは全てから除外、フィルター後のページ分割。自己：全て94件、マルチ65件、ランク9件、28が14件、手記1件、カスタム11件、その他5件。公開対象19806845：全て158件、ランク100件、マルチ49件、28が9件、カスタム42件。各フィルターで戦績の件数と分析件数が一致。全ての最多パーティー相手は35試合・勝率約48.57%。カスタム判定はゲームのis_customを使用し、訓練や協力狩り等のカスタム派生も除外。手記の追加は自分のみ。他人の手記は未確認。APIライブ確認・自動テスト済み。 | match_type_data.is_custom・match_mode_tid、src/game/match-modes.mjs / mode-records.mjs / presentation.mjs、GET /v1/players/{id}/history?mode=、analysis?mode=、.private/research/mode-filter-verification.json / public-mode-filter-verification.json、test/match-modes.test.mjs |
| 七段・星25以上のゲーム内段位アイコン | 通常段位の七段で星25以上の場合に、両陣営の専用の元画像へ切り替える。 | 実データで確認 | peek_part.peek_part_star=25、rank-survivor-peak、rank-hunter-peak、part_starの得点から表示上の星数への変換。ゲームのcheck_is_peek_partとpeek_partの切替条件を静的確認。現在段位のpart_starはpart_data.part_star_scoreで割り、最高段位の記録は格納済みの星数を使う。七段24星／25星の境界テスト成功。実際の全体ランキング先頭3件でも七段・星480／466／442の専用画像指定を確認し、両陣営の元画像をPNGとして読み込み確認。表示名は七段を維持する。手記の加筆の別の段位制度とは混同しない。 | cs_utils.check_is_peek_part / get_rank_score_star、DataManager.get_part_lv_data、peek_part・part_data、src/game/presentation.mjs.rankOf、.private/research/mode-filter-verification.json |
| ゲーム内アイコン枠の切り抜き素材 | 枠に専用マスクが設定されている場合、元の切り抜き画像をアイコン表示に使用する。 | 実データで確認 | face_frame.cut_mask、frame-mask-478／1066／1190／1215／1255／1256、avatar_masks対応表。6枠の設定と6件のPNG読み込み成功を確認。マスク中央の不透明領域・周囲の透明領域を実画像で確認。iPhoneは共通のAvatarArtworkでプロフィール・チャット・ランキング・戦績・分析に適用。元画像の余白に合わせて枠と背面アイコンの比率も修正。iPhone画面の検証・ビルド結果はリリース記録で別管理。 | face_frame.cut_mask、UIChangeFaceFrameNew.get_cut_mask / UIChangeFaceNew.init_ui、GET /v1/catalog.avatar_masks、src/game/assets.mjs、ios/Sources/App/DesignSystem.swift、.private/research/mode-filter-verification.json |
| iPhoneの名前コピー・チャット画像・戦績行のタップ | プロフィール名をコピーし、全体チャットに顔と枠を表示する。戦績と参加者は行全体から開ける。 | 実装・テスト済み | プロフィール名のコピーボタン、全体チャットのface_id・face_frame_id、共通AvatarArtworkと専用マスク、ゲームモード別の戦績・分析画面、戦績・参加者行全体のタップ。IPA 0.1.5（ビルド6）に収録。共通処理12テストとiPhone SE・iPhone 16の画面テスト各13件、計26件が成功。コピー完了表示、モード切替、矢印以外からの戦績詳細、探索戦績から参加者プロフィール、エラー時の非空扱いを確認。画面検証はテスト用データで行い、実ゲーム画像のAPI読み込みとは別。実機へのインストール・APNs配信は未確認。 | ios/Sources/App/ProfileView.swift・ChatViews.swift・DesignSystem.swift・MojinHistoryView.swift、ios/UITests/ProfileDataTests.swift・MojinSelfTests.swift、dist/release.json、dist/mode-qa-run15/build.log |
| 手記の加筆の自分の追加探索統計 | ゲーム接続時に受信した自分の追加統計を、累計・現シーズン・受信済み過去シーズン別に表示する。 | 実データで確認 | 異象累計撃破数（total_kill_monster_count）、配役探索者累計撃破数（total_kill_ai_survivor_count）、木の板を落とした回数（total_put_panel_count）、木の板を破壊した回数（total_break_panel_count）、エンディングクリア回数（total_kill_boss_count）、累計詞章解明数（total_bring_out_item_count）、累計移動距離（total_move_distance）。自分のinit_player.gold_rush_common_dataのみ。累計詞章解明数3、累計移動距離61 m、残り5項目は実受信値0を確認。0からの増加は未確認。加算項目の現シーズンは累計から過去シーズンを差し引き、欠損・矛盾はnullで返す。移動距離の整数表示と単位もゲーム設定に従う。他人の専用データ・所持品一覧には適用しない。未署名IPA 0.1.6（ビルド7）に収録。iPhone SE・iPhone 16の画面テスト各13件、計26件が成功。実機は未確認。 | init_player.gold_rush_common_data / history_season_data、cs_utils_personal.get_gold_rush_career_stats._scalar / get_now_season_cnt、goldrush_document_page_data_config（9220883ada1788ae60a536203923c327）、UIGRDocPageData.NormalDataItem.update_data、日本語TID_GOLD_IDCARD_PAGE2_DATA_3〜7 / 10 / 13・TID_OPENDATA_MI。GET /v1/me/mojin → statistics[].additional_statistics |
| 手記の加筆の自分の常用職業 | 職業別の使用回数から選ぶ上位2職業。職業別の勝利数や勝率ではない。累計・現シーズン・受信済み過去シーズンで切り替える。 | 実データで確認 | frequent_careers.label・status、items[].career_id・name・asset・use_count、累計／現シーズン／過去の区別。自分のinit_player.gold_rush_common_data.career_usageとhistory_season_dataのみ。累計・S0は智者2回、現シーズンは累計からS0を差し引いた結果が0で空配列になることを実確認。智者のゲーム内元画像もHTTP取得成功。他職業の非ゼロ値は未確認。上位2職業を回数降順で返し、同数はID順を使用するがゲームと完全に同じ同数順序は未確認。未受信・非整数・負数・過去が累計を超える矛盾を使用なしと混同しない。未対応IDの名前・画像は推測せずnull。相手IDを受け取るAPIは作らず自己情報だけに適用。未署名IPA 0.1.7（ビルド8）に収録。共通処理12テスト、iPhone SE・iPhone 16の画面テスト各14件、計28件成功。画面はテスト用データ、実機は未確認。 | init_player.gold_rush_common_data.career_usage、cs_utils_personal.get_gold_rush_career_stats._dict / _get_season_dict_cnt、GRDocDataMgr.get_top_careers / get_career_icon、goldrush_document_page_data_config・TID_GOLD_IDCARD_PAGE2_DATA_8、goldrush_career（23304517a005f602ad26c6f70b8a4a04）。GET /v1/me/mojin → statistics[].frequent_careers |
| 直近10・20・50試合の成績 | 終了日時で並べた受信戦績のうち、選択した件数の勝敗・引分・勝率。 | 実データで確認 | recent.requested_matches / total、recent.win / draw / loss / unknown、recent.known_results / win_rate、chronology.status。自己の全て94件・マルチ65件・カスタム11件と、公開対象19806845の全て158件でHTTP取得・集計を確認。元の自己マルチ戦績65件のMVP・得点と照合。取得件数は確認時点の値。通常戦績の公開条件を再確認し、非公開・判定不明は集計を返さない。全てからカスタム戦を除外。サーバーが返した範囲の計算であり、全期間の公式記録ではない。指定件数に満たない場合は実件数を表示。勝率の分母は結果判明試合で引分を含め、不明は除外。日時欠落や同時刻の曖昧さがある場合は直近順を作らず未確認にする。 | request_self_battle_records / request_friend_battle_records と自己のみ request_self_gold_rush_records → modeRecords → matchInsights。src/game/match-insights.mjs、GET /v1/players/{id}/analysis、test/match-insights.test.mjs、test/api.test.mjs、.private/research/match-insights-verification.json |
| 取得範囲の連勝・連敗 | 選択モードの受信戦績で、直近の継続と取得範囲内の最長連勝・連敗を計算。 | 実データで確認 | streaks.current.kind / count、streaks.longest_win / longest_loss、streaks.scope。自己の全て94件・マルチ65件・カスタム11件と、公開対象19806845の全て158件でHTTP取得・集計を確認。元の自己マルチ戦績65件のMVP・得点と照合。取得件数は確認時点の値。通常戦績の公開条件を再確認し、非公開・判定不明は集計を返さない。全てからカスタム戦を除外。サーバーが返した範囲の計算であり、全期間の公式記録ではない。引分・結果不明で継続を区切る。日時が欠けるか並び順が曖昧なら算出しない。試合なし・結果判明0件の最長記録も未確認にする。取得範囲より前の継続は不明。手記のみの表示では連続成功・失敗と表記。 | request_self_battle_records / request_friend_battle_records と自己のみ request_self_gold_rush_records → modeRecords → matchInsights。src/game/match-insights.mjs、GET /v1/players/{id}/analysis、test/match-insights.test.mjs、test/api.test.mjs、.private/research/match-insights-verification.json |
| 戦績内の本人の平均得点・MVP率 | 取得できた本人の得点と明示されたMVP判定から計算。 | 実データで確認 | self_performance.average_score / scored_matches、self_performance.mvp_count / mvp_known_matches / mvp_unknown_matches / mvp_rate。自己の全て94件・マルチ65件・カスタム11件と、公開対象19806845の全て158件でHTTP取得・集計を確認。元の自己マルチ戦績65件のMVP・得点と照合。取得件数は確認時点の値。通常戦績の公開条件を再確認し、非公開・判定不明は集計を返さない。全てからカスタム戦を除外。サーバーが返した範囲の計算であり、全期間の公式記録ではない。得点は有限の非負数のみを集計し0も含む。MVPは明示的なtrue/falseだけを分母にし、項目欠落をfalseに変換しない。自己の全ては判定59件・未取得35件、公開対象は判定26件・未取得132件。MVP率は判定取得分に限り、全試合の率とはしない。手記の詞章価値を通常得点に置き換えない。 | request_self_battle_records / request_friend_battle_records と自己のみ request_self_gold_rush_records → modeRecords → matchInsights。src/game/match-insights.mjs、GET /v1/players/{id}/analysis、test/match-insights.test.mjs、test/api.test.mjs、.private/research/match-insights-verification.json |
| 時間帯別の成績 | 試合終了時刻を指定タイムゾーンに変換して、時台ごとの試合数・勝敗・引分・勝率を計算。 | 実データで確認 | hourly.time_zone / timestamp_basis、hourly.items.hour / total / win / draw / loss / unknown / win_rate、hourly.dated_matches / undated_matches。自己の全て94件・マルチ65件・カスタム11件と、公開対象19806845の全て158件でHTTP取得・集計を確認。元の自己マルチ戦績65件のMVP・得点と照合。取得件数は確認時点の値。通常戦績の公開条件を再確認し、非公開・判定不明は集計を返さない。全てからカスタム戦を除外。サーバーが返した範囲の計算であり、全期間の公式記録ではない。APIはtimezoneにIANA名を指定（既定Asia/Tokyo）、iPhoneは端末のタイムゾーンを送信し画面に表記。開始時刻の集計ではない。日時欠落は時間帯集計から除外し件数を表示。夏時間の同じ時台は合算する。 | request_self_battle_records / request_friend_battle_records と自己のみ request_self_gold_rush_records → modeRecords → matchInsights。src/game/match-insights.mjs、GET /v1/players/{id}/analysis、test/match-insights.test.mjs、test/api.test.mjs、.private/research/match-insights-verification.json |
| 戦績の陣営別4項目の得点内訳 | 試合参加者のdetail_scoreを、その陣営のゲーム内の項目名で表示する。 | 実データで確認 | summary.players[].score_breakdown[].category_id / label / value / value_source、サバイバー：冷静・執着・友好・勇敢、ハンター：屈強・鋭敏・威嚇・狡猾。自己の全て94試合・公開対象19806845の先頭100試合で延べ1,040人分の内訳を取得し、4項目の合計とtotal_scoreの一致を確認。公開対象は計158試合中の100試合で全件ではない。実取得のモードは1・2・8・100、通常カスタム4は共通表示処理の静的確認と実装テストのみ。対応を確認していないモード・陣営は項目名を付けない。自己カスタム11試合はモード61・69で、この内訳は表示しない。既存の戦績閲覧権限を継承し、非公開・判定不明は戦績も内訳も返さない。受信済みの疎な辞書で省略された項目はゲームのget(category,0)と同じ0としvalue_sourceで区別。内訳全体の未受信・不正形式を4項目の0にしない。不正な値はnull。最大得点や割合は推測しない。 | request_self_battle_records / request_friend_battle_records の閲覧可能なall_pl_info.detail_score。UIDocumentRecord.pyのCIVILIAN_SCORE_CONF / BUTCHER_SCORE_CONF / show_detail_score、BattleRecordItemBase._update_battle_total_scoreの1〜4・省略時0。日本語TEXT_*はall_tid_jp_*.pyから照合。src/game/match-scores.mjs、presentation.mjs、ios/Sources/App/ProfileDataViews.swift |
| 得点内訳のゲーム内アイコン8種類 | サバイバー・ハンターそれぞれ4項目に対応する元のゲーム内画像。 | 実データで確認 | match-score-survivor-1〜4、match-score-hunter-1〜4。UIDocumentRecord.pyの各項目のiconパスから元の画像を索引し、8件とも素材MD5照合・PNG読み込み成功。独自画像への置き換えなし。サバイバーの冷静とハンターの威嚇は画像も視認。全8件を実機で描画確認したという意味ではない。 | CIVILIAN_SCORE_CONF / BUTCHER_SCORE_CONFのsystem/friend/ico_*画像、research/build-app-catalog.mjs、GameAssets.image、.private/research/match-score-verification.jsonのMD5 / SHA256 |
| 通常ランク戦の対戦前後の段位 | 各試合のold_rank・now_rankをゲームの段位表・元画像で表示する。 | 実データで確認 | summary.players[].rank_change.before / after、part / level / stars / label / asset。通常ランク戦（モード2）のみ。自己9試合で29人分・公開対象19806845の100試合中の通常85試合で425人分、延べ454人分を確認。公開100試合中のモード10は15試合で、入れ子の参加者対応は未確認のため表示を追加しない。part_change_infoのキーと参加者unique_idを一致させ、unit_typeも一致する場合だけ表示。内部entity ID・名前から対応を推測しない。BOTの専用補正は未確認のため、BOTフラグtrueや公開IDが0のものを対象外とする。既存の戦績公開判定を継承し、非公開・判定不明なら内訳も返さない。前後の段位・段階が変わった26人分も確認。シーズンを受信していない場合は付け足さない。星はゲームのpart_star_scoreで変換し、単純なpart_star差を総増減と呼ばない。 対戦前後の表示に必要な元の段位画像11種類をAPIでPNG読み込み確認。 | request_self_battle_records / request_friend_battle_records のpart_change_info.<unique_id>.old_rank / now_rank、UIDocumentRecordDetailLadder._handle_pl_infoのunique_idによる対応、rankOfとゲーム段位設定。src/game/rank-changes.mjs / presentation.mjs、ios/Sources/App/RankChangeView.swift |
| 通常ランク戦の段位ポイント増減理由 | 勝利・失敗・ガード・演繹順位・連勝・ソロプレイ等、受信した加点・減点理由を元の日本語名で表示する。 | 実データで確認 | summary.players[].rank_change.details[].reason_key / label / points、details_received / unlabelled_reasons / invalid_reasons。通常ランク戦（モード2）のみ。自己9試合で29人分・公開対象19806845の100試合中の通常85試合で425人分、延べ454人分を確認。公開100試合中のモード10は15試合で、入れ子の参加者対応は未確認のため表示を追加しない。part_change_infoのキーと参加者unique_idを一致させ、unit_typeも一致する場合だけ表示。内部entity ID・名前から対応を推測しない。BOTの専用補正は未確認のため、BOTフラグtrueや公開IDが0のものを対象外とする。既存の戦績公開判定を継承し、非公開・判定不明なら内訳も返さない。受信値と照合した表示理由は1407行。演繹順位の配列は1要素目が点数、2要素目に1を加えて順位名を埋める。ゲームと同じく配列の0点と通常のスカラー0点は省略し、TID_DES_DRAW・TID_DES_INTERGRAL_BADBEAHVIORのスカラー0点は保持。未受信の理由を0点として作らず、名前・形式不明のものは件数を返す。増減総計や保護カード補正を再構成しない。 | part_change_info.<unique_id>.score_detail、PlayerInfoItemBase.get_rank_score_info、RankScoreDetail.show_rank_score_detail、all_tid_jpの日本語TID。research/build-app-catalog.mjs、src/game/rank-changes.mjs、test/rank-changes.test.mjs |
| 昇段をまたぐ総増減・保護カード補正 | ゲーム内で前後の段位データから増減を求め、条件によって保護カード分を補正する表示処理。 | 処理・設定のみ確認 | utils.get_old_new_change、part_change_info.old_rank / now_rank、get_protection_card_score / protection_card_use_record。UIからget_old_new_changeを呼ぶことと保護カード補正の分岐を静的に確認。昇段・降段をまたぐ総増減の変換式、現在の自己ログインに依存する補正データ、過去試合への適用条件は未確認。part_starの単純差やscore_detailの合計を確定した総増減としてAPI・iPhoneへ表示しない。 | BattleRecordItemBase._update_battle_rank_score、PlayerInfoItemMain.get_rank_score_from_rank_change、PlayerInfoItemBase.get_rank_overflow_score、BattleRecordUtils.get_protection_card_score。呼び出し側の静的確認のみ |
| 過去シーズンの陣営別・通常戦／ランク戦の集計 | プロフィールの各過去シーズンに保存された通常戦・ランク戦の対戦数、勝利数、敗北数。個別戦績から再集計した値とは別。 | 実データで確認 | season_history.survivor / hunter[].statistics[].mode / label / total / wins / losses / consistent。field_access.statisticsがselfまたはpermittedの場合だけ返す。自分のS35〜S43、両陣営各9件を確認。他の3プロフィールは統計がhiddenでseason_history=null、元の統計も非返却を確認。他人の許可された非空シーズン記録の実取得は今回未確認。受信した過去シーズンだけを対象とし、全期間を保証しない。自己の18件で108個の件数値を受信元と照合。未受信を0にせず、負数・非整数・勝敗数が対戦数を超える値は未取得。引分や勝率を未確認の差から補わず、b_normal等の別モードを混ぜない。 | history_season_data.<season>.normal_battle_cnt / normal_battle_win_cnt / normal_battle_lose_cnt、rank_battle_cnt / rank_battle_win_cnt / rank_battle_lose_cnt。cs_utils_personal.match_type_2_cnt_key_prefix・get_battle_cnt_by_match_type_and_role・get_now_season_cnt、UIDocumentBattle.PlayerLabel。src/game/profile-seasons.mjs / test/profile-seasons.test.mjs |
| 戦績の陣営別5項目の行動記録 | 各試合の参加者について、ゲームの戦績画面が読む行動記録を元の日本語名と単位で表示する。 | 実データで確認 | summary.players[].action_details.status / items[]、action_id / record_key / label / value / unit / display_value / value_source。自己の全て94試合と公開対象19806845の先頭100試合で延べ1040人分・3156個の値を受信元と照合。解読進捗・板命中・援助・治療・ハンターへの牽制、残り暗号機・板の破壊・サバイバーに命中・恐怖の一撃・ダウンさせるの10名称。実取得の表示モードは1・2・8・100。通常カスタム4、28のカスタム9・101は共通表示処理の静的確認と実装テストまで。自己カスタム11試合（61・69）と手記等の未確認モード、入れ子のモード10は対象外。解読進捗は1ではなく+1キーを読み、100%を超える値を保持。牽制は12キーを読み、TEASE-self等から推測して補わない。%と秒はゲームと同じ整数化、その他は受信数値を保持。未取得2044項目と明示的な0を区別。内訳全体が空・未受信なら未取得表示。既存の戦績公開判定を継承し、非公開・判定不明なら返さない。 | request_self_battle_records / request_friend_battle_recordsのall_pl_info[].action_recored。ComuKeys.CIVILIAN_BATTLE_RESULT_ACTION / BUTCHER_BATTLE_RESULT_ACTIONと各SCORE_ACTIONの定数、BattleRecordUtils.CIVILIAN_RESULT_ACTION_NAME / BUTCHER_RESULT_ACTION_NAMEのTID順序、all_tid_jp。PlayerInfoItemBase.set_result_actionの+付き解読キー・%・秒の表示処理。PlayerInfoItemMainとPlayerInfoItemMBCarnivalの継承。src/game/match-actions.mjs / presentation.mjs、ios/Sources/App/MatchActionsView.swift |
| 戦績のサバイバー称号5種類 | 各試合のサバイバーに記録された解読・地形・援助・医療・牽制マスターの称号。プロフィールの徽章とは別の情報。 | 実データで確認 | summary.players[].action_details.titles_status / titles[] / unverified_title_records、id / action_id / label / description / asset / received_condition_value。自己94試合・公開対象の先頭100試合で延べ87人分の96個の称号を受信元と照合。5種類すべて実受信。元の日本語名・説明・画像5枚を使用し、PNG各124×124の読み込み・SHA256・視認を確認。実取得モード1・2・8・100。4・9・101は共通表示経路の静的確認とAPIテストまで。10の入れ子や手記等の別モード、ハンターの称号は対象外。title_recoredの行動キー1・20・7・8・12を対応させ、原設定と一致する有限数値300・3・3・3・180だけを表示。行動数値だけから付与しない。ゲーム本体は該当キーが非nullなら強調・画像を表示するが、このAPIは未確認形式を避けるため受信数値と原設定の一致も必要。空辞書は称号なし、記録欠落は未取得、未知キー・不一致は未確認件数として区別。既存の戦績公開判定を継承し非公開・判定不明なら返さない。 | request_self_battle_records / request_friend_battle_recordsのall_pl_info[].title_recored。combat_performance_dataのtitle_tid / title_desc_tid / title_ico / title_condition、all_tid_jp。ComuKeys.CIVILIAN_BATTLE_RESULT_ACTION_2_CONFIG_ID（1→1、20→2、7→3、8→4、12→5）。PlayerInfoItemBase.set_result_actionとMain / MBCarnivalの継承。src/game/match-titles.mjs / match-actions.mjs、ios/Sources/App/MatchActionsView.swift |
| 現シーズンの陣営別・通常戦／ランク戦の集計 | プロフィールの累計から受信した過去シーズン分を引いた、現シーズンの対戦数・勝利数・敗北数。直近の個別戦績の再集計とは別。 | 実データで確認 | current_season_statistics.survivor / hunter.season_id / history_seasons_count / calculation、statistics[].mode / label / total / wins / losses / consistent。自分のS44、両陣営の通常戦・ランク戦で12個の件数を受信元と照合。各陣営の保存された過去9シーズン（S35〜S43）を減算。例：ハンター通常戦は累計52−過去47＝5試合、勝利49−45＝4、敗北2−2＝0。新しいゲームRPC項目の受信成功ではなく、既存の受信データにゲーム内の算出方式を適用したAPI結果の実確認。field_access.statisticsがself / permittedの場合だけ返す。他の3プロフィールはhiddenで正規化結果null・元の統計も非返却を確認。他人の許可された非空データは未確認。season_id、累計、過去辞書または必要な過去件数が欠落した項目は未取得。ゲームのget(key,0)と異なり欠落を0扱いしない。明示的な空の過去辞書は過去合計0として扱う。現在・未来・不明IDや不正な行を含む過去辞書、負差分・非整数・安全な整数範囲外を拒否し、勝敗数が対戦数を超える組は全3件未取得。明示的な0は保持。通常戦・ランク戦以外のモード、引分、勝率、完全な全期間履歴を意味しない。 | ask_player_cil_butcher_data / reply_cil_butcher_dataのcivilian_data / butcher_data、normal_battle_cnt / normal_battle_win_cnt / normal_battle_lose_cnt、rank_battle_cnt / rank_battle_win_cnt / rank_battle_lose_cnt、history_season_data。cs_utils_personal.match_type_2_cnt_key_prefix（NORMAL→normal、RANK→rank、MB_NORMAL→b_normal）、get_battle_cnt_by_match_type_and_roleのcur_season分岐、get_now_season_cntの累計−過去合計。src/game/current-season.mjs / presentation.mjs、ios/Sources/App/ProfileDataViews.swift |
| 戦績の参加者ごとの個別結果 | 各参加者のres_typeをゲームの個別結果用日本語表記に対応させる。チーム全体の勝敗や個人の得点から推測した結果とは別。 | 実データで確認 | summary.players[].participant_result.status / code / label / label_key。自己94試合と公開対象の先頭100試合で延べ1040人分、コード1・2・4・5・6・7・8・9・10と日本語5表記（行方不明・脱出・完全勝利・完全敗北・辛勝）を受信元と照合。固有のプレイヤー人数ではない。実取得モード1・2・8・100。4・9・101はMain / MBCarnivalの共通処理の静的確認とAPIテストまで。モード10の入れ子・手記等・サバイバー／ハンター以外の陣営は正規化対象外。ゲームが同じ脱出や行方不明にまとめるコードはそのまま同じ日本語名にし、出口の種類や脱落原因を独自の表示名で区別しない。コード0「ゲーム中…」と3「途中退出」は設定・処理とテストまでで、今回対象モードで実受信していない。is_free_exitは全対象でfalseを実受信。true等の場合にゲームが使うBTN_QUITの表示は結果としての意味未確認のため表示しない。コード・フラグ欠落は未取得、未知・不正なコードや未確認のフリー退出条件は未確認として区別。既存の新しい戦績公開判定を継承し、非公開・判定不明なら結果を含む戦績を返さない。 | request_self_battle_records / request_friend_battle_recordsのall_pl_info[].res_type / is_free_exit。ComuKeys.RES_TYPE、BattleRecordUtils.RES_TXT、all_tid_jp、PlayerInfoItemBase._update_result_personal。src/game/participant-results.mjs / presentation.mjs、ios/Sources/App/ProfileDataViews.swift |
| 手記の加筆の自己得意武器（空の記録を実確認） | 自己のweapon_kills辞書を期間別に整理し、数値が多い上位2種類のアイテムをゲームの「得意武器」として表示する。今回の自己記録は空で、非空の実取得は未確認。 | 実データで確認 | statistics[].favorite_weapons.label / status / items[]、items[].item_id / name / asset / recorded_count。自己ログイン時スナップショットのみ。累計・現シーズンS1・過去S0の3期間でavailableと空配列をHTTPで実確認。非空の武器記録、数値の撃破対象・単位、他人の専用データは実確認していない。現シーズンは累計辞書から受信済み過去辞書をID別に減算し、正の数値が大きい2種類まで。0を含む辞書の画面をゲームと完全一致とする意味ではない。同数はアプリ側の数値ID順で、ゲームの同数順は未確認。欠落・形式不正・過去が累計を超える矛盾を空と混同しない。未知IDの名前と画像はnullとし、独自の画像・推測名で埋めない。アイテム設定81ID（名前80件）を索引し、庇護者の杖・燃える怨恨の元画像2枚をPNG取得・目視確認。ただし、この2種類を自己記録で受信したことや、索引の全IDが武器であることを意味しない。画面は元の名前・画像だけで、数値へ未確認の単位を付けない。所持武器・装備・現在使用武器の一覧ではない。相手IDを受け取る機能は追加しない。 | init_player.gold_rush_common_data.weapon_kills / history_season_data。cs_utils_personal.get_gold_rush_career_stats._dict / _get_season_dict_cnt、GRDocDataMgr.get_top_weapons、UIGRDocPageData.WeaponDataItem.update_data / _load_weapon_icon、ItemInfoMgr.name_tid / icon_path、goldrush_document_page_data_configのfield=weapon_kills・data_type=3・TID_GOLD_IDCARD_PAGE2_DATA_9。goldrush_item patch 9c4e0d093b3c0193046d1159b457db6e。GET /v1/me/mojin、src/game/mojin-weapons.mjs / mojin-dictionary.mjs、ios/Sources/App/MojinSelfView.swift |
| 戦績の通報処理用品性値データ（API非返却） | 通報結果の表示処理へ渡されるcharacter_value_infoの元データ。参照先と日本語表示を静的に確認した段階で、実際の処分適用や現在の品性値を確定する情報としては扱わない。 | 受信項目を確認 | character_value_info.ori_character_value（受信時は数値1要素の配列）、character_value_info.dec_character_value（受信時は数値）。除外前の自分の戦績94件中4試合・延べ5人分（本人2、他参加者3）で非空を受信。モード78・8・1。受信したことは処分適用・不正行為・通報成立の証拠ではない。result_utilsの通報ボタン用処理が辞書をUIReportへ渡し、UIReportResult.init_normal_successが放置行為・途中退出等の理由分岐で参照することを静的確認。dice_dataがない分岐ではori_character_value[0]−dec_character_valueを画面に使い、別分岐ではdice_data.pre_dec_cv等を使う。この算式を一般の戦績・全モード・現在のプロフィール値へ適用する条件は未確認。ゲーム内TIDは「本通報での失点：%sポイント」「失点後品性値：%sポイント」。一般公開条件・他人の閲覧可否を確認できていないため、APIの再帰的な公開データ整形と参加者整形からcharacter_value_infoを除外し、iPhoneへ表示しない。ゲーム内の通報・送信・設定変更は実行していない。 | 自己のrequest_self_battle_records応答、result_utils.on_btn_report_clicked（patch 93177a069c019f8aa47d75f18d2bc3cd）、UIReportResult.init_normal_success（base b7f699712b50602bdabe68279b1b9a79）、all_tid_jpのTID_REPORT_RESULT_REDUCE / COUNT / TID_HANGING_BE_REPORTED / TID_EXIT_HALFWAY。src/game/public-data.mjs clean / decodeRecords、src/game/presentation.mjs presentMatch |
| 手記の加筆のシーズン別最長連続真相解明回数 | 自己の現シーズンと保存された過去シーズンで受信したmax_win_streakの記録。過去値を加減算・最大化して作る全期間記録とは分ける。 | 実データで確認 | statistics[].longest_success_streak.label / status / value、statistics[].scope / season_id。自己ログイン時のgold_rush_common_dataのみ。現シーズンS1はルートのmax_win_streak=0、過去S0はhistory_season_data[0].max_win_streak=1をHTTPで確認。新しいゲームRPC項目の取得ではなく、既存の自己スナップショットの表示条件・意味を追加確認。ゲームの_scalar_topは過去の選択時に履歴の値を読み、それ以外はルート値を読み、加算項目のような差し引きはしない。累計選択にもルート0が使われる一方でS0は1のため、全期間の最長記録としての解釈は未確認とし、allではstatus=unverified_period・value=nullを返す。現／過去の未受信はunavailable、不正値はinvalid、明示的な0はreceivedの0と区別する。負数・非整数・安全な整数範囲外を拒否。ゲームUIの0時の「-」に対しアプリは受信済み0を0と表示し、未取得と混同しない。現在進行中の連続回数current_win_streak、対戦ログからの推定連勝、通常戦の連勝、全期間の最大値は追加していない。他プレイヤーのデータ取得・表示には適用しない。 | init_player.gold_rush_common_data.max_win_streak / history_season_data。cs_utils_personal.get_gold_rush_career_statsの_scalar_top / _mode、GRDocDataMgr.get_season_stats、UIGRDocPageData.NormalDataItem.update_data、goldrush_document_page_data_configのfield=max_win_streak・data_type=1・TID_GOLD_IDCARD_PAGE2_DATA_14。GET /v1/me/mojin、src/game/mojin-streak.mjs / mojin-data.mjs、ios/Sources/App/MojinSelfView.swift |
| 手記の加筆の陣営別参加回数 | サバイバーとハンターの参加回数を別々に表示する自己統計。各陣営の受信済みwin_cnt＋lose_cntから算出し、通常モードの対戦数や取得戦績の件数と混同しない。 | 受信項目を確認 | statistics[].participation_counts.label / survivor / hunter / calculation。自分のログイン時データgold_rush_data・gold_rush_butcher_dataのみ。ゲームと同じく累計はルート、過去は選択したhistory_season_data、現シーズンは累計から受信済み過去分を差し引いてからwin_cnt＋lose_cntを陣営別に算出する。ゲーム内元ラベルは「サバイバー/ハンターモード累計参加回数」で、左サバイバー／右ハンターの順序も原処理に合わせる。選択期間の参加回数であって全期間の完全な試合履歴取得を意味しない。保存済みの自己受信データで累計2/0、現S1が0/0、過去S0が2/0の6値を照合。今回のAPI更新後はゲーム側ゲートウェイ接続がタイムアウトし、稼働HTTPでの新項目取得は未確認。保存データでの実装確認を今回のライブ取得成功とは記録しない。欠落・不正値・負差分・安全な整数範囲外の和はnull。片方が未取得でも、もう片方の明示的な0は保持する。ゲームの欠落を0にする既定値や負数を0に丸める描画は採用せず、未取得を区別する。他プレイヤーへの新しい情報要求はなく、既存の閲覧条件・通知設定を変更していない。 | init_player.gold_rush_data / gold_rush_butcher_data.win_cnt・lose_cnt・history_season_data。cs_utils_personal.get_gold_rush_career_statsのsurvivor_match_count / butcher_match_count / _scalar・get_now_season_cnt、UIGRDocPageData.NormalDataItem.handle_special_fmt、goldrush_document_page_data_config id=11・fmt=survivor_butcher_match_count・TID_GOLD_IDCARD_PAGE2_DATA_11。GET /v1/me/mojin、src/game/mojin-data.mjs、ios/Sources/App/MojinSelfView.swift |
| 手記の加筆のプロフィール展示4枠 | プロフィールに展示する対象を選んだ枠の設定。倉庫の所持品全体や図鑑の収集記録とは別。 | 受信項目を確認 | gold_rush_common_data.display_magic_gold、設定上の枠0〜3・SLOT_COUNT=4、各枠のidまたはuuid（参照処理の静的確認のみ）。自己の保存済み共通データで空辞書を受信していたことを確認。非空の展示対象・画像の実受信は未確認。ゲームはdisplay_magic_goldの文字列キー0〜3を読み、idまたはuuidを持つ項目を展示する。空の展示設定から所持品なし・図鑑0件と判断しない。他プレイヤーではgr_hide_valuable_collectを確認する分岐があるが、相手の実データで公開条件を照合した成功は未確認。API・iPhoneの新しい表示は追加していない。 | GRDocDataMgr.get_display_magic_gold、UIGRDocPageDataRecyclables._refresh_items / _is_privacy_hidden、GRDocDataMgr.is_gr_hide_valuable_collect、UIGRDocPageDataChoose._build_recyclables_data_list。SLOT_COUNT=4。patch d11c9123bfa20574491e3114483ec1b8 / 4cda478aba0e3b04e11dc25d1d5059f0 / a4f0e9ecfb9747bb823dbeee64cb737e |
| 手記の加筆の自分の倉庫スロット | 自己ログイン時のinventory.warehouse.slotsに含まれるスロット行。展示設定や対戦戦績とは別のデータ。 | 受信項目を確認 | init_player.info.inventory.warehouse.slots[]、受信したid・cnt・durはいずれも数値型、uuidによる個体検索は静的処理のみ確認。2026-11-05の保存済み自己データでslots配列1行を確認。行数を所持数量と扱わない。ゲームのget_item_held_cntは対象idのcntを合計するが、今回その値の表示や全所持品の完全性は検証していない。受信したdurの意味、アイテム名・元画像の対応、倉庫全体の現在値は未確認。選択したmojin-read-probeのself_dataは4フィールドだけを保存するため、そこにinventoryが無いことをサーバーが未送信だった根拠にしない。自己の保存済みinit_playerを別に照合した。他プレイヤーの所持品取得・表示は追加していない。 | 保存済みinit_player.info.inventory.warehouse、GRDocDataMgr.get_warehouse_data、UIGRDocUtils.get_warehouse_item_by_uuid、UIGRUtils.get_item_held_cnt。patch 4cda478aba0e3b04e11dc25d1d5059f0 / 7e2ccfe989ac9d21c5311d10ecad4312 / 4a7e7f16f7fd2d0398e2f3682d38b966 |
| 手記の加筆の図鑑・収集記録 | 自己の図鑑に使う初収集・累計収集・初遭遇・撃破／被撃破回数等。単なる所持品一覧や対戦結果ではない。 | 処理・設定のみ確認 | request_goldrush_collection_guide()（引数なしの専用処理）、goldrush_collect_info.item側のfirst_ts・cnt、monster側のfirst_ts・kill・killed_by、既読read、設定のauto_unlock_time・count_ids。専用RPCとUIの参照処理・日本語名だけを静的確認し、実要求は行っていない。GoldRushLogic.init_inventory_logicはgoldrush_collect_infoを空辞書で初期化し、request_goldrush_collection_guideの成功後にresを代入する。ログイン初期値やinventory.collection_guideの空辞書を図鑑の取得成功・収集0件として扱わない。ゲーム内の元ラベルは初収集・累計収集・初遭遇・撃破回数・被撃破回数。異象はcount_idsによる参照、図鑑はauto_unlock_timeによる自動解放表示の分岐もあり、解放済み表示を遭遇・収集の実績と混同しない。first_gold_item_timestampsやseen_monster_idsだけで現在の図鑑を復元できるとは未確認。専用応答の実形式・非空データ・公開条件を実照合していないためAPI・iPhone表示は未実装。他プレイヤー取得には適用していない。既読化・展示変更・鑑定・報酬受領の操作は行っていない。 | GoldRushLogic.request_goldrush_collection_guide / init_inventory_logic（patch 6bf1e949f37da200488fa309aebf93a8）。UIBattleAdvCollectInfoAdd._get_monster_collect_info / _get_thing_collect_info / is_monster_unlock / is_thing_unlock / WidgetCollectDetailItem.add_thing_p_info / WidgetCollectDetailMonster._refresh_left / add_boss_info_p_info（patch b7ec0b465c74829e408eb4cdcc638f2c）。UIBattleAdvCollectRedDotUtils（patch e749835312a8f12f6954d2392909243d）。元TID_BATTLE_ADV_COLLECT_INFO_ITEM_1 / 6 / 7 / JI_1 / JI_2 |
| プロフィールの使用回数が最も多いキャラ | プロフィールのpid_cnt_allからゲームの条件で選ぶ、両陣営を合わせた常用キャラ。取得戦績の直近使用回数やキャラ別勝率とは別。 | 実データで確認 | most_used_characters.label / status / items[] / scope / source_field、items[].character_id / name / asset / camp。保存済み自己プロフィールとinit_playerの両陣営11＋21＝32キャラ分のpid_cnt_allが一致することを確認。player_release_dataの対象IDだけを残し、old_battle_cnt＋new_battle_cntの降順で選ぶ。ゲームのヘルパーは6体を返し、UIDocumentBattleのプロフィールは先頭4体を描画するためアプリも4体まで。受信済み自己の4体は狂眼・道化師・オペラ歌手・幸運児で、4位境界の同数はなし。一般の同数はアプリでID順とし、ゲームの同数順との一致は未確認。old/newそれぞれの境界・対象モードの完全性・全期間の完全性は未確認なので回数・勝率は新規表示せず、名前と元画像だけを表示する。元の日本語見出しはTID_FPD_CHAR_LIST_BATTLE。明示的0はゲームと同じ候補だが、欠損を0に補完しない。必要な辞書・値・元の名前／画像が不足する場合は未取得、不正・負数・整数範囲外の和は無効として部分的な順位を断定しない。自己、または新しく取得した完全なプロフィールで統計公開と常用キャラの条件を確認できた公開相手に適用。非公開・不明はnull。ゲームのis_fake_ai・is_special_friendによる非表示条件を照合し、部分応答・特殊フレンド・AI相当の相手には許可しない。新しいプロフィール項目のHTTP取得はSDK認証失敗のため未確認。APIソースとテストを追加し、更新したAPIプロセスへの反映を確認。ゲーム内元PNG4枚のHTTP取得・目視を確認。衣装を含めたゲーム画面との完全一致は未確認で、既存の元キャラ画像を使用。新しいゲームRPCは追加していない。 0.1.23以降はpublic_profile_extensionsの条件を満たす公開相手にも表示するソースへ拡張。以前の自己限定条件はこの追加実装で更新する。他人の最新・非空データのライブ検証は未確認。 追加の最新確認：新規認証したAPIで公開相手から常用キャラ4体・過去キャラ別成績93件のHTTP取得を確認。以前の未確認記述はその調査時点の記録。iPhoneは引き続きソースのみ。 | civilian_data.pid_cnt_all / butcher_data.pid_cnt_all。cs_utils_personal.get_history_most_used_pid（patch 080c02f16517fe9666229d156a043ff5）、PersonalDocDataMgr.get_history_most_used_pid / is_hide_fre_used_role_info（patch 3b7c074a11e00a68561286f033beac6d）、UIDocumentBattle.update_recent_info / RECENT_INFO（patch 9513b17d872eed7faaf7b17e7fb0f495）、player_release.py（patch 9f4662356563a7ac1c2814fc9fbeae5b）。src/game/frequent-characters.mjs / presentation.mjs、ios/Sources/App/ProfileFrequentCharacters.swift |
| 過去シーズンのキャラ別ランク戦記録 | 受信した各過去シーズン・陣営に保存された、キャラ別のランク戦対戦数・勝利数・引分数と、ゲーム表示と同じ引分除外の勝率。直近戦績からの集計、通常戦、常用キャラの使用回数とは別。 | 実データで確認 | season_history.survivor / hunter[].rank_characters.status / mode / items[]、items[].character_id / name / asset / camp / battle_count / wins / draws、items[].decisive_matches / win_rate / win_rate_display / zero_denominator、rate_basis=wins_over_battles_minus_draws / source_field=pid_data_rank。保存済み自己ログイン（2026-11-05T15:27:27.963Z）と保存済み自己API応答で両陣営9シーズンずつのpid_data_rankが一致。18辞書中16は明示的な空辞書、非空2辞書に計3キャラ。S37サバイバーの傭兵は6戦4勝1分で80.0%、幸運児は2戦2勝0分で100.0%、S35ハンターの復讐者は1戦1勝0分で100.0%。9つの受信カウントと3つの勝率を照合。勝率はwin_cnt÷（battle_cnt−draw_cnt）×100で小数1桁。ゲームは分母0を0.0%表示にするため同じ扱いとしzero_denominatorを明示。戦績分析の引分を含む勝率とは計算基準が違う。受信した行だけを表示し、ゲームが未受信の所持キャラに作る0件の表示行は新たに生成しない。空辞書と未取得を区別し、欠損を0に補完しない。負数・整数範囲外・勝利数と引分数の矛盾・名前や元画像の不足は成績を断定しない。対戦数の降順、同数はアプリのID順でゲームの同数順との一致は未確認。自己と、新しく取得した完全なプロフィールで統計公開等の条件を確認できた相手の過去シーズンに適用。非公開・不明・部分応答はrank_characters=null。元のキャラ日本語名・PNG3枚をローカル素材APIで照合・目視確認。ゲーム側は現在の衣装アイコンを参照するが、アプリは既存の元キャラ画像を使い衣装の一致は断定しない。同じ辞書のmvp・ave_scoreも受信済みだが今回の過去シーズン画面参照では表示の意味を追加確認できていないため新規表示しない。通常戦pid_data_normalや現在シーズンpid_data_rankを過去の行へ合算しない。今回の新しいプロフィールHTTP取得はSDK認証失敗で未確認。新しいRPC・ログイン操作・既存ログインの置き換えは行っていない。 0.1.23以降はpublic_profile_extensionsの条件を満たす公開相手にも表示するソースへ拡張。以前の自己限定条件はこの追加実装で更新する。他人の最新・非空データのライブ検証は未確認。 追加の最新確認：新規認証したAPIで公開相手から常用キャラ4体・過去キャラ別成績93件のHTTP取得を確認。以前の未確認記述はその調査時点の記録。iPhoneは引き続きソースのみ。 | init_player.info.civilian_data / butcher_data.history_season_data.<season>.pid_data_rank、保存済み/v1/me。UIRankSeasonReview.show / update_details / update_detail_item_data / SeasonDetailItem.update_data（patch df7081e7277cb8f103e314fff229aaf3）。src/game/season-characters.mjs / profile-seasons.mjs、ios/Sources/App/ProfileSeasonsView.swift |
| Blackjackの自己対戦・シーズン別記録 | Blackjack専用の対戦数・勝利数・敗北数、得点関連フィールド、保存済み過去シーズンの自己データ。通常ランク戦や週ランキング順位とは別。 | 受信項目を確認 | init_player.info.bj_data.battle_cnt / battle_win_cnt / battle_lose_cnt、score / max_score / season_max_score / season_id、history_season_data.<season> / week_info / now_week_no。自己ログイン保存データでルート3カウントと得点関連値はすべて0、season_id=44、過去S35〜43の9辞書を確認。各過去辞書の3カウント・score・season_max_scoreの計45値も0。ゲームのget_battle_cnt_by_match_type_and_roleはMATCH_TYPE.BLACK_JACK=11からbj_dataを参照し、通常参照とget_now_season_cntを使う現シーズン参照を分ける。今回、非0の記録・最新HTTP取得・他人の公開条件は未確認。battle_win_cntを1位回数とみなす根拠、max_score等の具体的な期間は未確認で意味を推測して表示しない。week_infoは明示的空辞書、受信したnow_week_no=363は最新週と断定しない。週辞書がない場合get_self_bj_week_scoreの-1は静的な欠落時の値であり、受信した負の週ポイントではない。自己情報を扱う既存/v1/meの返却リストにbj_dataは含まれず、専用API・iPhone画面は今回未追加。 | init_player.info.bj_data。ComuKeys（patch 2a6aa19d9c8369e4c067fea7d2a0883b）、cs_utils_personal.get_battle_cnt_by_match_type_and_role（patch 080c02f16517fe9666229d156a043ff5）、FriendLogic.get_self_bj_week_score / get_self_bj_score_data（patch e2ca5df59fd699cc4807f73cf39d6797） |
| 悪夢の影の自己週別記録 | 悪夢の影で本人が受信する週別ポイント、個人・チームの最短タイム用データ。ルート値、週ごとの値、マップ別の接尾辞付き値を区別する。 | 受信項目を確認 | init_player.info.race_data.week_info.<week>.score / min_time / min_time_team、min_time_tm / min_time_team_tm / score_tm、min_race_time_personal / min_race_time_team / now_week_no、別マップ用score_1101 / min_time_1101 / min_time_team_1101（静的参照のみ）。自己ログイン保存データで12週の辞書、得点0を12件、明示的nullの個人・チームタイムを24件確認。24件とも対応する*_tmは正の数値だったため、時刻の存在を非nullタイムの取得成功やプレイ済みの根拠にしない。ルートの個人・チーム最短も明示的null。黄金の石窟用*_1101はこの保存応答に存在せず、0に補完しない。元の日本語辞書とMATCH_TYPE.RACE=15で悪夢の影と照合し、場面72は月の河公園、1101は黄金の石窟。ヘルパーはTimeCheck.get_week_noで週を選び、場面1／72では無接尾辞、それ以外は_<scene_id>を付けて参照。FriendLogicのランキング表示用データは保存now_week_noで引き、タイムを1000倍して整数化する経路がある。単位と変換の対応は静的処理のみで、非nullの実タイムは未取得。週番号は独自基準時刻・日・時の補正で決まり、ISO暦の週番号や端末の暦へ推測で変換しない。受信したnow_week_no=461を現在の最新週と断定しない。非0得点、非nullタイム、最新HTTP、他人の閲覧条件は未確認のため専用API・新画面へ未反映。 | init_player.info.race_data。cs_utils_personal.get_cur_week_race_min_time / get_cur_week_race_min_time_team / get_cur_week_race_score（patch 080c02f16517fe9666229d156a043ff5）、FriendLogic.get_self_racing_score_data（patch e2ca5df59fd699cc4807f73cf39d6797）、TimeCheck.get_week_no（base 8cbf686ca55a32985a1eb56b5205fbf1）、元日本語TID_NAME_TYPE_RACE / 既存マップ辞書 |
| Blackjack週ポイントランキング | ゲーム内にあるBlackjack専用の週ポイント順位表と自分の順位・百分位の表示経路。保存済み自己週データの空辞書は順位表の取得成功を意味しない。 | 処理・設定のみ確認 | RANK_BLACKJACK_WEEK=rank_bj_week / RANK_TAB_ALL=2（文字列）、ask_rank_data(show_tab,show_camp)、rank_num / rank_percentからbj_week_rankへ変換する経路、自己表示は順位型に+1、百分位型は%表記。UIBJPick.init_bj_weekで全体タブと週ランキング種別を指定する経路を静的確認。見出しは元のTID_TITLE_21_RANKING_LIST_WEEK=Blackjack週ポイントランキングリスト、得点見出しはTID_TITLE_21_PERPARE_WEEK_POINT=週ポイント。rank_blackjackのscore参照とrank_bj_weekの週score参照は別。FriendLogic.ask_rank_dataからcall_server_methodのask_rank_dataへshow_tab/show_campを渡す。応答をbj_week_rankにまとめ、順位と百分位で表示を分ける。現在SDK認証失敗のためこの種別の新しいRPCは送っておらず、サーバー応答・公開参加者項目・現在利用可能か・過去週指定は未確認。APIランキングの選択肢を追加せず、静的経路を取得成功と記載しない。 | ComuKeys（patch 2a6aa19d9c8369e4c067fea7d2a0883b）、UIBJPick.init_bj_week / set_week_rank（base a1b520316c93b60fc099c91bb33c1110）、FriendLogic.ask_rank_data / bj_pick_ask_week（patch e2ca5df59fd699cc4807f73cf39d6797） |
| 悪夢の影のマップ別ランキング | 悪夢の影のマップごとに分かれた個人ポイント・個人タイム、およびチームタイム用の順位表の参照経路。 | 処理・設定のみ確認 | COMMON_GLOBAL_RANK_TYPE: RACE_TIME_PERSONAL=3 / RACE_SCORE_PERSONAL=4 / RACE_TIME_TEAM=5、RACE_RANK_ID: MOON=1 / GOLDEN=1101、common_rank_<type>_group_<group>（設定によってシーズン接尾辞）、ask_rank_dataのshow_tab / show_camp。UIRacePickは場面72（月の河公園）と1101（黄金の石窟）から対応するランキングgroupを選び、全体タブで個人ポイントと個人タイムを要求する。チームタイム用定数・自己表示処理も静的に存在するが、この画面がその順位表を要求するかは今回未確認。cs_utils.common_global_rank_name_by_idは設定のseason_clearに応じてシーズン接尾辞を付けるため、任意の過去週やシーズンへ固定文字列で要求できるとは断定しない。保存週情報は順位表の成功応答ではない。新しいRPCは未送信、どの種別も今回ライブ取得未確認。参加者の表示項目・公開条件・現在の利用可否・過去週順位も未確認でAPIやiPhoneへ選択肢を追加していない。 | ComuKeys（patch 2a6aa19d9c8369e4c067fea7d2a0883b）、UIRacePick.init_racing_rank_week / get_race_rank_id_by_map_id（base 11b6fa812eea76157f597fc275adc475）、FriendLogic.get_self_racing_score_data（patch e2ca5df59fd699cc4807f73cf39d6797）、cs_utils.common_global_rank_name_by_id / _get_rank_season_id（patch 909b1b8c3ae6c5ff27adfcbd686d70ff） |
| PC用ログイン接続コード取得EXE | 起動中の本人のPC版第五人格から、API接続に必要なSDKログイン情報を1本の接続コードへまとめるWindows用ツール。 | 実データで確認 | IDV1接続コード: version / issued_at / server / login_info、SDKのsdkuid / sessionid / sauth_jsonとゲームのfull_uid / client_version / pack_type。Windows x64のEXEをビルドし、合成データでJSON・単引用符の辞書片の抽出、アカウント照合、コード化とNode側の解釈を確認。起動中の本人の実PCゲームから新規SDK接続コードの抽出に成功し、稼働APIへの取り込み・DPAPI保存と値の一致を確認。その後、PC版終了後のAPIログイン成功も確認。指定した第五人格フォルダーのdwrg.exeだけを読み取り、プロセスへの書き込み・注入・ネットワーク・他ログインの置き換えを行わない。保存済みの古いSDK情報を再利用せず、対応するログイン記録を照合。複数候補を確定できないときは失敗扱い。コードは伏せ字で表示しコピー操作で渡し、認証情報のファイル保存やログ出力は行わない。コード取得時刻とゲーム側セッションの有効期限は別で、有効期限や短時間失効を断定しない。 | windows/SessionCapture.cs / scripts/build-session-capture.ps1。Windows QueryFullProcessImageName・VirtualQueryEx・ReadProcessMemory（読み取り専用）。既存の本人認証調査で確認したSDKとログイン記録の組合せ。 |
| iPhoneから接続コードを入力・更新 | PC用EXEの接続コードをiPhoneで貼り付け、認証付きPC APIへ保存してから接続する機能。API認証鍵とは別の入力。 | 実装・テスト済み | POST /v1/session/import {code}、stored / verified=false / captured_at、POST /v1/session/connect replace_existing=false。API138テスト成功。入力形式・サイズ・SDK識別子の一致を確認し、Windows CurrentUser DPAPIで保存。取り込み単体ではゲームへログインしない。コードに含まれるlogin_confirmやverifiedは信用せずfalseへ固定し、応答・状態にコードやSDK値を返さない。不正なコードで既存の認証情報を上書きしない。実際の稼働APIで不正コード400と保存ファイル不変を確認。iPhoneは設定→ゲームの接続コードを入力、伏せ字の入力欄、貼り付け、保存して接続を追加。保存後と画面離脱時に入力を消し、通常の接続ではPC側ログインを置き換えない。PCゲームを終了してから接続する。iPhoneの追加UI2テストは未実行、IPAは未更新。 起動中の本人の実ゲームから取得したコードで、稼働APIの取り込みHTTP成功と暗号化保存値の一致を追加確認。その後ゲームサーバーの認証成功も確認したが、iPhone実画面は未確認。 | src/session-code.mjs / src/server.mjs / test/session-code.test.mjs / test/api.test.mjs、ios/Sources/App/GameSessionImportView.swift |
| 公開された他プレイヤーへの表示拡張 | 自己限定だった常用キャラ・過去キャラ別ランク成績と、手記の加筆の探索統計・常用職業・得意武器・参加回数・シーズン記録・戦績を、許可された相手にも表示する実装。 | 実データで確認 | field_access.frequent_characters / season_characters、GET /v1/players/{id}/mojin、GET /v1/players/{id}/mojin/history、mode=mojin / allで他人の公開探索戦績を統合。通常プロフィールは他人への要求でキャッシュを使わず公開設定を再取得する。統計の公開、完全なプロフィール応答、元設定の特殊フレンド除外リスト、通常の公開IDの条件を確認して常用キャラと過去キャラ別成績を返す。検索・フレンドの部分応答だけでは新項目を許可しない。手記の加筆は専用RPC ask_player_gold_rush_data(uid)の相手ID・形式を確認し、gr_hide_personal_dataを独立判定。非公開403、設定欠落・不明409。戦績はgr_hide_battle_recordを取得前後に確認してrequest_friend_gold_rush_records(uid)を使用し、通常戦績のフラグや個人統計の許可で代用しない。取得中のセッション変更・違う相手の応答を破棄し、raw情報・倉庫・隠された内部状態を返さない。自己用の意味が確認された同じ正規化処理と元画像・日本語名を使い、受信しない値は未取得。公開許可・撤回・非公開・不明・相手違い・セッション変更を実装テストで確認したが、新規認証後、公開相手の常用キャラ4体・過去キャラ別成績93件、手記の公開プロフィール3人・公開戦績2人各50件、mode=mojinの戦績ページと分析HTTP200を確認。別の相手の手記戦績は403で返却を止めた。通常のプロフィールも受信後の公開設定に従い非公開統計を除外。受信した手記戦績の後で公開が撤回されたケースをテストし、APIへ返さずキャッシュにも残さないことを確認。 最新の通常閲覧での再確認（2026-11-06T23:35:29.211Z）：追加再確認：公開プロフィール44474049で両陣営各25シーズン・キャラ別成績合計389件、21536583で両陣営各39シーズン・合計733件をHTTP200で取得。19806845は通常統計が非公開のため返さず、独立して公開された手記の加筆の統計・現在段位五段IIIをHTTP200で取得。内部MMRやAI除外集計の他人の実数取得成功とは扱わない。 | src/game/public-data.mjs / frequent-characters.mjs / season-characters.mjs / mojin-public.mjs / mode-records.mjs。PersonalDocDataMgr（patch 3b7c074a11e00a68561286f033beac6d）、GRDocDataMgr（patch 4cda478aba0e3b04e11dc25d1d5059f0）、FriendLogic（patch e2ca5df59fd699cc4807f73cf39d6797）。元設定special_friends（base 29f483c2b4d7f58c7c0992cf30c49a41）は今回空。 |
| ランキングから他プレイヤーのキャラ別人格 | 選択したキャラクターに現在設定されている人格ページの獲得項目・レベル・消費人格点。試合当時の構成とは区別する。 | 実データで確認 | player_id / character_id / character_name / character_asset / camp、page_id / status / access / received_at、items[].id / name / level / asset / branch / layer / node_seq、used_points / unmapped_count。通常のランキング人格ボタンと同じget_data_from_cache(db_name=entities,key_lst=[文字列ID],client_cb=reply_get_genius_data,need_fields=[],ignore_fields=[])で受信後、ask_player_cil_butcher_dataをfreshで再取得しopen_talentを独立判定。公開設定不明409・非公開403・相手や応答形式不明502。返された人格側の明示的な非公開・不正な設定も拒否。相手違い・取得中のセッション変更を破棄し、原本をAPIへ出力・保存キャッシュしない。オンライン状態を公開許可の代わりにしない。pid_to_geniusの選択ページを使い、100未満の通常ページと10000超のキャラ別ページを解析。100〜10000の推奨ページは変換経路未確認のため未取得とし、別のページに置き換えない。人格辞書は元設定80項目・144レベル、同数の元アイコン。 | UIRank.on_btn_player_tips / UICharRank.on_btn_player_tips、UITipsBase.click_perosona_map（1259e283596adfed11cbac8c163eb4c4）、Avatar.get_data_from_cache / reply_get_genius_data / get_common_stage_genius_pid_and_page（2423b0b1afa1ca08252f8a0e3bdaeb00）、Genius.get_used_genius_point（2c5c98f9ca779b36ec562a040d58e8af）、civilian_genius / butcher_genius / passive_skill / 元日本語辞書。GET /v1/players/{id}/persona?character_id=89。src/game/persona.mjs、resources/persona-display.json、ios/Sources/App/PersonaView.swift |
| アプリ内観戦映像の再生調査 | ゲーム内の観戦・録画再生は、ゲーム本体の世界描画と記録片の処理を利用する。アプリ内映像再生は未対応。 | 処理・設定のみ確認 | Avatar.replay_battle_from_server_recodeはg_world_mgr.on_get_control_info_replay / start_wait_for_readへ渡し、req_read_bunchesは記録片を読む。通常の映像URLやiPhone向け再生方式は未確認。観戦参加要求や録画取得は行っていない。映像を再生できないならタブ不要というユーザーの指示で、観戦タブ・専用画面・仮の一覧APIを削除した。下部はホーム・検索・チャット・通知の4タブ。 | Avatar（2423b0b1afa1ca08252f8a0e3bdaeb00）、.private/research/spectating-world-playback.txt / spectating-playback-static.jsonl、ios/Sources/App/IDVViews.swift |
| 他プレイヤーの内部評価・隠しレート | 品性値とは別の内部評価。呼び出し名だけからMMRや数値の意味を断定しない。 | 未確認 | gm_show_hide_score（静的な名称・定義のみ）。show_hide_score(args)は引数を使用せずcall_soul_methodへ名前のみを渡し、他プレイヤーのIDを渡す処理はない。受信側GameLogic.gm_show_hide_score(self,info)はCLIENT_STUB・Dict(info)で登録されているが本体はreturn Noneのみ。これはサーバー側実装や返答がないことの証明ではない。通常アカウントの利用権限・返答・数値の意味は未確認。管理用要求は実行せず、架空の値や動作しない表示ボタンは追加していない。 追加の受信確認：本人のinit_playerにはhide_score系6項目の数値がある。一方、通常のask_player_cil_butcher_dataを使った他プレイヤー3人（統計permitted2人・hidden1人）の応答では、両陣営の現在データにこれらの項目は含まれていなかった。公開統計の許可を内部値の公開許可とは解釈しない。gm_show_hide_scoreの返答、他人の値の取得、値の意味は未確認。 | GMコマンドshow_hide_score（a72e1d90994c779235fd0abe17095592）、GameLogic.gm_show_hide_score（a382cf2417bbe248f72a89546f000c7c）、.private/research/internal-score-definition-proof.jsonl / internal-score-receiver.txt |
| 他プレイヤーの全フレンド一覧 | 相手のフレンド一覧。公開の親密関係や一緒に対戦した相手とは区別する。 | 未確認 | 確認できたgetFriendsは接続中の本人のnotify_friends_infoを読む。相手の全一覧の正式な公開取得経路・公開条件は未確認。戦績の同伴者からフレンド関係を推定しない。 | src/game/provider.mjs getFriends / notify_friends_info |
| 得点アイコンの視認性・小さいマップ・ランキング星数 | 元PNGを変えずに得点アイコンへ明るい台紙を付け、通常戦績のマップを132×80、探索戦績を160×88へ縮小。ランキングは七段以上を★25形式、六段以下を五段III形式で表示。受信済みの戦績参加者レベルも追加表示。 | 処理・設定のみ確認 | ScoreArtwork / MatchOutcomeHeader / MatchMapPreview、Ranking.rankLabel / summary.players[].level。iPhone0.1.25/26のソースのみ。HTML配置プレビューは元PNGで目視し、320/375幅の配置を確認。ネイティブのコンパイル・実機確認は未実施。ビルドはユーザーの次の明示依頼まで行わない。通常・手記の非公開エラー時に以前の戦績を消す処理を補完。以前のビルドのUI失敗3ケースは識別子が親から上書きされていた証拠を確認し、accessibilityのコンテナをソースで補完、再実行は未実施。 | ios/Sources/App/DesignSystem.swift / ProfileDataViews.swift / ProfileView.swift / MojinHistoryView.swift、ios/Sources/Core/Models.swift / MatchHistoryState.swift、design/refresh-preview.html |
| 本人ログインで受信するhide_score系の数値項目 | 本人ログインで受信する数値。rank付き2項目は保存済み本人の現在値でrank_scoreと一致し、段位ポイントに関係する値と見られる。rankなし2項目はSERVER_MODE限定ログのking_mmrの出力元として静的確認。b_付き2項目の用途は未確認。gm_show_hide_scoreの応答とは区別する。 | 受信項目を確認 | civilian_hide_score、civilian_rank_hide_score、b_civilian_hide_score、butcher_hide_score、butcher_rank_hide_score、b_butcher_hide_score。本人の現在データ6項目と保存済み過去シーズン18項目の存在を確認済み。追加照合ではrank_scoreの現在2件＋過去18件が初期値800＋sum_starに一致し、現在2件のrank_hide_scoreもrank_scoreと一致。ただしrank_hide_scoreへの実代入・更新式、全アカウント・全段位で同一になるかは未確認。rankなし2項目がログ定義のMMR欄に参照されることは、実サービスの現在のマッチング式の確認とは区別。b_の意味や800である理由を推測しない。新しいAPI・iPhone表示は追加しない。 rankなし2項目について、AI向けhidden_scoreへの転記と過去シーズンの変動をown_non_rank_hidden_score_analysisで追加確認。 | 本人init_player.info.civilian_data / butcher_data。受信前のUI加工ではなくGameSession.receiveの通常受信項目を照合。.private/research/internal-score-received-field-audit.json / internal-score-own-fields.json / internal-score-normal-receipt-audit.json 追加根拠：CivilianData / ButcherData.process_part_change、PartBase.part2sumstar / hide_score2part、global_dataのinit_kill_hide_score / init_break_hide_score、UtilsLog.log_race_civ_maze_pro_battle_fighterのSERVER_MODE分岐。 |
| 本人のrank_hide_scoreと段位ポイントの照合 | ランク戦の生涯加点合計と独立MMRを混同しないため、保存済み本人のrank_hide_score・rank_score・sum_starを比較した結果。 | 受信項目を確認 | 現在2件のrank_hide_score = rank_score、現在2件＋過去18件のrank_score = 800 + sum_star、rankなしhide_scoreは別値、rank_scoreはシーズン切替時に現在段位から再設定。本人の保存スナップショットで比較。sum_starはPartBase.part2sumstarが段位・段階・現在のpart_starから求める段位ポイントで、勝利加点を生涯分足し続ける値ではない。静的なprocess_part_changeはsum_starを再計算し、初期値800を足してrank_scoreを設定する。rank_hide_scoreの一般的な更新式は未確認のため、今回の一致を全アカウント・高段位・将来のシーズンへ一般化しない。 | CivilianData（8ec7e33aa408ffd23518c99a6ab3c055）/ ButcherData（644d2a1618b747c2487d029ac0c9285f）.process_part_change、PartBase（ed0d77cd79c988f5ebd2d43f31197a66）.part2sumstar、global_data（221fd3fc04ac50d4a431cb301664b67c）。.private/research/internal-vs-rank-score-own-comparison.json / internal-score-meaning-verification.json |
| 本人の陣営別hide_score（rankなし）の用途・変動 | civilian_hide_score / butcher_hide_scoreは段位ポイント側と異なる本人の内部値。配布コード内のSERVER_MODEログ定義ではking_mmr、AI向けプレイヤー情報ではhidden_scoreの出力元として参照される。現サービスの全マッチング処理で使われるMMRと同一とは断定しない。 | 受信項目を確認 | 本人の保存時点のcivilian_hide_score / butcher_hide_score、過去シーズン別の値・差分、同期間の通常戦・ランク戦の集計、king_mmr / hidden_scoreへの静的な参照。保存済み本人データで段位ポイント不変・ランク戦0件の期間にも2値が増える例を確認。別の期間には通常戦0件・ランク戦ありでの変動例もある。ただしシーズン境界をまたぐ集計の比較であり、1試合ごとの更新や因果関係の確認ではない。シーズン末記録には通常戦・ランク戦が共に0件でも前期と異なる例があり、勝利加点の単純累計とは扱わない。設定には初期値800・基礎値テーブル・補正係数があるが、対象6項目に対する適用順や現在のサーバー更新式は未確認。別途gatewayのmmr_infoもあり、同一値と混同しない。相手の強さ・AI戦・連勝・シーズン変更による補正は未確認。アプリへ推測のMMR・強さ順位・段位換算は追加していない。 | 本人init_playerとhistory_season_dataの保存値、UtilsLog（a70f2c44868c5eec0715712e10cd827f）.log_race_civ_maze_pro_battle_fighter、H55WorldCollector（1bfaa0495479ca0e524985531d5d0111）._build_player_ctx / _fill_PlayerStaticData_hidden_score / _collect_mmr_info、global_data（221fd3fc04ac50d4a431cb301664b67c）、.private/research/non-rank-score-deep-verification.json |
| 他プレイヤーの公開コレクション元データ | ゲーム内コレクション画面が読む衣装・携帯品・ペット・居館等の元データ。所持総数や恒久所持を断定する表示はまだ作っていない。 | 受信項目を確認 | players.role_cloth、players.hero_cards_info.cards、players.appendage_id_list、players.article_unlock.decoration_list / hall_list 等、players.custom_hall_info / used_custom_hall_id / article_setting。他人3人で通常のget_data_from_cache・reply_get_collection_infoの応答対象とコールバックを確認。取得前後の完全な通常プロフィールでblock_collect=falseを確認し、他人の公開コレクション関連の辞書・配列を実受信した。氏名・認証情報・全所持品原本は研究結果へ保存せず、形とフィールド名だけを記録。数の単純合計、期限付きと恒久の区別、レア度、日本語名・元画像の一致、展示設定と全所持品の区別は未照合。APIとiPhoneへは未追加。 | UIDocCollect.init_p_show / update_article_num_info（patch 9cf9512dce3d4f23bf2c3163e086c51d）、PersonalDocDataMgr.allow_collect_show / get_collection_info（patch 3b7c074a11e00a68561286f033beac6d）、ComuKeys.SETTING_SHOW_TYPE.BLOCK_COLLECT=block_collect。通常get_data_from_cache(db_name=entities,key_lst=[ID],client_cb=reply_get_collection_info,need_fields=[],ignore_fields=[])。 |
| 他プレイヤーの成就ID別データ・展示設定 | 個人資料の成就画面が参照するID別データと成就バッジの展示設定。戦績の称号やキャラ認知徽章とは別。 | 受信項目を確認 | achievement_info、achievement_detail、achievement_tag、achievement_global_info.badge_profile / badge_wall_pos_info、achievement_num_by_match_type / achievement_detail_by_match_type / achievement_global_by_match_type。通常のask_player_cil_butcher_data応答で他人3人の非空achievement_info・achievement_detailを確認。モード別by_match_typeの3辞書は全員明示的に空であり、各モードの成就取得成功とは扱わない。成就IDの数を達成数として表示しない。個々の進捗形式・達成日時・報酬受領と達成の区別・元の日本語名は未照合。badge_wallの非表示設定と各項目の表示条件を追加確認するまでAPI・iPhoneへ新規公開しない。 | 通常reply_cil_butcher_data、PersonalDocDataMgr.get_showed_achieve_badge_lst / is_hide_achieve_badge_wall_show / get_achieve_type_achievement_detail、UICommonAchieveNode。 |
| 他プレイヤーのCOPYCAT系成就データ | COPYCAT系専用の成就ID別の詳細・件数データ。通常の成就とは独立した辞書を使う。 | 受信項目を確認 | copycat_achievement_num、copycat_achievement_detail、copycat_achievement_global。通常プロフィール応答で他人2人に非空、別の1人に明示的な空辞書を実受信。空辞書から未プレイと断定しない。具体的な進捗数・成就日本語名・獲得済みかの判定・個別の公開条件は未検証。新しいスコアやMMRではなく成就画面への参照を静的確認。APIとiPhoneへは未追加。 | ask_player_cil_butcher_data / reply_cil_butcher_data、PersonalDocDataMgr.get_copycat_achievement_detail / get_copycat_achievement_num / get_copycat_achievement_score。new-copycat-achievement-static.txt（private）。 |
| 他プレイヤーの大会予想・応援関連の元データ | 大会予想記録や観戦イベントの個人資料画面が読むデータ。プロ選手・大会出場者であることの判定材料とは区別する。 | 受信項目を確認 | competition_profile_info、competition_predict_info、hide_competition_data / hide_competition_support / competition_collectible / hide_competition_photo_title（表示設定）。通常プロフィール応答の他人3人で非空のcompetition_profile_info・competition_predict_infoを確認。UICompetitionGuessRecord.build_cur_recordsが両辞書を読むこと、UICompetitionAchieveNodeの応援・相片展示と独立した非表示判定を確認。個別イベントID、予想内容・的中・報酬・応援数等の意味と公開条件の実照合は未完了。選手本人の出場履歴やプロ判定として表示しない。API・iPhone未追加。 | 通常reply_cil_butcher_data、UICompetitionGuessRecord.build_cur_records（patch 7a0afc6e0ef68f28d26b99fe3a12e25f）、CompetitionGuessRecordUtils（patch a0728734e6971d638c187867703312dc）、UICompetitionAchieveNode / PersonalDocDataMgr.is_hide_competition_data / is_hide_competition_support。 |
| 他プレイヤーの直近キャラ用last_N_cnt_dct | 受信した時刻付き記録から新しい100件を選び、使用回数上位6キャラを選択する処理に渡される項目。累計pid_cnt_allや個別戦績の取得範囲から作る分析とは別。 | 受信項目を確認 | reply_cil_butcher_data.last_N_cnt_dct、last_N_rank_cnt_by_pid / last_N_norm_cnt_by_pid / last_N_mb_cnt_by_pid（キャッシュ応答のフィールド名）。他人3人の通常プロフィール応答にlast_N_cnt_dctがあることだけ実確認。キャッシュ応答にもrank/norm/mbの専用キーを確認したが、この調査では非空・件数・中身の値や公開表示の可否は保存・検証していない。cs_utils_personal.get_most_used_pid_last_Nは各記録の第2要素を時刻として集約し、N=100をheapq.nlargestで選び、使用数上位most_numを返す。PersonalDocDataMgrからmost_num=6で呼ぶことを確認。現在アプリの累計常用キャラと混同しない。API・iPhone未追加。 | PersonalDocDataMgr.get_most_used_pid_last_N（patch 3b7c074a11e00a68561286f033beac6d）、cs_utils_personal.get_most_used_pid_last_N / get_rank_wl_cnt_by_pid_and_time（patch 080c02f16517fe9666229d156a043ff5）。new-recent-character-selection-static.txt（private）。 |
| ゲーム内AIの外部利用・単体実行の準備状況 | 調査したFuxi／AI Lab系の経路は試合状態を推論サービスへ送り、行動応答を受け取る構成。外部アプリで同じAIを利用できた状態ではない。 | 処理・設定のみ確認 | GatewayAdapter.format_observation / infer / parse_action、GatewayClient.connect / send、モデル本体・利用可能な推論サービス：未確認。配布コードを実行せず通信側の構成を確認。AIサービスへの接続・利用権限の検証、モデルの取得・単体実行、実際のキャラ操作は行っていない。公開公式資料の調査では第五人格の同じAI向けの利用可能なAPIやモデルを確認できていない。未発見を不存在・単体化不可能の証明とは扱わない。カスタム／練習モードのBOT設定は公式機能として確認できるが、調査した推論モデルと同一とは未確認。用途は「ゲーム内でAIに自動操作させる」とユーザーが指定。self_character_game_ai_controlで開始経路を追加調査。 | GatewayAdapter / GatewayClientの静的参照、NetEase Fuxi / AI Lab公式資料、Identity V 2024-05-23 Custom Mode Revamp公式告知。 |
| 自分のキャラクターをゲーム内AIへ任意に切り替える機能 | ゲームのAI操作・交代に関する処理はあるが、自分のプレイヤーを任意にAI操作へ切り替える通常の入力経路は未確認。 | 処理・設定のみ確認 | TrainCmdAI._active_cb / _inactive_cb の is_bot 条件、AITakeoverComponent.process_ai_takeover の FINISH_TAKEOVER 分岐、BattlePlayerUnit.start_ai_takeover / try_finish_ai_takeover。ユーザーの目的はゲーム内で自分のキャラクターをAIに自動操作させること。現行base/patchの31,172エントリーを4つの関連文字列で読み取り検索し、デコードエラー0。全処理の網羅的な意味解析ではない。練習AIの有効化・無効化処理はSERVER_MODE分岐でis_botを満たすプレイヤーのみ対象とすることを確認。確認した交代入力処理はFINISH_TAKEOVERでtakeover_by_selfを呼び、START_TAKEOVERを受け付ける分岐はない。受信側はSTART_TAKEOVERを処理するが、ClientUnits側のstart_ai_takeoverはb_ctrl_by_aiと復帰ダイアログ・通知を変更する処理であり、ローカルで呼ぶだけではサーバーのAI開始を実現した根拠にならない。自動テスト用・GM用の別処理も検索で見つかったが実行していない。通常権限で自分のAI操作を開始する経路や実動成功は未確認。試合開始・他プレイヤー操作・ゲーム改造・デバッグ機能有効化は行っていない。API・iPhoneへ自動操作機能は未実装。 | TrainCmdMgr patch 4ddf7c455b5b891b680899898edeff70、AITakeoverComponent base 756042754ce8ae3bdbd6acd3c6211fed、ClientUnits/BattlePlayerUnit patch 548b09421ceca7eee992eba0e5a81b6a、BattleEvent patch 83fc77e4629a4d609f207c5b0764bbb8。 |
| 0.1.26のデザイン刷新・取得後の公開設定再確認 | 通常取得の後で最新の公開設定を再確認し、両時点で許可された情報だけをAPIへ返す。iPhoneの表示更新時は古いプロフィール・戦績をクリア。 | 実装・テスト済み | profile.disclosure.checked_at / policy=after_receipt、field_accessのstatistics / profile_tags / history_badges / frequent_characters / season_characters / persona、presence.visibilityと公開時刻。API151テスト成功。非公開への変更、判定不明、非公開から公開へ変わった場合の古いデータ、オフライン形状の非表示、接続切り替え、相手違い、手記の公開撤回を確認。今回の新しいソースの実ゲームRPCでの再検証は未実施。既存の通常RPCのみを使用し、非公開の取得を拒む経路の前チェックは維持。HTMLプレビューの配置・元画像表示を確認。iPhoneコンパイル／UIテスト／実機、IPA・EXEビルドは未実行。 | src/game/public-data.mjs profileAfterReceipt、provider.mjs getProfile / getHistoryBadges / fetchHistory、mojin-public.mjs publicMojinProfile。ios/Sources/App DesignSystem / IDVViews / ProfileView / ProfileFrequentCharacters。 |
<!-- CAPABILITIES:END -->

<!-- MODE-UPDATE -->
戦績と分析の `mode` には `all / multi / rank / duo / mojin / custom / other` を指定できます。「全て」からカスタム戦を除外し、カスタムは専用表示・集計に分けます。ページ分割前に絞り込むため、先頭ページに該当試合がなくても後の取得済み試合を表示できます。組んだ相手の回数・勝率も選択モードだけで集計します。手記は現在自分のみ対応し、他人は取得条件未確認を返します。

`GET /v1/me/mojin/history` は手記の加筆の自己個別戦績です。専用の共有戦績を展開し、通常の戦績とは異なる結果定義とマップ対応表を使います。災いの女・職業「智者」・失敗・探索43秒の1件を取得し、マップと職業の元画像を読み込み確認しました。公開順位表や他人の非公開戦績の取得成功を示すものではありません。

通常の七段の星25以上では、ゲームの `peek_part` にある両陣営の元アイコンを使います。現在の段位得点と過去記録の星数は異なる形式として扱います。全体チャットの顔・枠、プロフィール名のコピー、行全体からの戦績詳細・参加者プロフィール移動、モード切替を未署名IPA **0.1.5（ビルド6）** に収録しました。この0.1.5更新時のAPIは68テスト、iPhone共通処理は12テスト、2端末の画面テストは計26件成功しています。画面テストはテスト用データで、実機インストールは未確認です。成果物は `dist/IDV-0.1.5-unsigned.ipa`、検証記録は `dist/release.json` です。

サイドロードでも通知許可があればローカル通知のバナーと音は利用できます。現在の実装はアプリ起動中に受信した状態変化をローカル通知にします。閉じている間の新しい状態変化の配信はAPNsの署名権限とサーバー設定が必要です。実機での配信成功は未確認です。

<!-- MOJIN-DETAIL-UPDATE:START -->
手記の加筆の追加探索統計（2026-11-06）：自分の「異象累計撃破数」「配役探索者累計撃破数」「木の板を落とした回数」「木の板を破壊した回数」「エンディングクリア回数」「累計詞章解明数」「累計移動距離」を追加しました。`GET /v1/me/mojin` の `statistics[].additional_statistics` は `field / label / value / display_value` を返します。日本語名はゲームの表示設定と辞書から取得し、累計・現シーズン・過去シーズンの切替に対応します。自分の実データで詞章3・距離61 mを確認しました。その他5項目は0の受信まで確認しており、増加した値は未確認です。欠損は0として補完しません。

未署名IPA **0.1.6（ビルド7）** に反映済みです。成果物は `dist/IDV-0.1.6-unsigned.ipa`。API70テスト、共通処理12テスト、iPhone SE・iPhone 16の画面テスト計26件が成功しました。画面テストはテスト用データで、実機インストールは未確認です。

`total_kill_boss_count` は「エンディングクリア回数」と表示される設定で、フィールド名から「ボス撃破数」と推測しません。最大連続回数は加算統計と異なる処理で、ルート値と過去値の大小も一致しないため、追加画面にはまだ反映していません。他プレイヤーの手記データ・専用ランキングの取得成功は未確認のままです。
<!-- MOJIN-DETAIL-UPDATE:END -->

<!-- MOJIN-CAREER-UPDATE:START -->
手記の加筆の常用職業（2026-11-06）：`GET /v1/me/mojin` の `statistics[].frequent_careers` に、職業名・ゲーム内元アイコン・使用回数を追加しました。ゲームの処理に合わせて使用回数の上位2職業を選び、累計・現シーズン・受信済みの過去シーズンに対応します。自分の実データは累計／S0ともに「智者」2回、現シーズンは差引後0件です。職業別の勝率は算出していません。未受信を「使用記録なし」に置き換えず、欠損・矛盾・未対応名を区別します。同数の並びはID順で、ゲームと完全に同じ順序かは未確認です。

未署名IPA **0.1.7（ビルド8）** に反映済み。`dist/IDV-0.1.7-unsigned.ipa` を署名して更新できます。API72テスト・共通処理12テスト・2端末の画面テスト計28件成功。画面テストはテスト用データで、実機は未確認です。

得意武器の非空データと対応ID、他プレイヤーの手記情報、専用ランキングは今回取得成功として追加していません。
<!-- MOJIN-CAREER-UPDATE:END -->

<!-- PROFILE-REOPEN-FIX:START -->
検索履歴からプロフィールを開いた際に読み込み表示が残る問題を修正しました。取得に失敗したときに画面内の読込状態を終了できていなかったため、理由と「再読み込み」を表示します。履歴の並べ替えが遷移中の表示や取得タスクを作り直す要因にならないよう、遷移先をIDで管理し、履歴更新を最新プロフィールの取得成功後に行います。同じ内容は繰り返し保存せず、概要を開く際の戦績の先読みもやめました。保存する履歴には以前の状態・段位・非公開情報を含めず、プロフィールの最新応答を確認して表示します。

未署名IPA **0.1.8（ビルド9）** に収録済みです。`dist/IDV-0.1.8-unsigned.ipa` を署名して更新できます。共通処理12テスト、iPhone SE・iPhone 16で各16件、計32件の画面テスト成功。履歴からの繰り返し表示・並べ替え後の表示・エラー後の再取得を確認しました。画面テストはテスト用データで、実機は未確認です。 公開プロフィールのAPIは実データで連続2回の成功を確認しましたが、APIの確認だけで実機の不具合を再現したとは扱いません。
<!-- PROFILE-REOPEN-FIX:END -->

<!-- MATCH-INSIGHTS:START -->
## 成績の推移（2026-11-06）

分析画面の「成績の推移」に、直近10・20・50試合、直近と取得範囲の最長連勝・連敗、平均得点、判定取得分のMVP率、終了時刻の時間帯別成績を追加しました。現在選んだモードで集計し、「全て」にはカスタム戦を含めません。サーバーから返された範囲の計算です。

勝率は勝利÷結果判明試合数で、引分は分母に含め、結果不明は除外します。引分・不明で連勝連敗を区切り、日時欠落や同時刻の曖昧さで順序を確認できない場合は直近成績・連勝連敗を未確認にします。得点0は有効ですが、未取得・負数等は平均から除きます。MVPは明示的なtrue/falseがある試合だけで算出し、判定件数・未取得件数を併記します。未取得を「MVPではない」とは扱いません。

APIは `/v1/players/{id}/analysis?mode=rank&timezone=Asia%2FTokyo` のように指定できます。timezone省略時はAsia/Tokyo、iPhoneは端末のタイムゾーンを使用し画面に表示します。時間帯は試合終了時刻を使い、開始時刻とは区別します。自己の全て94試合、マルチ65試合、カスタム11試合、公開対象の全て158試合で実データ確認。非公開の戦績は集計結果も返しません。

未署名IPA **0.1.9（ビルド10）** に収録。API78テスト、共通処理12テスト、iPhone SE・iPhone 16で各18件・計36件の画面テスト成功。通常／カスタムの切り替え、直近件数の変更、欠落値の表示をテスト用データで確認。実機は未確認です。
<!-- MATCH-INSIGHTS:END -->

<!-- MATCH-SCORE-BREAKDOWN:START -->
## 戦績の得点内訳（2026-11-06）

本人と参加プレイヤーの得点内訳に対応しました。サバイバーは「冷静・執着・友好・勇敢」、ハンターは「屈強・鋭敏・威嚇・狡猾」。番号の順序と項目名はゲームのCIVILIAN_SCORE_CONF / BUTCHER_SCORE_CONF、TEXT_*の日本語辞書で照合し、元の8種類のアイコンを使用します。

APIの `summary.players[].score_breakdown` に項目番号・名前・元画像キー・得点・値の出所を返します。自己の全て94試合と公開対象の先頭100試合で延べ1,040人分を確認し、4項目の合計が受信総得点と一致しました。既存の戦績閲覧権限を守り、取得後の公開判定が非公開・不明なら内訳も返しません。実取得はモード1・2・8・100、通常カスタム4は共通表示処理と実装テストまでの確認です。自己カスタム11試合（61・69）は未対応で、通常の項目名を付けません。

ゲームと同じく、受信した内訳辞書の省略項目は0として扱い、`value_source=game_default_zero` で区別します。内訳全体が未受信の場合は4項目を作りません。不正値は未取得とし、最大得点や割合を推測して追加しません。

未署名IPA **0.1.10（ビルド11）** に収録。API80テスト、共通処理12テスト、iPhone SE・iPhone 16で各20件・計40件の画面テスト成功。画面はテスト用データで、元アイコンの実PNG読み込みはPCのAPIで別途確認しました。実機は未確認です。
<!-- MATCH-SCORE-BREAKDOWN:END -->

<!-- RANK-CHANGES:START -->
## 戦績の段位変化とポイント理由（2026-11-06）

戦績詳細の「段位の変化」に、本人・参加者それぞれの対戦前後の段位と、受信したポイントの加点・減点理由を追加しました。勝利・失敗ガード・ソロプレイ追加得点・連勝・演繹得点順位などの名称は元の日本語TIDを使用し、段位は元のゲーム内アイコンで表示します。

データは参加者の直下ではなく、通常戦績の `part_change_info.<unique_id>` にあります。公開IDと陣営が一致した場合だけ、`summary.players[].rank_change` に整理します。自己9試合と公開ランク戦100試合で延べ454人分・1407行の表示理由を受信値と照合しました。公開100試合のうち通常ランク戦は85件、モード10は15件で、後者の入れ子データの対応は未確認のためこの表示を追加していません。非公開・閲覧条件不明の戦績から結果を返しません。

演繹順位の配列はゲームと同じく2要素目+1で順位名を作ります。ゼロ点の理由はゲームと同じ省略規則を使い、未受信を0点にしません。加点理由に含まれる「解読進度250%」等の日本語名はそのまま表示します。昇段をまたぐポイント総増減・保護カード補正・シーズンは、受信値や適用条件を確認できていない場合に推測して補いません。総増減・補正は呼び出し元の静的確認までで、表示対象と分けて一覧に記録しました。

未署名IPA **0.1.11（ビルド12）** に収録。API83テスト、共通処理12テスト、iPhone SE・iPhone 16で各22件・計44件の画面テスト成功。画面はテスト用データで、実機は未確認です。
<!-- RANK-CHANGES:END -->

<!-- PROFILE-SEASONS:START -->
## プロフィールのシーズン別記録（2026-11-06）

プロフィールの概要から「シーズン別の記録」を開き、サバイバー／ハンターと過去シーズンを選べます。記録段位・シーズン最高段位は元の段位画像と五段III等の表記、通常戦・ランク戦は対戦数／勝利数／敗北数を表示します。全体ランキングの過去順位や、全期間の個別戦績とは別の情報です。

自己のS35〜S43、両陣営18件・108個の件数値を実データで照合し、段位の元画像2種類もPNGとして取得しました。他の3プロフィールは統計が非公開だったため、シーズン記録も元の統計も返さないことを確認しました。他プレイヤーの許可された非空データは今回未確認です。

APIの`season_history.survivor / hunter`に受信した過去分だけを新しい順で返します。未取得を0にせず、不整合な件数は未取得にします。引分・勝率は追加していません。最高段位記録の星はゲームのPartUtil.get_max_part_infoと同じく配列の第5要素（段位ポイント）を元のpart_star_scoreで変換します。既存の最高段位表示もこの参照に修正しました。第3要素を直接星として使っていた以前の表示とは結果が変わる場合があります。

未署名IPA **0.1.12（ビルド13）** に収録。API86テスト、共通処理12テスト、iPhone SE・iPhone 16で各24件・計48件の画面テスト成功。画面テストはテスト用データで、実機は未確認です。
<!-- PROFILE-SEASONS:END -->

<!-- MATCH-ACTIONS:START -->
## 戦績の行動記録（2026-11-06）

戦績詳細の本人・各参加者の「行動記録」から、サバイバーの解読進捗／板命中／援助／治療／ハンターへの牽制、ハンターの残り暗号機／板の破壊／サバイバーに命中／恐怖の一撃／ダウンさせるを確認できます。元のゲーム内日本語名を使い、独自の画像は追加していません。

データは`all_pl_info[].action_recored`。ゲームの列順・行動enum・日本語TIDを照合しました。解読進捗は`+1`キーを整数%で、牽制は`12`キーを整数秒で表示し、100%を超える解読進捗を切り捨てません。他の項目は受信数値を保持します。未取得のキーや空の記録を0で埋めず、明示的な0と分けます。

自己94試合と公開対象の先頭100試合で、延べ1040人分・3156個の行動値を受信元と照合。2044項目は未取得として区別しました。実取得の表示モードは1・2・8・100。4・9・101は共通処理の静的確認と実装テストまでで、自己のカスタム11試合（61・69）には適用しません。モード10の入れ子データや手記等の別モードも対象外です。非公開・閲覧条件不明の戦績は行動記録も返しません。称号画像・称号条件は下記の「戦績の称号」で追加調査し、APIとiPhoneソースへ反映しました。`character_value_info`は後続調査で通報処理用の品性値データと確認しましたが、一般公開条件・実処分は未確認のためAPI返却から除外しています。

未署名IPA **0.1.13（ビルド14）** に収録。API89テスト、共通処理12テスト、iPhone SE・iPhone 16で各26件・計52件の画面テスト成功。画面はテスト用データで、実機は未確認です。
<!-- MATCH-ACTIONS:END -->

<!-- MATCH-TITLES:START -->
## 戦績の称号（2026-11-06）

各試合のサバイバーの「この試合の称号」に、解読マスター／地形マスター／援助マスター／医療マスター／牽制マスターを追加しました。原設定の名前・条件説明・元画像を使い、プロフィールの徽章とは別に表示します。

取得元は`all_pl_info[].title_recored`。行動キー1・20・7・8・12が原設定の300・3・3・3・180と一致した受信記録だけを表示します。解読の行動記録は`+1`ですが、称号は`1`です。ゲーム本体の非null判定に加え、APIは原設定と数値が一致することも要求し、行動数値から称号を推測しません。空辞書は「称号はありません」、欠落は「未取得」、未知・不一致は未確認件数に分けます。

自己94試合・公開対象の先頭100試合で延べ87人分・96個を照合し、5種類すべて受信しました。元画像5枚のPNG読み込みと視認も確認。モード1・2・8・100で実取得、4・9・101は静的確認とAPIテストまで。10の入れ子・手記等の別モード・ハンターには適用しません。非公開・閲覧条件不明の戦績は返しません。

APIは実データ確認済みで稼働中。API92テスト成功。iPhone 0.1.14（ビルド15）はソース実装のみで、追加2件のUIテストは未実行。GitHub Actions #27はアカウントの支払い・利用上限エラーによりジョブ開始前に停止し、IPAは生成されませんでした。配布済み0.1.13（ビルド14）には称号表示は含まれません。課金設定は変更していません。
<!-- MATCH-TITLES:END -->

<!-- CURRENT-SEASON:START -->
## プロフィールの現シーズン集計（2026-11-06）

`/v1/me`と閲覧が許可されたプロフィールに`current_season_statistics.survivor / hunter`を追加しました。通常戦・ランク戦ごとの対戦数／勝利数／敗北数を、ゲームの`get_now_season_cnt`と同じく「累計−保存された過去シーズンの合計」で算出します。新しいゲームRPC項目の取得ではなく、既存の受信データに裏付けられた算出結果です。

自分のS44、2陣営×2モード×3件数＝12値を受信元と照合。ハンター通常戦の例は累計52−過去47＝5試合、4勝・0敗です。残りを引分として補うことはしていません。他の3プロフィールは統計が非公開で、正規化結果は`null`、元の統計も返さないことを確認。他人の許可された非空データは未確認です。

必要な累計・過去辞書・過去の件数が欠けた項目は未取得にします。ゲームの0初期値をそのまま使わず、欠落と明示的な0を分けます。過去辞書の不正なシーズンや行、負差分、非整数・整数範囲外、勝敗数が対戦数を超える不整合も表示値にしません。保存された過去記録の完全性を独立に保証するものではありません。通常戦・ランク戦以外には適用しません。

APIは実データで確認し、96テストが成功。iPhoneでは「プロフィールの記録」に陣営別記録の「累計／現シーズン」切り替えをソース実装しました。上段の総対戦数・MVP回数は累計のままで、切り替え対象はその下の陣営別記録です。新規2件の画面テストを追加しましたが未実行。ソース版は **0.1.15（ビルド16）**、最新のビルド済みIPAは **0.1.13（ビルド14）** のままです。前回GitHub Actions #27は支払い・利用上限により開始前に停止しており、今回は再ビルドを送信していません。前回の称号表示も引き続きソース実装のみです。
<!-- CURRENT-SEASON:END -->

<!-- PARTICIPANT-RESULTS:START -->
## 戦績の参加者ごとの結果（2026-11-06）

`summary.players[].participant_result`に、ゲームの個別結果の元表記を追加しました。`all_pl_info[].res_type`を`ComuKeys.RES_TYPE`と`BattleRecordUtils.RES_TXT`、日本語辞書に対応させ、「行方不明」「脱出」「完全勝利」「完全敗北」「辛勝」を表示します。チーム全体の勝敗・得点とは別の項目で、チームが勝ったから本人も脱出したと判断することはありません。同じ日本語名になるコードを独自の原因名に置き換えません。

自己94試合と公開対象の先頭100試合で延べ1040人分、9コード・5表記を照合。実取得モードは1・2・8・100、4・9・101は継承経路の静的確認とAPIテストまでです。10の入れ子・手記等の別モードは対象外。新しいゲームRPCの成功ではなく、既存の戦績で受信したフィールドの意味・表示を追加確認しました。

`res_type`・`is_free_exit`の欠落は未取得。未知コード・不正な値やフリー退出の特殊表示は未確認として扱います。後者はゲームの`BTN_QUIT`分岐を静的に確認しましたが、辞書値を個別結果に使う意味を確認できていないため表示しません。今回対象モードの全参加者では`is_free_exit=false`を受信しています。コード0「ゲーム中…」・3「途中退出」は静的確認とテストのみで、実取得した9コードと区別します。非公開・公開条件不明の戦績は結果も返しません。

APIへ反映し99テスト成功。iPhoneの戦績詳細で「本人の個別結果」と各参加者の「個別結果」をソース実装し、元のゲーム内アイコン・使用キャラ・段位表示と併記します。画像の置き換えや新しい推測画像はありません。新規2件のUIテストは未実行です。ソース版は **0.1.16（ビルド17）**、ビルド済みIPAは **0.1.13（ビルド14）** のまま。前回のGitHub Actions支払い・利用上限エラー以降、今回は再ビルドを送信していません。
<!-- PARTICIPANT-RESULTS:END -->

<!-- MOJIN-WEAPONS:START -->
## 手記の加筆の得意武器（2026-11-06）

自己情報`/v1/me/mojin`の`statistics[].favorite_weapons`に「得意武器」を追加しました。元の`weapon_kills`辞書を使い、ゲームの期間選択・上位2種類の表示処理を確認しました。現シーズンは過去辞書をIDごとに差し引きます。アプリは正の値だけを選び、同数をID順にしますが、ゲームの同数順や0を含む辞書の表示との完全一致は未確認です。

実データで確認できたのは累計・現シーズンS1・過去S0の**空の記録3件**です。非空の武器記録はまだ取得していません。空・未受信・不正／矛盾を区別し、未知IDの名前や画像は推測で補いません。数値の対象・単位は未確認なので、APIでは`recorded_count`とし、画面へ独自の撃破数ラベルは付けません。

ゲームのアイテム設定81ID・名前80件を索引し、庇護者の杖・燃える怨恨の元画像2枚をPNG読み込み・目視確認しました。この2種類を自分の得意武器として受信した意味ではありません。全アイテムが武器であること、所持品・現在装備・全81画像の取得も意味しません。他プレイヤーの専用情報は取得していません。

API103テスト成功。非空ケースは模擬テストで確認した段階です。iPhoneには元の名前・画像と期間別の空／未取得を表示する処理をソース実装し、新規2件の画面テストを追加しましたが未実行です。ソース版は **0.1.17（ビルド18）**、ビルド済みIPAは **0.1.13（ビルド14）** のまま。前回のGitHub Actionsの支払い・利用上限エラー以降、今回は再ビルドを送信していません。
<!-- MOJIN-WEAPONS:END -->

<!-- REPORT-FIELDS:START -->
## 通報処理用データの意味と非返却（2026-11-06）

戦績の`character_value_info`は、通報結果画面が品性値の表示に参照する元データと確認できました。`result_utils.on_btn_report_clicked`は辞書を`UIReport`へ渡し、`UIReportResult.init_normal_success`は放置行為・途中退出等の分岐で`dec_character_value`、`ori_character_value[0]`を参照します。元の日本語TIDは「本通報での失点：%sポイント」「失点後品性値：%sポイント」です。別の`dice_data`から値を読む分岐もあり、受信した2値だけで全ケースを算出できる意味ではありません。

除外前の自己戦績94件中4試合、延べ5人分（本人2・他参加者3）で非空の受信を確認。モードは78・8・1でした。記録したのは型・配列長・件数のみです。**受信したことを、通報成立・実際の処分・不正行為・現在の品性値の確認とは扱いません。** 通報操作は一切実行していません。

一般公開・閲覧条件を確認できていないため、APIの返却からこの辞書を除外しました。自己94試合・公開対象100試合のHTTP応答で非返却を確認し、既存の得点・個別結果は延べ1040人分を保持しています。点数の算出・iPhone表示は追加していません。API104テストが成功し、入れ子・本人と他参加者・入力原本の非変更を確認しました。

今回はAPIのみの更新です。ビルド済みIPAは **0.1.13（ビルド14）**、未ビルドのiPhoneソースは **0.1.17（ビルド18）** のまま。新しいIPAや画面検証はありません。
<!-- REPORT-FIELDS:END -->

<!-- MOJIN-STREAK:START -->
## 手記の加筆の最長連続真相解明回数（2026-11-06）

`/v1/me/mojin`の`statistics[].longest_success_streak`に、現シーズン・保存された過去シーズンの記録を追加しました。ゲーム内の元ラベル「最長連続真相解明回数」を使い、自己のS1は0、S0は1をHTTPで確認しました。既存のログイン時スナップショットの意味・表示を追加確認したもので、新しいゲームRPCではありません。

`get_gold_rush_career_stats._scalar_top`は、選んだ過去シーズンの値、またはルートの値を直接読みます。通常の加算項目と違い、過去の合計を引いたり足したりしません。累計選択でもルート0を使う一方でS0は1なので、全期間の最長値という意味は未確認です。アプリは累計では「期間未確認」、APIは`unverified_period`・`value:null`として、最大値を推測しません。

現・過去の欠落は未取得、不正値は無効、受信済み0は0と区別します。ゲームUIは0を「-」と表示しますが、アプリは未知値との区別のため0と表示します。進行中の連続回数・通常戦の連勝・他人の非公開情報は追加していません。

API106テスト成功。iPhoneの期間選択に対応した行をソース実装し、新規2件の画面テストを追加しましたが未実行です。ソース版は **0.1.18（ビルド19）**、ビルド済みIPAは **0.1.13（ビルド14）** のまま。前回のGitHub Actionsの支払い・利用上限エラー以降、今回は再ビルドを送信していません。
<!-- MOJIN-STREAK:END -->

<!-- PRESENCE-DISCLOSURE:START -->
## 状態の公開判定と不明状態の通知修正（2026-11-06）

他プレイヤーの状態について、公開設定が欠落・不正・未知でも内部の状態コードからオンライン／オフラインや時刻を返し得る処理を修正しました。`state_info.state`が明示的な0・1・2でなければ「不明」とし、状態コード・サーバーのログイン／ログアウト時刻を返しません。認証済みの自分のプロフィール情報は維持します。非表示・取り込み中の閲覧者例外も配列として確認し、壊れたリストで処理が落ちたり表示許可になったりしないようにしました。

実HTTPでは、修正前に公開範囲unknownなのにofflineと返していた他プロフィールが、修正後はunknownとなりコード・サーバー時刻のフィールドを返さないことを確認。自己1件の情報と非表示フレンド2件の非返却も維持しました。生の欠落・不正フラグの実受信を直接確認したわけではなく、そのケースはテストで検証しています。状態定数DEFAULT=0・HIDE=1・BUSY=2とAVATAR_NOTICE_STATUSの1〜14もゲーム内設定から静的確認しました。全状態の実遷移を観測した成功とは分けます。

保存された公開不明／非表示の状態も現在値として再開示しません。状態イベント応答・SSEでは該当区間をunknownとし、公開不明の古い配信待ちイベントからもログイン／ログアウト／対戦開始終了を推測通知しません。非表示区間では既知の表示・非表示変更だけを通知条件にします。登録済みの通知対象1件とイベント8件を読み取り確認し、対象・通知ルールの設定自体は変更していません。

API110テスト成功。今回はAPIのみの修正です。iPhoneソースは **0.1.18（ビルド19）**、ビルド済みIPAは **0.1.13（ビルド14）** のままで、新しいビルド・実機確認・APNs配信確認はありません。
<!-- PRESENCE-DISCLOSURE:END -->

<!-- MOJIN-PARTICIPATION:START -->
## 手記の加筆の陣営別参加回数（2026-11-06）

`/v1/me/mojin`の`statistics[].participation_counts`に、サバイバー／ハンターの参加回数を追加しました。ゲーム内の元表記「サバイバー/ハンターモード累計参加回数」を使い、左がサバイバー、右がハンターです。各陣営の受信済み成功数＋失敗数から算出し、累計・現シーズン・保存された過去シーズンで切り替えます。新しいRPCや全期間の個別戦績の取得ではありません。

保存済みの自己ログイン受信データで、累計とS0は「2 / 0」、現S1は「0 / 0」の6値を照合しました。更新後のAPIは起動していますが、ゲーム側ゲートウェイへの再接続がタイムアウトし、新項目のライブHTTP取得は未確認です。保存データでの照合・計算テストを今回のライブ取得成功とは扱いません。 欠落・不正値・負差分・整数範囲外の合計は未取得とし、片方が不明でも他方の受信済み0を残します。他プレイヤーの専用情報取得・表示や、通知対象の変更はありません。

API113テスト成功。iPhoneは承認済みダーク画面に期間選択と連動する1行をソース実装しました。独自の画像は追加していません。新規2件のUIテストは未実行です。ソース版は **0.1.19（ビルド20）**、ビルド済みIPAは **0.1.13（ビルド14）** のまま。GitHub Actionsの既知の支払い・利用上限エラー以降、今回はビルドを送信していません。
<!-- MOJIN-PARTICIPATION:END -->

<!-- LOGIN-REJECTION:START -->
## SDKログイン拒否の判定と案内（2026-11-06）

前回「ゲートウェイのタイムアウト」と記録した接続失敗を調べ、自己SDKログインの`on_login._[0].code=6`を実受信しました。ゲームの`LOGIN_CODE.SAUTH_FAILED=6`と一致し、`ClientBoot.handle_sauth_failed`は`need_sdk_relogin=True`でログイン画面へ戻します。受信TIDは`TID_LOGIN_FAILED_UNKNOWN`です。SDK認証失敗までは確認できましたが、期限切れ・利用停止などの詳しい理由は断定できません。接続先の差異が原因だったという確認でもありません。

位置引数で届くログイン拒否を処理せず、応答待ちのタイムアウトへ進んでいたAPIを修正しました。`/v1/status`は`last_error=SDK_AUTH_REJECTED`、`session_recovery.login_failure={reason:sdk_auth_failed, server_code:6}`を返し、自動再試行を止めます。HTTPでこの状態を確認済みです。元のメッセージ・extra・ban_codeや認証情報は返しません。既存ログインの置き換え・通知設定変更はありません。ログイン復旧と新しいプレイヤー情報の取得は未確認です。

ゲームの成功応答は7・8で、0ではありません。成功応答を受けた場合もAvatar生成まで待ちます。7・8の今回の実ログイン再成功は未確認で、静的確認とテストを分けて記録しています。API118テスト成功。拒否時の非再試行・不正な応答・認証情報の非返却等を確認しました。

iPhoneのホーム・設定にSDK認証失敗と再ログインの案内をソース実装しました。追加したSwift共通2件・UI2件のテストは未実行です。ソース版は **0.1.20（ビルド21）**、ビルド済みIPAは **0.1.13（ビルド14）** のまま。既知のGitHub Actions支払い・利用上限エラー以降、新しいビルドは送信していません。
<!-- LOGIN-REJECTION:END -->

<!-- MOJIN-COLLECTIONS:START -->
## 手記の加筆の展示・倉庫・図鑑の追加調査（2026-11-06）

今回は保存済み自己データとゲーム内処理の調査だけです。新しいログイン・情報取得RPC・画面表示は追加していません。SDK認証失敗のため、現在値の取得・再確認はできていません。

| 対象 | 確認できた差分 | 確認状況 |
| --- | --- | --- |
| プロフィール展示 | `display_magic_gold`は0〜3の4枠。倉庫とは別の選択設定 | 保存済み自己データは空辞書。4枠・公開判定は静的確認。非空の展示は未確認 |
| 自分の倉庫 | `inventory.warehouse.slots`に数値型のid・cnt・durを持つ1行 | 11月5日の保存受信データ。行数を数量にしない。名前・画像・durの意味・現在の全所持品は未確認 |
| 図鑑 | 元の表記は「初収集」「累計収集」「初遭遇」「撃破回数」「被撃破回数」 | 専用の自己用`request_goldrush_collection_guide()`と表示処理の静的確認のみ。実要求・取得成功は未確認 |

図鑑の`goldrush_collect_info`は空で初期化され、専用要求が成功した後に応答が代入されます。初期の空辞書を「図鑑を取得して0件だった」と扱いません。設定による自動解放表示や異象レベル間の参照もあるため、解放表示を収集・遭遇の実績と混同しません。共通データの`first_gold_item_timestamps`・`seen_monster_ids`も保存時は空ですが、それだけで現在の図鑑全体は判断できません。

共通データの保存時刻は2026-11-05T22:52:10.603Z、倉庫を照合したログイン受信の保存時刻は2026-11-05T15:27:27.963Zです。`mojin-read-probe`は選択した4フィールドしか保存しないため、そこに倉庫が無いことを未受信の根拠にせず、別の保存済み`init_player`を確認しました。認証情報・アイテム個体ID・抽出コードの外部送信はありません。

今回の検証は保存データの型・件数・元の日本語名・4枠定数の照合と一覧の整合確認です。アプリ本体は変更していないためAPIテストを再実行しておらず、直近の成功は118件です。iPhoneソース **0.1.20（ビルド21）**、ビルド済みIPA **0.1.13（ビルド14）** のまま。新しいビルド・画面検証はありません。
<!-- MOJIN-COLLECTIONS:END -->

<!-- FREQUENT-CHARACTERS:START -->
## プロフィールの使用回数が最も多いキャラ（2026-11-06）

プロフィール概要に、ゲーム内の元の見出し「使用回数が最も多い」と、上位4キャラの元画像・日本語名を表示するソースを追加しました。保存済みの自己`pid_cnt_all`はサバイバー11・ハンター21の計32キャラ分で、保存済みAPI応答と`init_player`の値が一致しました。4体は「狂眼・道化師・オペラ歌手・幸運児」で、元PNG4枚のHTTP取得と目視も確認しています。現在値の取得成功とは区別します。

ゲームは`player_release_data`の対象IDに絞り、`old_battle_cnt＋new_battle_cnt`で選びます。ヘルパーの候補は6体、プロフィールの表示は先頭4枠です。アプリも4体までを使い、同数はID順ですが、ゲームの同数順との一致は未確認です。今回の4位境界は同数ではありません。旧／新の境界や対象モード・全期間の完全性は未確認なので、この追加表示では回数や勝率を表示しません。取得戦績のモード別使用回数、認知Pt順、キャラ別ランク戦勝率とは別です。

新しい`most_used_characters`は実データ・条件を照合した自分の統計だけに適用し、他人・非公開・不明なら`null`です。ゲームには通常の表示フラグ以外に特殊な相手やAIの非表示分岐もあるため、他人への新表示は追加していません。欠損を0にせず、元の名前や画像を推測で補いません。必要データが欠けるときに、既知の一部だけを全体の上位として扱いません。他プレイヤーの許可された非空の集計は今回未確認です。

API123テスト成功。APIソースへの追加、保存済み自己データでの照合、稼働プロセスへの反映は完了しました。新しいプロフィール項目のHTTP確認は未完了です。更新時の接続復元はSDK認証失敗で停止し、繰り返し再試行していません。素材HTTPの成功をプロフィール取得成功とは記録しません。

iPhoneソースは **0.1.21（ビルド22）**。追加2件のUIテストは未実行で、ビルド済みIPAは **0.1.13（ビルド14）** のままです。既知のGitHub Actions支払い・利用上限エラー以降、今回はビルドを送信していません。
<!-- FREQUENT-CHARACTERS:END -->

<!-- SEASON-CHARACTERS:START -->
## 過去シーズンのキャラ別ランク戦（2026-11-06）

自分の「シーズン別の記録」へ、受信済みキャラの元画像・日本語名、対戦数・勝利数・引分数・勝率を表示するAPIとiPhoneソースを追加しました。保存済み自己ログインと自己API応答の18辞書を照合し、非空の2辞書に3キャラ分を確認しました。確認したデータの取得日は2026-11-05で、今回の新しいプロフィール取得成功とは区別します。

| シーズン・陣営 | キャラ | 対戦数 | 勝利 | 引分 | 勝率（引分除外） |
| --- | --- | --- | --- | --- | --- |
| S37・サバイバー | 傭兵 | 6 | 4 | 1 | 80.0% |
| S37・サバイバー | 幸運児 | 2 | 2 | 0 | 100.0% |
| S35・ハンター | 復讐者 | 1 | 1 | 0 | 100.0% |

ゲームの`UIRankSeasonReview`は各シーズンの`pid_data_rank`を使い、勝率を`win_cnt ÷ (battle_cnt − draw_cnt)`で表示します。アプリの戦績分析では引分を分母に含むため、この追加欄は「勝率（引分除外）」と明記します。分母0はゲームと同じ0.0%で`zero_denominator`を返します。受信済みの空辞書と欠損を区別し、未受信キャラを0戦として増やしません。同数の並びはID順で、ゲームとの完全一致は未確認です。通常戦や現在シーズンの値を過去シーズンへ合算しません。

この新しい表示は、実データ・閲覧条件を確認できた自分だけが対象です。他人は既存統計が公開でも`rank_characters=null`です。`mvp`と`ave_score`も同じ保存レコードにありますが、今回の過去シーズン画面での参照は確認できていないため新規表示を加えていません。元PNG3枚の素材HTTP取得と目視は確認済みです。

API128テスト成功。APIのソース実装と保存データ照合は完了し、稼働中プロセスへの読み込みは次の再起動待ちです。SDK認証失敗のままなので、今回ログインの再試行やAPIの再起動は行っていません。最新プロフィールHTTPとiPhone画面での確認は未完了です。

iPhoneソースは **0.1.22（ビルド23）**、追加2UIテストは未実行。ビルド済みIPAは **0.1.13（ビルド14）** のままです。既知のGitHub Actions支払い・利用上限エラー以降、今回はビルドを送信していません。
<!-- SEASON-CHARACTERS:END -->

<!-- AMUSEMENT-RECORDS:START -->
## Blackjack・悪夢の影の追加調査（2026-11-06）

今回は保存済み自己ログインとゲーム内参照処理を照合し、取得情報一覧へ4項目を追加しました。最新のゲーム接続はSDK認証失敗のままです。調査の確認日時は、保存データの取得日時（2026-11-05T15:27:27.963Z）とは別です。

| 情報 | 保存データ・確認した内容 | 確認段階 |
| --- | --- | --- |
| Blackjackの自己対戦・シーズン記録 | ルートの対戦・勝利・敗北数は各0、過去S35〜43の9辞書と45個のカウント・得点値も0。週辞書は明示的な空 | 受信項目＋静的参照。非0実績・最新HTTPは未確認 |
| 悪夢の影の自己週記録 | 12週でポイント0、個人・チームの最短タイムは計24件が明示的null。24件とも時刻メタデータは正の数値 | 受信項目＋静的参照。非nullの実タイムは未確認 |
| Blackjack週ポイントランキング | 元の見出し、`rank_bj_week`の要求、順位／百分位の表示経路 | 静的確認のみ。順位表応答は未取得 |
| 悪夢の影のマップ別ランキング | 月の河公園／黄金の石窟の個人ポイント・個人タイム要求。チームタイム用の定数と自己表示処理 | 静的確認のみ。チーム順位表の要求と実応答は未確認 |

Blackjackの通常得点と週ポイントは別です。週記録がないときの内部値`-1`を、取得した負の得点として扱いません。悪夢の影は個人・チーム、マップ別の接尾辞付きキーを分けています。黄金の石窟用`*_1101`は今回の保存応答にはなく、0に補完しません。

最短タイムがnullでも`*_tm`は存在したため、時刻の存在を実タイムや対戦済みの証拠にしません。ゲームの週番号は独自の基準時刻と補正で決まり、端末のISO暦週や「現在週」に置き換えません。保存された週ポインターはBlackjackが363、悪夢の影が461ですが、これを最新週と断定していません。

自己データは0／未記録だけ、他人の閲覧条件と順位表の実応答も未確認のため、今回はAPI返却項目・iPhone画面を増やしていません。読み取り調査と一覧更新のみです。新しいゲームRPC・ログイン・設定変更・ビルド送信はありません。

調査スクリプトで保存値、元日本語名、定数、29個の静的参照条件、ソースZIPとIPAの不変を検証しました。API・iPhoneのソースは変更していないためAPIテストは再実行しておらず、直近成功は128件です。ソース **0.1.22（ビルド23）**、ビルド済みIPA **0.1.13（ビルド14）** のまま。新しい画面検証はありません。
<!-- AMUSEMENT-RECORDS:END -->

<!-- SESSION-PUBLIC:START -->
## PC用接続コード・公開相手への表示拡張（2026-11-06）

以下は0.1.23時点の実装記録です。最新のソース・保存済みIPA・検証結果は冒頭と「次版ソース」の欄を参照してください。

PCで自分のゲームにログインし、取得ツールの「取得」→「コピー」で IDV1. 接続コードを作ります。iPhoneソース0.1.23の「設定」→「ゲームの接続コードを入力」で貼り付け、PCゲームを終了してから「保存して接続」を使います。PCのAPIは起動したまま使います。APIのURL・認証鍵は別に設定します。コードはログイン情報として扱い、共有しないでください。

ビルド済みEXEと同じ.NET Frameworkの処理で本人の実プロセスから新しいコードを取得し、稼働APIへの取り込み・DPAPI保存値との一致を確認しました。PCゲーム終了後は replace_existing=false でAPIの独立ログインに成功。自己プロフィール・フレンド9件の新規取得も確認しました。SDKの有効期限や以前の拒否原因は未確認です。最初のPowerShell 7による検証は.NETの相違で失敗し、EXEと同じWindows PowerShellで確認し直しています。

| 公開相手への追加項目 | 最新の実データ確認 |
| --- | --- |
| 常用キャラ・過去シーズンのキャラ別ランク戦成績 | 公開相手で常用4体・過去成績93件 |
| 手記の現在／最高段位・探索統計・常用職業・得意武器・シーズン記録 | 3人の専用公開プロフィールで受信・正規化 |
| 手記の戦績・参加者・モード別分析 | 2人各50件。全100件の記録ID・元マップ名・モード名、計228参加者行。手記指定の戦績ページと分析HTTP200 |
| 非公開の判定 | 別の相手の手記戦績は403。通常プロフィールの非公開統計も返却せず |

通常の応答を受信した後、項目ごとの公開設定を確認し、許可された情報だけAPI・画面に渡します。手記戦績は取得前の閲覧条件に加えて受信後にも最新設定を照合し、公開が撤回されたデータを返却・分析・キャッシュへ流しません。非公開の状態から追加取得する処理は入れていません。通常統計・手記個人情報・手記戦績それぞれの許可を独立して判定します。欠損は0に置き換えません。ゲーム内の元画像と日本語名を使います。

API138テスト成功。コード取り込み、不正コード400、認証情報不変、受信後の公開撤回・異なる相手・セッション変更による破棄を検証しました。最新のAPI接続・公開情報取得成功と、iPhoneでの表示確認は別です。新しいiPhoneのコンパイル・UIテストは未実行。ソースZIPは55ファイルを照合済みです。
<!-- SESSION-PUBLIC:END -->

<!-- SCORE-RECEIPT-EVIDENCE:START -->
## 2026-11-06：内部名の数値とハンター人格の追加確認

| 項目 | 新しい根拠 | 状態・表示 |
| --- | --- | --- |
| 本人のhide_score系 | 保存済み本人データと今回のinit_playerで、両陣営の現在データ6項目の数値を確認。保存済み過去シーズンには18項目。 | 受信項目の確認。rank付き2項目の段位ポイントとの一致を追加確認（下表）。更新式や適用範囲は未確認。API・iPhoneへ追加表示せず |
| 他人のhide_score系 | 通常プロフィール3人分を表示フィルターの前で確認。統計公開2人・非公開1人とも、現在データには対象6項目なし。 | この通常経路で他人の内部値は未取得。GM要求は送らず、権限回避も行っていない |
| gm_show_hide_score | 呼び出し名と空のクライアント受信処理のみ。本人のinit_playerの数値とは別。 | 管理用応答・通常権限・他人の値は未確認 |
| ハンターの現在の人格 | 他プレイヤー44474049の復讐者、通常ページ2、人格14項目・消費130点・未対応0。元PNG14枚もHTTP200。 | 実取得成功。既存の人格API・画面ソースで扱えることを確認。iPhoneのビルド・実機描画は未確認 |

数値を受信しただけでMMRや公開情報と断定しません。本人の数値はゲームログイン時の本人データで、管理用RPCの成功ではありません。新しい調査では元コード・認証情報を外部へ送らず、チャット送信・マッチング開始・他のログインの置き換え・IPA/EXEビルドは行っていません。
<!-- SCORE-RECEIPT-EVIDENCE:END -->

<!-- RANK-SCORE-MEANING:START -->
## 2026-11-06：ランクでもらうポイントとの関係

| 対象 | 確認結果 | 確認範囲 |
| --- | --- | --- |
| civilian_rank_hide_score / butcher_rank_hide_score | 本人の現在2件はrank_scoreと同値。rank_scoreは初期値800＋sum_starとも一致。 | 保存済み本人データの比較。全アカウント・全段位への一般化は未確認 |
| rank_scoreとsum_star | 本人の現在2件と過去18件で800＋sum_starが一致。シーズン切替処理にも同じrank_score再設定を確認。 | 受信値の比較＋元処理の静的確認 |
| 生涯の獲得ポイント累計か | sum_starは現在の段位から計算され、シーズン切替時に再計算される。勝利時の加点を生涯分足した累計とは区別する。 | PartBase.part2sumstar、両陣営のprocess_part_change |
| rankなしのhide_score | 本人の2値はrank_scoreと異なる。SERVER_MODE限定のログ定義ではking_mmrの出力元。 | 静的な参照用途。現サービスのマッチングへの影響や計算式は未確認 |
| b_付きのhide_score | 本人では800。初期値と同じ数字であっても、未プレイや特定モード用とは断定しない。 | 用途は未確認 |

調査対象はインストール済みbase/patchの31,172エントリーと保存済み本人データです。ゲームコードは実行せず、関連する設定・参照箇所を読み取りました。デコードエラー0件ですが、サーバー専用の実装や稼働中のマッチングロジックを全て入手した意味ではありません。管理用RPC・対戦開始は実行していません。rank_hide_scoreへの実際の代入・更新式は未確認なので、rank_scoreとの一致から独立したMMRと断定しません。

公式の[ランク戦段位・マッチング調整告知](https://www.identityv.jp/news/gonggao/2020/07/21/29435_893798.html)には段位・チーム内の段位差による調整の説明がありますが、今回の6項目との対応を示す資料としては扱っていません。

API・iPhoneの動作コードは変更していません。直近のAPI144件成功を保持し、今回はデータ照合を実施。新しいIPA・EXEのビルドはありません。
<!-- RANK-SCORE-MEANING:END -->

<!-- NON-RANK-HIDDEN-SCORE:START -->
## 2026-11-06：rankなしの陣営別内部値を追加調査

本人の保存時点のcivilian_hide_score / butcher_hide_scoreはrank_scoreと異なり、段位ポイント側が不変でも変動した記録があります。ログ定義ではking_mmr、AI向けプレイヤー情報ではhidden_scoreの出力元として使われます。これらは配布コードの静的な参照であり、今回サーバー処理・AI・管理用機能を実行した意味ではありません。

| 保存済み記録の比較 | 確認できたこと | 限界 |
| --- | --- | --- |
| 両陣営のS38→39 | 段位ポイント側は不変。S39のランク戦0件、通常戦の記録ありで内部値は増加。 | シーズンをまたぐ集計比較。1試合ごとの加点式や因果関係は未確認 |
| サバイバーS36→37 | 通常戦0件・ランク戦の記録ありで内部値が増加。 | 通常戦専用の値と断定しない。シーズン変更の影響も分離できていない |
| サバイバーS37→38・ハンターS35→36 | そのシーズンの通常・ランク戦集計が0件でも前期から内部値が減った例。 | シーズン変更の正確な減衰式は未確認。未集計の別要因も排除できない |
| 元設定 | 初期値800、基礎値テーブル、補正係数を確認。 | 設定名だけで1勝の増減や相手強度補正を計算しない |
| AI向け出力 | 対象2項目をhidden_scoreへそのまま転記する定義。 | APIからAI入力を取得・送信した意味ではない |
| 別のMMR情報 | gateway用パラメータからmmr_infoを読む別経路も存在。 | その値と本人のhide_scoreが同じとは未確認 |

ここでいうAI向け処理は、ゲームに同梱された対戦AIとの連携基盤です。ai_vendorにはfuxi / ailabの識別名、MATCH_BOT_SRCに応じた配置計画、担当キャラや陣営の選択、記録の有効化を分ける処理があります。WorldCollectorは参加者のis_botと対戦状態を集め、hidden_scoreを含む開始データを組み立てます。コード上のボット連携・記録経路の確認であり、本人の特定試合でどのモデルが動作したか、学習に使われたか、hidden_scoreで難易度を決めたかは未確認です。調査ではこの基盤を起動せず、データを送信していません。

| AI連携の段階 | 元のデータ定義で確認した項目・処理 |
| --- | --- |
| 開始時 | マップ・モード・参加者のキャラ、陣営／チーム、BOT判定、段位、ランク戦勝率、キャラ別ランク戦勝率、使用情報、hidden_score、別のmmr_info |
| 対戦中 | 位置・向き・体力・スキル状態・暗号機・板・窓・椅子・ゲート等の状態を整形。AIに送る観測と、返った操作指示を読む処理がある |
| 終了時 | 脱出・脱落結果、勝敗等の終了データを組み立てる |
| 記録 | RL_RECORD_ENABLE等で有効化を分ける。コードの既定値を本人試合の実設定とはみなさない。記録の存在だけでは学習利用を確認したことにならない |

位置・体力等の項目が定義されていることは、全情報が全AIに常時渡る証明ではありません。収集・可視性・AI種別等の分岐があります。またinferという行動推定の要求と、モデルの学習・更新は別の工程です。今回確認したのは観測を渡して操作結果を受け取る定義と記録の設定までで、モデルの中でhidden_scoreをどう利用するかは分かっていません。

king_mmrはログの項目名です。log_race_civ_maze_pro_battle_fighterでは両陣営のhide_scoreを格納しますが、log_race_civ_maze_battle_fighterではmaze_search_gold_mmrを格納します。同じラベルが別の出力元にも使われるため、全モードで一意の指標名とは扱いません。kingという語の由来は未確認です。

「強敵対抗」「猛者対抗」の日本語名と+1/+2の段位ポイント設定も確認しましたが、条件表はpart_score_diff等を参照しており、今回の2値の増減式とは結び付けていません。UIのhide_score_detailは得点詳細を閉じる処理で、内部値の表示機能とは区別しました。

調査は本人の保存済みデータとインストール済みコード・設定の読み取りだけです。31,172エントリーのバイト検索では383候補があり、短いmmr文字列の偶然一致を除いて63の現行モジュールを解析、関連する101箇所のシンボル参照を確認しました。この全てが本人の2値に関係する意味ではなく、別モード・UI操作・文字列だけの一致を分けています。配布コードの範囲で対象2項目の更新本体を特定できていないため、サーバーの計算式・相手補正・AI補正・連勝補正・シーズン継承式は未確認です。

数値を推測で強さ順位や段位へ変換せず、API・iPhoneの表示は追加していません。APIの動作コードとネイティブソースは変更せず、IPA・EXEの追加ビルドもありません。
<!-- NON-RANK-HIDDEN-SCORE:END -->
