// Reconcile saved self data with inspected game definitions; no game RPC is sent.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const comparison=read('.private/research/internal-vs-rank-score-own-comparison.json');
const config=read('.private/research/221fd3fc04ac50d4a431cb301664b67c.config.json');
const base=config.data.init_kill_hide_score;
assert.equal(base,800);assert.equal(config.data.init_break_hide_score,800);
const current=[],history=[];
for(const [camp,data]of Object.entries(comparison.camps)){
 const row=data.current,rank=row[camp+'_rank_score'],hidden=row[camp+'_rank_hide_score'];
 assert.equal(rank,base+row.sum_star);assert.equal(hidden,rank);
 assert.notEqual(row[camp+'_hide_score'],rank);
 current.push({camp,rank_score_equals_base_plus_sum_star:true,rank_hide_score_equals_rank_score:true,non_rank_hide_score_differs:true});
 for(const row of data.history){assert.equal(row[camp+'_rank_score'],base+row.sum_star);history.push({camp,season:row.season,rank_score_equals_base_plus_sum_star:true,rank_hide_score_received:Object.hasOwn(row,camp+'_rank_hide_score')});}
}
assert.equal(current.length,2);assert.equal(history.length,18);
const proof={checked_at:new Date().toISOString(),snapshot_at:comparison.snapshot_at,scope:'saved_self_only',base,current,history,rank_hide_formula_generalized:false,game_requests_sent:false,game_code_executed:false,app_behavior_changed:false,sources:{global_data:'221fd3fc04ac50d4a431cb301664b67c',civilian_data:'8ec7e33aa408ffd23518c99a6ab3c055',butcher_data:'644d2a1618b747c2487d029ac0c9285f',part_base:'ed0d77cd79c988f5ebd2d43f31197a66',server_log_definition:'a70f2c44868c5eec0715712e10cd827f'}};
fs.writeFileSync('.private/research/internal-score-meaning-verification.json',JSON.stringify(proof,null,2)+'\n');

const cap=read('capabilities.json'),own=cap.items.find(r=>r.id==='own_internal_score_received_fields');
own.meaning='本人ログインで受信する数値。rank付き2項目は保存済み本人の現在値でrank_scoreと一致し、段位ポイントに関係する値と見られる。rankなし2項目はSERVER_MODE限定ログのking_mmrの出力元として静的確認。b_付き2項目の用途は未確認。gm_show_hide_scoreの応答とは区別する。';
own.condition='本人の現在データ6項目と保存済み過去シーズン18項目の存在を確認済み。追加照合ではrank_scoreの現在2件＋過去18件が初期値800＋sum_starに一致し、現在2件のrank_hide_scoreもrank_scoreと一致。ただしrank_hide_scoreへの実代入・更新式、全アカウント・全段位で同一になるかは未確認。rankなし2項目がログ定義のMMR欄に参照されることは、実サービスの現在のマッチング式の確認とは区別。b_の意味や800である理由を推測しない。新しいAPI・iPhone表示は追加しない。';
const sourceNote=' 追加根拠：CivilianData / ButcherData.process_part_change、PartBase.part2sumstar / hide_score2part、global_dataのinit_kill_hide_score / init_break_hide_score、UtilsLog.log_race_civ_maze_pro_battle_fighterのSERVER_MODE分岐。';
if(!own.source.includes(sourceNote))own.source+=sourceNote;
const evidence={status:'received',at:proof.checked_at,record:'.private/research/internal-score-meaning-verification.json',detail:'保存済み本人の現在2件・過去18件のrank_scoreに800＋sum_starが一致。現在2件のみrank_hide_scoreも同値。過去のrank_hide_scoreは未受信で、同じ式と断定しない。静的なシーズン切替処理はrank_scoreを同じ基準で再設定する。'};
own.evidence=[...(own.evidence??[]).filter(e=>e.record!==evidence.record),evidence];
const item={id:'internal_rank_score_relation',label:'本人のrank_hide_scoreと段位ポイントの照合',status:'received',meaning:'ランク戦の生涯加点合計と独立MMRを混同しないため、保存済み本人のrank_hide_score・rank_score・sum_starを比較した結果。',fields:['現在2件のrank_hide_score = rank_score','現在2件＋過去18件のrank_score = 800 + sum_star','rankなしhide_scoreは別値','rank_scoreはシーズン切替時に現在段位から再設定'],condition:'本人の保存スナップショットで比較。sum_starはPartBase.part2sumstarが段位・段階・現在のpart_starから求める段位ポイントで、勝利加点を生涯分足し続ける値ではない。静的なprocess_part_changeはsum_starを再計算し、初期値800を足してrank_scoreを設定する。rank_hide_scoreの一般的な更新式は未確認のため、今回の一致を全アカウント・高段位・将来のシーズンへ一般化しない。',source:'CivilianData（8ec7e33aa408ffd23518c99a6ab3c055）/ ButcherData（644d2a1618b747c2487d029ac0c9285f）.process_part_change、PartBase（ed0d77cd79c988f5ebd2d43f31197a66）.part2sumstar、global_data（221fd3fc04ac50d4a431cb301664b67c）。.private/research/internal-vs-rank-score-own-comparison.json / internal-score-meaning-verification.json',evidence:[evidence,{status:'static',record:'.private/research/internal-score-rank-reset-civilian.txt / internal-score-rank-reset-hunter.txt',detail:'シーズン切替時に段位からsum_starを再計算し、初期値800＋sum_starでrank_scoreを設定する。rank_hide_scoreの代入式が確認できたという意味ではない。'}]};
const i=cap.items.findIndex(r=>r.id===item.id);if(i<0)cap.items.push(item);else cap.items[i]=item;
cap.updated_at=proof.checked_at.slice(0,10);cap.last_reviewed_at=proof.checked_at;fs.writeFileSync('capabilities.json',JSON.stringify(cap,null,2)+'\n');

let text=fs.readFileSync('README.md','utf8');
text=text.replace('受信項目の確認。単位・意味・計算方法は未確認。API・iPhoneへ追加表示せず','受信項目の確認。rank付き2項目の段位ポイントとの一致を追加確認（下表）。更新式や適用範囲は未確認。API・iPhoneへ追加表示せず');
const start='<!-- RANK-SCORE-MEANING:START -->',end='<!-- RANK-SCORE-MEANING:END -->';
const section=`${start}
## 2026-11-06：ランクでもらうポイントとの関係

| 対象 | 確認結果 | 確認範囲 |
| --- | --- | --- |
| civilian_rank_hide_score / butcher_rank_hide_score | 本人の現在2件はrank_scoreと同値。rank_scoreは初期値800＋sum_starとも一致。 | 保存済み本人データの比較。全アカウント・全段位への一般化は未確認 |
| rank_scoreとsum_star | 本人の現在2件と過去18件で800＋sum_starが一致。シーズン切替処理にも同じrank_score再設定を確認。 | 受信値の比較＋元処理の静的確認 |
| 生涯の獲得ポイント累計か | sum_starは現在の段位から計算され、シーズン切替時に再計算される。勝利時の加点を生涯分足した累計とは区別する。 | PartBase.part2sumstar、両陣営のprocess_part_change |
| rankなしのhide_score | 本人の2値はrank_scoreと異なる。SERVER_MODE限定のログ定義ではking_mmrの出力元。 | 静的な参照用途。現サービスのマッチングへの影響や計算式は未確認 |
| b_付きのhide_score | 本人では800。初期値と同じ数字であっても、未プレイや特定モード用とは断定しない。 | 用途は未確認 |

調査対象はインストール済みbase/patchの31,172エントリーと保存済み本人データです。ゲームコードは実行せず、関連する設定・参照箇所を読み取りました。デコードエラー0件ですが、サーバー専用の実装や稼働中のマッチングロジックを全て入手した意味ではありません。管理用RPC・対戦開始は実行していません。rank_hide_scoreへの実際の代入・更新式は未確認なので、rank_scoreとの一致から独立したMMRと断定しません。

公式の[ランク戦段位・マッチング調整告知](https://www.identityv.jp/news/gonggao/2020/07/21/29435_893798.html)には段位・チーム内の段位差による調整の説明がありますが、今回の6項目との対応を示す資料としては扱っていません。

API・iPhoneの動作コードは変更していません。直近のAPI144件成功を保持し、今回はデータ照合を実施。新しいIPA・EXEのビルドはありません。
${end}`;
const a=text.indexOf(start),b=text.indexOf(end);text=a>=0&&b>a?text.slice(0,a)+section+text.slice(b+end.length):text.trimEnd()+'\n\n'+section+'\n';
fs.writeFileSync('README.md',text);
console.log(JSON.stringify({capabilities:cap.items.length,current_rank_hide_equalities:current.length,rank_score_formula_matches:current.length+history.length,general_update_formula_verified:false,game_requests_sent:false,build_run:false}));
