import fs from 'node:fs';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8')),write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n');
const proof=read('.private/research/persona-verification.json'),cap=read('capabilities.json');
const items=[
 {id:'ranking_character_persona',label:'ランキングから他プレイヤーのキャラ別人格',status:'live',meaning:'選択したキャラクターに現在設定されている人格ページの獲得項目・レベル・消費人格点。試合当時の構成とは区別する。',fields:['player_id / character_id / character_name / character_asset / camp','page_id / status / access / received_at','items[].id / name / level / asset / branch / layer / node_seq','used_points / unmapped_count'],condition:'通常のランキング人格ボタンと同じget_data_from_cache(db_name=entities,key_lst=[文字列ID],client_cb=reply_get_genius_data,need_fields=[],ignore_fields=[])で受信後、ask_player_cil_butcher_dataをfreshで再取得しopen_talentを独立判定。公開設定不明409・非公開403・相手や応答形式不明502。返された人格側の明示的な非公開・不正な設定も拒否。相手違い・取得中のセッション変更を破棄し、原本をAPIへ出力・保存キャッシュしない。オンライン状態を公開許可の代わりにしない。pid_to_geniusの選択ページを使い、100未満の通常ページと10000超のキャラ別ページを解析。100〜10000の推奨ページは変換経路未確認のため未取得とし、別のページに置き換えない。人格辞書は元設定80項目・144レベル、同数の元アイコン。',source:'UIRank.on_btn_player_tips / UICharRank.on_btn_player_tips、UITipsBase.click_perosona_map（1259e283596adfed11cbac8c163eb4c4）、Avatar.get_data_from_cache / reply_get_genius_data / get_common_stage_genius_pid_and_page（2423b0b1afa1ca08252f8a0e3bdaeb00）、Genius.get_used_genius_point（2c5c98f9ca779b36ec562a040d58e8af）、civilian_genius / butcher_genius / passive_skill / 元日本語辞書。GET /v1/players/{id}/persona?character_id=89。src/game/persona.mjs、resources/persona-display.json、ios/Sources/App/PersonaView.swift',evidence:[{status:'live',at:proof.at,record:'.private/research/persona-verification.json',detail:'他プレイヤー19806845・21536583の曲芸師ページ10089をHTTP200で取得。人格14項目・15項目、消費人格点各130、未対応項目0。別のランキング相手3595139は403 PERSONA_PRIVATE。最初の試行で不正な形式やタイムアウトを受けたが、元の引数の既定値が空配列であることを確認して修正後に成功。'},{status:'tested',detail:'API144テスト成功。取得後の許可判定、相手・セッション変更、非公開・不明、選択ページ・ペア配列の解析を検証。iPhoneは0.1.25/26のソースのみ。追加UIテスト2件は未実行。元PNGの読み込みとHTML配置プレビューは確認したが、iPhone実機・ネイティブ画面の確認とは区別。'}]},
 {id:'spectating_tab_readiness',label:'アプリ内観戦映像の再生調査',status:'static',meaning:'ゲーム内の観戦・録画再生は、ゲーム本体の世界描画と記録片の処理を利用する。アプリ内映像再生は未対応。',fields:[],condition:'Avatar.replay_battle_from_server_recodeはg_world_mgr.on_get_control_info_replay / start_wait_for_readへ渡し、req_read_bunchesは記録片を読む。通常の映像URLやiPhone向け再生方式は未確認。観戦参加要求や録画取得は行っていない。映像を再生できないならタブ不要というユーザーの指示で、観戦タブ・専用画面・仮の一覧APIを削除した。下部はホーム・検索・チャット・通知の4タブ。',source:'Avatar（2423b0b1afa1ca08252f8a0e3bdaeb00）、.private/research/spectating-world-playback.txt / spectating-playback-static.jsonl、ios/Sources/App/IDVViews.swift'},
 {id:'other_player_internal_score',label:'他プレイヤーの内部評価・隠しレート',status:'unknown',meaning:'品性値とは別の内部評価。呼び出し名だけからMMRや数値の意味を断定しない。',fields:['gm_show_hide_score（静的な名称・定義のみ）'],condition:'show_hide_score(args)は引数を使用せずcall_soul_methodへ名前のみを渡し、他プレイヤーのIDを渡す処理はない。受信側GameLogic.gm_show_hide_score(self,info)はCLIENT_STUB・Dict(info)で登録されているが本体はreturn Noneのみ。これはサーバー側実装や返答がないことの証明ではない。通常アカウントの利用権限・返答・数値の意味は未確認。管理用要求は実行せず、架空の値や動作しない表示ボタンは追加していない。',source:'GMコマンドshow_hide_score（a72e1d90994c779235fd0abe17095592）、GameLogic.gm_show_hide_score（a382cf2417bbe248f72a89546f000c7c）、.private/research/internal-score-definition-proof.jsonl / internal-score-receiver.txt'},
 {id:'other_player_full_friend_list',label:'他プレイヤーの全フレンド一覧',status:'unknown',meaning:'相手のフレンド一覧。公開の親密関係や一緒に対戦した相手とは区別する。',fields:[],condition:'確認できたgetFriendsは接続中の本人のnotify_friends_infoを読む。相手の全一覧の正式な公開取得経路・公開条件は未確認。戦績の同伴者からフレンド関係を推定しない。',source:'src/game/provider.mjs getFriends / notify_friends_info'},
 {id:'dark_match_artwork_refresh',label:'得点アイコンの視認性・小さいマップ・ランキング星数',status:'static',meaning:'元PNGを変えずに得点アイコンへ明るい台紙を付け、通常戦績のマップを132×80、探索戦績を160×88へ縮小。ランキングは七段以上を★25形式、六段以下を五段III形式で表示。受信済みの戦績参加者レベルも追加表示。',fields:['ScoreArtwork / MatchOutcomeHeader / MatchMapPreview','Ranking.rankLabel / summary.players[].level'],condition:'iPhone0.1.25/26のソースのみ。HTML配置プレビューは元PNGで目視し、320/375幅の配置を確認。ネイティブのコンパイル・実機確認は未実施。ビルドはユーザーの次の明示依頼まで行わない。通常・手記の非公開エラー時に以前の戦績を消す処理を補完。以前のビルドのUI失敗3ケースは識別子が親から上書きされていた証拠を確認し、accessibilityのコンテナをソースで補完、再実行は未実施。',source:'ios/Sources/App/DesignSystem.swift / ProfileDataViews.swift / ProfileView.swift / MojinHistoryView.swift、ios/Sources/Core/Models.swift / MatchHistoryState.swift、design/refresh-preview.html'}
];
for(const item of items){const i=cap.items.findIndex(v=>v.id===item.id);if(i<0)cap.items.push(item);else cap.items[i]=item;}
cap.updated_at=new Date().toISOString().slice(0,10);cap.last_reviewed_at=new Date().toISOString();write('capabilities.json',cap);
const start='<!-- source-refresh-2026-11-06:start -->',end='<!-- source-refresh-2026-11-06:end -->';
const section=`${start}
## 2026-11-06：他プレイヤーの人格・画面更新（次版ソース）

**iPhoneソースは0.1.25（26）、未ビルドです。** ユーザーの指示により、次に「ビルドして」と依頼されるまでIPA・EXEの新しいビルドは行いません。保存済みIPAは0.1.24（25）のままで、以下の新しい画面は含みません。PCのAPIソースと稼働確認、ネイティブ画面のソース実装、HTML配置プレビューを区別します。

| 追加・調査項目 | 確認できた内容 | 状態 |
| --- | --- | --- |
| ランキングからの他人の人格 | キャラごとの現在の選択ページ、人格名・レベル・元アイコン・消費人格点。19806845の曲芸師14項目・130点、21536583は15項目・130点。3595139は非公開403。 | 他人の実HTTP取得成功。iPhoneはソースのみ |
| 取得後の公開判定 | 通常のget_data_from_cacheで受信後、最新プロフィールのopen_talentを独立確認。非公開・不明は内容を返さず、相手違い・セッション変更も破棄。オフライン表示を理由に判定を省かない。 | 実取得＋拒否を確認、合成テスト済み |
| 人格の対象ページ | pid_to_geniusの通常ページ・キャラ別ページ。100〜10000の推奨ページは変換未確認のため未取得。試合当時の人格は対象外。 | 受信ページのみ。別ページで補わない |
| 元の人格素材 | ゲーム内80項目・144レベルの名称・説明・元PNG参照を追加。元画像の色や形は変更しない。 | 静的照合、元PNG読み込みと配置プレビュー確認 |
| 戦績の見やすさ | 屈強などの暗い元アイコンに明るい台紙。通常マップ132×80、探索マップ160×88。プロフィールと戦績の配置を整理し、既に受信していた参加者レベルを表示。 | ソース実装・配置プレビューのみ |
| ランキングの星数 | 七段以上は「★25」の形式、六段以下は「五段III」。星数未受信は未取得。 | ソース実装のみ |
| 観戦 | 原ゲームの世界描画と記録片の再生を利用する。通常の映像URLは未確認。映像を再生できないなら不要という指示で、観戦タブと仮の一覧APIを削除。 | 再生未対応・タブ削除済み（ソースのみ） |
| 他人の内部スコア | show_hide_scoreは他人のIDを渡さず、gm_show_hide_scoreのクライアント受信処理は空。サーバーの返答・通常権限・意味は未確認。 | 静的定義のみ確認。管理用要求は実行していない |
| 他人の全フレンド一覧 | 自分の一覧とは別。公開取得経路と閲覧条件は未確認。戦績の同伴者をフレンドと推定しない。 | 未確認 |

APIは144テスト成功。人格の追加UIテスト2件、変更したCore・画面テストは未実行です。人格画面は受信済みデータを更新開始時に消し、非公開へ変わった後に前回の人格を残しません。手記戦績の非公開エラーもキャッシュの表示を撤回します。

保存済み0.1.24のクラウドビルドは成功しましたが、iPhone SEのUI46ケース中3ケース（assertion失敗5件）が失敗しました。確認画像・AX階層では名称と値そのものはあり、親のaccessibilityIdentifierが子の識別子を上書きしていました。関連コンテナのソースは補完済みですが、再実行は次回ビルド時です。2台目のUI検証は最初の失敗で未実行。実機インストール・署名・APNs到達は未確認です。

IPA・EXE・検証ログをPCへ保存して受け渡した後、一時公開リポジトリmodule-kit-9246は、ユーザーのGitHub本人確認完了後に削除しました。最新のAPI・追加ソースや認証情報、抽出したゲームコードはそこへアップロードしていません。
${end}`;
let text=fs.readFileSync('README.md','utf8'),a=text.indexOf(start),b=text.indexOf(end);
if(a>=0&&b>a)text=text.slice(0,a)+section+text.slice(b+end.length);
else {const at=text.indexOf('\n\n');text=text.slice(0,at)+'\n\n'+section+text.slice(at);}
fs.writeFileSync('README.md',text);console.log(JSON.stringify({capabilities:cap.items.length,new_items:items.length,source_version:'0.1.25',build:'26',ipa_built:false}));
