// Merge only verified Japanese labels and original game artwork into the local catalog.
import fs from 'node:fs';import path from 'node:path';
import {readThy,lookupUIPath} from './resource-map.mjs';
const game='C:/Loading Bay Games/Identity V',directory='.data/game-assets';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const catalog=read(directory+'/catalog.json'),source=read(directory+'/source.json'),jp=read('.private/research/japanese-tids.json');
const cfg=h=>read('.private/research/'+h+'.config.json').data;
const passive=cfg('49935ed4ce1fe7d4514844e9974de2d2');
const tables=[['base','thd/ui.thy'],['patch','Documents/thd/ui.thy']].map(([source,p])=>({source,table:readThy(path.join(game,p))}));
const text=k=>typeof jp[k]==='string'?jp[k]:null;
catalog.persona={page_rules:{recommended_start:100,character_recommended_start:10000},survivor:{},hunter:{}};
for(const [camp,hash]of [['survivor','208e8bb64a7393b2d1952b821870ac8b'],['hunter','54ba30bb2223bdef9b7c67620cc164b2']]){
 for(const [id,levels]of Object.entries(cfg(hash))){
  catalog.persona[camp][id]={};
  for(const [level,row]of Object.entries(levels)){
   const skill=row.passive_skill_id_lv?.[0],info=passive[skill?.[0]]?.[skill?.[1]],original=info?.ico?'ui/dm65ui/res/image/traits/'+info.ico:null,found=original?lookupUIPath(original,tables):null,key=`persona-${camp}-${id}-${level}`;
   if(found?.md5)catalog.assets[key]={md5:found.md5,resource_path:original};
   catalog.persona[camp][id][level]={name:text(info?.name_tid),asset:found?.md5?key:null,description:text(row.genius_background),branch:row.attr_id,layer:row.layer,node_seq:row.node_seq,cost:row.genius_point};
  }
 }
}
const needed=new Set(Object.values(catalog.assets).map(a=>a.md5));
for(const dir of ['res','Documents/res'])for(const group of ['ui','tex_critical','special_icon','common']){
 const file=path.join(game,dir,group+'.idx');if(!fs.existsSync(file))continue;const idx=fs.readFileSync(file);
 for(let i=0;i<idx.readUInt32LE(12);i++){const r=idx.subarray(32+i*36,68+i*36),hash=r.subarray(0,16).toString('hex');if(needed.has(hash))source.locations[hash]={dir,group,pkg:r[20],offset:r.readUInt32LE(24)+r.readUInt16LE(32),size:r.readUInt32LE(28)};}
}
fs.writeFileSync(directory+'/catalog.json',JSON.stringify(catalog));fs.writeFileSync(directory+'/source.json',JSON.stringify(source));
fs.mkdirSync('resources',{recursive:true});
fs.writeFileSync('resources/persona-display.json',JSON.stringify({source:'installed_game_display_tables',persona:catalog.persona,assets:Object.fromEntries(Object.entries(catalog.assets).filter(([key])=>key.startsWith('persona-')))}));
console.log(JSON.stringify({nodes:Object.values(catalog.persona.survivor).length+Object.values(catalog.persona.hunter).length,levels:Object.values(catalog.persona.survivor).concat(Object.values(catalog.persona.hunter)).flatMap(Object.values).length,original_icons:Object.keys(catalog.assets).filter(k=>k.startsWith('persona-')).length}));
