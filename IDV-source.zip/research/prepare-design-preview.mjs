import fs from 'node:fs';import {GameAssets} from '../src/game/assets.mjs';
const assets=new GameAssets('.data/game-assets'),art=key=>'data:image/png;base64,'+assets.image(key).toString('base64');
const proof=fs.existsSync('.private/research/persona-verification.json')?JSON.parse(fs.readFileSync('.private/research/persona-verification.json','utf8')):{reads:[]},persona=proof.reads.find(p=>p.player_id==='19806845')??{items:[]};
const escape=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let html=fs.readFileSync('design/refresh-template.html','utf8');
for(const [name,key]of Object.entries({portrait:'face-1',rank:'rank-survivor-5',peak:'rank-survivor-peak',map:'map-33',character:'character-89',score1:'match-score-hunter-1',score2:'match-score-hunter-2',score3:'match-score-hunter-3',score4:'match-score-hunter-4'}))html=html.replaceAll('{{'+name+'}}',art(key));
html=html.replace('{{persona-items}}',(persona?.items??[]).map(item=>`<div class="persona"><img src="${art(item.asset)}" alt=""><div><strong>${escape(item.name)}</strong></div><span class="level">Lv.${item.level}</span></div>`).join(''));
if(/\{\{/.test(html))throw Error('Unfilled preview');fs.writeFileSync('design/refresh-preview.html',html);console.log(JSON.stringify({original_artwork:true,persona_nodes:persona.items.length,ipa_build:false}));
