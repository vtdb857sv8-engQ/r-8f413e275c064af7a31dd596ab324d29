import fs from 'node:fs';import path from 'node:path';import {WindowsVault} from '../src/vault.mjs';
const vault=new WindowsVault(path.resolve('.data')),key=vault.get('api-key').token;
const get=async p=>{const r=await fetch('http://127.0.0.1:8787'+p,{headers:{authorization:`Bearer ${key}`},signal:AbortSignal.timeout(25000)});const b=await r.json();return {status:r.status,data:b.data,error:b.error?.code};};
const result={at:new Date().toISOString(),scope:'other_players_only',mutating_game_requests:false,reads:[]};
for(const id of ['19806845','3595139','21536583']){
 const p=await get(`/v1/players/${id}/persona?character_id=89`);
 result.reads.push({player_id:id,http_status:p.status,error:p.error,access:p.data?.access,status:p.data?.status,page:p.data?.page_id,node_count:p.data?.items?.length,used_points:p.data?.used_points,unmapped:p.data?.unmapped_count,items:p.data?.items?.map(x=>({id:x.id,level:x.level,name:x.name,asset:x.asset}))});
 if(p.status===504)break;
}
fs.writeFileSync('.private/research/persona-verification.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
