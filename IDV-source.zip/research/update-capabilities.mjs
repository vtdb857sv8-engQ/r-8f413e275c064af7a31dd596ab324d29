import fs from 'node:fs';
const data=JSON.parse(fs.readFileSync('capabilities.json','utf8')),labels={live:'実データで確認',received:'受信項目を確認',tested:'実装・テスト済み',static:'処理・設定のみ確認',unknown:'未確認'};
const cell=x=>String(x??'').replaceAll('|','／').replaceAll('\n',' ');
const lines=[`## 取得情報一覧（${data.updated_at}）`,'','[構造化した一覧](capabilities.json)を確認に合わせて更新します。実データでの成功、受信フィールド、テスト、静的な処理確認を区別します。静的確認は取得成功やアプリでの利用可能を意味しません。','', '| 情報 | 何の情報か | 確認状況 | 項目・取得条件 | 根拠 |','| --- | --- | --- | --- | --- |',...data.items.map(x=>`| ${cell(x.label)} | ${cell(x.meaning)} | ${labels[x.status]} | ${cell([x.fields?.join('、'),x.condition].filter(Boolean).join('。'))} | ${cell(x.source??'既存のAPI実測・受信・テスト記録（条件欄参照）')} |`)];
const start='<!-- CAPABILITIES:START -->',end='<!-- CAPABILITIES:END -->',section=start+'\n'+lines.join('\n')+'\n'+end;
let readme=fs.readFileSync('README.md','utf8');const a=readme.indexOf(start),b=readme.indexOf(end);readme=a>=0&&b>a?readme.slice(0,a)+section+readme.slice(b+end.length):readme.trimEnd()+'\n\n'+section+'\n';fs.writeFileSync('README.md',readme);
console.log(JSON.stringify({groups:data.items.length,by_status:Object.fromEntries(Object.keys(labels).map(s=>[s,data.items.filter(x=>x.status===s).length]))}));
