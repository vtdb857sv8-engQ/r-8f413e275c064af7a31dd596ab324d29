// Analyze saved self-only values. This does not open a game session or execute game code.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root='.private/research/',read=f=>JSON.parse(fs.readFileSync(root+f,'utf8'));
const saved=read('non-rank-score-history-counts.json'),scan=read('non-rank-score-symbol-uses.json');
const settings=read('221fd3fc04ac50d4a431cb301664b67c.config.json').data;
const current=[];
for(const [camp,data]of Object.entries(saved.camps)){
 const value=data.current[camp+'_hide_score'],rank=data.current[camp+'_rank_score'];
 assert.ok(Number.isFinite(value)&&Number.isFinite(rank));assert.notEqual(value,rank);
 current.push({camp,hidden_score:value,rank_score:rank,different_from_rank:true});
}
const changes=[];
for(const [camp,before,after]of [['civilian','38','39'],['butcher','38','39'],['civilian','36','37'],['civilian','37','38'],['butcher','35','36']]){
 const a=saved.camps[camp].history[before],b=saved.camps[camp].history[after];
 const hidden=k=>k[camp+'_hide_score'],rank=k=>k[camp+'_rank_score'];
 changes.push({camp,before_season:before,after_season:after,hidden_score_before:hidden(a),hidden_score_after:hidden(b),hidden_score_change:hidden(b)-hidden(a),rank_score_before:rank(a),rank_score_after:rank(b),rank_score_change:rank(b)-rank(a),period_normal_battles:b.normal_battle_cnt,period_normal_wins:b.normal_battle_win_cnt,period_rank_battles:b.rank_battle_cnt,period_rank_wins:b.rank_battle_win_cnt,per_match_causation_verified:false});
}
assert.ok(changes.slice(0,2).every(r=>r.rank_score_change===0&&r.hidden_score_change>0&&r.period_rank_battles===0&&r.period_normal_battles>0));
assert.equal(settings.init_break_hide_score,800);assert.equal(settings.init_kill_hide_score,800);
const find=name=>scan.functions.find(f=>f.function.endsWith('.'+name));
assert.ok(find('_fill_PlayerStaticData_hidden_score')?.hits.includes('hidden_score'));
assert.ok(find('_build_player_ctx')?.hits.includes('civilian_hide_score'));
assert.ok(find('log_race_civ_maze_pro_battle_fighter')?.hits.includes('king_mmr'));
const proof={verified_at:new Date().toISOString(),snapshot_at:saved.snapshot_at,scope:'saved_self_only',game_requests_sent:false,game_code_executed:false,current,period_changes:changes,static_references:{log:'UtilsLog.log_race_civ_maze_pro_battle_fighter, SERVER_MODE branch -> king_mmr',player_context:'H55WorldCollector._build_player_ctx -> camp hide_score key',player_export:'H55WorldCollector._fill_PlayerStaticData_hidden_score -> hidden_score',separate_gateway_mmr:'_collect_mmr_info reads room._rl_gateway_param.mmr_info; equality to the per-player hidden_score is unverified'},settings:{initial_break:settings.init_break_hide_score,initial_kill:settings.init_kill_hide_score,base_tables_exist:Array.isArray(settings.base_hide_score_civilian)&&Array.isArray(settings.base_hide_score_butcher),application_of_base_tables_verified:false},search:{package_entries:scan.scanned_entries,byte_candidates:scan.candidate_modules,selected_current_modules_parsed:scan.current_modules,parse_errors:scan.parse_errors.length,symbol_references:scan.functions.length},score_update_formula_verified:false,opponent_strength_correction_verified:false,ai_correction_verified:false,season_reset_formula_verified:false,other_player_public_access_verified:false};
fs.writeFileSync(root+'non-rank-score-deep-verification.json',JSON.stringify(proof,null,2)+'\n');

const cap=JSON.parse(fs.readFileSync('capabilities.json','utf8'));
const item={id:'own_non_rank_hidden_score_analysis',label:'本人の陣営別hide_score（rankなし）の用途・変動',status:'received',meaning:'civilian_hide_score / butcher_hide_scoreは段位ポイント側と異なる本人の内部値。配布コード内のSERVER_MODEログ定義ではking_mmr、AI向けプレイヤー情報ではhidden_scoreの出力元として参照される。現サービスの全マッチング処理で使われるMMRと同一とは断定しない。',fields:['本人の保存時点のcivilian_hide_score / butcher_hide_score','過去シーズン別の値・差分','同期間の通常戦・ランク戦の集計','king_mmr / hidden_scoreへの静的な参照'],condition:'保存済み本人データで段位ポイント不変・ランク戦0件の期間にも2値が増える例を確認。別の期間には通常戦0件・ランク戦ありでの変動例もある。ただしシーズン境界をまたぐ集計の比較であり、1試合ごとの更新や因果関係の確認ではない。シーズン末記録には通常戦・ランク戦が共に0件でも前期と異なる例があり、勝利加点の単純累計とは扱わない。設定には初期値800・基礎値テーブル・補正係数があるが、対象6項目に対する適用順や現在のサーバー更新式は未確認。別途gatewayのmmr_infoもあり、同一値と混同しない。相手の強さ・AI戦・連勝・シーズン変更による補正は未確認。アプリへ推測のMMR・強さ順位・段位換算は追加していない。',source:'本人init_playerとhistory_season_dataの保存値、UtilsLog（a70f2c44868c5eec0715712e10cd827f）.log_race_civ_maze_pro_battle_fighter、H55WorldCollector（1bfaa0495479ca0e524985531d5d0111）._build_player_ctx / _fill_PlayerStaticData_hidden_score / _collect_mmr_info、global_data（221fd3fc04ac50d4a431cb301664b67c）、.private/research/non-rank-score-deep-verification.json',evidence:[{status:'received',at:proof.verified_at,record:'.private/research/non-rank-score-deep-verification.json',detail:'本人の保存時点の2値がrank_scoreと異なる。S38→39で段位側不変・通常戦あり・ランク戦なしの値変化を確認。通常戦なしの別期間、試合数0の別期間での差分も区別して記録。単一試合の増減、最新値、他人の値を取得した意味ではない。'},{status:'static',record:'.private/research/non-rank-score-player.txt / internal-score-log-mmr.txt / non-rank-score-collect.txt',detail:'同じ2項目をking_mmrとhidden_scoreの出力に使う参照を確認。後者は値をそのまま転記する処理。別のgateway mmr_infoを読む処理も存在。いずれも今回実行・外部送信していない。'}]};
item.evidence.push({status:'static',record:'.private/research/ai-purpose-metadata.jsonl',detail:'ai_vendorのfuxi / ailab、MATCH_BOT_SRCに応じたボット配置、担当キャラ・陣営、記録有効化とis_bot収集を確認。本人試合のモデル・実動作・学習利用・hidden_scoreによる難易度制御は未確認。調査では起動・送信していない。'});
item.evidence.push({status:'static',record:'.private/research/king-mmr-mode-log.txt',detail:'king_mmrというログ欄は別のログ関数ではmaze_search_gold_mmrが出力元。全モード共通の一つの値の名前とは判断しない。'});
item.evidence.push({status:'static',record:'.private/research/ai-explanation-infer.txt / ai-explanation-parse-action.txt / ai-explanation-record-switch.txt',detail:'GatewayAdapter.inferは整形済み観測とreward / done / tickをAI連携先へ渡し、parse_actionは応答を操作指示へ変換する定義。開始データにはhidden_score、対戦中データには位置・体力等の状態項目がある。記録有効化は別のRL_RECORD_ENABLEを参照。実試合での動作・モデル・学習利用・入力ごとの難易度制御は未確認。'});
const index=cap.items.findIndex(r=>r.id===item.id);if(index<0)cap.items.push(item);else cap.items[index]=item;
const own=cap.items.find(r=>r.id==='own_internal_score_received_fields');
const note=' rankなし2項目について、AI向けhidden_scoreへの転記と過去シーズンの変動をown_non_rank_hidden_score_analysisで追加確認。';
if(!own.condition.includes(note))own.condition+=note;
cap.updated_at=proof.verified_at.slice(0,10);cap.last_reviewed_at=proof.verified_at;fs.writeFileSync('capabilities.json',JSON.stringify(cap,null,2)+'\n');

let text=fs.readFileSync('README.md','utf8');
const start='<!-- NON-RANK-HIDDEN-SCORE:START -->',end='<!-- NON-RANK-HIDDEN-SCORE:END -->';
const section=`${start}
## 2026-11-06：rankなしの陣営別内部値を追加調査

本人の保存時点のcivilian_hide_score / butcher_hide_scoreはrank_scoreと異なり、段位ポイント側が不変でも変動した記録があります。ログ定義ではking_mmr、AI向けプレイヤー情報ではhidden_scoreの出力元として使われます。これらは配布コードの静的な参照であり、今回サーバー処理・AI・管理用機能を実行した意味ではありません。

| 保存済み記録の比較 | 確認できたこと | 限界 |
| --- | --- | --- |
| 両陣営のS38→39 | 段位ポイント側は不変。S39のランク戦0件、通常戦の記録ありで内部値は増加。 | シーズンをまたぐ集計比較。1試合ごとの加点式や因果関係は未確認 |
| サバイバーS36→37 | 通常戦0件・ランク戦の記録ありで内部値が増加。 | 通常戦専用の値と断定しない。シーズン変更の影響も分離できていない |
| サバイバーS37→38・ハンターS35→36 | そのシーズンの通常・ランク戦集計が0件でも前期から内部値が減った例。 | シーズン変更の正確な減衰式は未確認。未集計の別要因も排除できない |
| 元設定 | 初期値800、基礎値テーブル、補正係数を確認。 | 設定名だけで1勝の増減や相手強度補正を計算しない |
| AI向け出力 | 対象2項目をhidden_scoreへそのまま転記する定義。 | APIからAI入力を取得・送信した意味ではない |
| 別のMMR情報 | gateway用パラメータからmmr_infoを読む別経路も存在。 | その値と本人のhide_scoreが同じとは未確認 |

ここでいうAI向け処理は、ゲームに同梱された対戦AIとの連携基盤です。ai_vendorにはfuxi / ailabの識別名、MATCH_BOT_SRCに応じた配置計画、担当キャラや陣営の選択、記録の有効化を分ける処理があります。WorldCollectorは参加者のis_botと対戦状態を集め、hidden_scoreを含む開始データを組み立てます。コード上のボット連携・記録経路の確認であり、本人の特定試合でどのモデルが動作したか、学習に使われたか、hidden_scoreで難易度を決めたかは未確認です。調査ではこの基盤を起動せず、データを送信していません。

| AI連携の段階 | 元のデータ定義で確認した項目・処理 |
| --- | --- |
| 開始時 | マップ・モード・参加者のキャラ、陣営／チーム、BOT判定、段位、ランク戦勝率、キャラ別ランク戦勝率、使用情報、hidden_score、別のmmr_info |
| 対戦中 | 位置・向き・体力・スキル状態・暗号機・板・窓・椅子・ゲート等の状態を整形。AIに送る観測と、返った操作指示を読む処理がある |
| 終了時 | 脱出・脱落結果、勝敗等の終了データを組み立てる |
| 記録 | RL_RECORD_ENABLE等で有効化を分ける。コードの既定値を本人試合の実設定とはみなさない。記録の存在だけでは学習利用を確認したことにならない |

位置・体力等の項目が定義されていることは、全情報が全AIに常時渡る証明ではありません。収集・可視性・AI種別等の分岐があります。またinferという行動推定の要求と、モデルの学習・更新は別の工程です。今回確認したのは観測を渡して操作結果を受け取る定義と記録の設定までで、モデルの中でhidden_scoreをどう利用するかは分かっていません。

king_mmrはログの項目名です。log_race_civ_maze_pro_battle_fighterでは両陣営のhide_scoreを格納しますが、log_race_civ_maze_battle_fighterではmaze_search_gold_mmrを格納します。同じラベルが別の出力元にも使われるため、全モードで一意の指標名とは扱いません。kingという語の由来は未確認です。

「強敵対抗」「猛者対抗」の日本語名と+1/+2の段位ポイント設定も確認しましたが、条件表はpart_score_diff等を参照しており、今回の2値の増減式とは結び付けていません。UIのhide_score_detailは得点詳細を閉じる処理で、内部値の表示機能とは区別しました。

調査は本人の保存済みデータとインストール済みコード・設定の読み取りだけです。31,172エントリーのバイト検索では383候補があり、短いmmr文字列の偶然一致を除いて63の現行モジュールを解析、関連する101箇所のシンボル参照を確認しました。この全てが本人の2値に関係する意味ではなく、別モード・UI操作・文字列だけの一致を分けています。配布コードの範囲で対象2項目の更新本体を特定できていないため、サーバーの計算式・相手補正・AI補正・連勝補正・シーズン継承式は未確認です。

数値を推測で強さ順位や段位へ変換せず、API・iPhoneの表示は追加していません。APIの動作コードとネイティブソースは変更せず、IPA・EXEの追加ビルドもありません。
${end}`;
const a=text.indexOf(start),b=text.indexOf(end);text=a>=0&&b>a?text.slice(0,a)+section+text.slice(b+end.length):text.trimEnd()+'\n\n'+section+'\n';
fs.writeFileSync('README.md',text);
console.log(JSON.stringify({snapshot_at:proof.snapshot_at,current,period_changes:changes.map(({camp,before_season,after_season,hidden_score_change,rank_score_change,period_normal_battles,period_rank_battles})=>({camp,before_season,after_season,hidden_score_change,rank_score_change,period_normal_battles,period_rank_battles})),capability_items:cap.items.length,score_update_formula_verified:false,game_requests_sent:false,build_run:false}));
