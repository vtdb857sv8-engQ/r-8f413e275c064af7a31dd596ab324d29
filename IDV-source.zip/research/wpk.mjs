// Read-only inspection of the user's installed NeoX packages.
// Format reference: https://github.com/liubairun/NeoXtractor-IDXWPK (idxwpk-dev).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
const nxsKey=`-----BEGIN RSA PUBLIC KEY-----
MIGJAoGBAOZAaZe2qB7dpT9Y8WfZIdDv+ooS1HsFEDW2hFnnvcuFJ4vIuPgKhISm
pY4/jT3aipwPNVTjM6yHbzOLhrnGJh7Ec3CQG/FZu6VKoCqVEtCeh15hjcu6QYtn
YWIEf8qgkylqsOQ3IIn76udV6m0AWC2jDlmLeRcR04w9NNw7+9t9AgMBAAE=
-----END RSA PUBLIC KEY-----`;
export function unpackNxs(b){
 const key=crypto.publicDecrypt({key:nxsKey,padding:crypto.constants.RSA_PKCS1_PADDING},b.subarray(20,148));
 let state=key.readUInt32LE(0);const out=Buffer.from(b.subarray(148));
 for(let i=0;i<out.length;i++){
  out[i]^=(state>>>((i%4)*8))&255;
  if(i%4===3){const ror=(state>>>19)|(state<<13);state=(ror+((ror<<2)>>>0)+0xe6546b64)>>>0;}
 }
 return out;
}
export function unpackLz4(b){
 const out=Buffer.alloc(Math.min(32*1024*1024,Math.max(4096,b.length*32)));let p=0,q=0;
 while(p<b.length){
  const token=b[p++];let literal=token>>>4,match=token&15;
  if(literal===15){let v;do{v=b[p++];literal+=v;}while(v===255&&p<b.length);}
  if(p+literal>b.length||q+literal>out.length)throw new Error('LZ4 bounds');
  b.copy(out,q,p,p+literal);q+=literal;p+=literal;if(p===b.length)break;
  if(p+2>b.length)throw new Error('LZ4 truncated');const offset=b.readUInt16LE(p);p+=2;
  if(!offset||offset>q)throw new Error('LZ4 offset');
  if(match===15){let v;do{v=b[p++];match+=v;}while(v===255&&p<b.length);}
  match+=4;if(q+match>out.length)throw new Error('LZ4 output');for(let j=0;j<match;j++)out[q+j]=out[q+j-offset];q+=match;
 }
 return out.subarray(0,q);
}
export function decodeStage(payload){
 const tag=payload.readUInt16LE(0),p=payload[2],t=payload[3];
 if(![0x4341,0x4350,0x4358].includes(tag))return payload;
 const b=Buffer.from(payload.subarray(8)),n=b.length,want=p?Math.min(n,128*2**(p-1)):0,seed=t+n;
 if(tag===0x4358){for(let i=0;i<want;i++)b[i]^=(seed+i)&255;}
 else{
  const v=(t+n)&255,k=Buffer.alloc(16);
  k.writeBigUInt64LE(0x7c2e6b6a00000000n|((BigInt(n)<<8n)&0xffff0000n)|(BigInt(v)<<8n)|BigInt(n%253),0);
  k.writeBigUInt64LE(0x5c74656e00003630n|((BigInt(v^0x33)<<16n)&0xffffffff00ffffffn)|(BigInt(v|0x2e)<<24n),8);
  const done=Math.floor(want/16)*16;
  if(done){const d=crypto.createDecipheriv('aes-128-ecb',k,null);d.setAutoPadding(false);Buffer.concat([d.update(b.subarray(0,done)),d.final()]).copy(b);}
  const remain=want-done,mirror=Math.min(done,remain);
  for(let i=0;i<remain;i++)b[done+i]^=(seed+i+(i<mirror?b[i]:0))&255;
 }
 const end=Math.min(64,b.length);const orig=Buffer.from(b.subarray(0,end));for(let i=0;i<end;i++)b[i]=orig[end-i-1]^0x5a;
 return b;
}
export function unwrap(data){
 let b=data;
 for(let i=0;i<8;i++){
  const h=b.subarray(0,4).toString('latin1');
  if(h==='NXS3'){b=unpackNxs(b);continue;}
  if(b.subarray(0,4).equals(Buffer.from([0x27,0xe3,0,1]))){b=unpackLz4(b);continue;}
  if(h==='ENON'||h==='NONE'){b=b.subarray(4);continue;}
  if(h==='DTSZ'){b=zlib.zstdDecompressSync(b.subarray(4));continue;}
  if(h==='BILZ'){b=zlib.inflateSync(b.subarray(4));continue;}
  break;
 }
 return b;
}
export function* entries(base){
 const idx=fs.readFileSync(path.join(base,'script.idx'));const files=new Map();
 try{
  for(let i=0;i<idx.readUInt32LE(12);i++){
   const r=idx.subarray(32+i*36,68+i*36),pkg=r[20],size=r.readUInt32LE(28),header=r.readUInt16LE(32),offset=r.readUInt32LE(24);
   if(pkg>15)continue;
   if(!files.has(pkg))files.set(pkg,fs.openSync(path.join(base,`script${pkg}.wpk`),'r'));
   const b=Buffer.alloc(size);fs.readSync(files.get(pkg),b,0,size,offset+header);
   try{yield {i,hash:r.subarray(0,16).toString('hex'),data:unwrap(decodeStage(b))};}catch(e){yield{i,error:e.code||e.name};}
  }
 }finally{for(const h of files.values())fs.closeSync(h);}
}
