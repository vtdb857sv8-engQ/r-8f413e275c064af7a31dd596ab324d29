// Read public character rankings and the normal, post-permission persona API only.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {WindowsVault} from '../src/vault.mjs';
const key=new WindowsVault(path.resolve('.data')).get('api-key').token;
const get=async resource=>{
  const response=await fetch('http://127.0.0.1:8787'+resource,{headers:{authorization:`Bearer ${key}`},signal:AbortSignal.timeout(30000)});
  const body=await response.json();
  return {status:response.status,data:body.data,error:body.error?.code};
};
const result={at:new Date().toISOString(),scope:'other_players_public_persona',mutating_game_requests:false,character_id:1,camp:'hunter',attempts:[]};
const ranking=await get('/v1/rankings?kind=hunter&character_id=1&limit=3');
assert.equal(ranking.status,200,ranking.error);
assert.equal(ranking.data.character_id,1);
result.ranking={requested_limit:3,returned:ranking.data.items.length};
for(const player of ranking.data.items.slice(0,3)){
  const response=await get(`/v1/players/${player.player_id}/persona?character_id=1`);
  const row={player_id:player.player_id,http_status:response.status,error:response.error};
  result.attempts.push(row);
  if(response.status===403||response.status===409)continue;
  if(response.status!==200)break;
  const data=response.data;
  assert.equal(data.player_id,player.player_id);
  assert.equal(data.character_id,1);
  assert.equal(data.camp,'hunter');
  assert.equal(data.access,'permitted');
  Object.assign(row,{access:data.access,status:data.status,page_id:data.page_id,node_count:data.items.length,used_points:data.used_points,unmapped_count:data.unmapped_count,items:data.items.map(({id,name,level,asset,description})=>({id,name,level,asset,description}))});
  if(data.status!=='received'||!data.items.length)continue;
  result.artwork=[];
  for(const item of data.items){
    const response=await fetch(`http://127.0.0.1:8787/v1/assets/${item.asset}.png`,{headers:{authorization:`Bearer ${key}`},signal:AbortSignal.timeout(30000)});
    const bytes=Buffer.from(await response.arrayBuffer());
    assert.equal(response.status,200);
    assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
    result.artwork.push({asset:item.asset,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
  }
  break;
}
fs.mkdirSync('.private/research',{recursive:true});
fs.writeFileSync('.private/research/persona-hunter-verification.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({at:result.at,attempts:result.attempts.map(({items,...row})=>row),original_pngs_verified:result.artwork?.length??0}));
