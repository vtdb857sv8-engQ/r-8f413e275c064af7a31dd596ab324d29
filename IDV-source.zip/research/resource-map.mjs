/* Independent resource index reader. Reads data only; never loads game DLLs or executes game code. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export function xxhash32(value,seed=163){
 const b=Buffer.isBuffer(value)?value:Buffer.from(value),len=b.length;
 let p=0,h;
 const rol=(x,r)=>((x<<r)|(x>>>(32-r)))>>>0;
 const round=(a,w)=>Math.imul(rol((a+Math.imul(w,0x85ebca77))>>>0,13),0x9e3779b1)>>>0;
 if(len>=16){
  let v1=(seed+0x24234428)>>>0,v2=(seed+0x85ebca77)>>>0,v3=seed,v4=(seed+0x61c8864f)>>>0;
  for(;p<=len-16;p+=16){v1=round(v1,b.readUInt32LE(p));v2=round(v2,b.readUInt32LE(p+4));v3=round(v3,b.readUInt32LE(p+8));v4=round(v4,b.readUInt32LE(p+12));}
  h=(rol(v1,1)+rol(v2,7)+rol(v3,12)+rol(v4,18))>>>0;
 }else h=(seed+0x165667b1)>>>0;
 h=(h+len)>>>0;
 for(;p<=len-4;p+=4)h=Math.imul(rol((h+Math.imul(b.readUInt32LE(p),0xc2b2ae3d))>>>0,17),0x27d4eb2f)>>>0;
 for(;p<len;p++)h=Math.imul(rol((h+Math.imul(b[p],0x165667b1))>>>0,11),0x9e3779b1)>>>0;
 h^=h>>>15;h=Math.imul(h,0x85ebca77);h^=h>>>13;h=Math.imul(h,0xc2b2ae3d);h^=h>>>16;
 return h>>>0;
}

export function readThy(filename){
 const b=fs.readFileSync(filename);
 if(b.subarray(0,4).toString()!=='THFB')throw Error('Unsupported resource index');
 const u32=p=>b.readUInt32LE(p);
 const field=(table,index)=>{const v=table-b.readInt32LE(table),offset=b.readUInt16LE(v+4+index*2);return offset?table+offset:0;};
 const follow=p=>p+u32(p);
 const root=8+u32(8),table=follow(field(root,1)),keyTable=follow(field(table,1));
 const keys=follow(field(keyTable,0)),values=follow(field(table,0)),seeds=follow(field(keyTable,2));
 const count=u32(keys),map=new Map();
 for(let i=0;i<count;i++)map.set(u32(keys+4+i*4),{index:i,md5:b.subarray(values+4+i*32+16,values+4+(i+1)*32).toString('hex')});
 return {map,count,seeds:Array.from({length:u32(seeds)},(_,i)=>u32(seeds+4+i*4))};
}

export function canonicalUIPath(logicalPath){return logicalPath.replace(/^ui\//,'').replace(/\.png$/i,'.dds');}

export function lookupUIPath(logicalPath,tables){
 const canonical=canonicalUIPath(logicalPath),key=xxhash32(canonical,163),matches=[];
 for(const {source,table} of tables){const match=table.map.get(key);if(match)matches.push({source,...match});}
 return {path:logicalPath,canonical,key,matches,md5:matches.at(-1)?.md5||null};
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const research=path.resolve('.private/research'),paths=new Set();
 const walk=x=>{if(typeof x==='string'&&x.startsWith('ui/'))paths.add(x);else if(Array.isArray(x))x.forEach(walk);else if(x&&typeof x==='object')Object.values(x).forEach(walk);};
 for(const filename of fs.readdirSync(research).filter(x=>/^(b64ee6|5db99|4f4c).+config\.json$/.test(x)))walk(JSON.parse(fs.readFileSync(path.join(research,filename),'utf8')));
 const tables=[];
 for(const [source,folder]of [['base','C:/Loading Bay Games/Identity V/thd'],['patch','C:/Loading Bay Games/Identity V/Documents/thd']]){
  const file=path.join(folder,'ui.thy');if(fs.existsSync(file))tables.push({source,table:readThy(file)});
 }
 const assets=[...paths].map(p=>lookupUIPath(p,tables));
 const result={rule:'XXHash32(seed=163) of resource path without ui/ prefix; .png becomes .dds',tables:tables.map(({source,table})=>({source,count:table.count,seeds:table.seeds})),count:assets.length,matched:assets.filter(x=>x.md5).length,assets};
 fs.writeFileSync(path.join(research,'hash-support-ui-assets.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify({count:result.count,matched:result.matched,tables:result.tables,examples:assets.filter(x=>/fh_000[1-5]\.png$|fc_0001\.png$|ico_rank_[sh]_[456]\.png$/.test(x.path))},null,2));
}
