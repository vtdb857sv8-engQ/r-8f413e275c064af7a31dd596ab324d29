import fs from 'node:fs';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const cap=read('capabilities.json'),hunter=read('.private/research/persona-hunter-verification.json'),audit=read('.private/research/internal-score-normal-receipt-audit.json');
const own=audit.records.find(r=>r.rpc==='init_player'),profiles=audit.records.filter(r=>r.rpc==='reply_cil_butcher_data');
if(!own||own.fields.length!==6||!own.fields.every(r=>r.numeric)||profiles.length!==3||profiles.some(r=>r.fields.length))throw Error('Evidence changed; review before documenting.');
const persona=cap.items.find(r=>r.id==='ranking_character_persona'),h=hunter.attempts.find(r=>r.http_status===200&&r.status==='received');
if(!h||h.node_count!==14||h.used_points!==130||hunter.artwork.length!==14)throw Error('Review hunter evidence.');
persona.evidence=persona.evidence.filter(e=>e.record!=='.private/research/persona-hunter-verification.json');
persona.evidence.push({status:'live',at:hunter.at,record:'.private/research/persona-hunter-verification.json',detail:'他プレイヤー44474049の復讐者をキャラ別ランキングから選び、通常ページ2の人格14項目・消費130点・未対応0をHTTP200で確認。サバイバーのキャラ別ページ10089とは別に、ハンターの通常ページを実取得。元アイコン14枚もHTTP200・PNGシグネチャ・SHA256で確認。ネイティブ画面のビルド・実機描画は未確認。'});
const internal=cap.items.find(r=>r.id==='other_player_internal_score');
const receiptNote=' 追加の受信確認：本人のinit_playerにはhide_score系6項目の数値がある。一方、通常のask_player_cil_butcher_dataを使った他プレイヤー3人（統計permitted2人・hidden1人）の応答では、両陣営の現在データにこれらの項目は含まれていなかった。公開統計の許可を内部値の公開許可とは解釈しない。gm_show_hide_scoreの返答、他人の値の取得、値の意味は未確認。';
if(!internal.condition.includes(receiptNote))internal.condition+=receiptNote;
internal.evidence=[...(internal.evidence??[]).filter(e=>e.record!=='.private/research/internal-score-normal-receipt-audit.json'),{status:'received',at:profiles.at(-1).at,record:'.private/research/internal-score-normal-receipt-audit.json',detail:'表示フィルターより前の通常プロフィール応答の項目名・型だけを確認。3人とも対象6項目なし。GM要求を送らず、他人のスコア値も保存していない。本人のログイン時のみ対象6項目がnumber。'}];
const item={id:'own_internal_score_received_fields',label:'本人ログインで受信するhide_score系の数値項目',status:'received',meaning:'ログイン本人のcivilian_data / butcher_dataに含まれる内部名の数値。gm_show_hide_scoreの応答や、他プレイヤーの公開スコアとは区別する。MMR・計算方法・単位・モードの意味は未確認。',fields:own.fields.map(r=>r.field),condition:'2026-11-05の保存済み本人スナップショットで現在データ6項目と過去シーズン18項目の存在を確認。2026-11-06の本人init_playerでも現在の6項目が有限の数値であることを再確認。通常・ランク・b_の意味を内部名だけから決めない。意味と公開条件が未確認のためAPI・iPhoneへ追加表示しない。既存の個人資料とログインの読み取りだけを使用し、管理用要求は実行していない。',source:'本人init_player.info.civilian_data / butcher_data。受信前のUI加工ではなくGameSession.receiveの通常受信項目を照合。.private/research/internal-score-received-field-audit.json / internal-score-own-fields.json / internal-score-normal-receipt-audit.json',evidence:[{status:'received',at:own.at,record:'.private/research/internal-score-normal-receipt-audit.json',detail:'本人ログインの現在データで6項目を再受信。新しい記録は項目名・型のみで数値は保存していない。過去の保存済みスナップショットは2026-11-05時点のもので、最新値とは区別。'}]};
const index=cap.items.findIndex(r=>r.id===item.id);if(index<0)cap.items.push(item);else cap.items[index]=item;
cap.updated_at=new Date().toISOString().slice(0,10);cap.last_reviewed_at=new Date().toISOString();fs.writeFileSync('capabilities.json',JSON.stringify(cap,null,2)+'\n');

let text=fs.readFileSync('README.md','utf8');
// Keep the source/build note outside the generated table so future refreshes preserve it.
const noteStart='<!-- source-refresh-2026-11-06:start -->',noteEnd='<!-- source-refresh-2026-11-06:end -->';
const a=text.indexOf(noteStart),b=text.indexOf(noteEnd),table=text.indexOf('<!-- CAPABILITIES:START -->');
if(a>table&&table>=0&&b>a){const note=text.slice(a,b+noteEnd.length);text=text.slice(0,a)+text.slice(b+noteEnd.length);text=text.replace('<!-- CAPABILITIES:START -->',note+'\n\n<!-- CAPABILITIES:START -->');}
const status='現在のソースは **0.1.25（ビルド26・未ビルド）**、保存済みIPAは **0.1.24（ビルド25）** です。直近のAPI検証は144件成功。今回の読み取り調査ではAPI・iPhoneの動作コードを変更していません。新しいIPA・EXEのビルドは、ユーザーの明示依頼まで行いません。\n\n';
if(!text.includes(status)){const p=text.indexOf('\n\n');text=text.slice(0,p+2)+status+text.slice(p+2);}
text=text.replace(/開発中のソースは \*\*0\.1\.23（ビルド24）\*\* です。[^\n]+/,'開発中のソースは **0.1.25（ビルド26・未ビルド）** です。PC用取得EXEと保存済みIPAは0.1.24です。新しい公開人格表示、星数、画面更新は次版ソースに含まれます。実APIの独立接続と他プレイヤーの公開情報取得は確認済みです。iPhoneの今回の変更はコンパイル・実機検証前です。');
text=text.replace('iPhoneアプリの最新版は **0.1.13（ビルド14）** です。','以前の **0.1.13（ビルド14）** では、次の機能を収録しました。');
text=text.replace('138件：Bearer認証','144件成功（直近のAPI検証）：Bearer認証');
text=text.replace('iOS共通部分はソース上14件（追加2件は未実行、直近のビルド済み版は12件成功）です。','iOS共通部分は14件で、保存済み0.1.24のビルドでは成功しました。今回変更したソースでは未実行です。UIテストはソース上48件。直前のビルドでは46件中3ケースが失敗し、2台目は未実行でした。');
text=text.replace('ソース **0.1.23（ビルド24）**。API・iPhoneアプリ・PC用取得ツールを実装しました。現在のビルド済みIPAは **0.1.13（ビルド14）** で、新しい入力欄・画面は未収録です。GitHub Actionsの前回の支払い・利用上限エラー以降、追加のビルド送信はしていません。','以下は0.1.23時点の実装記録です。最新のソース・保存済みIPA・検証結果は冒頭と「次版ソース」の欄を参照してください。');
const route='| GET | `/v1/players/{id}/persona` | `character_id`で選んだキャラの現在の人格。受信後に最新の公開条件を確認し、元アイコン・名称・レベル・消費点を返す。非公開403・不明409 |\n';
if(!text.includes('| GET | `/v1/players/{id}/persona`'))text=text.replace('| GET | `/v1/players/{id}/presence`',route+'| GET | `/v1/players/{id}/presence`');
const start='<!-- SCORE-RECEIPT-EVIDENCE:START -->',end='<!-- SCORE-RECEIPT-EVIDENCE:END -->';
const section=`${start}
## 2026-11-06：内部名の数値とハンター人格の追加確認

| 項目 | 新しい根拠 | 状態・表示 |
| --- | --- | --- |
| 本人のhide_score系 | 保存済み本人データと今回のinit_playerで、両陣営の現在データ6項目の数値を確認。保存済み過去シーズンには18項目。 | 受信項目の確認。単位・意味・計算方法は未確認。API・iPhoneへ追加表示せず |
| 他人のhide_score系 | 通常プロフィール3人分を表示フィルターの前で確認。統計公開2人・非公開1人とも、現在データには対象6項目なし。 | この通常経路で他人の内部値は未取得。GM要求は送らず、権限回避も行っていない |
| gm_show_hide_score | 呼び出し名と空のクライアント受信処理のみ。本人のinit_playerの数値とは別。 | 管理用応答・通常権限・他人の値は未確認 |
| ハンターの現在の人格 | 他プレイヤー44474049の復讐者、通常ページ2、人格14項目・消費130点・未対応0。元PNG14枚もHTTP200。 | 実取得成功。既存の人格API・画面ソースで扱えることを確認。iPhoneのビルド・実機描画は未確認 |

数値を受信しただけでMMRや公開情報と断定しません。本人の数値はゲームログイン時の本人データで、管理用RPCの成功ではありません。新しい調査では元コード・認証情報を外部へ送らず、チャット送信・マッチング開始・他のログインの置き換え・IPA/EXEビルドは行っていません。
${end}`;
const x=text.indexOf(start),y=text.indexOf(end);text=x>=0&&y>x?text.slice(0,x)+section+text.slice(y+end.length):text.trimEnd()+'\n\n'+section+'\n';
fs.writeFileSync('README.md',text);
console.log(JSON.stringify({capabilities:cap.items.length,hunter_nodes:h.node_count,original_pngs:hunter.artwork.length,own_fields:own.fields.length,other_profiles_checked:profiles.length,other_internal_scores_received:false,gm_request_sent:false,app_behavior_changed:false,build_run:false}));
