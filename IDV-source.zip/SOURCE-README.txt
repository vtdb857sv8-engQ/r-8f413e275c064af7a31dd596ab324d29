第五人格 Companion ソース 0.1.27（iPhoneビルド28）

API: src/、test/、package.json
iPhone: ios/（SwiftUI、Core、テスト）、scripts/build-unsigned.sh
PC接続コード取得ツール: windows/SessionCapture.cs、scripts/build-session-capture.ps1
GitHub Actions: .github/workflows/ios-unsigned.yml

これはソース一式です。IPAとEXEの実行ファイルは含みません。
APIはNode.js 24で npm ci → npm test → npm start。
iPhoneのビルドにはXcodeのあるmacOS環境が必要です。
PC取得ツールはWindowsの.NET Framework C#コンパイラーでビルドします。

トークン・認証鍵・取得済みプレイヤーデータ・抽出したゲームコードは含みません。
.data/ の接続先・DPAPI認証情報とゲーム素材は各PCで設定する実行時データです。
READMEの過去の調査欄は当時の結果で、末尾に今回の最新確認を記載しています。
0.1.27の変更: ゲームサーバーから受信できた相手のデータは、相手の公開設定が非表示でも表示するように変更。戦績・統計・徽章・人格・手記が対象で、設定が読めない場合だけ従来どおり隠す。API151テスト成功。
新しいiPhoneソースのコンパイル・UIテストは未実行（UIテスト文言は新方針に更新済み）。現在の完成IPAは0.1.13です。
