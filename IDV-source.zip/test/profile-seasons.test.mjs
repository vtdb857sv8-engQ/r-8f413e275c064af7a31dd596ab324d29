import test from 'node:test';
import assert from 'node:assert/strict';
import {presentProfile} from '../src/game/presentation.mjs';
import {profileOf} from '../src/game/public-data.mjs';
const catalog={rank_rules:{star_scores:{1:20,5:30,7:30},peak_stars:25}};
test('past season records keep camps separate, newest first and missing counters unknown',()=>{
 const profile={field_access:{statistics:'self'},civilian_data:{season_id:44,history_season_data:{43:{part:5,part_lv:3,part_star:90,season_max_part_record:[7,1,99,0,750],rank_battle_cnt:12,rank_battle_win_cnt:7,rank_battle_lose_cnt:3},35:{normal_battle_cnt:0,normal_battle_win_cnt:0},44:{rank_battle_cnt:20},bad:{},0:{}}},butcher_data:{history_season_data:{40:{rank_battle_cnt:1,rank_battle_win_cnt:1,rank_battle_lose_cnt:0}}}};
 const seasons=presentProfile(profile,catalog).season_history;
 assert.deepEqual(seasons.survivor.map(x=>x.season_id),[43,35]);assert.equal(seasons.hunter.length,1);
 assert.equal(seasons.survivor[0].recorded_rank.label,'五段III');assert.equal(seasons.survivor[0].recorded_rank.stars,3);
 assert.equal(seasons.survivor[0].highest_rank.stars,25);assert.equal(seasons.survivor[0].highest_rank.asset,'rank-survivor-peak');
 assert.equal(seasons.survivor[1].statistics[0].total,0);assert.equal(seasons.survivor[1].statistics[0].losses,null);assert.equal(seasons.survivor[1].highest_rank,null);
});
test('unreadable statistics keep normalized season records hidden; explicit hide flags display them',()=>{
 const raw={unique_id:'20',civilian_data:{history_season_data:{43:{rank_battle_cnt:12}}}};
 for(const settings of [undefined,{open_char_data:'unexpected'},{hide_max_history_rank:'unexpected'}])assert.equal(presentProfile(profileOf({...raw,setting_show_info:settings},'10'),catalog).season_history,null);
 assert.equal(presentProfile(profileOf({...raw,setting_show_info:{hide_max_history_rank:true}},'10'),catalog).season_history.survivor.length,1);
 assert.equal(presentProfile(profileOf({...raw,setting_show_info:{}},'10'),catalog).season_history.survivor.length,1);
 const p=presentProfile({field_access:{statistics:'self'},civilian_data:{history_season_data:{43:{rank_battle_cnt:1,rank_battle_win_cnt:2,rank_battle_lose_cnt:0}}}},catalog);
 assert.deepEqual(p.season_history.survivor[0].statistics[1],{mode:'rank',label:'ランク戦',total:null,wins:null,losses:null,consistent:false});
});
test('highest historical rank uses original raw-score slot and never treats tuple slot 2 as stars',()=>{
 const p=presentProfile({field_access:{statistics:'self'},civilian_data:{part:5,part_lv:1,part_star:0,max_part_record:[7,1,1,0,750],history_season_data:{43:{season_max_part_record:[7,1,99,0,720]}}}},catalog);
 assert.equal(p.ranks.survivor.highest.stars,25);assert.equal(p.ranks.survivor.highest.asset,'rank-survivor-peak');assert.equal(p.ranks.survivor.highest.season_id,null);
 const q=presentProfile({field_access:{statistics:'self'},civilian_data:{history_season_data:{43:{season_max_part_record:[7,1,99]}}}},catalog);
 assert.equal(q.season_history.survivor[0].highest_rank.stars,null);assert.equal(q.season_history.survivor[0].highest_rank.asset,'rank-survivor-7');
});
