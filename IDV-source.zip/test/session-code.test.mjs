import test from 'node:test';
import assert from 'node:assert/strict';
import {sessionCodeCredentials} from '../src/session-code.mjs';
const payload=()=>({version:1,issued_at:'2026-11-06T20:00:00.0000000Z',server:'asia',verified:true,login_info:{login_confirm:true,pack_type:1,info:{sdkuid:'synthetic-user',sessionid:'synthetic-session',full_uid:'synthetic-full',client_version:1,sauth_json:JSON.stringify({sdkuid:'synthetic-user',sessionid:'synthetic-session',deviceid:'synthetic-device'})}}});
const encode=value=>'IDV1.'+Buffer.from(JSON.stringify(value)).toString('base64url');
test('PC session code preserves required SDK fields but never authorizes replacement or claims authentication',()=>{
 const parsed=sessionCodeCredentials(' \n'+encode(payload())+'\n');assert.equal(parsed.login_info.info.sessionid,'synthetic-session');assert.equal(parsed.login_info.login_confirm,false);assert.equal(parsed.verified,false);assert.equal(parsed.server,'asia');assert.equal(parsed.captured_at,payload().issued_at);
 assert.deepEqual(parsed.login_info.log_info,{deviceid:'synthetic-device'});
});
test('malformed and oversized session codes expose no input and cannot become SDK credentials',()=>{
 for(const code of [null,'test-token','IDV1.!','IDV1.'+'a'.repeat(15000),encode(null),encode({}),encode({...payload(),version:2}),encode({...payload(),server:'invalid'}),encode({...payload(),issued_at:'yesterday'})]){
  assert.throws(()=>sessionCodeCredentials(code),error=>error.code==='SESSION_CODE_INVALID'&&!error.message.includes('synthetic-session'));
 }
});
test('session import requires matching SDK identities and complete original login fields',()=>{
 for(const mutate of [p=>delete p.login_info.info.sauth_json,p=>p.login_info.info.sdkuid='other',p=>p.login_info.info.sessionid='',p=>delete p.login_info.info.full_uid,p=>p.login_info.info.client_version=0,p=>delete p.login_info.pack_type]){
  const p=payload();mutate(p);assert.throws(()=>sessionCodeCredentials(encode(p)),{code:'SESSION_CODE_INVALID'});
 }
});
