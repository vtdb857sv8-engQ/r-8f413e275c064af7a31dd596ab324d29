import test from 'node:test';
import assert from 'node:assert/strict';
import {presentMojinSelf} from '../src/game/mojin-data.mjs';
import {LiveGameProvider} from '../src/game/provider.mjs';
const catalog={mojin:{parts:{1:{3:{star_score:20,star_slots:2,asset:'rank-mojin-1',game_label:'1段Ⅲ'}}},season_parts:{0:{1:{3:{star_score:10,star_slots:2,asset:'rank-mojin-s0-1'}}}},seasons:{0:{name:'S0-災いの女'},1:{name:'S1-燐光症'}}}};
const snapshot=()=>({player_id:'10',received_at:'2026-11-05T22:00:00Z',common:{season_id:1,part:1,part_lv:3,part_star:25,max_part_record:[1,3,2,99,99],total_deliver_value:60000,total_action_duration:800,history_season_data:{0:{total_deliver_value:20000,total_action_duration:300}},session_token:'secret'},survivor:{win_cnt:3,lose_cnt:2,history_season_data:{0:{win_cnt:1,lose_cnt:1}}},hunter:{win_cnt:1,lose_cnt:0,history_season_data:{0:{win_cnt:0,lose_cnt:0}}}});

test('own Mojin totals, season slices and current season are not double counted',()=>{
  const result=presentMojinSelf(snapshot(),catalog),[all,current,past]=result.statistics;
  assert.equal(result.mode_name,'手記の加筆');assert.equal(result.scope,'self');assert.equal(result.source,'login_snapshot');
  assert.equal(all.total_actions,6);assert.equal(all.successful_actions,4);assert.equal(all.total_deliver_value,60000);assert.equal(all.average_duration_seconds,133);
  assert.equal(current.total_actions,4);assert.equal(current.successful_actions,3);assert.equal(current.success_rate,75);assert.equal(current.total_deliver_value,40000);assert.equal(current.average_duration_seconds,125);
  assert.equal(past.season_id,0);assert.equal(past.total_actions,2);assert.equal(past.success_rate,50);assert.equal(past.total_deliver_value,20000);
  assert.ok(!JSON.stringify(result).includes('secret'));assert.equal(result.common,undefined);
});

test('Mojin rank progress is converted to stars using its season table; highest season stays unknown',()=>{
  const data=snapshot(),result=presentMojinSelf(data,catalog);
  assert.equal(result.current_rank.label,'一段III');assert.equal(result.current_rank.game_label,'1段Ⅲ');assert.equal(result.current_rank.stars,1);assert.equal(result.highest_rank.stars,2);assert.equal(result.highest_rank.season_id,null);
  data.common.season_id=0;const old=presentMojinSelf(data,catalog);assert.equal(old.current_rank.stars,2);assert.equal(old.current_rank.asset,'rank-mojin-s0-1');
  delete data.common.season_id;assert.equal(presentMojinSelf(data,catalog).current_rank,null);
});

test('missing, malformed or inconsistent Mojin counters remain unknown',()=>{
  const data=snapshot();delete data.hunter.win_cnt;data.survivor.lose_cnt=0;data.survivor.history_season_data[0].lose_cnt=2;
  const result=presentMojinSelf(data,catalog);assert.equal(result.statistics[0].total_actions,null);assert.equal(result.statistics[1].survivor.failed,null);assert.equal(result.statistics[1].success_rate,null);
  const empty=presentMojinSelf({player_id:'10'},catalog);assert.equal(empty.current_rank,null);assert.equal(empty.highest_rank,null);assert.equal(empty.statistics[0].total_actions,null);
});

test('the highest Mojin tier keeps the game name instead of inventing an eighth tier label',()=>{
  const data=snapshot(),settings=structuredClone(catalog);
  settings.mojin.parts[7]={[-1]:{star_score:400,star_slots:20,game_label:'7段',asset:'rank-mojin-7'}};
  settings.mojin.parts[8]={[-1]:{star_score:500,star_slots:-1,game_label:'最高峰7段',asset:'rank-mojin-8'}};
  Object.assign(data.common,{part:7,part_lv:-1,part_star:8000,max_part_record:[7,-1,20]});
  const result=presentMojinSelf(data,settings);assert.equal(result.current_rank.label,'最高峰7段');assert.equal(result.current_rank.stars,16);assert.equal(result.highest_rank.label,'最高峰7段');assert.equal(result.highest_rank.asset,'rank-mojin-8');
});

test('own Mojin snapshot requires an active session and never accepts a target player',async()=>{
  const p=new LiveGameProvider({});assert.throws(()=>p.getMojinSelf(),{code:'GAME_NOT_CONNECTED'});
  p.connected=true;p.selfId='10';p.selfInfo={};assert.throws(()=>p.getMojinSelf(),{code:'MOJIN_SELF_DATA_UNAVAILABLE'});
  p.selfInfo={gold_rush_common_data:{part:1},gold_rush_data:{win_cnt:1}};p.selfInfoReceivedAt='2026-11-05T22:00:00Z';
  assert.equal(p.getMojinSelf('20').player_id,'10');assert.equal(p.getMojinSelf().received_at,p.selfInfoReceivedAt);
});

test('additional Mojin counters follow the game period slices and original labels',()=>{
  const data=snapshot(),settings=structuredClone(catalog);
  settings.mojin.stat_fields=[{field:'total_bring_out_item_count',label:'累計詞章解明数'},{field:'total_move_distance',label:'累計移動距離'},{field:'total_kill_boss_count',label:'エンディングクリア回数'},{field:'session_token',label:'not allowed'}];
  settings.mojin.stat_distance_format='%s m';
  Object.assign(data.common,{total_bring_out_item_count:7,total_move_distance:151.75,total_kill_boss_count:2});
  Object.assign(data.common.history_season_data[0],{total_bring_out_item_count:3,total_move_distance:61,total_kill_boss_count:1});
  const [all,current,past]=presentMojinSelf(data,settings).statistics.map(row=>row.additional_statistics);
  assert.equal(all.length,3);assert.equal(all[0].label,'累計詞章解明数');assert.equal(all[0].value,7);
  assert.equal(current[0].value,4);assert.equal(current[1].value,90.75);assert.equal(current[1].display_value,'90 m');
  assert.equal(past[0].value,3);assert.equal(past[1].display_value,'61 m');assert.equal(all[2].label,'エンディングクリア回数');
  assert.ok(!JSON.stringify(all).includes('secret'));assert.ok(!JSON.stringify(all).includes('not allowed'));
});

test('additional Mojin counters distinguish known zero from missing, invalid and inconsistent data',()=>{
  const data=snapshot(),settings=structuredClone(catalog);
  settings.mojin.stat_fields=[{field:'total_bring_out_item_count',label:'累計詞章解明数'},{field:'total_move_distance',label:'累計移動距離'}];settings.mojin.stat_distance_format='%s m';
  data.common.total_bring_out_item_count=0;data.common.history_season_data[0].total_bring_out_item_count=0;
  let rows=presentMojinSelf(data,settings).statistics;
  assert.equal(rows[1].additional_statistics[0].display_value,'0');assert.equal(rows[0].additional_statistics[1].value,null);
  data.common.total_bring_out_item_count=1.2;assert.equal(presentMojinSelf(data,settings).statistics[0].additional_statistics[0].value,null);
  data.common.total_bring_out_item_count=1;data.common.history_season_data[0].total_bring_out_item_count=2;
  assert.equal(presentMojinSelf(data,settings).statistics[1].additional_statistics[0].value,null);
  data.common.total_move_distance=10;delete settings.mojin.stat_distance_format;
  const distance=presentMojinSelf(data,settings).statistics[0].additional_statistics[1];assert.equal(distance.value,10);assert.equal(distance.display_value,null);
});

test('Mojin participation counts keep survivor first and follow all, current and saved periods',()=>{
  const data=snapshot(),settings=structuredClone(catalog);
  settings.mojin.participation_counts_label='サバイバー/ハンターモード累計参加回数';
  const [all,current,past]=presentMojinSelf(data,settings).statistics.map(x=>x.participation_counts);
  assert.equal(all.label,'サバイバー/ハンターモード累計参加回数');
  assert.deepEqual([all.survivor,all.hunter],[5,1]);
  assert.deepEqual([current.survivor,current.hunter],[3,1]);
  assert.deepEqual([past.survivor,past.hunter],[2,0]);
  assert.equal(all.calculation,'sum_of_received_win_and_lose_counts');
  assert.equal(presentMojinSelf(data,{}).statistics[0].participation_counts.label,null);
});

test('Mojin participation counts preserve one known camp when the other is incomplete',()=>{
  const data=snapshot();delete data.survivor.lose_cnt;
  let [all,current,past]=presentMojinSelf(data,catalog).statistics.map(x=>x.participation_counts);
  assert.deepEqual([all.survivor,all.hunter],[null,1]);
  assert.deepEqual([current.survivor,current.hunter],[null,1]);
  assert.deepEqual([past.survivor,past.hunter],[2,0]);
  delete data.hunter.history_season_data[0].lose_cnt;
  [all,current,past]=presentMojinSelf(data,catalog).statistics.map(x=>x.participation_counts);
  assert.deepEqual([current.survivor,current.hunter],[null,null]);
  assert.deepEqual([past.survivor,past.hunter],[2,null]);
  assert.equal(presentMojinSelf({},catalog).statistics[0].participation_counts.survivor,null);
});

test('Mojin participation counts reject overflow, invalid counters and negative season differences',()=>{
  const data=snapshot();data.survivor.win_cnt=Number.MAX_SAFE_INTEGER;data.survivor.lose_cnt=1;
  assert.equal(presentMojinSelf(data,catalog).statistics[0].participation_counts.survivor,null);
  for(const invalid of [-1,1.5,Infinity,'2',null,true]){
    data.survivor.win_cnt=invalid;
    assert.equal(presentMojinSelf(data,catalog).statistics[0].participation_counts.survivor,null);
  }
  data.survivor.win_cnt=0;
  assert.equal(presentMojinSelf(data,catalog).statistics[1].participation_counts.survivor,null);
});
