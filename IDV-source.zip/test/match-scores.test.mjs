import test from 'node:test';
import assert from 'node:assert/strict';
import {presentMatch} from '../src/game/presentation.mjs';
const catalog={match_score_fields:{survivor:['冷静','執着','友好','勇敢'].map((label,i)=>({id:i+1,label,asset:`match-score-survivor-${i+1}`})),hunter:['屈強','鋭敏','威嚇','狡猾'].map((label,i)=>({id:i+1,label,asset:`match-score-hunter-${i+1}`}))}};
const score=(detail_score,utype=2,mode=1)=>presentMatch({common_info:{match_type:mode},all_pl_info:[{utype,detail_score}]},catalog).summary.players[0].score_breakdown;
test('score fields use game category order, camp labels and the sparse dictionary zero convention',()=>{
  const rows=score({'1':61,'3':200,'4':958});assert.deepEqual(rows.map(x=>x.label),['冷静','執着','友好','勇敢']);assert.deepEqual(rows.map(x=>x.value),[61,0,200,958]);assert.equal(rows[1].value_source,'game_default_zero');assert.equal(rows[0].value_source,'received');
  const hunter=score({'1':7206,'2':5052,'3':4702,'4':1360},1,8);assert.deepEqual(hunter.map(x=>x.label),['屈強','鋭敏','威嚇','狡猾']);assert.equal(hunter[0].asset,'match-score-hunter-1');assert.equal(hunter[0].value,7206);
});
test('missing, malformed, unknown-camp and unverified-mode score data are never relabeled or fabricated',()=>{
  for(const detail of [undefined,null,[],0,'0'])assert.deepEqual(score(detail),[]);
  assert.deepEqual(score({},1088),[]);assert.deepEqual(score({},2,102),[]);assert.deepEqual(score({},2,9),[]);
  const rows=score({'1':null,'2':-1,'3':'200','4':Infinity});assert.ok(rows.every(x=>x.value===null&&x.value_source==='unavailable'));
  for(const mode of [1,2,4,8,100]){const zero=score({},2,mode);assert.equal(zero.length,4);assert.ok(zero.every(x=>x.value===0&&x.value_source==='game_default_zero'));}
  assert.equal(presentMatch({common_info:{match_type:1},all_pl_info:[{utype:2,detail_score:{1:20}}]}).summary.players[0].score_breakdown.length,0);
});
