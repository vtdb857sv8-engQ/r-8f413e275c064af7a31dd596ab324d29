import test from 'node:test';
import assert from 'node:assert/strict';
import {frequentCharacters} from '../src/game/frequent-characters.mjs';
import {presentProfile} from '../src/game/presentation.mjs';
import {profileOf} from '../src/game/public-data.mjs';
const row=(old_battle_cnt,new_battle_cnt)=>({old_battle_cnt,new_battle_cnt});
const catalog={profile_most_used:{label:'使用回数が最も多い',released_character_ids:[1,2,14,15,17]},characters:Object.fromEntries([[1,'hunter'],[2,'hunter'],[14,'survivor'],[15,'survivor'],[17,'survivor']].map(([id,camp])=>[id,{name:`元の名前${id}`,camp,asset:`character-${id}`}]))};
const profile=()=>({field_access:{statistics:'self'},civilian_data:{pid_cnt_all:{14:row(20,0),15:row(1,10),17:row(0,8)}},butcher_data:{pid_cnt_all:{1:row(0,15),2:row(2,1),999:row(10000,10000)}}});

test('frequent characters rank both camps by old plus new, filter release data and expose only four identities',()=>{
  const p=profile(),before=JSON.stringify(p),result=presentProfile(p,catalog).most_used_characters;
  assert.equal(result.label,'使用回数が最も多い');assert.equal(result.status,'available');
  assert.deepEqual(result.items.map(x=>x.character_id),[14,1,15,17]);assert.equal(result.items[0].asset,'character-14');
  assert.equal(result.scope,'self_profile_aggregate');assert.equal(result.source_field,'pid_cnt_all');
  assert.ok(!/old_battle_cnt|new_battle_cnt|weight|win_rate/.test(JSON.stringify(result)));assert.equal(JSON.stringify(p),before);
});

test('zero and explicitly empty inputs remain distinct from missing and invalid character counts',()=>{
  let p=profile();p.civilian_data.pid_cnt_all={14:row(0,0)};p.butcher_data.pid_cnt_all={};
  assert.equal(frequentCharacters(p,catalog).items[0].character_id,14);
  p.civilian_data.pid_cnt_all={};assert.deepEqual(frequentCharacters(p,catalog).items,[]);assert.equal(frequentCharacters(p,catalog).status,'available');
  delete p.butcher_data.pid_cnt_all;assert.equal(frequentCharacters(p,catalog).status,'unavailable');
  p=profile();delete p.civilian_data.pid_cnt_all[14].new_battle_cnt;assert.equal(frequentCharacters(p,catalog).status,'unavailable');
  for(const value of [-1,1.5,'2',true,null,Number.MAX_SAFE_INTEGER+1]){p=profile();p.civilian_data.pid_cnt_all[14].old_battle_cnt=value;assert.equal(frequentCharacters(p,catalog).status,'invalid');}
  p=profile();p.civilian_data.pid_cnt_all[14]=row(Number.MAX_SAFE_INTEGER,1);assert.equal(frequentCharacters(p,catalog).status,'invalid');
});

test('frequent character lists follow readable fresh profile disclosure settings',()=>{
  const raw={unique_id:'10',...profile(),setting_show_info:{hide_fre_used_role_info:true}},opts={completeProfile:true,specialFriendIds:[]};
  assert.equal(presentProfile(profileOf(raw,'20',undefined,opts),catalog).most_used_characters.status,'available');
  assert.equal(presentProfile(profileOf({...raw,setting_show_info:undefined},'20',undefined,opts),catalog).most_used_characters,null);
  assert.equal(presentProfile(profileOf(raw,'10'),catalog).most_used_characters.status,'available');
  for(const state of ['hidden','unknown','permitted'])assert.equal(frequentCharacters({...profile(),field_access:{statistics:state}},catalog),null);
});

test('missing release metadata, original names or assets never receive fabricated replacements',()=>{
  const p=profile();assert.equal(frequentCharacters(p,{}).status,'unavailable');
  for(const key of ['name','asset']){const c=structuredClone(catalog);delete c.characters[14][key];assert.equal(frequentCharacters(p,c).status,'unavailable');}
  const c=structuredClone(catalog);c.characters[14].camp='hunter';assert.equal(frequentCharacters(p,c).status,'unavailable');
});

test('ties use deterministic IDs while duplicate or malformed identities cannot corrupt the list',()=>{
  const p=profile();p.civilian_data.pid_cnt_all={17:row(3,2),14:row(3,2),15:row(3,2)};p.butcher_data.pid_cnt_all={};
  assert.deepEqual(frequentCharacters(p,catalog).items.map(x=>x.character_id),[14,15,17]);
  p.butcher_data.pid_cnt_all={14:row(1,2)};assert.equal(frequentCharacters(p,catalog).status,'invalid');
  p.butcher_data.pid_cnt_all={};p.civilian_data.pid_cnt_all={'014':row(3,2)};assert.equal(frequentCharacters(p,catalog).status,'invalid');
});
