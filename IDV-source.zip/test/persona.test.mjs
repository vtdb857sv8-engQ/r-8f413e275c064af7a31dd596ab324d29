import test from 'node:test';import assert from 'node:assert/strict';
import {presentPersona} from '../src/game/persona.mjs';
import {LiveGameProvider} from '../src/game/provider.mjs';import {profileOf} from '../src/game/public-data.mjs';
const catalog={characters:{89:{name:'曲芸師',camp:'survivor'}},persona:{page_rules:{recommended_start:100,character_recommended_start:10000},survivor:{1:{1:{name:'群集心理',branch:1,layer:1,node_seq:1,cost:5,asset:'original'}}}}};
const received={player_id:'20',character_id:89,access:'permitted',players:{pid_to_genius:{89:'2'},civilian_data:{genius:{1:{genius_dict:{1:{1:0}}},2:{genius_dict:{1:{1:1}}}}}}};
test('persona selects the character page, retains original labels and does not substitute another page',()=>{
 const data=structuredClone(received),result=presentPersona(data,catalog);assert.equal(result.page_id,'2');assert.equal(result.items[0].name,'群集心理');assert.equal(result.items[0].asset,'original');assert.equal(result.used_points,5);assert.deepEqual(data,received);
 data.players.pid_to_genius[89]='101';assert.equal(presentPersona(data,catalog).status,'unavailable');
 data.players.pid_to_genius[89]='10001';data.players.pid_genius={'10001':{genius_dict:{1:{1:1}}}};assert.equal(presentPersona(data,catalog).items.length,1);
 data.players.pid_genius['10001'].genius_dict={1:[[1,1]],2:[],3:[],4:[]};assert.equal(presentPersona(data,catalog).items.length,1);
 data.players.pid_genius['10001'].genius_dict={1:[1,2,3]};assert.equal(presentPersona(data,catalog).status,'unavailable');
});
test('persona displays received loadouts even for private disclosure; unknown stays refused',()=>{
 assert.equal(presentPersona({...received,access:'hidden'},catalog).items.length,1);
 for(const access of ['unknown',undefined])assert.throws(()=>presentPersona({...received,access},catalog),e=>e.code==='PERSONA_PERMISSION_UNKNOWN');
 for(const settings of [undefined,null,[],{open_talent:'bad'}])assert.equal(profileOf({unique_id:'20',setting_show_info:settings},'1',undefined,{completeProfile:true,specialFriendIds:[]}).field_access.persona,'unknown');
 assert.equal(profileOf({unique_id:'20',setting_show_info:{open_talent:false}},'1',undefined,{completeProfile:true,specialFriendIds:[]}).field_access.persona,'permitted');
});
test('persona checks latest disclosure after the standard read and does not cache raw data',async()=>{
 for(const access of ['permitted','hidden','unknown']){
  const p=new LiveGameProvider({});p.connected=true;p.session={};const calls=[];
  p.request=async(method,args,callback)=>{calls.push('read');assert.equal(method,'get_data_from_cache');assert.deepEqual(args.key_lst,['20']);assert.deepEqual(args.need_fields,[]);assert.deepEqual(args.ignore_fields,[]);assert.equal(args.client_cb,'reply_get_genius_data');assert.equal(callback,'reply_get_data_from_cache');return {info:{db_name:'entities',client_cb:'reply_get_genius_data',info_dict:{20:{players:received.players}}}};};
  p.getProfile=async(id,{fresh})=>{assert.equal(id,'20');assert.equal(fresh,true);calls.push('permission');return {field_access:{persona:access}};};
  if(access==='unknown')await assert.rejects(p.getPersona('20',{characterId:89}),e=>e.code==='PERSONA_PERMISSION_UNKNOWN');
  else assert.equal((await p.getPersona('20',{characterId:89})).access,access);
  assert.deepEqual(calls,['read','permission']);assert.equal(p.cache.size,0);
 }
});
test('persona rejects mismatched responses and a session changed during receipt',async()=>{
 const p=new LiveGameProvider({});p.connected=true;p.session={};p.getProfile=async()=>({field_access:{persona:'permitted'}});p.request=async()=>({db_name:'entities',client_cb:'reply_get_genius_data',info_dict:{99:{players:received.players}}});
 await assert.rejects(p.getPersona('20',{characterId:89}),{code:'PERSONA_RESPONSE_UNVERIFIED'});
 p.request=async()=>{p.session={};return {};};await assert.rejects(p.getPersona('20',{characterId:89}),{code:'GAME_SESSION_CHANGED'});
});
