import test from 'node:test';
import assert from 'node:assert/strict';
import {presentMojinSelf} from '../src/game/mojin-data.mjs';
const catalog={mojin:{career_usage_label:'常用職業',careers:{1:{name:'智者',asset:'career-mojin-1'},2:{name:'test-career-2',asset:'career-mojin-2'},3:{name:'test-career-3',asset:'career-mojin-3'}}}};
const present=common=>presentMojinSelf({player_id:'10',common},catalog).statistics;

test('own frequent careers use received usage counts, original artwork and independent season slices',()=>{
  const data={season_id:1,career_usage:{1:9,2:6,3:1},history_season_data:{0:{career_usage:{1:8,2:2,3:1}}},session_token:'secret'};
  const [all,current,past]=present(data).map(x=>x.frequent_careers);
  assert.equal(all.label,'常用職業');assert.equal(all.status,'available');assert.deepEqual(all.items.map(x=>[x.career_id,x.use_count]),[[1,9],[2,6]]);
  assert.equal(all.items[0].name,'智者');assert.equal(all.items[0].asset,'career-mojin-1');
  assert.deepEqual(current.items.map(x=>[x.career_id,x.use_count]),[[2,4],[1,1]]);
  assert.deepEqual(past.items.map(x=>[x.career_id,x.use_count]),[[1,8],[2,2]]);
  assert.ok(!JSON.stringify(all).includes('secret'));assert.deepEqual(data.career_usage,{1:9,2:6,3:1});
});

test('an explicit empty career period remains distinct from missing, malformed and contradictory data',()=>{
  const data={season_id:1,career_usage:{1:2},history_season_data:{0:{career_usage:{1:2}}}};
  const current=()=>present(data)[1].frequent_careers;
  assert.equal(current().status,'available');assert.deepEqual(current().items,[]);
  delete data.history_season_data[0].career_usage;assert.equal(current().status,'unavailable');
  data.history_season_data[0].career_usage={1:3};assert.equal(current().status,'invalid');
  data.history_season_data[0].career_usage={2:1};assert.equal(current().status,'invalid');
  for(const career_usage of [null,[],{1:-1},{1:0.5},{'bad':2}])assert.equal(present({career_usage})[0].frequent_careers.status,'invalid');
  assert.equal(present({})[0].frequent_careers.status,'unavailable');
  const unknown=present({career_usage:{99:1}})[0].frequent_careers;assert.equal(unknown.status,'partial');assert.equal(unknown.items[0].name,null);assert.equal(unknown.items[0].asset,null);
});
