import test from 'node:test';
import assert from 'node:assert/strict';
import {modeRecords} from '../src/game/mode-records.mjs';
import {modeFilter,matchesMode} from '../src/game/match-modes.mjs';
import {presentMatch,analyzeMatches,rankOf,presentProfile} from '../src/game/presentation.mjs';
const catalog={mode_rules:{4:{is_custom:true},9:{is_custom:true},14:{is_custom:true},100:{is_custom:false}},rank_rules:{peak_stars:25,star_scores:{7:30}}};
const raw=(mode,id)=>({record_id:id,common_info:{match_type:mode,self_eid:'me',wdf:[1,-1],end_time:100},all_pl_info:[{eid:'me',unique_id:'1',utype:2,team_uid:'party'},{unique_id:'2',utype:2,team_uid:'party'}]});
test('25-star peak art uses game score conversion, historical star counts and the exact boundary',()=>{
  assert.equal(rankOf({part:7,part_star:749},'survivor',44,catalog).asset,'rank-survivor-7');
  assert.equal(rankOf({part:7,part_star:750},'survivor',44,catalog).asset,'rank-survivor-peak');
  assert.equal(rankOf({part:7,part_star:750},'hunter',44,catalog).stars,25);
  assert.equal(rankOf({part:7},'hunter',44,catalog).asset,'rank-hunter-7');
  const profile=presentProfile({field_access:{statistics:'self'},civilian_data:{part:7,part_star:30,max_part_record:[7,-1,25,0,750]}},catalog);
  assert.equal(profile.ranks.survivor.highest.asset,'rank-survivor-peak');assert.equal(profile.ranks.survivor.highest.stars,25);
  assert.equal(profile.ranks.survivor.highest.label,'七段');
});
test('all excludes every configured custom variant, including partner and win-rate statistics',()=>{
  const rows=[2,4,8,9,14,100].map((mode,i)=>presentMatch(raw(mode,String(i)),catalog));
  const all=analyzeMatches(rows);assert.equal(all.total,3);assert.equal(all.by_party_partner[0].total,3);
  const custom=analyzeMatches(rows,{mode:'custom'});assert.equal(custom.total,3);assert.equal(custom.by_party_partner[0].total,2);
  assert.equal(analyzeMatches(rows,{mode:'duo'}).total,2);assert.equal(analyzeMatches(rows,{mode:'rank'}).total,1);
  assert.equal(matchesMode(presentMatch(raw(9,'custom-duo'),catalog),'duo'),false);
  assert.throws(()=>modeFilter('invalid'),{code:'INVALID_MODE_FILTER'});
});
test('filtering happens before paging and public Mojin records use the target-specific permission path',async()=>{
  let mojinCalls=0;const provider={selfId:'1',getMatchHistory:async()=>({items:[raw(4,'custom'),raw(2,'rank'),raw(100,'duo')],total_received:3}),getMojinHistory:async()=>{mojinCalls++;throw Object.assign(new Error(),{code:'TEST_UNAVAILABLE'});}};
  const all=await modeRecords(provider,'1','all',catalog);assert.equal(all.items.length,2);assert.equal(all.mojin_status,'TEST_UNAVAILABLE');assert.equal(mojinCalls,1);
  assert.equal((await modeRecords(provider,'2','custom',catalog)).items[0].record_id,'custom');
  provider.getPlayerMojinHistory=async id=>{assert.equal(id,'2');return {scope:'public',player_id:id,records:[]};};
  assert.equal((await modeRecords(provider,'2','mojin',catalog)).items.length,0);assert.equal(mojinCalls,1);
  assert.equal((await modeRecords(provider,'1','rank',catalog)).items.length,1);
});
test('a combined history never reads or combines data from a replacement session',async()=>{
  let mojinCalls=0;
  const provider={selfId:'1',session:{},getMatchHistory:async()=>{provider.session={};return {items:[raw(2,'rank')]};},getMojinHistory:async()=>{mojinCalls++;return {player_id:'1',records:[]};}};
  await assert.rejects(modeRecords(provider,'1','all',catalog),{code:'GAME_SESSION_CHANGED'});assert.equal(mojinCalls,0);
});
