import test from 'node:test';
import assert from 'node:assert/strict';
import {presentMojinSelf} from '../src/game/mojin-data.mjs';
import {presentMojinStreak} from '../src/game/mojin-streak.mjs';
const settings={longest_success_streak_label:'最長連続真相解明回数'};
const present=common=>presentMojinSelf({player_id:'10',common},{mojin:settings}).statistics.map(x=>x.longest_success_streak);
test('Mojin season peaks use their received values without subtracting, summing, or taking the maximum across periods',()=>{
 const common={season_id:1,max_win_streak:3,history_season_data:{0:{max_win_streak:10}}},[all,current,past]=present(common);
 assert.equal(all.status,'unverified_period');assert.equal(all.value,null);assert.equal(current.label,'最長連続真相解明回数');assert.equal(current.status,'received');assert.equal(current.value,3);assert.equal(past.value,10);
 common.max_win_streak=0;assert.equal(present(common)[1].value,0);assert.equal(present(common)[2].value,10);
 assert.equal(common.history_season_data[0].max_win_streak,10);
});
test('missing, invalid and unsupported streak periods remain distinct from an explicitly received zero',()=>{
 for(const max_win_streak of [null,-1,0.5,'1',true,Number.MAX_SAFE_INTEGER+1])assert.equal(present({season_id:1,max_win_streak})[1].status,'invalid');
 assert.equal(present({season_id:1})[1].status,'unavailable');
 assert.equal(presentMojinStreak({season_id:1,max_win_streak:0},'current',2,settings).status,'unavailable');
 assert.equal(presentMojinStreak({history_season_data:{}},'season',0,settings).status,'unavailable');
 assert.equal(presentMojinStreak({history_season_data:{0:{}}},'season',0,settings).status,'unavailable');
 assert.equal(presentMojinStreak({history_season_data:[]},'season',0,settings).status,'invalid');
 assert.equal(presentMojinStreak({history_season_data:{0:null}},'season',0,settings).status,'invalid');
 assert.equal(presentMojinStreak({history_season_data:{0:{max_win_streak:0}}},'season',0,settings).value,0);
 assert.equal(presentMojinStreak({},'other',null,settings).status,'invalid');assert.equal(presentMojinStreak(null,'current',1,settings).status,'unavailable');
});
