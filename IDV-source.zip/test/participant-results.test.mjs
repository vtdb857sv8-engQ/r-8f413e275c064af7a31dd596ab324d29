import test from 'node:test';
import assert from 'node:assert/strict';
import {participantResult} from '../src/game/participant-results.mjs';
import {presentMatch} from '../src/game/presentation.mjs';
const catalog={match_result_labels:{0:{label:'ゲーム中…',label_key:'TID_BATTLE_END_GAMING'},1:{label:'行方不明',label_key:'TID_BATTLE_END_S_DIE'},5:{label:'脱出',label_key:'TID_BATTLE_END_S_ESCAPE'},10:{label:'辛勝',label_key:'TID_BATTLE_END_H_DRAW'}}};
test('individual results use original labels independently of team victory and score',()=>{
 const match=presentMatch({common_info:{match_type:1,self_eid:'a',wdf:[1,-1]},all_pl_info:[{eid:'a',unique_id:'20',utype:2,res_type:1,is_free_exit:false,total_score:9999},{eid:'b',unique_id:'30',utype:1,res_type:10,is_free_exit:false}]},catalog);
 assert.equal(match.summary.result,'win');assert.equal(match.summary.players[0].participant_result.label,'行方不明');assert.equal(match.summary.players[1].participant_result.label,'辛勝');
 assert.equal(participantResult({utype:2,res_type:0,is_free_exit:0},1,catalog).label,'ゲーム中…');
});
test('missing fields, unknown codes and unverified free-exit override never manufacture a result',()=>{
 for(const res_type of [undefined,null])assert.equal(participantResult({utype:2,res_type,is_free_exit:false},2,catalog).status,'unavailable');
 for(const res_type of ['5',-1,1.5,true,11,999]){const r=participantResult({utype:2,res_type,is_free_exit:false},2,catalog);assert.equal(r.status,'unverified');assert.equal(r.label,null);}
 for(const flag of [true,1,2,'false',{}])assert.equal(participantResult({utype:2,res_type:5,is_free_exit:flag},1,catalog).status,'unverified');
 assert.equal(participantResult({utype:2,res_type:5},1,catalog).status,'unavailable');
 assert.equal(participantResult({utype:2,res_type:5,is_free_exit:false},1,{}).label,null);
});
test('individual result normalization only applies to the statically verified standard display modes and camps',()=>{
 const p={utype:2,res_type:5,is_free_exit:false};for(const mode of [1,2,4,8,9,100,101])assert.equal(participantResult(p,mode,catalog).label,'脱出');
 for(const mode of [10,61,69,73,78,102,103,undefined])assert.equal(participantResult(p,mode,catalog),null);
 for(const utype of [1088,undefined,'2'])assert.equal(participantResult({...p,utype},1,catalog),null);
});
