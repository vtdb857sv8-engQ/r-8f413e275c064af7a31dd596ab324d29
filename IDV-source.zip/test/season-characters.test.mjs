import test from 'node:test';
import assert from 'node:assert/strict';
import {seasonRankCharacters} from '../src/game/season-characters.mjs';
import {presentProfile} from '../src/game/presentation.mjs';
import {profileOf} from '../src/game/public-data.mjs';
const self={field_access:{statistics:'self'}},catalog={characters:{3:{name:'幸運児',asset:'character-3',camp:'survivor'},25:{name:'傭兵',asset:'character-25',camp:'survivor'},1:{name:'復讐者',asset:'character-1',camp:'hunter'}}};
const row=(n,w,d)=>({battle_cnt:n,win_cnt:w,draw_cnt:d});
const normalize=data=>seasonRankCharacters(self,{pid_data_rank:data},'survivor',catalog);
test('season character rates exclude draws and sort received records by battle count',()=>{
 const r=normalize({3:{...row(2,2,0),mvp:0,ave_score:9308},25:{...row(6,4,1),mvp:2,ave_score:7682}});
 assert.equal(r.status,'available');assert.equal(r.mode,'rank');assert.equal(r.rate_basis,'wins_over_battles_minus_draws');
 assert.deepEqual(r.items.map(x=>[x.character_id,x.battle_count,x.wins,x.draws,x.decisive_matches,x.win_rate_display]),[[25,6,4,1,5,'80.0%'],[3,2,2,0,2,'100.0%']]);
 assert.ok(r.items.every(x=>!('mvp'in x)&&!('ave_score'in x)&&!('losses'in x)));
});
test('empty received character dictionary, absent fields and explicit zero are distinct',()=>{
 assert.equal(normalize({}).status,'available');assert.deepEqual(normalize({}).items,[]);
 assert.equal(seasonRankCharacters(self,{},'survivor',catalog).status,'unavailable');
 assert.equal(normalize({3:{battle_cnt:1,win_cnt:1}}).status,'unavailable');
 for(const r of [row(0,0,0),row(3,0,3)]){const x=normalize({3:r}).items[0];assert.equal(x.win_rate,0);assert.equal(x.win_rate_display,'0.0%');assert.equal(x.zero_denominator,true);}
});
test('invalid and inconsistent character counts never produce a partial ranking or a win rate',()=>{
 for(const data of [null,[],{3:null},{'03':row(1,1,0)},{3:row(-1,0,0)},{3:row(1.5,1,0)},{3:row('2',1,0)},{3:row(2,1,2)},{3:row(1,0,2)},{3:row(Number.MAX_SAFE_INTEGER+1,1,0)},{3:row(1,NaN,0)},{3:row(1,1,0),25:row(1,2,0)}]){
  const result=normalize(data);assert.equal(result.status,'invalid');assert.deepEqual(result.items,[]);
 }
 assert.equal(normalize({3:row(Number.MAX_SAFE_INTEGER,1,0)}).status,'available');
});
test('character season display requires self access and original name, image and matching camp',()=>{
 for(const access of ['permitted','hidden','unknown',undefined])assert.equal(seasonRankCharacters({field_access:{statistics:access}},{pid_data_rank:{3:row(1,1,0)}},'survivor',catalog),null);
 for(const character of [undefined,{name:'幸運児',camp:'survivor'},{asset:'character-3',camp:'survivor'},{name:'復讐者',asset:'character-1',camp:'hunter'}]){
  assert.equal(seasonRankCharacters(self,{pid_data_rank:{3:row(1,1,0)}},'survivor',{characters:{3:character}}).status,'unavailable');
 }
});
test('past character records remain in their received season and camp and never use normal or current data',()=>{
 const p=presentProfile({...self,civilian_data:{season_id:44,pid_data_rank:{25:row(99,99,0)},history_season_data:{37:{pid_data_rank:{3:row(2,2,0)},pid_data_normal:{25:row(70,1,0)}},43:{},44:{pid_data_rank:{3:row(100,100,0)}}}},butcher_data:{season_id:44,history_season_data:{35:{pid_data_rank:{1:row(1,1,0)}}}}},catalog);
 assert.deepEqual(p.season_history.survivor.map(x=>x.season_id),[43,37]);assert.equal(p.season_history.survivor[0].rank_characters.status,'unavailable');
 assert.equal(p.season_history.survivor[1].rank_characters.items[0].battle_count,2);assert.equal(p.season_history.hunter[0].rank_characters.items[0].name,'復讐者');
 const other=presentProfile(profileOf({unique_id:'20',setting_show_info:{},civilian_data:{season_id:44,history_season_data:{37:{pid_data_rank:{3:row(2,2,0)}}}}},'10'),catalog);
 assert.equal(other.season_history.survivor[0].rank_characters,null);
});
