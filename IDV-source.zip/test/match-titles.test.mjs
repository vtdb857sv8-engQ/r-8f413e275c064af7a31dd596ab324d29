import test from 'node:test';
import assert from 'node:assert/strict';
import {matchPerformanceTitles} from '../src/game/match-titles.mjs';
import {matchActionDetails} from '../src/game/match-actions.mjs';
const catalog={match_action_fields:{survivor:[]},match_performance_titles:[{id:1,action_id:1,record_key:'1',condition_value:300,label:'解読マスター',description:'解読進捗が300%に到達',asset:'match-performance-1'},{id:5,action_id:12,record_key:'12',condition_value:180,label:'牽制マスター',description:'ハンターへの牽制時間が180秒に到達',asset:'match-performance-5'}]};
test('received per-match title thresholds select original labels and artwork, independently of action values',()=>{
 const p={utype:2,title_recored:{1:300,12:180},action_recored:{'+1':500,12:200}};
 const t=matchPerformanceTitles(p,catalog);assert.equal(t.titles_status,'received');assert.deepEqual(t.titles.map(x=>x.asset),['match-performance-1','match-performance-5']);assert.equal(t.titles[0].received_condition_value,300);
 assert.equal(matchPerformanceTitles({...p,title_recored:{}},catalog).titles.length,0);
 assert.equal(matchActionDetails({...p,action_recored:undefined},2,catalog).titles.length,2);
});
test('missing title dictionaries, explicit empty records and unrecognized values remain distinct',()=>{
 for(const title_recored of [undefined,null,[],0])assert.equal(matchPerformanceTitles({utype:2,title_recored},catalog).titles_status,'unavailable');
 assert.deepEqual(matchPerformanceTitles({utype:2,title_recored:{}},catalog),{titles_status:'received',titles:[],unverified_title_records:0});
 const t=matchPerformanceTitles({utype:2,title_recored:{1:0,12:true,20:3}},catalog);assert.equal(t.titles.length,0);assert.equal(t.unverified_title_records,3);
 assert.equal(matchPerformanceTitles({utype:2,title_recored:{1:null}},catalog).unverified_title_records,0);
});
test('survivor performance titles never attach to hunters or unchecked game modes',()=>{
 assert.deepEqual(matchPerformanceTitles({utype:1,title_recored:{1:300}},catalog),{titles_status:'not_applicable',titles:[],unverified_title_records:0});
 assert.equal(matchActionDetails({utype:2,title_recored:{1:300}},10,catalog),null);
 assert.equal(matchActionDetails({utype:2,title_recored:{1:300}},102,catalog),null);
});
