import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {setTimeout as sleep} from 'node:timers/promises';
import {SessionRecovery} from '../src/session-recovery.mjs';
import {ApiError} from '../src/errors.mjs';
class Provider extends EventEmitter {
  connected=false;calls=[];fail=null;gate=null;
  async connect(credentials,options){
    this.calls.push({credentials,options});if(this.gate)await this.gate;
    if(this.fail){this.connected=false;this.lastDisconnect=this.fail.code==='GAME_ALREADY_ONLINE'?{code:'GAME_ALREADY_ONLINE',retryable:false}:{code:'GATEWAY_NETWORK_ERROR',retryable:true};this.emit('disconnected',this.lastDisconnect);throw this.fail;}
    this.connected=true;
  }
  lose(){this.connected=false;this.lastDisconnect={code:'GATEWAY_CLOSED',retryable:true};this.emit('disconnected',this.lastDisconnect);}
  async disconnect(){this.connected=false;this.emit('disconnected',{code:'SESSION_DISCONNECTED',retryable:false});}
}
function fixture(t,options={}){
  const provider=new Provider(),settings=new Map(),credentials={login_info:{info:{sessionid:'never-print'}}};
  const store={setting:(key,value)=>{if(value!==undefined)settings.set(key,value);return settings.get(key)??null;}};
  const recovery=new SessionRecovery({provider,store,vault:{get:()=>credentials},automatic:true,retryDelaysMs:[2,3],...options});
  t.after(()=>recovery.stop());return{provider,recovery,settings,credentials};
}
async function until(predicate){for(let i=0;i<100;i++){if(predicate())return;await sleep(5);}throw Error('Recovery did not reach expected state');}
test('startup restores a saved session without requesting replacement',async t=>{
  const f=fixture(t);assert.equal(await f.recovery.restore(),true);assert.equal(f.provider.calls.length,1);assert.equal(f.provider.calls[0].options.replaceExisting,false);assert.equal(f.settings.get('game_connection_desired'),'1');assert.ok(!JSON.stringify(f.recovery.status()).includes('never-print'));
});
test('a transient disconnect recovers, and an explicit replacement is never reused automatically',async t=>{
  const f=fixture(t);await f.recovery.connect(f.credentials,{replaceExisting:true});f.provider.lose();
  await until(()=>f.provider.calls.length===2&&f.provider.connected);assert.equal(f.provider.calls[0].options.replaceExisting,true);assert.equal(f.provider.calls[1].options.replaceExisting,false);
});
test('another game login stops retries instead of being displaced',async t=>{
  const f=fixture(t);await f.recovery.restore();f.provider.fail=new ApiError(409,'GAME_ALREADY_ONLINE','test');f.provider.lose();await until(()=>f.recovery.status().paused_reason==='GAME_ALREADY_ONLINE');await sleep(20);assert.equal(f.provider.calls.length,2);assert.equal(f.recovery.status().retry_at,null);
});

test('explicit login rejection stops automatic attempts, whitelists status and clears after recovery',async t=>{
  const f=fixture(t);let calls=0,rejected=true;
  f.provider.connect=async(credentials,options)=>{
    calls++;assert.equal(options.replaceExisting,false);
    if(rejected){f.provider.lastDisconnect={code:'SDK_AUTH_REJECTED',retryable:false,login_failure:{reason:'sdk_auth_failed',server_code:6,sessionid:'never-print'}};f.provider.emit('disconnected',f.provider.lastDisconnect);throw new ApiError(409,'SDK_AUTH_REJECTED','test');}
    f.provider.connected=true;
  };
  assert.equal(await f.recovery.restore(),false);await sleep(20);assert.equal(calls,1);
  const status=f.recovery.status();assert.equal(status.paused_reason,'SDK_AUTH_REJECTED');assert.equal(status.retry_at,null);
  assert.deepEqual(status.login_failure,{reason:'sdk_auth_failed',server_code:6});assert.ok(!JSON.stringify(status).includes('never-print'));
  rejected=false;await f.recovery.connect(f.credentials,{replaceExisting:false});assert.equal(f.recovery.status().login_failure,null);
  assert.equal(f.recovery.status().paused_reason,null);assert.equal(calls,2);
});
test('manual disconnect cancels retry and remains disconnected on the next startup',async t=>{
  const f=fixture(t);await f.recovery.restore();f.provider.lose();await f.recovery.disconnect();await sleep(20);assert.equal(f.provider.calls.length,1);assert.equal(f.settings.get('game_connection_desired'),'0');assert.equal(await f.recovery.restore(),false);
});
test('disconnect during login closes the late connection without scheduling another login',async t=>{
  const f=fixture(t);let release;f.provider.gate=new Promise(resolve=>{release=resolve;});
  const connection=f.recovery.restore();await until(()=>f.provider.calls.length===1);const stopped=f.recovery.disconnect();release();await connection;await stopped;await sleep(10);assert.equal(f.provider.connected,false);assert.equal(f.provider.calls.length,1);assert.equal(f.recovery.status().retry_at,null);
});
test('repeated network failures reach a bounded retry limit',async t=>{
  const f=fixture(t,{retryLimit:2});await f.recovery.restore();f.provider.fail=new ApiError(502,'GAME_LOGIN_FAILED','test');f.provider.lose();await until(()=>f.recovery.status().paused_reason==='RECONNECT_LIMIT_REACHED');await sleep(15);assert.equal(f.provider.calls.length,3);assert.equal(f.recovery.status().retry_at,null);
});
test('stopping the API preserves the request to connect after a restart',async t=>{
  const f=fixture(t);await f.recovery.restore();await f.recovery.stop();assert.equal(f.settings.get('game_connection_desired'),'1');assert.equal(f.recovery.status().retry_at,null);
});
