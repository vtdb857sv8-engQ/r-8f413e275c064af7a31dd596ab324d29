import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, generateKeyPairSync, verify } from 'node:crypto';
import { Store } from '../src/store.mjs';
import { LiveGameProvider as GameProvider } from '../src/game/provider.mjs';
import { Monitor } from '../src/monitor.mjs';
import { createApi } from '../src/server.mjs';
import { openapi } from '../src/openapi.mjs';
import { Apns } from '../src/apns.mjs';
import {ApiError} from '../src/errors.mjs';
class TestVault {
  values=new Map();
  has(k){return this.values.has(k);}get(k){return this.values.get(k);}set(k,v){this.values.set(k,v);}
  crypt(op,v){return op==='protect'?`encrypted:${v}`:v.slice(10);}
}
async function fixture(t,provider=new GameProvider(),assets=null){
  const store=new Store(':memory:'),vault=new TestVault(),apiKey=randomBytes(32).toString('hex');
  const monitor=new Monitor({store,provider,vault});
  const server=createApi({store,provider,monitor,vault,apiKey,openapi,assets});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(async()=>{server.closeStreams();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await monitor.stop();store.close();});
  const url=`http://127.0.0.1:${server.address().port}`;
  const request=async(path,options={})=>{
    const response=await fetch(url+path,{...options,headers:{authorization:`Bearer ${apiKey}`,'content-type':'application/json',...options.headers}});
    return {status:response.status,data:await response.json()};
  };
  return{store,vault,apiKey,monitor,server,url,request};
}
test('auth is required for personal data; query-string keys are rejected',async t=>{
  const f=await fixture(t);
  assert.equal((await fetch(f.url+'/health')).status,200);
  assert.equal((await fetch(f.url+'/v1/status')).status,401);
  assert.equal((await fetch(f.url+'/v1/status?token='+f.apiKey)).status,401);
  assert.equal((await f.request('/v1/status',{headers:{origin:'https://example.com'}})).status,403);
});
test('disconnected game routes report 503 without returning invented records',async t=>{
  const f=await fixture(t);
  for(const path of ['/v1/me/mojin','/v1/me/mojin/history','/v1/players?query=test','/v1/players/123','/v1/players/123/history','/v1/players/123/badges/history','/v1/friends','/v1/rankings','/v1/ugc/play-history','/v1/ugc/rankings','/v1/ugc/maps/123/rankings','/v1/chat/global','/v1/recruitments']){
    const r=await f.request(path);assert.equal(r.status,503,path);assert.equal(r.data.error.code,'GAME_NOT_CONNECTED');assert.equal(r.data.data,undefined);
  }
  const s=await f.request('/v1/status');assert.equal(s.data.connected,false);assert.equal(s.data.independent_game_connection_verified,false);
});
test('character ranking validates the game catalog and camp before sending a request',async t=>{
  const provider=new GameProvider(),calls=[];provider.getRankings=async opts=>{calls.push(opts);return {items:[]};};
  const f=await fixture(t,provider,{catalog:{characters:{14:{name:'医師',camp:'survivor'}}}});
  for(const path of ['/v1/rankings?character_id=0','/v1/rankings?character_id=999','/v1/rankings?character_id=14&kind=hunter'])assert.equal((await f.request(path)).status,400);
  assert.equal(calls.length,0);assert.equal((await f.request('/v1/rankings?character_id=14&kind=survivor')).status,200);assert.equal(calls[0].character_id,14);
});
test('SDK credential storage validates shape, does not claim verification or echo secrets',async t=>{
  const f=await fixture(t),token='private-game-credential-for-test';
  const info={sdkuid:'test',sessionid:token,full_uid:'test',client_version:1,sauth_json:JSON.stringify({sdkuid:'test',sessionid:token})};
  let r=await f.request('/v1/session/credentials',{method:'PUT',body:JSON.stringify({login_info:{info},server:'asia'})});
  assert.equal(r.status,200);assert.equal(r.data.verified,false);assert.ok(!JSON.stringify(r.data).includes(token));
  assert.equal(f.vault.get('game-session').login_info.info.sessionid,token);
  r=await f.request('/v1/session/credentials',{method:'PUT',body:JSON.stringify({token,server:'asia'})});assert.equal(r.status,400);assert.equal(f.monitor.connected,false);
  assert.equal(f.vault.get('game-session').login_info.info.sessionid,token);
  assert.ok(!JSON.stringify((await f.request('/v1/status')).data).includes(token));
});
test('session code import is authenticated, never logs in and never echoes the code or SDK session',async t=>{
 const f=await fixture(t),info={sdkuid:'synthetic-user',sessionid:'synthetic-secret-session',full_uid:'synthetic-full',client_version:1,sauth_json:JSON.stringify({sdkuid:'synthetic-user',sessionid:'synthetic-secret-session'})};
 const code='IDV1.'+Buffer.from(JSON.stringify({version:1,issued_at:'2026-11-06T20:00:00Z',server:'asia',login_info:{info,pack_type:1,login_confirm:true}})).toString('base64url');
 assert.equal((await fetch(f.url+'/v1/session/import',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({code})})).status,401);
 assert.equal(f.vault.has('game-session'),false);
 const result=await f.request('/v1/session/import',{method:'POST',body:JSON.stringify({code})});
 assert.equal(result.status,200);assert.equal(result.data.stored,true);assert.equal(result.data.verified,false);assert.equal(f.monitor.connected,false);
 assert.equal(f.vault.get('game-session').login_info.login_confirm,false);assert.ok(!JSON.stringify(result.data).includes(code));assert.ok(!JSON.stringify(result.data).includes('synthetic-secret-session'));
 const before=structuredClone(f.vault.get('game-session'));
 assert.equal((await f.request('/v1/session/import',{method:'POST',body:'{"code":"bad-code"}'})).status,400);assert.deepEqual(f.vault.get('game-session'),before);
});
test('watch registration is separate from live tracking',async t=>{
  const f=await fixture(t);
  const r=await f.request('/v1/watches/123',{method:'PUT',body:'{"notify":true}'});
  assert.equal(r.data.tracking_active,false);
  assert.equal((await f.request('/v1/watches')).data.data.length,1);
  assert.equal((await f.request('/v1/players/123/presence')).data.data.state,'unknown');
  assert.equal((await f.request('/v1/watches/123',{method:'DELETE'})).status,200);
});

test('game login rejection reaches HTTP and status without exposing raw SDK or report metadata',async t=>{
  let closed=false;
  const session={events:[],close:()=>{closed=true;},login:async info=>{
    assert.equal(info.login_confirm,false);const error=new ApiError(409,'SDK_AUTH_REJECTED','保存されたSDK認証がゲーム側で拒否されました。');
    error.serverLoginCode=6;error.extra={sessionid:'never-print',ban_code:['not-a-ban-conclusion']};throw error;
  }};
  const provider=new GameProvider({},{sessionFactory:()=>session}),f=await fixture(t,provider);
  f.vault.set('game-session',{login_info:{info:{sessionid:'never-print'},login_confirm:true}});
  const rejected=await f.request('/v1/session/connect',{method:'POST',body:'{}'});
  assert.equal(rejected.status,409);assert.equal(rejected.data.error.code,'SDK_AUTH_REJECTED');assert.equal(closed,true);
  const status=(await f.request('/v1/status')).data;
  assert.equal(status.connected,false);assert.equal(status.last_error,'SDK_AUTH_REJECTED');
  assert.equal(status.session_recovery.paused_reason,'SDK_AUTH_REJECTED');assert.equal(status.session_recovery.retry_at,null);
  assert.deepEqual(status.session_recovery.login_failure,{reason:'sdk_auth_failed',server_code:6});
  assert.equal(provider.lastDisconnect.retryable,false);
  for(const value of [rejected,status])assert.ok(!/never-print|sessionid|ban_code|not-a-ban-conclusion/.test(JSON.stringify(value)));
});
test('history permissions are rechecked; received records display even under a private setting while unreceived ones stay refused',async t=>{
  const provider=new GameProvider({});provider.connected=true;provider.selfId='1';
  let info={show_battle_record:true,battle_records:[{common_info:{battle_id:'public-match'}}]};
  provider.request=async()=>({info});const f=await fixture(t,provider);
  let result=await f.request('/v1/players/2/history');assert.equal(result.status,200);assert.equal(result.data.data.items[0].common_info.battle_id,'public-match');
  info={show_battle_record:false,battle_records:[{common_info:{battle_id:'private-match'}}]};
  result=await f.request('/v1/players/2/history');assert.equal(result.status,200);assert.equal(result.data.data.items[0].common_info.battle_id,'private-match');assert.equal(result.data.data.access.reason,'records_received_with_private_setting');
  result=await f.request('/v1/players/2/history/access');assert.equal(result.data.data.allowed,true);assert.equal(result.data.data.visibility,'permitted');
  info={show_battle_record:false};
  result=await f.request('/v1/players/2/history');assert.equal(result.status,403);assert.ok(!JSON.stringify(result.data).includes('private-match'));
  info={};
  result=await f.request('/v1/players/2/history');assert.equal(result.status,409);assert.equal(result.data.error.code,'HISTORY_PERMISSION_UNKNOWN');
  result=await f.request('/v1/players/1/history');assert.equal(result.status,200);assert.equal(result.data.data.access.reason,'account_owner');
});
test('invalid payloads fail before touching the game provider',async t=>{
  const f=await fixture(t);
  assert.equal((await f.request('/v1/players?query=')).status,400);
  assert.equal((await f.request('/v1/rankings?kind=invalid')).status,400);
  assert.equal((await f.request('/v1/events?limit=1e2')).status,400);
  assert.equal((await f.request('/v1/events?player_id=abc')).status,400);
  assert.equal((await f.request('/v1/watches/abc',{method:'PUT',body:'{"notify":true}'})).status,400);
  assert.equal((await f.request('/v1/watches/123',{method:'PUT',body:'{"notify":"false"}'})).status,400);
  assert.equal((await f.request('/v1/session/credentials',{method:'PUT',body:'{'})).status,400);
  assert.equal((await f.request('/v1/session/credentials',{method:'PUT',body:'x'.repeat(16385)})).status,413);
});
test('analysis validates timezone before game reads and displays received records even when the setting is private',async t=>{
  const provider=new GameProvider({});provider.connected=true;provider.selfId='1';let reads=0;
  provider.request=async()=>{reads++;return {info:{show_battle_record:false,battle_records:[{common_info:{battle_id:'hidden-match'}}]}};};
  const f=await fixture(t,provider);
  let result=await f.request('/v1/players/2/analysis?timezone=wrong%2Fzone');assert.equal(result.status,400);assert.equal(reads,0);
  result=await f.request('/v1/players/2/analysis?timezone=Asia%2FTokyo');assert.equal(result.status,200);assert.equal(result.data.data.total,1);assert.equal(result.data.data.coverage,'server_returned_records');
});
test('presence bootstrap is not a fabricated login; transitions are timestamped and deduplicated',t=>{
  const store=new Store(':memory:');t.after(()=>store.close());
  assert.equal(store.observe('1','online','2026-01-01T00:00:00.000Z'),null);
  assert.equal(store.presence('1').last_login_observed_at,null);
  assert.equal(store.observe('1','offline','2026-01-01T00:01:00.000Z').previous_state,'online');
  assert.equal(store.presence('1').last_logout_observed_at,'2026-01-01T00:01:00.000Z');
  assert.equal(store.observe('1','in_match','2026-01-01T00:02:00.000Z').state,'in_match');
  assert.equal(store.presence('1').last_login_observed_at,'2026-01-01T00:02:00.000Z');
  assert.equal(store.observe('1','offline','2026-01-01T00:01:00.000Z'),null);
  assert.equal(store.observe('1','in_match','2026-01-01T00:03:00.000Z'),null);
  assert.equal(store.events().length,2);
});
test('visibility-only changes are durable notifications without fabricated login or logout',async t=>{
  const f=await fixture(t);f.store.watch('1',true);f.store.registerDevice('phone','encrypted:token','sandbox');
  f.monitor.record({player_id:'1',state:'unknown',visibility:'hidden',observed_at:'2026-01-01T00:00:00Z'});
  f.monitor.record({player_id:'1',state:'unknown',visibility:'visible',observed_at:'2026-01-01T00:01:00Z'});
  const events=f.store.events();assert.equal(events.length,1);assert.equal(events[0].previous_visibility,'hidden');assert.equal(events[0].visibility,'visible');assert.equal(f.store.pendingDeliveries().length,1);
  assert.equal(f.store.presence('1').last_login_observed_at,null);assert.equal(f.store.presence('1').last_logout_observed_at,null);
  f.monitor.record({player_id:'1',state:'unknown',visibility:'hidden',observed_at:'2026-01-01T00:00:30Z'});
  assert.equal(f.store.presenceDetails('1').visibility,'visible');assert.equal(f.store.events().length,1);
});
test('a network error preserves last known state without creating a logout',async t=>{
  const provider=new GameProvider();provider.capabilities=()=>({presence:true});provider.pollPresence=async()=>{throw new Error('network');};
  const f=await fixture(t,provider);f.store.watch('1',true);f.monitor.connected=true;
  f.store.observe('1','online','2026-01-01T00:00:00.000Z');await f.monitor.tick();
  assert.equal(f.store.presence('1').state,'online');assert.equal(f.store.events().length,0);assert.equal(f.monitor.lastError,'PRESENCE_FETCH_FAILED');
});
test('an invalid full batch creates no partial status changes',async t=>{
  const provider=new GameProvider();provider.capabilities=()=>({presence:true});
  provider.pollPresence=async()=>[{player_id:'1',state:'offline',observed_at:'2026-01-01T00:01:00Z'},{player_id:'999',state:'online',observed_at:'2026-01-01T00:01:00Z'}];
  const f=await fixture(t,provider);f.monitor.connected=true;f.store.watch('1',true);f.store.observe('1','online','2026-01-01T00:00:00.000Z');
  await f.monitor.tick();assert.equal(f.store.presence('1').state,'online');assert.equal(f.store.events().length,0);
});
test('APNs device tokens are encrypted before persistence and never echoed',async t=>{
  const f=await fixture(t),token='a'.repeat(64);
  const r=await f.request('/v1/devices',{method:'POST',body:JSON.stringify({device_id:'test-iphone',token,environment:'sandbox'})});
  assert.equal(r.status,200);assert.equal(r.data.push_configured,false);assert.ok(!JSON.stringify(r.data).includes(token));
  assert.equal(f.store.db.prepare('SELECT token FROM devices').get().token,`encrypted:${token}`);
});
test('notifications are durable, retryable, and isolated per device',async t=>{
  const f=await fixture(t);f.store.watch('1',true);f.store.registerDevice('a','encrypted:aaa','sandbox');f.store.registerDevice('b','encrypted:bbb','sandbox');
  f.store.observe('1','online','2026-11-05T00:00:00Z');f.store.observe('1','offline',new Date().toISOString());
  assert.equal(f.store.pendingDeliveries().length,2);
  const calls=[];f.monitor.apns={send:async(token)=>{calls.push(token);return{status:token==='aaa'?200:503};},close(){}};
  await f.monitor.deliver();assert.deepEqual(calls,['aaa','bbb']);
  const rows=f.store.db.prepare('SELECT device_id,status,attempts FROM deliveries ORDER BY device_id').all();
  assert.equal(rows[0].status,'sent');assert.equal(rows[1].status,'pending');assert.equal(rows[1].attempts,1);
});
test('APNs 410 removes expired device registration',async t=>{
  const f=await fixture(t);f.store.watch('1',true);f.store.registerDevice('a','encrypted:aaa','sandbox');
  f.store.observe('1','online','2026-01-01T00:00:00Z');f.store.observe('1','offline',new Date().toISOString());
  f.monitor.apns={send:async()=>({status:410}),close(){}};await f.monitor.deliver();
  assert.equal(f.store.db.prepare('SELECT COUNT(*) AS n FROM devices').get().n,0);
});
test('SSE replays missed transitions with ids and bearer authentication',async t=>{
  const f=await fixture(t);f.store.observe('1','online','2026-01-01T00:00:00Z');f.store.observe('1','offline','2026-01-01T00:01:00Z');
  const controller=new AbortController();
  const response=await fetch(f.url+'/v1/events/stream?after=0',{headers:{authorization:`Bearer ${f.apiKey}`},signal:controller.signal});
  assert.equal(response.status,200);assert.match(response.headers.get('content-type'),/text\/event-stream/);
  const reader=response.body.getReader();let text='';
  while(!text.includes('event: presence')){const {value}=await reader.read();text+=new TextDecoder().decode(value);}
  assert.match(text,/id: 1/);assert.match(text,/"state":"offline"/);controller.abort();
});
test('APNs JWT uses a verifiable ES256 signature and caches the provider token',()=>{
  const {privateKey,publicKey}=generateKeyPairSync('ec',{namedCurve:'prime256v1'});
  const apns=new Apns({keyId:'TESTKEY123',teamId:'TESTTEAM12',topic:'test.bundle',privateKey:privateKey.export({format:'pem',type:'pkcs8'})});
  const bearer=apns.authorization();assert.equal(apns.authorization(),bearer);
  const [header,payload,signature]=bearer.slice(7).split('.');
  assert.equal(JSON.parse(Buffer.from(header,'base64url')).alg,'ES256');assert.equal(JSON.parse(Buffer.from(payload,'base64url')).iss,'TESTTEAM12');
  assert.ok(verify('sha256',Buffer.from(`${header}.${payload}`),{key:publicKey,dsaEncoding:'ieee-p1363'},Buffer.from(signature,'base64url')));
});
test('OpenAPI is available to authenticated clients',async t=>{
  const f=await fixture(t),r=await f.request('/openapi.json');assert.equal(r.status,200);assert.equal(r.data.openapi,'3.1.0');
  assert.ok(r.data.paths['/v1/players/{player_id}/history']);assert.ok(r.data.paths['/v1/events/stream']);
});
test('persona API validates the character and returns a disclosure refusal without a raw loadout',async t=>{
  const provider=new GameProvider();let calls=0;provider.getPersona=async()=>{calls++;throw new ApiError(403,'PERSONA_PRIVATE','人格は非公開です。');};
  const f=await fixture(t,provider,{catalog:{characters:{89:{name:'曲芸師',camp:'survivor'}}}});
  assert.equal((await f.request('/v1/players/19806845/persona?character_id=9999')).status,400);assert.equal(calls,0);
  const r=await f.request('/v1/players/19806845/persona?character_id=89');assert.equal(r.status,403);assert.equal(r.data.error.code,'PERSONA_PRIVATE');assert.equal(r.data.data,undefined);
});
