import test from 'node:test';
import assert from 'node:assert/strict';
import {profileOf} from '../src/game/public-data.mjs';
import {presentProfile} from '../src/game/presentation.mjs';
import {LiveGameProvider} from '../src/game/provider.mjs';
import {presentMojinSelf} from '../src/game/mojin-data.mjs';
import {presentMojinRecords} from '../src/game/mojin-records.mjs';
const catalog={profile_most_used:{label:'使用回数が最も多い',released_character_ids:[3]},characters:{3:{name:'幸運児',asset:'character-3',camp:'survivor'}}};
const info=()=>({unique_id:'20',setting_show_info:{},civilian_data:{season_id:44,pid_cnt_all:{3:{old_battle_cnt:1,new_battle_cnt:1}},history_season_data:{37:{pid_data_rank:{3:{battle_cnt:2,win_cnt:2,draw_cnt:0}}}}},butcher_data:{pid_cnt_all:{}}});
test('public complete profiles expose frequent characters and season character records even when settings hide them',()=>{
 const result=presentProfile(profileOf(info(),'10',undefined,{completeProfile:true,specialFriendIds:[]}),catalog);
 assert.equal(result.most_used_characters.scope,'public_profile_aggregate');assert.equal(result.most_used_characters.items[0].name,'幸運児');assert.equal(result.season_history.survivor[0].rank_characters.items[0].win_rate,100);
 for(const options of [{},{completeProfile:true},{completeProfile:true,specialFriendIds:['20']}]){
  const presented=presentProfile(profileOf(info(),'10',undefined,options),catalog);
  assert.equal(presented.most_used_characters===null,options.completeProfile!==true);
 }
 for(const setting of [{hide_fre_used_role_info:true},{open_char_data:false}])assert.equal(presentProfile(profileOf({...info(),setting_show_info:setting},'10',undefined,{completeProfile:true,specialFriendIds:[]}),catalog).most_used_characters.status,'available');
 assert.equal(presentProfile(profileOf({...info(),setting_show_info:undefined},'10',undefined,{completeProfile:true,specialFriendIds:[]}),catalog).most_used_characters,null);
});
test('other profiles re-read disclosure after each fetch and never reuse an earlier cached permission',async()=>{
 const provider=new LiveGameProvider({special_friend_ids:[]});provider.connected=true;provider.selfId='10';let calls=0;
 provider.request=async()=>({info:{...info(),setting_show_info:++calls<=2?{}:{hide_fre_used_role_info:true}}});
 assert.equal(presentProfile(await provider.getProfile('20'),catalog).most_used_characters.status,'available');
 const refreshed=presentProfile(await provider.getProfile('20'),catalog);
 assert.equal(refreshed.most_used_characters.status,'available');assert.notEqual(refreshed.season_history,null);
 assert.notEqual(refreshed.civilian_data,undefined);assert.notEqual(refreshed.butcher_data,undefined);
 assert.equal(calls,4);assert.equal(provider.cache.size,0);
});
const data=(settings={})=>({unique_id:'20',setting_show_info:settings,gold_rush_common_data:{season_id:1,total_deliver_value:120,history_season_data:{}},gold_rush_data:{win_cnt:1,lose_cnt:0,history_season_data:{}},gold_rush_butcher_data:{win_cnt:0,lose_cnt:0,history_season_data:{}}});
function provider(responses){const p=new LiveGameProvider({});p.connected=true;p.selfId='10';p.session={};p.methods=[];p.request=async(m,args,callback,filter)=>{p.methods.push(args.info.methodname);assert.equal(filter({info:{callbackid:args.info.callbackid}}),true);return {info:{res:[0,responses.shift()]}};};return p;}
test('public Mojin statistics use the target response and an independent personal-data permission',async()=>{
 const p=provider([data({gr_hide_battle_record:true}),data({gr_hide_battle_record:true})]);const result=presentMojinSelf(await p.getPlayerMojin('20'));
 assert.equal(result.scope,'public');assert.equal(result.source,'ask_player_gold_rush_data');assert.equal(result.statistics[0].total_actions,1);assert.equal(result.statistics[0].total_deliver_value,120);assert.deepEqual(p.methods,['ask_player_gold_rush_data','ask_player_gold_rush_data']);
});
test('received Mojin statistics display even when hidden; unknown, malformed and wrong-target responses never disclose',async()=>{
 const shown=presentMojinSelf(await provider([data({gr_hide_personal_data:true}),data({gr_hide_personal_data:true})]).getPlayerMojin('20'));assert.equal(shown.scope,'public');assert.equal(shown.source,'ask_player_gold_rush_data');assert.ok(shown.statistics.length>=1);
 for(const settings of [null,[],{gr_hide_personal_data:'false'}])await assert.rejects(provider([data(settings)]).getPlayerMojin('20'),{code:'MOJIN_PERMISSION_UNKNOWN'});
 await assert.rejects(provider([{...data(),unique_id:'30'}]).getPlayerMojin('20'),{code:'MOJIN_PROFILE_FORMAT_UNSUPPORTED'});
});
test('public Mojin history checks fresh disclosure before and after receipt and uses its dedicated RPC',async()=>{
 const p=provider([data(),[],data()]);const page=await p.getPlayerMojinHistory('20');assert.equal(page.scope,'public');assert.deepEqual(p.methods,['ask_player_gold_rush_data','request_friend_gold_rush_records','ask_player_gold_rush_data']);
 assert.equal(presentMojinRecords(page).source,'request_friend_gold_rush_records');
 const blocked=provider([data({gr_hide_battle_record:'unexpected'})]);await assert.rejects(blocked.getPlayerMojinHistory('20'),{code:'MOJIN_PERMISSION_UNKNOWN'});assert.equal(blocked.methods.length,1);
 const revoked=provider([data(),[{received_only_canary:'not-for-presentation'}],data({gr_hide_battle_record:'unexpected'})]);
 await assert.rejects(revoked.getPlayerMojinHistory('20'),{code:'MOJIN_PERMISSION_UNKNOWN'});
 assert.deepEqual(revoked.methods,['ask_player_gold_rush_data','request_friend_gold_rush_records','ask_player_gold_rush_data']);
 assert.equal(revoked.cache.size,0);
});
test('Mojin permissions remain independent and a session replacement discards the response',async()=>{
 const p=provider([data({gr_hide_personal_data:true}),[],data({gr_hide_personal_data:true})]);assert.equal((await p.getPlayerMojinHistory('20')).scope,'public');
 const changed=provider([]);changed.request=async()=>{changed.session={};return {info:{res:[0,data()]}};};await assert.rejects(changed.getPlayerMojin('20'),{code:'GAME_SESSION_CHANGED'});
});
test('public Mojin profile still displays when the personal-data setting changes to hidden after receipt',async()=>{
 const p=provider([data(),data({gr_hide_personal_data:true})]);
 const result=await p.getPlayerMojin('20');assert.equal(result.scope,'public');assert.equal(result.survivor.win_cnt,1);
 assert.equal(p.cache.size,0);assert.deepEqual(p.methods,['ask_player_gold_rush_data','ask_player_gold_rush_data']);
});
