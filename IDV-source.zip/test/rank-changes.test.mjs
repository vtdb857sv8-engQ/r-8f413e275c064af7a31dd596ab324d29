import test from 'node:test';
import assert from 'node:assert/strict';
import {presentMatch} from '../src/game/presentation.mjs';
const catalog={rank_rules:{star_scores:{3:20,7:30},peak_stars:25},rank_score_labels:{TID_DES_VICTORY:'勝利',TID_DES_DEFEAT:'失敗',TID_DES_GRADE_SUR:'サバイバー演繹得点第%s位',TID_DES_DRAW:'引き分け',TID_DES_INTERGRAL_BADBEAHVIOR:'対戦マナー',ZERO:'零',BROKEN:'不明%s%s',PERCENT:'解読進度250%（失敗）'}};
const record=(detail,extra={})=>({common_info:{self_eid:'e',match_type:2},part_change_info:{'123':{unit_type:2,old_rank:{part:3,part_lv:5,part_star:99},now_rank:{part:3,part_lv:4,part_star:8},score_detail:detail}},all_pl_info:[{eid:'e',unique_id:'123',utype:2}],...extra});
const change=r=>presentMatch(r,catalog).summary.players[0].rank_change;
test('rank reasons join on public unique id, keep signed values and apply the game placement offset',()=>{
  const data=change(record({TID_DES_GRADE_SUR:[4,0],TID_DES_DEFEAT:-8,TID_DES_VICTORY:8}));
  assert.equal(data.before.label,'三段V');assert.equal(data.after.label,'三段IV');
  assert.deepEqual(data.details.map(x=>[x.label,x.points]),[['勝利',8],['サバイバー演繹得点第1位',4],['失敗',-8]]);
  assert.equal(data.details_received,true);assert.equal(data.source,'part_change_info');assert.ok(!Object.hasOwn(data,'total_points'));
  const peakRecord=record({});peakRecord.part_change_info['123'].old_rank={part:7,part_star:749};peakRecord.part_change_info['123'].now_rank={part:7,part_star:750};
  const peak=change(peakRecord);assert.equal(peak.before.asset,'rank-survivor-7');assert.equal(peak.after.asset,'rank-survivor-peak');assert.equal(peak.after.stars,25);
});
test('rank detail filtering follows the game zero rule while unknown and malformed values stay explicit',()=>{
  const data=change(record({TID_DES_DRAW:0,TID_DES_INTERGRAL_BADBEAHVIOR:0,TID_DES_GRADE_SUR:[0,3],ZERO:0,UNKNOWN:2,BROKEN:[1,3],bad:[1],nan:NaN,str:'2'}));
  assert.deepEqual(data.details.map(x=>x.label),['引き分け','対戦マナー']);assert.equal(data.unlabelled_reasons,2);assert.equal(data.invalid_reasons,3);
  assert.equal(change(record(undefined)).details_received,false);assert.equal(change(record({})).details_received,true);
  assert.equal(change(record({PERCENT:3})).details[0].label,'解読進度250%（失敗）');
});
test('entity ids, another camp and other modes cannot receive someone else’s rank changes',()=>{
  assert.equal(change(record({}, {all_pl_info:[{eid:'123',utype:2}]})),null);
  assert.equal(change(record({}, {all_pl_info:[{unique_id:'999',utype:2}]})),null);
  assert.equal(change(record({}, {all_pl_info:[{unique_id:'123',utype:1}]})),null);
  assert.equal(change(record({}, {all_pl_info:[{unique_id:'123',utype:2,bot:true}]})),null);
  assert.equal(change(record({}, {all_pl_info:[{unique_id:'0',utype:2}]})),null);
  assert.equal(change(record({}, {common_info:{match_type:10}})),null);
  assert.equal(change(record({}, {common_info:{match_type:1}})),null);
});
