import test from 'node:test';
import assert from 'node:assert/strict';
import {presentMojinSelf} from '../src/game/mojin-data.mjs';
const catalog={mojin:{weapon_kills_label:'得意武器',items:{60012001:{name:'庇護者の杖',asset:'item-mojin-60012001'},60012002:{name:'燃える怨恨',asset:'item-mojin-60012002'},60012003:{name:'装填された猟銃',asset:'item-mojin-60012003'}}}};
const present=common=>presentMojinSelf({player_id:'10',common},catalog).statistics.map(x=>x.favorite_weapons);
test('favorite weapons preserve original names and artwork and select the top two independently for each period',()=>{
 const raw={season_id:1,weapon_kills:{60012001:10,60012002:8,60012003:2},history_season_data:{0:{weapon_kills:{60012001:9,60012002:3,60012003:2}}},session_token:'private'};
 const [all,current,past]=present(raw);assert.equal(all.label,'得意武器');assert.equal(all.status,'available');assert.deepEqual(all.items.map(x=>x.recorded_count),[10,8]);
 assert.equal(all.items[0].name,'庇護者の杖');assert.equal(all.items[0].asset,'item-mojin-60012001');assert.deepEqual(current.items.map(x=>x.item_id),[60012002,60012001]);assert.deepEqual(past.items.map(x=>x.recorded_count),[9,3]);
 assert.deepEqual(raw.weapon_kills,{60012001:10,60012002:8,60012003:2});assert.ok(!JSON.stringify(all).includes('private'));
});
test('explicit empty weapon dictionaries differ from missing, invalid and incomplete period records',()=>{
 const raw={season_id:1,weapon_kills:{},history_season_data:{0:{weapon_kills:{}}}};
 for(const row of present(raw)){assert.equal(row.status,'available');assert.deepEqual(row.items,[]);}
 assert.equal(present({})[0].status,'unavailable');delete raw.history_season_data[0].weapon_kills;assert.equal(present(raw)[1].status,'unavailable');
 for(const weapon_kills of [null,[],{1:-1},{1:0.5},{'bad':1},{1:Number.MAX_SAFE_INTEGER+1}])assert.equal(present({weapon_kills})[0].status,'invalid');
 assert.equal(present({season_id:1,weapon_kills:{},history_season_data:null})[1].status,'invalid');
});
test('unknown item IDs remain partial and never receive guessed names or substitute artwork',()=>{
 const [r]=present({weapon_kills:{99999999:1}});assert.equal(r.status,'partial');assert.equal(r.items[0].name,null);assert.equal(r.items[0].asset,null);
 const zero=present({weapon_kills:{60012001:0}})[0];assert.equal(zero.status,'available');assert.deepEqual(zero.items,[]);
});
test('contradictory historical weapon counts are invalid, while ties use a deterministic numeric item order',()=>{
 for(const old of [{60012001:3},{60012002:1}])assert.equal(present({season_id:1,weapon_kills:{60012001:2},history_season_data:{0:{weapon_kills:old}}})[1].status,'invalid');
 const tie=present({weapon_kills:{60012003:2,60012002:2,60012001:2}})[0];assert.deepEqual(tie.items.map(x=>x.item_id),[60012001,60012002]);
});
