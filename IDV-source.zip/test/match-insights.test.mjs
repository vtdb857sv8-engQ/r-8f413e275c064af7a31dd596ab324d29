import test from 'node:test';
import assert from 'node:assert/strict';
import {analyzeMatches,presentMatch} from '../src/game/presentation.mjs';
import {analysisTimeZone} from '../src/game/match-insights.mjs';
const row=(id,result,extra={})=>({record_id:String(id),summary:{mode_id:2,result,ended_at:new Date(Date.UTC(2026,0,1,Number(id))).toISOString(),players:[],...extra}});

test('recent samples use chronological results after custom filtering and deduplication',()=>{
  const a=row(1,'win'),records=[row(5,'win'),row(4,'win'),row(3,'draw'),row(2,'loss'),a,a,row(6,'loss',{is_custom:true})];
  const data=analyzeMatches(records);
  assert.equal(data.total,5);assert.deepEqual(data.streaks.current,{kind:'win',count:2});assert.equal(data.streaks.longest_win,2);assert.equal(data.streaks.longest_loss,1);
  assert.deepEqual(data.recent.map(x=>[x.requested_matches,x.total,x.win,x.draw,x.loss,x.win_rate]),[[10,5,3,1,1,60],[20,5,3,1,1,60],[50,5,3,1,1,60]]);
  assert.equal(analyzeMatches(records,{mode:'custom'}).streaks.current.kind,'loss');
  const long=Array.from({length:60},(_,i)=>row(i,i<50?'loss':'win'));
  const recent=analyzeMatches(long).recent;assert.equal(recent[0].win_rate,100);assert.equal(recent[1].win_rate,50);assert.equal(recent[2].win_rate,20);
});
test('draws and unknown results break streaks; unorderable records do not invent a recent sequence',()=>{
  const records=[row(1,'win'),row(2,'draw'),row(3,'win'),row(4,'unknown'),row(5,'loss')];
  let data=analyzeMatches(records);assert.equal(data.streaks.longest_win,1);assert.equal(data.recent[0].win_rate,50);assert.equal(data.recent[0].unknown,1);
  data=analyzeMatches([...records,row(6,'unknown')]);assert.deepEqual(data.streaks.current,{kind:'unknown',count:null});
  data=analyzeMatches([...records,row(6,'draw')]);assert.deepEqual(data.streaks.current,{kind:'none',count:0});
  data=analyzeMatches([...records,row(6,'win',{ended_at:null})]);assert.equal(data.chronology.status,'missing_timestamps');assert.equal(data.streaks.current,null);assert.equal(data.streaks.longest_win,null);assert.deepEqual(data.recent,[]);assert.equal(data.hourly.undated_matches,1);
  data=analyzeMatches([row(1,'win'),row(1,'loss')].map((r,i)=>({...r,record_id:String(i)})));assert.equal(data.chronology.status,'ambiguous_timestamps');assert.deepEqual(data.recent,[]);
});
test('MVP and score metrics distinguish absent values, explicit false, zero and invalid values',()=>{
  const make=(id,fields)=>presentMatch({record_id:String(id),common_info:{match_type:2,self_eid:'self',end_time:id},all_pl_info:[{eid:'self',utype:2,unique_id:'1',...fields}]});
  const records=[make(1,{mvp:true,total_score:0}),make(2,{mvp:false,total_score:100}),make(3,{}),make(4,{mvp:0,total_score:-1}),make(5,{mvp:'true',total_score:'100'})];
  assert.equal(records[2].summary.players[0].mvp,null);assert.equal(records[1].summary.players[0].mvp,false);assert.equal(records[2].summary.players[0].is_bot,null);
  const data=analyzeMatches(records).self_performance;
  assert.equal(data.mvp_count,1);assert.equal(data.mvp_known_matches,2);assert.equal(data.mvp_unknown_matches,3);assert.equal(data.mvp_rate,50);assert.equal(data.average_score,50);assert.equal(data.scored_matches,2);
  const missing=analyzeMatches([row(1,'unknown')]).self_performance;assert.equal(missing.mvp_rate,null);assert.equal(missing.average_score,null);
});
test('time-of-day analysis uses the selected zone and match end timestamps, even across DST',()=>{
  const records=[row(1,'win',{ended_at:'2026-11-01T08:30:00Z'}),row(2,'draw',{ended_at:'2026-11-01T09:30:00Z'}),row(3,'unknown',{ended_at:'bad'})];
  const la=analyzeMatches(records,{timeZone:'America/Los_Angeles'}).hourly;
  assert.equal(la.items.length,1);assert.equal(la.items[0].hour,1);assert.equal(la.items[0].total,2);assert.equal(la.items[0].win_rate,50);assert.equal(la.undated_matches,1);
  const jp=analyzeMatches(records,{timeZone:'Asia/Tokyo'}).hourly;assert.deepEqual(jp.items.map(x=>x.hour),[17,18]);
  assert.throws(()=>analysisTimeZone('bad/zone'),{code:'INVALID_TIMEZONE'});assert.throws(()=>analysisTimeZone(null),{code:'INVALID_TIMEZONE'});
});
test('empty and Mojin records never fabricate ordinary-mode scores or MVP results',()=>{
  const empty=analyzeMatches([]);assert.equal(empty.win_rate,null);assert.equal(empty.streaks.current,null);assert.equal(empty.streaks.longest_win,null);assert.equal(empty.self_performance.mvp_rate,null);assert.equal(empty.recent[0].total,0);
  const unknown=analyzeMatches([row(1,'unknown')]);assert.equal(unknown.streaks.longest_win,null);assert.equal(unknown.streaks.longest_loss,null);
  const mojin=analyzeMatches([row(1,'loss',{mode_id:102,players:[{is_self:true,deliver_value:0}]})],{mode:'mojin'});
  assert.equal(mojin.self_performance.average_score,null);assert.equal(mojin.self_performance.mvp_known_matches,0);assert.equal(mojin.recent[0].loss,1);
});
