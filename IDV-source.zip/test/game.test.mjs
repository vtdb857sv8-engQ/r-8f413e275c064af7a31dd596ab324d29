import test from 'node:test';
import assert from 'node:assert/strict';
import {decode} from '@msgpack/msgpack';
import {deflateSync} from 'node:zlib';
import {Rc4,FrameDecoder,frame,protobuf,parseProtobuf} from '../src/game/wire.mjs';
import {pack} from '../src/game/pack.mjs';
import {LiveGameProvider} from '../src/game/provider.mjs';
import {GameSession} from '../src/game/session.mjs';
import {presenceOf,profileOf,decodeRecords} from '../src/game/public-data.mjs';
import {eventTypes} from '../src/notification-rules.mjs';
test('RC4 matches RFC 6229 and maintains state across TCP fragments',()=>{
  const key=Buffer.from('0102030405','hex'),zero=Buffer.alloc(16),whole=new Rc4(key).update(zero);
  assert.equal(whole.toString('hex'),'b2396305f03dc027ccc3524a0a1118a8');
  const split=new Rc4(key);assert.deepEqual(Buffer.concat([split.update(zero.subarray(0,3)),split.update(zero.subarray(3))]),whole);
});
test('fragmented and coalesced frames decode and oversized lengths are rejected',()=>{
  const d=new FrameDecoder(),a=frame(3,Buffer.from('abc')),b=frame(5,Buffer.from('d'));
  assert.deepEqual(d.push(a.subarray(0,2)),[]);const output=d.push(Buffer.concat([a.subarray(2),b]));
  assert.equal(output.length,2);assert.equal(output[0].opcode,3);assert.equal(output[1].payload.toString(),'d');
  const huge=Buffer.alloc(4);huge.writeUInt32LE(0xffffffff);assert.throws(()=>new FrameDecoder().push(huge));
  const fields=parseProtobuf(protobuf([[2,Buffer.from('payload')],[3,123456789]]));assert.equal(fields.get(3)[0],123456789n);
});
test('MessagePack retains integer condition keys rather than stringifying them',()=>{
  assert.equal(pack(new Map([[1,[1]]])).toString('hex'),'81019101');
  assert.deepEqual(decode(pack({info:{cond_params:new Map([[1,[2]]])}})),{info:{cond_params:{1:[2]}}});
});
test('hidden presence never exposes internal logout time or positive real status',()=>{
  const raw={unique_id:'42',name:'player',online_stat:1,state_info:{state:1,hide_show:[]},logout_time:100,logout_time_no_hide:200,real_stat:1,sessionid:'private',civilian_data:{rank:2,access_token:'private',civilian_rank_hide_score:999}};
  const publicInfo=profileOf(raw,'1');assert.deepEqual(publicInfo.presence,{state:'unknown',visibility:'hidden'});
  assert.ok(!JSON.stringify(publicInfo).includes('private'));assert.ok(!JSON.stringify(publicInfo).includes('hide_score'));assert.ok(!JSON.stringify(publicInfo).includes('200'));
  assert.equal(presenceOf({...raw,state_info:{state:0}},'1').state,'online');assert.equal(presenceOf({...raw,state_info:{state:2}},'1').state,'busy');
});
test('unknown disclosure flags conceal another player while retaining authorized own-account observations',()=>{
  const raw={unique_id:'42',online_stat:1,avatar_notice_status:3,battle_stat:1,login_time:100,logout_time:200};
  for(const state_info of [undefined,null,[],0,'bad',{}, {state:'0'},{state:9},{state:false},Object.create({state:0})]){
    assert.deepEqual(presenceOf({...raw,state_info},'1'),{state:'unknown',visibility:'unknown'});
  }
  const visible=presenceOf({...raw,state_info:{state:0}},'1');assert.equal(visible.state,'in_match');assert.equal(visible.visibility,'visible');assert.equal(visible.last_logout_at,new Date(200000).toISOString());
  const own=presenceOf(raw,'42');assert.equal(own.state,'in_match');assert.equal(own.visibility,'unknown');assert.equal(own.last_login_at,new Date(100000).toISOString());
  const unknown=presenceOf(raw,'1');assert.deepEqual(eventTypes({previous_state:'in_match',state:unknown.state,previous_visibility:'visible',visibility:unknown.visibility}),[]);
  assert.deepEqual(eventTypes({previous_state:unknown.state,state:'offline',previous_visibility:unknown.visibility,visibility:'visible'}),[]);
});
test('malformed hide and busy exception lists cannot disclose a player or crash profile parsing',()=>{
  const raw={unique_id:'42',online_stat:1,login_time:100,logout_time:200};
  for(const list of [undefined,null,0,'1',{},[{}],false]){
    assert.deepEqual(presenceOf({...raw,state_info:{state:1,hide_show:list}},'1'),{state:'unknown',visibility:'hidden'});
    const busy=presenceOf({...raw,state_info:{state:2,busy_show:list}},'1');assert.equal(busy.state,'busy');assert.equal(busy.online_stat,undefined);
  }
  assert.equal(presenceOf({...raw,state_info:{state:1,hide_show:[1]}},'1').state,'online');
  assert.equal(presenceOf({...raw,state_info:{state:2,busy_show:['1']}},'1').state,'online');
  assert.equal(presenceOf({...raw,state_info:{state:1,hide_show:[undefined]}},undefined).visibility,'hidden');
});
test('compressed battle history is readable and corrupt payload is reported',()=>{
  const rows=decodeRecords([{tm:10,uuid:'match',origin_data:deflateSync(JSON.stringify({common_info:{end_time:10},all_pl_info:[{player_name:'p',session_token:'secret'}]}))}]);
  assert.equal(rows[0].record_id,'match');assert.equal(rows[0].all_pl_info[0].player_name,'p');assert.ok(!JSON.stringify(rows).includes('secret'));assert.throws(()=>decodeRecords([{origin_data:Buffer.from('broken')}]));
});
test('received profile data is displayed even when privacy settings hide it; unreadable settings still omit groups',()=>{
  const raw={unique_id:'2',name:'p',civilian_data:{private_stat:99},profile_tag_info:{badge:1},setting_show_info:{open_char_data:false,hide_badge:true}};
  let data=profileOf(raw,'1');assert.equal(data.field_access.statistics,'permitted');assert.equal(data.civilian_data.private_stat,99);assert.ok(data.profile_tag_info);
  data=profileOf({...raw,setting_show_info:undefined},'1');assert.equal(data.field_access.statistics,'unknown');assert.equal(data.civilian_data,undefined);
  data=profileOf({...raw,setting_show_info:{}},'1');assert.equal(data.civilian_data.private_stat,99);assert.equal(data.field_access.statistics,'permitted');
  data=profileOf(raw,'2');assert.equal(data.civilian_data.private_stat,99);assert.equal(data.field_access.statistics,'self');
  data=profileOf({...raw,setting_show_info:{open_char_data:0}},'1');assert.equal(data.field_access.statistics,'permitted');assert.equal(data.civilian_data.private_stat,99);
  data=profileOf({...raw,setting_show_info:{open_char_data:'unexpected'}},'1');assert.equal(data.field_access.statistics,'unknown');assert.equal(data.civilian_data,undefined);
});
test('recruitment arrives in the generic RPC envelope and receives its callback acknowledgement',async()=>{
  const session=new GameSession({}),id=Buffer.alloc(12),sent=[];
  session.gateway={next:async()=>({opcode:5,payload:protobuf([[2,id],[3,protobuf([[1,'server_client_gen_rpc_method']])],[4,pack({info:{callbackid:77,methodname:'request_recruit_info_lst_cb',args:[{recruit_info_lst:[{r_id:'listing'}]}],kwargs:{}}})]])}),send:(opcode,payload)=>sent.push({opcode,payload})};
  const event=await session.receive();assert.equal(event.name,'request_recruit_info_lst_cb');assert.equal(event.parameters.recruit_info_lst[0].r_id,'listing');
  assert.equal(sent.length,1);const reply=decode(parseProtobuf(sent[0].payload).get(4)[0]);assert.deepEqual(reply,{info:{callbackid:77,res:[0,true]}});
});
test('badge replies in the UI callback envelope are unwrapped without executing arbitrary callbacks',async()=>{
  const session=new GameSession({}),id=Buffer.alloc(12);
  session.gateway={next:async()=>({opcode:5,payload:protobuf([[2,id],[3,protobuf([[1,'reply_client_rpc']])],[4,pack({info:{func:'reply_get_history_badge',uid:'20',info:{14:{badge_info:{S:{num:2}}}},tid:'notice'}})]])})};
  const event=await session.receive();assert.equal(event.name,'reply_get_history_badge');assert.equal(event.parameters.info.uid,'20');assert.equal(event.parameters.info.info[14].badge_info.S.num,2);assert.equal(event.parameters.info.tid,undefined);
});
class FakeSession{
  constructor(){this.avatar=Buffer.alloc(12);this.waiters=[];this.queue=[];this.sent=[];}
  async login(){this.push('init_player',{info:{nickname:'me'}});this.push('notify_friends_info',{info:[['20'],{'20':{unique_id:'20',name:'friend',online_stat:1}}]});return{authenticated:true,avatar_info:{unique_id:'10'}};}
  push(name,parameters){const e={kind:'rpc',name,parameters};const w=this.waiters.shift();if(w)w.resolve(e);else this.queue.push(e);}
  receive(){if(this.queue.length)return Promise.resolve(this.queue.shift());return new Promise((resolve,reject)=>this.waiters.push({resolve,reject}));}
  sendEntity(id,name,parameters){this.sent.push({name,parameters});}
  close(){for(const w of this.waiters.splice(0))w.reject(new Error('closed'));}
}
test('character boards use character-specific cache and ignore other board replies',async t=>{
  const session=new FakeSession(),p=new LiveGameProvider({}, {sessionFactory:()=>session});t.after(()=>p.disconnect());await p.connect({login_info:{info:{}}});
  const a=p.getRankings({kind:'survivor',character_id:14,limit:100});await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(session.sent.at(-1),{name:'ask_rank_data',parameters:{show_tab:'2',show_camp:'rank_14'}});
  session.push('reply_rank_data',{info:{show_camp:'rank_c',rank_lst:[{uid:'wrong'}]}});
  session.push('reply_rank_data',{info:{show_camp:'rank_14',rank_lst:[{unique_id:'30',name:'p',ladder_score:14487,score:1}]}});
  const result=await a;assert.equal(result.items[0].player_id,'30');assert.equal(result.items[0].character_score,14487);assert.equal(result.character_id,14);
  const b=p.getRankings({kind:'hunter',character_id:1});await new Promise(resolve=>setImmediate(resolve));assert.equal(session.sent.at(-1).parameters.show_camp,'rank_1');
  session.push('reply_rank_data',{info:{show_camp:'rank_1',rank_lst:[{uid:'40',score:100}]}});assert.equal((await b).items[0].character_score,100);
  await assert.rejects(p.getRankings({kind:'survivor',character_id:0}),{code:'INVALID_CHARACTER'});
});
test('received history badges are displayed even when the fresh disclosure hides them; unreadable settings stay refused',async t=>{
  const session=new FakeSession(),p=new LiveGameProvider({}, {sessionFactory:()=>session});t.after(()=>p.disconnect());await p.connect({login_info:{info:{}}});
  const flush=()=>new Promise(resolve=>setImmediate(resolve));
  for(const [flag,expected]of [[true,null],['unexpected','HISTORY_BADGES_PERMISSION_UNKNOWN'],[false,null]]){
    p.cache.set('profile:20',{expires:Date.now()+60000,value:Promise.resolve({info:{base_info:{setting_show_info:{}}}})});
    const request=p.getHistoryBadges('20');const observed=request.then(v=>({value:v}),e=>({error:e}));await flush();
    assert.equal(session.sent.at(-1).name,'get_history_badge');session.push('reply_get_history_badge',{info:{uid:'21',info:{}}});
    session.push('reply_get_history_badge',{info:{uid:'20',info:{14:{highest_badge:{grade:'A'}}}}});await flush();assert.equal(session.sent.at(-1).name,'ask_player_cil_butcher_data');
    session.push('reply_cil_butcher_data',{info:{base_info:{setting_show_info:{hide_badge:true,hide_history_badge:flag}}}});await flush();
    session.push('reply_cil_butcher_data',{info:{base_info:{setting_show_info:{hide_badge:true,hide_history_badge:flag}}}});const result=await observed;
    if(expected)assert.equal(result.error.code,expected);else{assert.equal(result.value.access,'permitted');assert.equal(result.value.records[14].highest_badge.grade,'A');}
  }
  const own=p.getHistoryBadges('10');await flush();assert.equal(session.sent.at(-1).parameters.uid,'10');session.push('reply_get_history_badge',{info:{uid:'10',info:{}}});assert.deepEqual(await own,{player_id:'10',access:'self',records:{}});
});
test('UGC reads correlate callback ids, report failures and keep play history self scoped',async t=>{
  const session=new FakeSession(),p=new LiveGameProvider({}, {sessionFactory:()=>session});t.after(()=>p.disconnect());await p.connect({login_info:{info:{}}});
  const a=p.getUGCPlayHistory();await new Promise(resolve=>setImmediate(resolve));const sent=session.sent.at(-1).parameters.info;
  assert.equal(sent.methodname,'get_ugc_play_record');assert.deepEqual(sent.args,[]);
  session.push('rpc_callback',{info:{callbackid:sent.callbackid+1,res:[0,{wrong:true}]}});
  session.push('rpc_callback',{info:{callbackid:sent.callbackid,res:[0,{}]}});assert.deepEqual(await a,{scope:'self',records:{}});
  const b=p.getUGCRankings({period:'month',tag:1000});await new Promise(resolve=>setImmediate(resolve));const rank=session.sent.at(-1).parameters.info;
  assert.equal(rank.methodname,'get_ugc_rank_month_maps');assert.deepEqual(rank.args,[1000,null]);
  session.push('rpc_callback',{info:{callbackid:rank.callbackid,res:[0,[{name:'map',session_token:'secret'}]]}});assert.deepEqual((await b).items,[{name:'map'}]);
  await assert.rejects(p.requestUGCRead('ugc_publish_map',[]),{code:'INVALID_UGC_READ'});
  const failed=p.getUGCRankings({period:'week'});await new Promise(resolve=>setImmediate(resolve));session.push('rpc_callback',{info:{callbackid:session.sent.at(-1).parameters.info.callbackid,res:[1,[]]}});await assert.rejects(failed,{code:'UGC_DATA_UNAVAILABLE'});
  await p.disconnect();await assert.rejects(p.getUGCPlayHistory(),{code:'GAME_NOT_CONNECTED'});
});
test('live provider serializes uncorrelated RPCs and only returns public room chat',async t=>{
  const session=new FakeSession(),p=new LiveGameProvider({}, {sessionFactory:()=>session,searchIntervalMs:0});t.after(()=>p.disconnect());await p.connect({login_info:{info:{}}});
  assert.equal(p.independentVerified,true);assert.equal((await p.getFriends())[0].player_id,'20');
  const a=p.searchPlayers('first'),b=p.searchPlayers('second');await new Promise(resolve=>setImmediate(resolve));assert.equal(session.sent.length,1);
  session.push('reply_rank_data',{info:{}});session.push('reply_friend_search',{info:[{_id:'30',name:'first'}]});assert.equal((await a)[0].name,'first');
  await new Promise(resolve=>setImmediate(resolve));assert.equal(session.sent.length,2);session.push('reply_friend_search',{info:[]});assert.deepEqual(await b,[]);
  session.push('on_receive_chat',{info:{channel:99,content:'private',unique_id:'30'}});
  session.push('on_receive_region_chat_lst',{info:{chat_info_lst:[{channel:4,content:'public',unique_id:'30',time:10,sign:'secret'}]}});await new Promise(resolve=>setImmediate(resolve));
  p.cache.set('chat:join',{expires:Date.now()+60000,value:Promise.resolve({})});
  const chat=await p.getGlobalChat({limit:50});assert.equal(chat.items.length,1);assert.equal(chat.items[0].content,'public');assert.ok(!JSON.stringify(chat).includes('secret'));
});
test('an RPC timeout closes the session so late replies cannot match later requests',async t=>{
  const session=new FakeSession(),p=new LiveGameProvider({}, {sessionFactory:()=>session,requestTimeoutMs:10});t.after(()=>p.disconnect());await p.connect({login_info:{info:{}}});
  const first=p.searchPlayers('a'),second=p.searchPlayers('b');const settled=await Promise.allSettled([first,second]);
  assert.equal(settled[0].reason.code,'GAME_RESPONSE_TIMEOUT');assert.equal(settled[1].reason.code,'GAME_NOT_CONNECTED');assert.equal(p.connected,false);
  assert.equal(p.lastDisconnect.code,'GAME_RESPONSE_TIMEOUT');assert.equal(p.lastDisconnect.retryable,true);assert.equal(p.lastDisconnect.request_method,'search_name');assert.ok(!Object.hasOwn(p.lastDisconnect,'parameters'));
});
test('queued reads and messages are not replayed into a replacement session',async()=>{
  const p=new LiveGameProvider({}),sent=[];p.connected=true;p.session={avatar:Buffer.alloc(12),sendEntity:(...args)=>sent.push(args)};p.friends.set('friend',{unique_id:'20'});
  let release;p.serial=new Promise(resolve=>{release=resolve;});
  const read=p.request('search_name',{name:'test'},'reply_friend_search'),message=p.sendChat({friendId:'20',content:'test',clientMessageId:'test-message-123456'});
  const observed=Promise.allSettled([read,message]);p.session={avatar:Buffer.alloc(12),sendEntity:(...args)=>sent.push(args)};release();
  for(const result of await observed){assert.equal(result.status,'rejected');assert.equal(result.reason.code,'GAME_SESSION_CHANGED');}assert.equal(sent.length,0);
});
test('a read waiting for its cooldown cannot cross a reconnection',async()=>{
  const p=new LiveGameProvider({}, {searchIntervalMs:30}),sent=[];p.connected=true;p.session={avatar:Buffer.alloc(12),sendEntity:(...args)=>sent.push(args)};p.lastSearchAt=Date.now();
  const read=p.request('search_name',{name:'test'},'reply_friend_search');await new Promise(resolve=>setImmediate(resolve));p.session={avatar:Buffer.alloc(12),sendEntity:(...args)=>sent.push(args)};
  await assert.rejects(read,{code:'GAME_SESSION_CHANGED'});assert.equal(sent.length,0);
});
