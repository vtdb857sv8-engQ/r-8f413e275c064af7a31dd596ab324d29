import test from 'node:test';
import assert from 'node:assert/strict';
import {GameSession} from '../src/game/session.mjs';

function scripted(parameters,{avatar=false}={}){
  const s=new GameSession({}),sent=[];let reads=0;
  s.boot=Buffer.alloc(12);s.open=async()=>{};s.sendEntity=(id,name,parameters)=>sent.push({name,parameters});
  s.receive=async()=>{
    reads++;
    if(reads===1)return {kind:'rpc',name:'become_player'};
    if(reads===2)return {kind:'rpc',name:'on_login',parameters};
    if(avatar&&reads===3){assert.equal(s.authenticated,false);s.avatar=Buffer.alloc(12,1);s.entities.set(s.avatar.toString('hex'),{info:{unique_id:'10'}});s.authenticated=true;return{kind:'entity_created',type:'Avatar'};}
    throw Error('GATEWAY_RESPONSE_TIMEOUT');
  };
  return{s,sent,reads:()=>reads};
}

test('positional SDK rejection is handled before a timeout without exposing server text or extra data',async()=>{
  const raw={_:[{code:6,msg:'never-print-session-token',extra:{code:-1,ban_code:['not-a-ban-conclusion'],sessionid:'never-print-session-token'},tid:'TID_LOGIN_FAILED_UNKNOWN'}]};
  const f=scripted(raw);
  await assert.rejects(f.s.login({login_confirm:false}),error=>{
    assert.equal(error.code,'SDK_AUTH_REJECTED');assert.equal(error.status,409);assert.equal(error.serverLoginCode,6);
    assert.ok(!error.message.includes('never-print'));assert.ok(!JSON.stringify(error).includes('ban_code'));assert.ok(!/期限切れ|利用停止/.test(error.message));return true;
  });
  assert.equal(f.reads(),2);assert.equal(f.s.authenticated,false);assert.equal(f.sent.length,1);
  assert.equal(f.sent[0].name,'sdk_login_gas3');assert.equal(f.sent[0].parameters.login_info.login_confirm,false);
});

test('only original success codes 7 and 8 continue, and neither authenticates without an Avatar',async()=>{
  for(const parameters of [{_:[{code:7}]},{info:{code:8}}]){
    const f=scripted(parameters,{avatar:true}),result=await f.s.login({login_confirm:false});
    assert.equal(result.authenticated,true);assert.equal(result.avatar_info.unique_id,'10');assert.equal(f.reads(),3);
    const withoutAvatar=scripted(parameters);
    await assert.rejects(withoutAvatar.s.login({login_confirm:false}),/GATEWAY_RESPONSE_TIMEOUT/);assert.equal(withoutAvatar.s.authenticated,false);
  }
  for(const code of [0,1,9,999])await assert.rejects(scripted({info:{code}}).s.login({login_confirm:false}),error=>error.code==='GAME_LOGIN_REJECTED'&&error.serverLoginCode===code);
});

test('missing, malformed and ambiguous login replies are unverified rather than SDK failures or successes',async()=>{
  for(const parameters of [null,{},[],{_:[]},{_:[{code:7},{}]},{_:[{code:7}],info:{code:7}},{info:{code:'7'}},{info:{code:true}},{info:{code:-1}},{info:{code:NaN}},{info:Object.create({code:7})}]){
    const f=scripted(parameters);
    await assert.rejects(f.s.login({login_confirm:false}),error=>error.code==='GAME_LOGIN_RESPONSE_INVALID'&&error.serverLoginCode===null);
    assert.equal(f.s.authenticated,false);assert.equal(f.reads(),2);
  }
});
