import test from 'node:test';
import assert from 'node:assert/strict';
import {inflateSync} from 'node:zlib';
import {rankOf,presentProfile,presentMatch,presentHistoryBadges,analyzeMatches} from '../src/game/presentation.mjs';
import {texturePNG} from '../src/game/texture.mjs';
import {LiveGameProvider} from '../src/game/provider.mjs';
import {profileOf,decodeRecords} from '../src/game/public-data.mjs';

test('unverified report-specific character values are omitted without inventing deductions or changing the input',()=>{
  const raw={common_info:{self_eid:'own',match_type:1,wdf:[1,-1]},all_pl_info:[{eid:'own',utype:2,unique_id:'10',total_score:100,res_type:5,is_free_exit:false,character_value_info:{ori_character_value:[100],dec_character_value:1}},{eid:'other',utype:1,unique_id:'20',total_score:200,character_value_info:{ori_character_value:[80],dec_character_value:2}}],extra:{character_value_info:{ori_character_value:[90],dec_character_value:3}}};
  const decoded=decodeRecords([raw])[0],result=presentMatch(decoded);
  assert.ok(!JSON.stringify(result).includes('character_value_info'));assert.equal(result.all_pl_info[0].total_score,100);assert.equal(result.all_pl_info[0].res_type,5);assert.equal(result.summary.result,'win');assert.equal(result.summary.players[1].score,200);
  assert.deepEqual(raw.all_pl_info[0].character_value_info,{ori_character_value:[100],dec_character_value:1});assert.ok(raw.extra.character_value_info);
  const direct=presentMatch(raw);assert.equal(direct.all_pl_info[0].character_value_info,undefined);assert.equal(direct.all_pl_info[1].character_value_info,undefined);
});
test('current badges honor visibility and expiry and are distinct from unreceived data',()=>{
  const raw={unique_id:'10',time_limited_article:{50:{14:[3,Date.now()/1000+3600],3:[4,1]}},setting_show_info:{}};
  const catalog={characters:{14:{name:'医師',camp:'survivor'}}};
  let p=presentProfile(profileOf(raw,'10'),catalog);assert.equal(p.profile_tag_info.character_badges.length,1);assert.equal(p.profile_tag_info.character_badges[0].label,'医師 A徽章');assert.equal(p.profile_tag_info.character_badges[0].asset,'badge-survivor-a');assert.equal(p.badge_records,undefined);
  p=presentProfile(profileOf({...raw,setting_show_info:{hide_badge:true}},'20'),catalog);assert.equal(p.profile_tag_info.character_badges.length,1);
  p=presentProfile(profileOf({unique_id:'10'},'10'),catalog);assert.equal(p.profile_tag_info,undefined);
  p=presentProfile(profileOf({unique_id:'10',time_limited_article:{}},'10'),catalog);assert.deepEqual(p.profile_tag_info.character_badges,[]);
});
test('ranks use numeric tiers and highest season only when the response identifies it',()=>{
  assert.equal(rankOf({part:5,part_lv:3},'survivor').label,'五段III');
  const raw={field_access:{statistics:'permitted'},civilian_data:{part:2,part_lv:3,season_id:44,max_part_record:[6,1,0,0,99],history_season_data:{43:{season_max_part_record:[5,1,0]}}}};
  const p=presentProfile(raw);assert.equal(p.ranks.survivor.highest.label,'六段I');assert.equal(p.ranks.survivor.highest.season_id,null);
  assert.equal(presentProfile({...raw,field_access:{statistics:'hidden'}}).ranks,null);
});
test('match results use the player camp; entity ids never become searchable player ids',()=>{
  const r=presentMatch({common_info:{self_eid:'entity',wdf:[1,-1],match_type:2,scene_id:6},all_pl_info:[{eid:'entity',utype:1,pid:1,player_name:'A'}]},{maps:{6:{name:'軍需工場'}}});
  assert.equal(r.summary.result,'loss');assert.equal(r.summary.map_name,'軍需工場');assert.equal(r.summary.players[0].player_id,null);
  const data=analyzeMatches([r,{summary:{result:'unknown',map_id:6,players:[]}}]);assert.equal(data.known_results,1);assert.equal(data.win_rate,0);assert.equal(data.average_duration,null);assert.equal(data.identity_based_partner_analysis_available,false);
});
test('public match details keep historical rank separate and mode rates exclude unknown results',()=>{
  const r=presentMatch({common_info:{self_eid:'e',wdf:[1,-1],match_type:2},all_pl_info:[{eid:'e',utype:2,lv:21,rank_info:{part:5,part_lv:3},total_score:1200,mvp:true,unique_id:'123'}]});
  assert.equal(r.summary.players[0].match_rank.label,'五段III');assert.equal(r.summary.players[0].level,21);assert.equal(r.summary.players[0].mvp,true);
  const unknown=presentMatch({common_info:{match_type:2},all_pl_info:[]});assert.equal(unknown.summary.players.length,0);
  const result=analyzeMatches([r,unknown,{summary:{mode_id:2,result:'loss',players:[]}},{summary:{mode_id:1,result:'draw',players:[]}}]);
  assert.equal(result.by_mode.find(x=>x.id===2).total,3);assert.equal(result.by_mode.find(x=>x.id===2).win_rate,50);
  assert.equal(result.by_mode.find(x=>x.id===1).win_rate,0);
  const peers=analyzeMatches([{summary:{result:'win',players:[{player_id:'10',is_self:true},{player_id:'20',is_self:false}]}}]);
  assert.equal(peers.public_participant_ids_available,true);assert.equal(peers.identity_based_partner_analysis_available,false);
});
test('partner analysis distinguishes public parties from teammates, excludes opponents and deduplicates records',()=>{
  const match=(id,result,visible=true)=>presentMatch({record_id:id,common_info:{self_eid:'me',match_type:2,wdf:[result,-result],end_time:100},all_pl_info:[
    {eid:'me',utype:2,unique_id:'10',team_uid:'party',show_team:true},
    {eid:'a',utype:2,unique_id:'20',player_name:'peer',team_uid:'party',show_team:visible},
    {eid:'duplicate',utype:2,unique_id:'20',player_name:'peer',team_uid:'party',show_team:visible},
    {eid:'b',utype:2,unique_id:'30',player_name:'random',team_uid:'other',show_team:true},
    {eid:'bot',utype:2,unique_id:'40',bot:true},
    {eid:'opponent',utype:1,unique_id:'50',team_uid:'party',show_team:true},
    {eid:'unknown',utype:2,player_name:'unidentified'}]});
  const win=match('a',1),loss=match('b',-1),hidden=match('c',0,false);
  const data=analyzeMatches([win,win,loss,hidden]);
  assert.equal(data.total,3);assert.equal(data.by_party_partner.length,1);assert.equal(data.by_party_partner[0].total,2);assert.equal(data.by_party_partner[0].win_rate,50);
  assert.equal(data.by_teammate.length,2);assert.equal(data.by_teammate.find(x=>x.player_id==='20').total,3);assert.equal(data.partner_coverage.public_party_matches,2);
  assert.equal(hidden.summary.players[1].premade_with_owner,null);assert.ok(!JSON.stringify(hidden).includes('party'));assert.equal(data.identity_based_partner_analysis_available,true);
  const unknown=analyzeMatches([{summary:{mode_id:2,result:'unknown',players:[{is_self:true,player_id:'1',camp:'survivor'},{player_id:'2',camp:'survivor',premade_with_owner:true}]}}]);assert.equal(unknown.by_party_partner[0].win_rate,null);
  const noOwner=presentMatch({common_info:{match_type:2},all_pl_info:[{unique_id:'20',utype:2}]});assert.equal(noOwner.summary.players[0].is_self,false);assert.equal(analyzeMatches([noOwner]).by_teammate.length,0);
});
test('past badges keep grade counts and game history art separate from unreceived data',()=>{
  const data=presentHistoryBadges({player_id:'20',access:'permitted',records:{14:{highest_badge:{grade:'A'},hightest_rank_score:7335,badge_info:{A:{num:4,latest_date:'2025-06-16'}}},15:{highest_badge:{grade:'?'},hightest_rank_score:-1}}},{characters:{14:{name:'医師',camp:'survivor',asset:'character-14'}}});
  assert.equal(data.items[0].highest_asset,'badge-survivor-a-history');assert.equal(data.items[0].grades[0].count,0);assert.equal(data.items[0].grades[1].count,4);assert.equal(data.items[0].grades[1].latest_date,'2025-06-16');assert.equal(data.items[1].grades[0].count,null);assert.equal(data.items[1].highest_score,null);
});
test('DXT1 conversion keeps original pixels and rejects truncated or oversized textures',()=>{
  const source=Buffer.alloc(136);source.write('DDS ');source.writeUInt32LE(4,12);source.writeUInt32LE(4,16);source.write('DXT1',84);source.writeUInt16LE(0xf800,128);
  const png=texturePNG(source);assert.equal(png.readUInt32BE(16),4);let cursor=8;const parts=[];
  while(cursor<png.length){const size=png.readUInt32BE(cursor),type=png.toString('ascii',cursor+4,cursor+8);if(type==='IDAT')parts.push(png.subarray(cursor+8,cursor+8+size));cursor+=12+size;}
  const pixels=inflateSync(Buffer.concat(parts));assert.deepEqual([...pixels.subarray(0,5)],[0,255,0,0,255]);
  assert.throws(()=>texturePNG(source.subarray(0,130)),/TRUNCATED/);source.writeUInt32LE(4096,16);assert.throws(()=>texturePNG(source),/UNSUPPORTED/);
});
test('chat sends deduplicate concurrent retries and use the internal friend uid for the selected public id',async()=>{
  const p=new LiveGameProvider({}),sent=[];p.connected=true;p.selfId='10';p.selfInfo={unique_id:'10'};p.session={avatar:Buffer.alloc(12),sendEntity:(...args)=>sent.push(args)};p.friends.set('internal-friend',{unique_id:'20',name:'friend'});
  const input={friendId:'20',content:'test',clientMessageId:'message-12345678'};
  const [a,b]=await Promise.all([p.sendChat(input),p.sendChat(input)]);assert.deepEqual(a,b);assert.equal(sent.length,1);assert.equal(sent[0][1],'friend_chat');assert.equal(sent[0][2].info.uid,'internal-friend');assert.equal(a.server_confirmation,false);
  await assert.rejects(p.sendChat({...input,content:'different'}),{code:'MESSAGE_ID_CONFLICT'});
  p.handle({kind:'rpc',name:'on_friend_chat',parameters:{info:{uid:'internal-friend',message_type:0,message:'received'}}});assert.equal(p.privateChats.get('20')[0].author.player_id,'20');
});
test('a room change while a send is queued cannot send to the wrong public room',async()=>{
  const p=new LiveGameProvider({chat_rooms:[{id:'3'}]}),sent=[];p.connected=true;p.hostNum=10005;p.chatRoom={province_id:'3'};p.publicChannels.add('4');p.session={avatar:Buffer.alloc(12),sendEntity:(...v)=>sent.push(v)};
  let resume;p.serial=new Promise(r=>{resume=r;});const send=p.sendChat({room:'3',content:'test',clientMessageId:'message-abcdefgh'});await new Promise(r=>setImmediate(r));p.chatRoom={province_id:'2'};resume();await assert.rejects(send,{code:'CHAT_ROOM_CHANGED'});assert.equal(sent.length,0);
});
