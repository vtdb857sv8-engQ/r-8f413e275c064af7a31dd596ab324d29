import test from 'node:test';
import assert from 'node:assert/strict';
import {LiveGameProvider} from '../src/game/provider.mjs';
import {ugcRankMetadata,presentUGCMapRanking} from '../src/game/ugc-data.mjs';

test('UGC public settings and response shapes fail closed',()=>{
  const doc={_id:'42',name:'作品',open_rank:true};
  assert.deepEqual(ugcRankMetadata(doc,'42'),{map_id:'42',name:'作品'});
  for(const flag of [false,0])assert.throws(()=>ugcRankMetadata({...doc,open_rank:flag},'42'),{code:'UGC_RANKING_PRIVATE'});
  for(const flag of [undefined,null,'true',{}])assert.throws(()=>ugcRankMetadata({...doc,open_rank:flag},'42'),{code:'UGC_RANKING_PERMISSION_UNKNOWN'});
  assert.throws(()=>ugcRankMetadata(doc,'43'),{code:'UGC_FORMAT_UNSUPPORTED'});
  for(const payload of [null,[],[[],5,1,''],[[],1,3,''],[[{score:1,member:{}}],1,2,''],[[{score:'1'}],1,1,'']])assert.throws(()=>presentUGCMapRanking(payload,{}),{code:'UGC_FORMAT_UNSUPPORTED'});
});

test('UGC time and event records preserve game order and whitelist public members',()=>{
  const player={uid:'20',name:'公開名',face_id:1,face_frame_id:2,face_vfx_id:3,setting_show_info:{private:true},image_role:99,session_token:'secret'};
  const team=presentUGCMapRanking([[{score:90.25,member:[player]}],1,2,'タイム'],{map_id:'42',name:'作品'});
  assert.equal(team.score_unit,'seconds');assert.equal(team.order,'ascending');assert.equal(team.items[0].score_display,'01:30.25');assert.deepEqual(team.items[0].members,[{player_id:'20',name:'公開名',face_id:1,face_frame_id:2,face_vfx_id:3}]);
  assert.ok(!JSON.stringify(team).includes('secret'));assert.ok(!JSON.stringify(team).includes('image_role'));
  const solo=presentUGCMapRanking([[{...player,score:100},{uid:'not-id',score:50}],3,1,''],{});
  assert.equal(solo.score_kind,'event');assert.equal(solo.order,'descending');assert.equal(solo.score_unit,null);assert.equal(solo.items[0].score_display,'100');assert.equal(solo.items[1].members[0].player_id,null);
  assert.deepEqual(presentUGCMapRanking([[],2,1,''],{}).items,[]);
});

test('UGC rankings recheck uncached permissions after receipt and do not request private boards',async()=>{
  const p=new LiveGameProvider({});p.connected=true;p.session={};
  for(const [flag,code,expectedCalls]of [[false,'UGC_RANKING_PRIVATE',1],[undefined,'UGC_RANKING_PERMISSION_UNKNOWN',1],[true,null,3]]){
    const calls=[];p.requestUGCRead=async(method,args)=>{calls.push([method,args]);return method==='get_ugc_map_info'?{_id:'42',name:'作品',open_rank:flag}:[[],1,1,''];};
    if(code)await assert.rejects(p.getUGCMapRanking('42'),{code});else assert.equal((await p.getUGCMapRanking('42')).visibility,'public');
    assert.equal(calls.length,expectedCalls);assert.deepEqual(calls[0],['get_ugc_map_info',['42']]);
    if(!code)assert.deepEqual(calls.map(x=>x[0]),['get_ugc_map_info','get_ugc_map_single_rank','get_ugc_map_info']);
  }
  const calls=[];p.requestUGCRead=async method=>{calls.push(method);return method==='get_ugc_map_single_rank'?[[{uid:'20',name:'must not escape',score:1}],1,1,'']:{_id:'42',open_rank:calls.length===1};};
  await assert.rejects(p.getUGCMapRanking('42'),{code:'UGC_RANKING_PRIVATE'});assert.equal(calls.length,3);
  calls.length=0;await assert.rejects(p.getUGCMapRanking('not-published-id'),{code:'INVALID_UGC_MAP'});assert.equal(calls.length,0);
});

test('UGC records are discarded if the session changes during acquisition',async()=>{
  for(const stage of [1,2,3]){
    const p=new LiveGameProvider({});p.connected=true;p.session={};let calls=0;
    p.requestUGCRead=async method=>{calls++;if(calls===stage)p.session={};return method==='get_ugc_map_single_rank'?[[],1,1,'']:{_id:'42',open_rank:true};};
    await assert.rejects(p.getUGCMapRanking('42'),{code:'GAME_SESSION_CHANGED'});assert.equal(calls,stage);
  }
});

test('a UGC metadata read waiting for its interval cannot cross a session change',async()=>{
  const p=new LiveGameProvider({}, {ugcInfoIntervalMs:30}),sent=[];p.connected=true;p.session={avatar:Buffer.alloc(12),sendEntity:(...args)=>sent.push(args)};p.lastUGCInfoAt=Date.now();
  const read=p.requestUGCRead('get_ugc_map_info',['42']);await new Promise(resolve=>setImmediate(resolve));p.session={avatar:Buffer.alloc(12),sendEntity:(...args)=>sent.push(args)};
  await assert.rejects(read,{code:'GAME_SESSION_CHANGED'});assert.equal(sent.length,0);
});
