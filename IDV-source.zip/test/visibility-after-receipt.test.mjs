import test from 'node:test';
import assert from 'node:assert/strict';
import {presenceOf,profileOf,profileAfterReceipt} from '../src/game/public-data.mjs';
import {LiveGameProvider} from '../src/game/provider.mjs';

test('received offline-shaped data is filtered by disclosure before profile output, including internal online and logout fields',()=>{
  const received={unique_id:'42',name:'synthetic',online_stat:0,real_stat:1,avatar_notice_status:3,battle_stat:1,login_time:100,logout_time:200,logout_time_no_hide:999,state_info:{state:1,hide_show:[]}};
  const hidden=profileOf(received,'1');
  assert.deepEqual(hidden.presence,{state:'unknown',visibility:'hidden'});
  assert.equal(hidden.presence.last_login_at,undefined);assert.equal(hidden.presence.last_logout_at,undefined);
  assert.ok(!/real_stat|logout_time_no_hide|999/.test(JSON.stringify(hidden)));
  // A normal public offline response can show its public time, never the internal time.
  const visible=presenceOf({...received,state_info:{state:0}},'1');
  assert.equal(visible.state,'offline');assert.equal(visible.visibility,'visible');
  assert.equal(visible.last_logout_at,new Date(200000).toISOString());
  assert.equal(visible.real_stat,undefined);assert.equal(visible.logout_time_no_hide,undefined);
  const unknown=presenceOf({...received,state_info:undefined},'1');
  assert.deepEqual(unknown,{state:'unknown',visibility:'unknown'});
  // Receipt is not a permission decision; the unmodified synthetic input still has both fields.
  assert.equal(received.real_stat,1);assert.equal(received.logout_time_no_hide,999);
});
const publicInfo=()=>({unique_id:'20',name:'synthetic',setting_show_info:{},state_info:{state:0},online_stat:1,login_time:100,logout_time:200,civilian_data:{normal_battle_cnt:5},butcher_data:{},battle_count:5,profile_tag_info:{label:'public'}});
test('profile disclosure is rechecked after data receipt and unreadable settings omit groups',()=>{
 const first=publicInfo(),latest={...publicInfo(),setting_show_info:{open_char_data:'unexpected',hide_badge:'unexpected'},state_info:{state:1},online_stat:0};
 const value=profileAfterReceipt(first,latest,'10',{completeProfile:true,specialFriendIds:[]});
 assert.equal(value.field_access.statistics,'unknown');assert.equal(value.civilian_data,undefined);assert.equal(value.battle_count,undefined);assert.equal(value.profile_tag_info,undefined);
 assert.deepEqual(value.presence,{state:'unknown',visibility:'hidden'});assert.equal(value.disclosure.policy,'after_receipt');
 assert.equal(first.civilian_data.normal_battle_cnt,5);assert.equal(first.logout_time,200);
});
test('missing latest disclosure settings cannot retain earlier public statistics',()=>{
 const value=profileAfterReceipt(publicInfo(),{...publicInfo(),setting_show_info:undefined},'10',{completeProfile:true,specialFriendIds:[]});
 assert.equal(value.field_access.statistics,'unknown');assert.equal(value.civilian_data,undefined);
});
test('a private latest policy still displays received data',()=>{
 const value=profileAfterReceipt({...publicInfo(),setting_show_info:{open_char_data:false}},publicInfo(),'10',{completeProfile:true,specialFriendIds:[]});
 assert.equal(value.field_access.statistics,'permitted');assert.equal(value.civilian_data.normal_battle_cnt,5);
});
test('profile provider reads data then policy without using an earlier permitted cache',async()=>{
 const p=new LiveGameProvider({special_friend_ids:[]});p.connected=true;p.selfId='10';p.session={};let n=0;
 p.request=async()=>({info:++n===1?publicInfo():{...publicInfo(),setting_show_info:{open_char_data:'unexpected'}}});
 const result=await p.getProfile('20');assert.equal(n,2);assert.equal(result.field_access.statistics,'unknown');assert.equal(p.cache.size,0);
});
test('profile recheck rejects another target and a changed game session',async()=>{
 for(const kind of ['target','session']){
  const p=new LiveGameProvider({special_friend_ids:[]});p.connected=true;p.selfId='10';p.session={};let n=0;
  p.request=async()=>{n++;if(kind==='session'&&n===2)p.session={};return {info:{...publicInfo(),unique_id:kind==='target'&&n===2?'30':'20'}};};
  await assert.rejects(p.getProfile('20'),{code:kind==='target'?'PROFILE_RESPONSE_MISMATCH':'GAME_SESSION_CHANGED'});
 }
});
test('a session change discards acquired history and badges before disclosure',async()=>{
 for(const kind of ['history','badges']){
  const p=new LiveGameProvider({});p.connected=true;p.selfId='10';p.session={};
  p.request=async()=>{p.session={};return {info:{uid:'20',show_battle_record:true,battle_records:[],info:{}}};};
  await assert.rejects(kind==='history'?p.fetchHistory('20'):p.getHistoryBadges('20'),{code:'GAME_SESSION_CHANGED'});
 }
});
