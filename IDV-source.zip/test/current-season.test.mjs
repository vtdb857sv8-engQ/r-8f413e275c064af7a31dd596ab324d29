import test from 'node:test';
import assert from 'node:assert/strict';
import {presentProfile} from '../src/game/presentation.mjs';
import {profileOf} from '../src/game/public-data.mjs';
const counters=(total,wins,losses)=>({normal_battle_cnt:total,normal_battle_win_cnt:wins,normal_battle_lose_cnt:losses,rank_battle_cnt:0,rank_battle_win_cnt:0,rank_battle_lose_cnt:0});
const own=data=>presentProfile({field_access:{statistics:'self'},civilian_data:data}).current_season_statistics;
test('current profile season uses cumulative minus all historical counts, not cumulative or recent matches',()=>{
 const d={season_id:44,...counters(52,49,2),history_season_data:{35:counters(20,19,1),43:counters(27,26,1)}};
 const r=own(d);assert.equal(r.survivor.season_id,44);assert.equal(r.survivor.history_seasons_count,2);assert.deepEqual(r.survivor.statistics[0],{mode:'normal',label:'通常戦',total:5,wins:4,losses:0,consistent:true});assert.equal(r.hunter,null);
 assert.equal(r.survivor.statistics[1].total,0);assert.equal(d.normal_battle_cnt,52);
});
test('missing historical inputs stay unknown while explicitly empty history and zero remain usable',()=>{
 const d={season_id:44,...counters(5,4,0)};
 for(const history of [undefined,null,[],{43:null}])assert.equal(own({...d,history_season_data:history}).survivor.statistics[0].total,null);
 const sparse=own({...d,history_season_data:{43:{normal_battle_cnt:2,normal_battle_win_cnt:1}}}).survivor.statistics[0];assert.equal(sparse.total,3);assert.equal(sparse.wins,3);assert.equal(sparse.losses,null);
 assert.equal(own({...d,history_season_data:{}}).survivor.statistics[0].losses,0);
 const missing={...d,history_season_data:{}};delete missing.normal_battle_cnt;assert.equal(own(missing).survivor.statistics[0].total,null);
});
test('current season follows readable statistics disclosure and rejects current, future or unknown history keys',()=>{
 const data={season_id:44,...counters(5,4,0),history_season_data:{}};
 for(const settings of [undefined,{open_char_data:'unexpected'}])assert.equal(presentProfile(profileOf({unique_id:'20',civilian_data:data,setting_show_info:settings},'10')).current_season_statistics,null);
 for(const settings of [{open_char_data:false},{hide_battle_page_info:true}])assert.equal(presentProfile(profileOf({unique_id:'20',civilian_data:data,setting_show_info:settings},'10')).current_season_statistics.survivor.statistics[0].total,5);
 assert.equal(presentProfile(profileOf({unique_id:'20',civilian_data:data,setting_show_info:{}},'10')).current_season_statistics.survivor.statistics[0].total,5);
 for(const id of ['44','45','bad'])assert.equal(own({...data,history_season_data:{[id]:counters(1,1,0)}}).survivor.statistics[0].total,null);
 assert.equal(own({...data,season_id:undefined}).survivor,null);
});
test('negative differences, unsafe counts and inconsistent current wins/losses never produce valid statistics',()=>{
 const r=own({season_id:44,...counters(5,4,0),history_season_data:{43:counters(4,0,0)}}).survivor.statistics[0];assert.equal(r.consistent,false);assert.equal(r.total,null);assert.equal(r.wins,null);
 for(const value of [-1,NaN,1.2,Number.MAX_SAFE_INTEGER+1])assert.equal(own({season_id:44,...counters(value,0,0),history_season_data:{}}).survivor.statistics[0].total,null);
 assert.equal(own({season_id:44,...counters(1,0,0),history_season_data:{43:counters(2,0,0)}}).survivor.statistics[0].total,null);
 const invalidHistory=own({season_id:44,...counters(5,4,0),history_season_data:{43:counters(2,3,0)}}).survivor.statistics[0];assert.equal(invalidHistory.consistent,false);assert.equal(invalidHistory.total,null);
 assert.equal(own({season_id:44,...counters(10,0,0),history_season_data:{42:counters(Number.MAX_SAFE_INTEGER,0,0),43:counters(1,0,0)}}).survivor.statistics[0].total,null);
});
