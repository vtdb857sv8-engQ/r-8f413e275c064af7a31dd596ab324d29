import test from 'node:test';
import assert from 'node:assert/strict';
import {presentMatch} from '../src/game/presentation.mjs';
import {matchActionDetails} from '../src/game/match-actions.mjs';
const catalog={match_action_fields:{survivor:[{id:1,record_key:'+1',label:'解読進捗',unit:'percent'},{id:12,record_key:'12',label:'ハンターへの牽制',unit:'seconds'},{id:7,record_key:'7',label:'援助',unit:null}],hunter:[{id:2,record_key:'2',label:'板の破壊',unit:null}]}};
test('match actions use the original camp IDs, +1 progress and the game integer conversion',()=>{
 const p={utype:2,action_recored:{1:999,'+1':160.9,12:87.9,7:0}};
 const d=matchActionDetails(p,2,catalog);assert.deepEqual(d.items.map(x=>x.display_value),['160%','87秒','0']);assert.equal(d.items[0].record_key,'+1');
 const record=presentMatch({common_info:{match_type:1},all_pl_info:[p,{utype:1,action_recored:{2:6,12:99}}]},catalog);
 assert.equal(record.summary.players[0].action_details.items.length,3);assert.deepEqual(record.summary.players[1].action_details.items.map(x=>x.label),['板の破壊']);assert.equal(record.summary.players[1].action_details.items[0].value,6);
});
test('unreceived action records and sparse invalid values never become invented zero values',()=>{
 for(const action_recored of [undefined,null,{},[],0])assert.deepEqual(matchActionDetails({utype:2,action_recored},1,catalog),{status:'unavailable',items:[],titles_status:'unavailable',titles:[],unverified_title_records:0});
 const d=matchActionDetails({utype:2,action_recored:{'+1':0,12:-1,7:'2'}},1,catalog);
 assert.equal(d.items[0].value,0);assert.equal(d.items[1].display_value,null);assert.equal(d.items[2].value_source,'unavailable');
 const sparse=matchActionDetails({utype:2,action_recored:{95:1}},1,catalog);assert.ok(sparse.items.every(x=>x.value===null));
});
test('unknown camps and unchecked modes do not reuse ordinary action meanings',()=>{
 for(const mode of [10,61,69,102,103,999])assert.equal(matchActionDetails({utype:2,action_recored:{12:1}},mode,catalog),null);
 assert.equal(matchActionDetails({utype:7,action_recored:{12:1}},1,catalog),null);
 for(const mode of [1,2,4,8,9,100,101])assert.equal(matchActionDetails({utype:2,action_recored:{12:1}},mode,catalog).items[1].value,1);
});
