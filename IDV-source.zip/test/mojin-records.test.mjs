import test from 'node:test';
import assert from 'node:assert/strict';
import {deflateSync} from 'node:zlib';
import {presentMojinRecords} from '../src/game/mojin-records.mjs';
import {LiveGameProvider} from '../src/game/provider.mjs';
const catalog={modes:{102:'手記の加筆（サバイバー）'},characters:{3:{name:'確認済みキャラ',asset:'character-3'}},mojin:{levels:{100:{map_name:'災いの女',map_asset:'map-mojin-1'}},careers:{1:{name:'智者',asset:'career-mojin-1'}},record_labels:{success:'成功',failure:'失敗'}}};
const record=()=>({common_info:{match_type:102,level_id:100,scene_id:2601,start_time:100,end_time:150,battle_time_exclude_pause:43},all_pl_info:[{unique_id:'10',player_name:'本人',face:8,face_frame:1,pid:3,team_uid:'private-team',gold_rush_rank_mode:false,session_token:'secret',mode_info:{career_id:1,battle_result:1,deliver_amount:0,survive_time:26.19,material_items:{secret:1}}},{unique_id:'20',player_name:'参加者',mode_info:{battle_result:2,deliver_amount:123}}]});
const wrapper=r=>({bid:'one',shared_data:deflateSync(JSON.stringify(r)),rank_add:{10:0},gm_clone_uid_map:{}});
const present=(r=record(),extra={})=>presentMojinRecords({player_id:'10',received_at:'2026-11-05T23:00:00Z',records:[{...wrapper(r),...extra}]},catalog);

test('Mojin history uses its dedicated result enum and level map instead of ordinary match results',()=>{
  const output=present(),row=output.items[0];
  assert.equal(row.result,'failure');assert.equal(row.result_label,'失敗');assert.equal(row.map_name,'災いの女');assert.equal(row.duration_seconds,43);
  assert.equal(row.players[0].career_name,'智者');assert.equal(row.players[0].survive_time_seconds,26.19);assert.equal(row.players[1].result,'success');assert.equal(row.deliver_value,0);
  assert.ok(!/secret|team_uid|material_items|mode_info|rank_info/.test(JSON.stringify(output)));assert.equal(output.coverage,'server_returned_records');
});
test('Mojin missing names, timestamps, results and counters remain unknown',()=>{
  const r=record();r.common_info.level_id=999;r.common_info.end_time=-1;delete r.all_pl_info[0].mode_info.deliver_amount;r.all_pl_info[0].mode_info.battle_result=99;
  const row=present(r).items[0];assert.equal(row.map_name,null);assert.equal(row.ended_at,null);assert.equal(row.result,'unknown');assert.equal(row.result_label,null);assert.equal(row.deliver_value,null);
});
test('Mojin corrupt, oversized, other-mode and wrong-owner data cannot become an empty successful history',()=>{
  for(const input of [{shared_data:Buffer.from('bad')},{shared_data:deflateSync('x'.repeat(2*1024*1024+1))}])assert.throws(()=>present(record(),input),{code:'MOJIN_RECORD_FORMAT_UNSUPPORTED'});
  const wrongMode=record();wrongMode.common_info.match_type=100;assert.throws(()=>present(wrongMode),{code:'MOJIN_RECORD_FORMAT_UNSUPPORTED'});
  const wrongOwner=record();wrongOwner.all_pl_info[0].unique_id='30';assert.throws(()=>present(wrongOwner),{code:'MOJIN_RECORD_FORMAT_UNSUPPORTED'});
  assert.equal(presentMojinRecords({player_id:'10',records:[]}).total_received,0);
  const clone=record();clone.all_pl_info[0].unique_id='30';assert.equal(present(clone,{gm_clone_uid_map:{30:'10'}}).items[0].players[0].player_id,'10');
});
test('Mojin own-history RPC has no target argument, correlates its callback and distinguishes errors from no records',async()=>{
  const p=new LiveGameProvider({});await assert.rejects(p.getMojinHistory(),{code:'GAME_NOT_CONNECTED'});p.connected=true;p.selfId='10';
  let sent;
  p.request=async(method,parameters,callback,filter)=>{
    sent={method,parameters,callback};const callbackid=parameters.info.callbackid;
    assert.equal(filter({info:{callbackid:callbackid+1}}),false);assert.equal(filter({info:{callbackid}}),true);
    return {info:{res:[0,{records:[wrapper(record())]}]}};
  };
  const output=await p.getMojinHistory('20');assert.equal(output.player_id,'10');assert.equal(output.records.length,1);
  assert.equal(sent.parameters.info.methodname,'request_self_gold_rush_records');assert.deepEqual(sent.parameters.info.args,[]);assert.equal(sent.method,'client_server_gen_rpc_method');
  p.cache.clear();p.request=async()=>({info:{res:[1,[]]}});await assert.rejects(p.getMojinHistory(),{code:'MOJIN_HISTORY_UNAVAILABLE'});
  p.cache.clear();p.request=async()=>({info:{res:[0,null]}});await assert.rejects(p.getMojinHistory(),{code:'MOJIN_RECORD_FORMAT_UNSUPPORTED'});
});
