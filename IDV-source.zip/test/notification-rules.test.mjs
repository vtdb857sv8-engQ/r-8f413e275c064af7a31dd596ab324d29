import test from 'node:test';
import assert from 'node:assert/strict';
import {Store} from '../src/store.mjs';
import {eventTypes,notificationRules,shouldNotify} from '../src/notification-rules.mjs';
test('notification conditions classify explicit transitions without inferring hidden login or logout',()=>{
  assert.deepEqual(eventTypes({previous_state:'offline',state:'online'}),['login']);
  assert.deepEqual(eventTypes({previous_state:'online',state:'in_match'}),['match_start']);
  assert.deepEqual(eventTypes({previous_state:'in_match',state:'online'}),['match_end']);
  assert.deepEqual(eventTypes({previous_state:'online',state:'unknown',previous_visibility:'visible',visibility:'hidden'}),['visibility']);
  assert.deepEqual(eventTypes({previous_state:'unknown',state:'offline'}),[]);
  assert.equal(shouldNotify({previous_state:'online',state:'in_match'},notificationRules({match_start:false})),false);
  assert.throws(()=>notificationRules({logout:'true'}));assert.throws(()=>notificationRules({made_up:true}));
});
test('global and per-player rules control durable queue while all observed changes remain in history',t=>{
  const s=new Store(':memory:');t.after(()=>s.close());s.watch('1',true);s.registerDevice('phone','protected','sandbox');
  s.notificationSettings({logout:false,match_start:true});
  s.observe('1','online','2026-01-01T00:00:00Z');
  s.observe('1','offline','2026-01-01T00:01:00Z');assert.equal(s.pendingDeliveries().length,0);
  s.observe('1','online','2026-01-01T00:02:00Z');assert.equal(s.pendingDeliveries().length,1);
  s.watchRules('1',{match_start:false});
  s.observe('1','in_match','2026-01-01T00:03:00Z');assert.equal(s.pendingDeliveries().length,1);assert.equal(s.events().length,3);
  const pending=s.pendingDeliveries()[0];s.unwatch('1');assert.equal(s.notificationAllowed(pending),false);
});
test('unconfirmed public visibility cannot infer activity or authorize a legacy queued notification',t=>{
  const s=new Store(':memory:');t.after(()=>s.close());s.watch('1',true);s.registerDevice('phone','protected','sandbox');
  const details=visibility=>({player_id:'1',visibility});
  s.observe('1','offline','2026-01-01T00:00:00Z','game',details('unknown'));
  const unconfirmed=s.observe('1','online','2026-01-01T00:01:00Z','game',details('unknown'));assert.equal(s.pendingDeliveries().length,0);
  assert.equal(unconfirmed.previous_state,'unknown');assert.equal(unconfirmed.state,'unknown');assert.equal(s.events()[0].state,'unknown');
  assert.equal(s.notificationAllowed({player_id:'1',previous_state:'offline',state:'online',previous_visibility:'unknown',visibility:'visible'}),false);
  s.observe('1','offline','2026-01-01T00:02:00Z','game',details('visible'));assert.equal(s.pendingDeliveries().length,0);
  s.observe('1','online','2026-01-01T00:03:00Z','game',details('visible'));assert.equal(s.pendingDeliveries().length,1);
  assert.deepEqual(eventTypes({previous_state:'online',state:'in_match',previous_visibility:'visible',visibility:'unknown'}),[]);
  assert.deepEqual(eventTypes({previous_state:'offline',state:'online',previous_visibility:'hidden',visibility:'visible'}),['visibility']);
});
test('cached identities and presence details cannot retain undisclosed server states or timestamps in API snapshots',t=>{
  const s=new Store(':memory:');t.after(()=>s.close());
  for(const visibility of ['unknown','hidden']){
    const profile={player_id:'42',name:'player',presence:{state:'online',visibility,last_login_at:'2026-01-01T00:00:00Z',online_stat:1}};
    s.cacheIdentity(profile);const identity=s.identity('42');assert.equal(identity.name,'player');assert.equal(identity.presence,undefined);assert.equal(profile.presence.online_stat,1);
    s.savePresenceDetails({player_id:'42',visibility,last_login_at:'2026-01-01T00:00:00Z',last_logout_at:'2026-01-01T00:01:00Z',online_stat:1,battle_stat:1,avatar_notice_status:3});
    assert.deepEqual(s.presenceDetails('42'),{state:'unknown',visibility,last_login_observed_at:null,last_logout_observed_at:null});
  }
  s.savePresenceDetails({player_id:'42',visibility:'visible',online_stat:1});assert.equal(s.presenceDetails('42').online_stat,1);
});
