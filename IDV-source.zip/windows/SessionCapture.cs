// Own Identity V process only. Read access only; no injection, network or secret files.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Drawing;

internal static class SessionCapture {
    internal static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 32768, RecursionLimit = 30 };
    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr h, uint flags, StringBuilder value, ref uint length);
    [DllImport("kernel32.dll")] static extern UIntPtr VirtualQueryEx(IntPtr h, IntPtr address, out MemoryRegion region, UIntPtr length);
    [DllImport("kernel32.dll")] static extern bool ReadProcessMemory(IntPtr h, IntPtr address, byte[] buffer, UIntPtr size, out UIntPtr read);
    [StructLayout(LayoutKind.Sequential)] struct MemoryRegion {
        public IntPtr Address, Allocation; public uint AllocationProtect; public ushort Partition;
        public UIntPtr Size; public uint State, Protect, Type;
    }
    internal static string StringValue(IDictionary<string,object> value, string key) {
        object result; return value.TryGetValue(key, out result) ? result as string : null;
    }
    internal static bool IsSdk(IDictionary<string,object> value) {
        return !String.IsNullOrEmpty(StringValue(value,"sdkuid")) && !String.IsNullOrEmpty(StringValue(value,"sessionid")) &&
            !String.IsNullOrEmpty(StringValue(value,"gameid")) && !String.IsNullOrEmpty(StringValue(value,"deviceid")) &&
            !String.IsNullOrEmpty(StringValue(value,"login_channel"));
    }
    static string ObjectAt(string text, int start) {
        int level=0; char quote='\0'; bool escape=false;
        for(int i=start; i<text.Length && i-start<16000; i++) {
            char ch=text[i];
            if(quote!='\0') { if(escape)escape=false;else if(ch=='\\')escape=true;else if(ch==quote)quote='\0';continue; }
            if(ch=='"'||ch=='\'')quote=ch; else if(ch=='{')level++; else if(ch=='}' && --level==0)return text.Substring(start,i-start+1);
        }
        return null;
    }
    internal static void FindSdk(string text, string expectedUid, Dictionary<string,Dictionary<string,object>> found) {
        foreach(Match sessionKey in Regex.Matches(text,"[\"']sessionid[\"']")) {
            int anchor=sessionKey.Index;
            int lower=Math.Max(0,anchor-12000);
            for(int start=text.LastIndexOf('{',anchor); start>=lower && start>=0; start=start==0?-1:text.LastIndexOf('{',start-1)) {
                string raw=ObjectAt(text,start); if(raw==null)continue;
                try {
                    var value=Json.DeserializeObject(raw) as Dictionary<string,object>;
                    if(value!=null && IsSdk(value) && StringValue(value,"sdkuid")==expectedUid) {
                        string key=StringValue(value,"sdkuid")+"\n"+StringValue(value,"sessionid");
                        found[key]=value;
                    }
                } catch { /* Invalid heap fragments are discarded, never logged. */ }
            }
        }
    }
    internal static string BuildCode(Dictionary<string,object> sdk, string log, string server) {
        if(!IsSdk(sdk))throw new InvalidOperationException("SDK_NOT_FOUND");
        string sdkUid=StringValue(sdk,"sdkuid"),full=null;
        foreach(Match match in Regex.Matches(log,@"new_full_uid=([^,\r\n]+), new_sdk_uid=([^\r\n]+)"))
            if(match.Groups[2].Value.Trim()==sdkUid)full=match.Groups[1].Value.Trim();
        var versions=Regex.Matches(log,@"client_version[= :]+(\d+)");
        var pack=Regex.Match(log,@"pack_config\.PACK_TYPE=(\d+)");
        int version,packType;
        if(String.IsNullOrEmpty(full)||versions.Count==0||!pack.Success||!Int32.TryParse(versions[versions.Count-1].Groups[1].Value,out version)||!Int32.TryParse(pack.Groups[1].Value,out packType)||version<=0)
            throw new InvalidOperationException("LOGIN_LOG_INCOMPLETE");
        var info=new Dictionary<string,object>(sdk);
        info["usr_name"]="";info["scr_orientation"]="landscape";info["full_uid"]=full;
        info["pay_channel"]=sdk["login_channel"];info["origin_login_channel"]=sdk["login_channel"];
        info["timestamp"]="";info["auth_type_name"]="";info["client_version"]=version;info["sauth_json"]=Json.Serialize(sdk);
        var login=new Dictionary<string,object> { {"info",info},{"log_info",new Dictionary<string,object>{{"deviceid",sdk["deviceid"]}}},
            {"active_code",""},{"just_login",true},{"c_str",""},{"pack_type",packType},{"login_confirm",false} };
        var value=new Dictionary<string,object> { {"version",1},{"server",server},{"issued_at",DateTime.UtcNow.ToString("o")},{"login_info",login} };
        byte[] bytes=Encoding.UTF8.GetBytes(Json.Serialize(value));
        if(bytes.Length>11000)throw new InvalidOperationException("CODE_TOO_LARGE");
        return "IDV1."+Convert.ToBase64String(bytes).TrimEnd('=').Replace('+','-').Replace('/','_');
    }
    internal static string Capture(string directory, string server, CancellationToken stop, Action<int> progress) {
        string image=Path.GetFullPath(Path.Combine(directory,"dwrg.exe")),logPath=Path.Combine(directory,"log.txt");
        if(!File.Exists(image)||!File.Exists(logPath))throw new InvalidOperationException("GAME_FOLDER_INVALID");
        string log;
        using(var stream=new FileStream(logPath,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
        using(var reader=new StreamReader(stream,Encoding.UTF8))log=reader.ReadToEnd();
        var identities=Regex.Matches(log,@"new_full_uid=([^,\r\n]+), new_sdk_uid=([^\r\n]+)");
        if(identities.Count==0)throw new InvalidOperationException("LOGIN_LOG_INCOMPLETE");
        string expected=identities[identities.Count-1].Groups[2].Value.Trim();
        IntPtr handle=IntPtr.Zero;
        foreach(var process in Process.GetProcessesByName("dwrg")) {
            try {
                IntPtr candidate=OpenProcess(0x410,false,process.Id);if(candidate==IntPtr.Zero)continue;
                var name=new StringBuilder(32768);uint size=32768;
                if(QueryFullProcessImageName(candidate,0,name,ref size)&&String.Equals(Path.GetFullPath(name.ToString()),image,StringComparison.OrdinalIgnoreCase)) {
                    if(handle!=IntPtr.Zero){CloseHandle(candidate);CloseHandle(handle);handle=IntPtr.Zero;throw new InvalidOperationException("MULTIPLE_GAMES");}
                    handle=candidate;
                } else CloseHandle(candidate);
            } finally { process.Dispose(); }
        }
        if(handle==IntPtr.Zero)throw new InvalidOperationException("GAME_NOT_RUNNING");
        var found=new Dictionary<string,Dictionary<string,object>>();long scanned=0,address=0;
        var watch=Stopwatch.StartNew();
        try {
            while(address<0x7fffffffffffL && scanned<2L*1024*1024*1024 && watch.Elapsed.TotalSeconds<90) {
                stop.ThrowIfCancellationRequested();MemoryRegion region;
                if(VirtualQueryEx(handle,new IntPtr(address),out region,new UIntPtr((uint)Marshal.SizeOf(typeof(MemoryRegion))))==UIntPtr.Zero)break;
                long start=region.Address.ToInt64(),length=(long)region.Size.ToUInt64();
                if(length<=0||start+length<=address)break;address=start+length;
                if(region.State!=0x1000||(region.Protect&0x101)!=0||region.Type!=0x20000||length>256L*1024*1024)continue;
                for(long position=start;position<start+length;position+=1024*1024) {
                    stop.ThrowIfCancellationRequested();int n=(int)Math.Min(1024*1024+16000,start+length-position);
                    byte[] buffer=new byte[n];UIntPtr read;
                    if(!ReadProcessMemory(handle,new IntPtr(position),buffer,new UIntPtr((uint)n),out read))continue;
                    int got=(int)read.ToUInt64();scanned+=got;
                    string text=Encoding.UTF8.GetString(buffer,0,got);
                    if(text.IndexOf("sessionid",StringComparison.Ordinal)>=0)FindSdk(text,expected,found);
                    if(text.IndexOf("s\0e\0s\0s\0i\0o\0n",StringComparison.Ordinal)>=0)FindSdk(Encoding.Unicode.GetString(buffer,0,got),expected,found);
                    foreach(Match encoded in Regex.Matches(text,@"eyJ[A-Za-z0-9_+/=-]{40,15000}")) {
                        try {string b64=encoded.Value.Replace('-','+').Replace('_','/');b64=b64.PadRight((b64.Length+3)/4*4,'=');
                            FindSdk(Encoding.UTF8.GetString(Convert.FromBase64String(b64)),expected,found);
                        } catch { }
                    }
                    Array.Clear(buffer,0,buffer.Length);progress((int)(scanned/1024/1024));
                    if(watch.Elapsed.TotalSeconds>=90)break;
                }
            }
        } finally { CloseHandle(handle); }
        stop.ThrowIfCancellationRequested();
        if(found.Count==0)throw new InvalidOperationException("SDK_NOT_FOUND");
        if(found.Count!=1)throw new InvalidOperationException("SDK_AMBIGUOUS");
        // Never reuse the saved API session. Only this running game's result is used.
        return BuildCode(found.Values.First(),log,server);
    }
    [STAThread] static int Main(string[] args) {
        if(args.Length==2&&args[0]=="--self-test") {
            try {
                var sdk=new Dictionary<string,object>{{"sdkuid","synthetic-user"},{"sessionid","synthetic-session"},{"gameid","synthetic-game"},{"deviceid","synthetic-device"},{"login_channel","synthetic-channel"}};
                var found=new Dictionary<string,Dictionary<string,object>>();
                FindSdk("noise"+Json.Serialize(sdk)+"noise","synthetic-user",found);
                if(found.Count!=1)throw new Exception();
                FindSdk("{'sdkuid':'synthetic-user','sessionid':'synthetic-session','gameid':'synthetic-game','deviceid':'synthetic-device','login_channel':'synthetic-channel'}","synthetic-user",found);
                if(found.Count!=1)throw new Exception();
                FindSdk(Json.Serialize(sdk),"different-user",found);if(found.Count!=1)throw new Exception();
                string code=BuildCode(sdk,"new_full_uid=synthetic-full, new_sdk_uid=synthetic-user\nclient_version=1\npack_config.PACK_TYPE=1","asia");
                string raw=code.Substring(5).Replace('-','+').Replace('_','/');raw=raw.PadRight((raw.Length+3)/4*4,'=');
                var decoded=Json.DeserializeObject(Encoding.UTF8.GetString(Convert.FromBase64String(raw))) as Dictionary<string,object>;
                if(decoded==null||!decoded.ContainsKey("login_info"))throw new Exception();
                File.WriteAllText(Path.ChangeExtension(args[1],".code"),code);
                File.WriteAllText(args[1],"{\"passed\":true,\"synthetic_only\":true,\"process_read\":false,\"network\":false}");return 0;
            } catch { return 1; }
        }
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new CaptureForm());return 0;
    }
}
internal sealed class CaptureForm : Form {
    TextBox folder=new TextBox(),code=new TextBox();ComboBox server=new ComboBox();
    Button capture=new Button(),copy=new Button(),cancel=new Button();Label status=new Label();CancellationTokenSource stop;
    public CaptureForm() {
        Text="第五人格 接続コード取得";ClientSize=new Size(600,300);MinimumSize=new Size(616,339);
        BackColor=Color.FromArgb(24,24,27);ForeColor=Color.Gainsboro;Font=new Font("Yu Gothic UI",10);
        var tip=new Label{Text="自分のPC版でログイン後、「取得」を押してください。",Left=20,Top=18,Width=560,Height=30};Controls.Add(tip);
        folder.SetBounds(20,58,460,28);folder.Text="C:\\Loading Bay Games\\Identity V";Controls.Add(folder);
        var browse=new Button{Text="参照",Left=490,Top=56,Width=85,Height=32};browse.Click+=(s,e)=>{using(var dialog=new FolderBrowserDialog()){if(dialog.ShowDialog()==DialogResult.OK)folder.Text=dialog.SelectedPath;}};Controls.Add(browse);
        server.SetBounds(20,100,160,28);server.DropDownStyle=ComboBoxStyle.DropDownList;server.Items.AddRange(new object[]{"Asia","NA/EU","中国"});server.SelectedIndex=0;Controls.Add(server);
        capture.Text="取得";capture.SetBounds(200,98,110,34);capture.Click+=async(s,e)=>await CaptureCode();Controls.Add(capture);
        cancel.Text="中止";cancel.SetBounds(320,98,110,34);cancel.Enabled=false;cancel.Click+=(s,e)=>{if(stop!=null)stop.Cancel();};Controls.Add(cancel);
        code.SetBounds(20,150,460,28);code.ReadOnly=true;code.UseSystemPasswordChar=true;Controls.Add(code);
        copy.Text="コピー";copy.SetBounds(490,148,85,34);copy.Enabled=false;copy.Click+=(s,e)=>{try{Clipboard.SetText(code.Text);status.Text="コピーしました。iPhoneの設定 → ゲームの接続コードに貼り付けてください。";}catch{status.Text="コピーできませんでした。もう一度押してください。";}};Controls.Add(copy);
        status.SetBounds(20,198,555,70);status.Text="コードを取得してもゲームのログインは切り替わりません。";Controls.Add(status);
        FormClosing+=(s,e)=>{if(stop!=null)stop.Cancel();code.Clear();};
    }
    async Task CaptureCode() {
        code.Clear();copy.Enabled=false;capture.Enabled=false;cancel.Enabled=true;folder.Enabled=false;server.Enabled=false;
        stop=new CancellationTokenSource();string directory=folder.Text,region=new[]{"asia","na-eu","china"}[server.SelectedIndex];
        try {
            var progress=new Progress<int>(n=>{if(!IsDisposed&&stop!=null)status.Text="自分のゲームを読み取り中… "+n+" MiB";});
            string value=await Task.Run(()=>SessionCapture.Capture(directory,region,stop.Token,n=>((IProgress<int>)progress).Report(n)));
            code.Text=value;copy.Enabled=true;status.Text="取得できました（ゲームサーバーでの有効性は未確認）。コピーしてiPhoneに貼り付けてください。";
        } catch(OperationCanceledException) {status.Text="取得を中止しました。";}
        catch(Exception error) {
            var messages=new Dictionary<string,string>{{"GAME_FOLDER_INVALID","ゲームのフォルダーを選択してください。"},{"GAME_NOT_RUNNING","PC版第五人格を起動し、自分のアカウントでログインしてください。"},{"MULTIPLE_GAMES","同じ場所のゲームが複数起動しています。1つにして取得してください。"},{"SDK_NOT_FOUND","ログイン情報が見つかりません。再ログイン直後に取得してください。"},{"SDK_AMBIGUOUS","ログイン情報を1つに確定できません。ゲームを再起動・再ログインして取得してください。"},{"LOGIN_LOG_INCOMPLETE","ログイン記録を確認できません。再ログイン後に取得してください。"},{"CODE_TOO_LARGE","接続コードを作成できません。取得形式の確認が必要です。"}};
            string message;status.Text=messages.TryGetValue(error.Message,out message)?message:"読み取りできませんでした。ゲームの起動状態とフォルダーを確認してください。";
        } finally {capture.Enabled=true;cancel.Enabled=false;folder.Enabled=true;server.Enabled=true;stop.Dispose();stop=null;}
    }
}
