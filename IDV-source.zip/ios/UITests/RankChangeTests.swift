import XCTest
final class RankChangeTests: XCTestCase {
    private func open(received: Bool) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing"] + (received ? ["--ui-rank-change"] : []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.buttons["戦績"].waitForExistence(timeout:15));app.buttons["戦績"].tap()
        let match = app.buttons["match-record-demo"];XCTAssertTrue(match.waitForExistence(timeout:10));match.tap()
        XCTAssertTrue(app.staticTexts["本人の得点"].waitForExistence(timeout:10));return app
    }
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    func testBeforeAfterRanksAndSignedReasonsBelongToTheSelectedParticipant() {
        let app = open(received:true),own = app.buttons["own-rank-change"];XCTAssertTrue(own.waitForExistence(timeout:10));reveal(own,app:app);own.tap()
        XCTAssertTrue(app.staticTexts["段位ポイントの内訳"].waitForExistence(timeout:10))
        for label in ["対戦前","対戦後","五段IV","五段III","サバイバー演繹得点第1位","+8","+4"] { XCTAssertTrue(app.staticTexts[label].exists) }
        let selfCapture = XCTAttachment(screenshot:app.screenshot());selfCapture.name = "rank-change-owner";selfCapture.lifetime = .keepAlways;add(selfCapture)
        app.navigationBars.buttons.element(boundBy:0).tap()
        let peer = app.buttons["rank-change-30"];XCTAssertTrue(peer.waitForExistence(timeout:10));reveal(peer,app:app);peer.tap()
        XCTAssertTrue(app.staticTexts["失敗（一人残留）"].waitForExistence(timeout:10));XCTAssertTrue(app.staticTexts["-7"].exists);XCTAssertTrue(app.staticTexts["集計相手"].exists)
        XCTAssertFalse(app.staticTexts["サバイバー演繹得点第1位"].exists)
        let peerCapture = XCTAttachment(screenshot:app.screenshot());peerCapture.name = "rank-change-peer";peerCapture.lifetime = .keepAlways;add(peerCapture)
    }
    func testUnreceivedRankChangesDoNotCreateZeroPointDetails() {
        let app = open(received:false)
        XCTAssertFalse(app.buttons["own-rank-change"].exists);XCTAssertFalse(app.buttons["rank-change-30"].exists)
    }
}
