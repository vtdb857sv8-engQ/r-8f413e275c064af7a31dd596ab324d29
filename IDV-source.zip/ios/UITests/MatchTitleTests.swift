import XCTest
final class MatchTitleTests: XCTestCase {
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    private func open(_ flag: String? = nil) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-match-actions","--ui-match-titles"] + (flag.map { [$0] } ?? []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.buttons["戦績"].waitForExistence(timeout:15));app.buttons["戦績"].tap()
        let record = app.buttons["match-record-demo"];XCTAssertTrue(record.waitForExistence(timeout:10));record.tap()
        let link = app.buttons["own-match-actions"];XCTAssertTrue(link.waitForExistence(timeout:10));reveal(link,app:app);link.tap()
        XCTAssertTrue(app.staticTexts["この試合の称号"].waitForExistence(timeout:10));return app
    }
    func testReceivedPerformanceTitlesUseOriginalNamesAndDescriptions() {
        let app = open(),first = app.descendants(matching:.any)["match-title-1"].firstMatch,last = app.descendants(matching:.any)["match-title-5"].firstMatch
        for id in 1...5 { XCTAssertTrue(app.descendants(matching:.any)["match-title-\(id)"].firstMatch.exists) }
        XCTAssertEqual(first.label,"解読マスター");XCTAssertEqual(first.value as? String,"解読進捗が300%に到達")
        reveal(first,app:app)
        let start = XCTAttachment(screenshot:app.screenshot());start.name = "match-titles-first";start.lifetime = .keepAlways;add(start)
        reveal(last,app:app);XCTAssertEqual(last.label,"牽制マスター");XCTAssertEqual(last.value as? String,"ハンターへの牽制時間が180秒に到達")
        let end = XCTAttachment(screenshot:app.screenshot());end.name = "match-titles-last";end.lifetime = .keepAlways;add(end)
    }
    func testEmptyUnknownAndUnreceivedTitlesRemainDistinctDespiteHighActionValues() {
        var app = open("--ui-titles-empty")
        XCTAssertTrue(app.staticTexts["この試合の称号はありません"].exists);XCTAssertFalse(app.descendants(matching:.any)["match-title-1"].firstMatch.exists)
        app.terminate();app = open("--ui-titles-unavailable")
        XCTAssertTrue(app.staticTexts["称号記録は未取得です"].exists);XCTAssertFalse(app.staticTexts["この試合の称号はありません"].exists)
        app.terminate();app = open("--ui-titles-unknown")
        XCTAssertTrue(app.staticTexts["内容を確認できていない称号記録が1件あります"].exists);XCTAssertFalse(app.staticTexts["この試合の称号はありません"].exists)
    }
}
