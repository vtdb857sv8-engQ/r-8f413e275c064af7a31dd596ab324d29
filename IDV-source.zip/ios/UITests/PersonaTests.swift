import XCTest
final class PersonaTests: XCTestCase {
    private func open(_ flag: String) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing",flag];app.launch()
        XCTAssertTrue(app.buttons["検索"].waitForExistence(timeout:15));app.buttons["検索"].tap()
        app.buttons["ランキング"].tap()
        let persona = app.buttons["ranking-persona-20"];XCTAssertTrue(persona.waitForExistence(timeout:10));persona.tap()
        return app
    }
    func testRankingPersonaClearsReceivedNodesWhenDisclosureIsRevoked() {
        let app = open("--ui-persona-revoked")
        let node = app.descendants(matching:.any)["persona-node-1"].firstMatch
        XCTAssertTrue(node.waitForExistence(timeout:10));XCTAssertTrue(node.label.contains("群集心理"))
        app.buttons["再読み込み"].tap()
        XCTAssertTrue(app.staticTexts["人格の公開範囲を確認できません。"].waitForExistence(timeout:10))
        XCTAssertFalse(app.descendants(matching:.any)["persona-node-1"].exists)
    }
    func testUnreadablePersonaNeverShowsReceivedConfiguration() {
        let app = open("--ui-persona-private")
        XCTAssertTrue(app.staticTexts["人格の公開範囲を確認できません。"].waitForExistence(timeout:10))
        XCTAssertFalse(app.descendants(matching:.any)["persona-node-1"].exists)
    }
}
