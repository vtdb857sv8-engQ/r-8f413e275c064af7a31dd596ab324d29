import XCTest

final class SearchHistoryTests: XCTestCase {
    private func openSearch(extra: [String] = []) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-search-history"] + extra;app.launch()
        app.buttons["検索"].firstMatch.tap()
        XCTAssertTrue(app.buttons["search-history-30"].waitForExistence(timeout:15));return app
    }
    func testReopeningHistoryAfterReorderingLoadsFreshProfilesRepeatedly() {
        let app = openSearch(extra:["--ui-profile-slow"])
        for id in ["30","31","30"] {
            let row = app.buttons["search-history-\(id)"];XCTAssertTrue(row.waitForExistence(timeout:10));row.tap()
            let name = id == "30" ? "集計相手" : "履歴の別プレイヤー"
            XCTAssertTrue(app.buttons["copy-player-name"].waitForExistence(timeout:12))
            XCTAssertTrue(app.staticTexts[name].exists);XCTAssertTrue(app.staticTexts["ID  \(id)"].exists)
            XCTAssertFalse(app.progressIndicators["profile-loading"].exists)
            if id == "30" {
                let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "history-profile-reopened";capture.lifetime = .keepAlways;add(capture)
            }
            app.navigationBars.buttons.firstMatch.tap()
            XCTAssertTrue(app.buttons["search-history-\(id)"].waitForExistence(timeout:10))
        }
    }
    func testProfileFailureStopsLoadingAndRetryLoadsTheProfile() {
        let app = openSearch(extra:["--ui-profile-fails-once"])
        app.buttons["search-history-30"].tap()
        let retry = app.buttons["reload-profile"];XCTAssertTrue(retry.waitForExistence(timeout:12))
        XCTAssertTrue(app.staticTexts["ゲームサーバーから応答がありません。再読み込みしてください。"].exists)
        XCTAssertFalse(app.progressIndicators["profile-loading"].exists)
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "history-profile-retry";capture.lifetime = .keepAlways;add(capture)
        retry.tap()
        XCTAssertTrue(app.buttons["copy-player-name"].waitForExistence(timeout:12))
        XCTAssertTrue(app.staticTexts["集計相手"].exists);XCTAssertFalse(retry.exists)
    }
}
