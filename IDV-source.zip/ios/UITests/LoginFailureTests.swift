import XCTest
final class LoginFailureTests: XCTestCase {
    func testSdkRejectionExplainsTheNextStepOnHomeAndSettings() {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-login-rejected"];app.launch()
        let note = app.staticTexts["login-failure-note"].firstMatch
        XCTAssertTrue(note.waitForExistence(timeout:15));XCTAssertEqual(note.label,"SDK認証を確認できません。PC版でログインし直してから接続してください。")
        XCTAssertFalse(app.buttons["home-profile"].exists)
        app.buttons["接続と設定"].tap();XCTAssertTrue(app.navigationBars["設定"].waitForExistence(timeout:5))
        XCTAssertTrue(note.exists);XCTAssertFalse(note.label.contains("期限切れ"))
        let image = XCTAttachment(screenshot:app.screenshot());image.name = "login-sdk-rejection";image.lifetime = .keepAlways;add(image)
    }
    func testOtherRejectionsDoNotClaimAnSdkFailure() {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-login-rejected","--ui-login-rejected-other"];app.launch()
        let note = app.staticTexts["login-failure-note"].firstMatch
        XCTAssertTrue(note.waitForExistence(timeout:15));XCTAssertEqual(note.label,"ゲーム側でログインが受け付けられませんでした。PC版でログインできるか確認してください。")
        XCTAssertFalse(note.label.contains("SDK認証"));XCTAssertFalse(note.label.contains("利用停止"))
    }
}
