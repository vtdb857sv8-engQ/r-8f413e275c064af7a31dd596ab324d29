import XCTest
final class MojinWeaponTests: XCTestCase {
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    private func open(_ flags: [String] = []) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-mojin-weapons"]+flags;app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        let link = app.buttons["own-mojin"];XCTAssertTrue(link.waitForExistence(timeout:15));reveal(link,app:app);link.tap()
        XCTAssertTrue(app.staticTexts["S1-燐光症"].waitForExistence(timeout:10));return app
    }
    func testWeaponNamesAndArtworkReferencesFollowSelectedPeriod() {
        let app = open(),first = app.descendants(matching:.any)["mojin-weapon-60012001"].firstMatch
        XCTAssertTrue(first.waitForExistence(timeout:5));XCTAssertEqual(first.label,"庇護者の杖")
        XCTAssertEqual(app.descendants(matching:.any)["mojin-weapon-60012002"].firstMatch.label,"燃える怨恨")
        reveal(first,app:app)
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "mojin-favorite-weapons";capture.lifetime = .keepAlways;add(capture)
        let period = app.segmentedControls["mojin-period"];reveal(period,app:app);period.buttons["現シーズン"].tap()
        XCTAssertTrue(app.staticTexts["この期間の得意武器の記録はありません"].exists);XCTAssertFalse(first.exists)
        period.buttons["S0"].tap();XCTAssertTrue(first.exists)
    }
    func testEmptyUnavailableAndUnknownWeaponRecordsRemainDistinct() {
        var app = open(["--ui-mojin-weapons-empty"])
        XCTAssertTrue(app.staticTexts["この期間の得意武器の記録はありません"].exists);XCTAssertFalse(app.staticTexts["武器データを確認できません"].exists)
        app.terminate();app = open(["--ui-mojin-weapons-unavailable"])
        XCTAssertTrue(app.staticTexts["武器データを確認できません"].exists);XCTAssertFalse(app.staticTexts["この期間の得意武器の記録はありません"].exists)
        app.terminate();app = open(["--ui-mojin-weapons-partial"])
        XCTAssertEqual(app.descendants(matching:.any)["mojin-weapon-99999999"].firstMatch.label,"武器名未取得");XCTAssertFalse(app.staticTexts["庇護者の杖"].exists)
    }
}
