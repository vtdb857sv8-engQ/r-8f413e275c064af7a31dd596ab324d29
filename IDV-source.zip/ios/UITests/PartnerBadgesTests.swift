import XCTest
final class PartnerBadgesTests: XCTestCase {
    private func profile(hidden: Bool = false) -> XCUIApplication {
        let app = XCUIApplication(); app.launchArguments = ["--ui-testing"] + (hidden ? ["--ui-hidden-badges"] : []); app.launch()
        let button = app.buttons["home-profile"]; XCTAssertTrue(button.waitForExistence(timeout:15)); button.tap()
        XCTAssertTrue(app.staticTexts["プロフィールの記録"].waitForExistence(timeout:15)); return app
    }
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<6 { if element.isHittable { return }; app.scrollViews.firstMatch.swipeUp() }
        XCTAssertTrue(element.isHittable)
    }
    func testPartyFrequencyAndWinRateLeadToThatPlayersProfile() {
        let app = profile(); app.buttons["分析"].tap()
        XCTAssertTrue(app.staticTexts["一緒に組んだ相手"].waitForExistence(timeout:10))
        let peer = app.buttons["party-peer-30"]; reveal(peer,app:app)
        XCTAssertTrue(app.staticTexts["17勝 / 8分 / 10敗"].exists)
        XCTAssertTrue(app.staticTexts["48.6%"].exists)
        let capture = XCTAttachment(screenshot:app.screenshot()); capture.name = "party-analysis"; capture.lifetime = .keepAlways; add(capture)
        peer.tap(); XCTAssertTrue(app.staticTexts["集計相手"].waitForExistence(timeout:10))
    }
    func testHistoricalBadgesExpandByCharacter() {
        let app = profile(); app.buttons["徽章"].tap(); app.segmentedControls["badge-period"].buttons["過去"].tap()
        let badge = app.buttons["history-badge-14"]; XCTAssertTrue(badge.waitForExistence(timeout:10)); reveal(badge,app:app); badge.tap()
        XCTAssertTrue(app.staticTexts["最高認知ポイント"].exists)
        let count = app.staticTexts["A × 4"]; reveal(count,app:app)
        XCTAssertTrue(app.staticTexts["最終獲得日 2025-06-16"].exists)
        let capture = XCTAttachment(screenshot:app.screenshot()); capture.name = "historical-badges"; capture.lifetime = .keepAlways; add(capture)
    }
    func testHiddenHistoricalBadgesDoNotDisplayFixtureData() {
        let app = profile(hidden:true); app.buttons["徽章"].tap(); app.segmentedControls["badge-period"].buttons["過去"].tap()
        XCTAssertTrue(app.staticTexts["過去徽章の公開範囲を確認できません"].waitForExistence(timeout:10))
        XCTAssertFalse(app.buttons["history-badge-14"].exists)
        XCTAssertFalse(app.staticTexts["7335"].exists)
    }
}
