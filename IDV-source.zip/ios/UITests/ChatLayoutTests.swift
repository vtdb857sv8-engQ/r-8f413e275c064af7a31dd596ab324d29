import XCTest
final class ChatLayoutTests: XCTestCase {
    private func verifyComposer(friend: Bool) {
        let app = XCUIApplication(); app.launchArguments = ["--ui-testing"]; app.launch()
        if friend {
            let button = app.buttons["表示テストとチャット"]
            XCTAssertTrue(button.waitForExistence(timeout:15)); button.tap()
        } else { app.buttons["チャット"].tap() }
        let field = app.descendants(matching:.any).matching(identifier:"chat-draft").firstMatch
        let send = app.buttons["chat-send"]
        XCTAssertTrue(field.waitForExistence(timeout:15))
        XCTAssertTrue(field.isHittable); XCTAssertTrue(send.isHittable); XCTAssertFalse(send.isEnabled)
        XCTAssertLessThanOrEqual(send.frame.maxY,app.buttons["ホーム"].frame.minY)
        field.tap(); field.typeText("layout test\nline two\nline three\nline four")
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout:5))
        XCTAssertTrue(send.isHittable); XCTAssertTrue(send.isEnabled)
        XCTAssertLessThanOrEqual(send.frame.maxY,app.keyboards.firstMatch.frame.minY + 1)
        XCTAssertLessThanOrEqual(send.frame.maxY,app.buttons["ホーム"].frame.minY)
        let capture = XCTAttachment(screenshot:app.screenshot()); capture.name = friend ? "friend-chat-keyboard" : "global-chat-keyboard"; capture.lifetime = .keepAlways; add(capture)
        // URLProtocol intercepts the send; no other player receives this fixture message.
        send.tap()
        XCTAssertTrue(app.staticTexts["送信確認中"].waitForExistence(timeout:5))
        app.scrollViews["chat-messages"].swipeDown()
        XCTAssertTrue(send.isHittable)
    }
    func testGlobalComposerWithOneHundredMessagesAndKeyboard() { verifyComposer(friend:false) }
    func testFriendComposerWithOneHundredMessagesAndKeyboard() { verifyComposer(friend:true) }
}
