import XCTest
final class SessionCodeTests: XCTestCase {
    private func open(extra: [String] = []) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing"]+extra;app.launch()
        XCTAssertTrue(app.buttons["接続と設定"].waitForExistence(timeout:15));app.buttons["接続と設定"].tap()
        let link = app.buttons["session-code-settings"];XCTAssertTrue(link.waitForExistence(timeout:10));link.tap()
        XCTAssertTrue(app.secureTextFields["game-session-code"].waitForExistence(timeout:10));return app
    }
    func testCodeInputUsesASecureFieldAndClearsAfterStorage() {
        let app = open(),input = app.secureTextFields["game-session-code"]
        input.tap();input.typeText("IDV1.synthetic-fixture")
        app.buttons["import-game-session"].tap()
        let result = app.staticTexts["session-import-result"]
        XCTAssertTrue(result.waitForExistence(timeout:10));XCTAssertEqual(result.label,"ログイン情報を更新して接続しました。")
        XCTAssertFalse((input.value as? String ?? "").contains("synthetic"))
        let image = XCTAttachment(screenshot:app.screenshot());image.name = "session-code-import";image.lifetime = .keepAlways;add(image)
    }
    func testInvalidCodeExplainsHowToObtainANewCode() {
        let app = open(extra:["--ui-session-import-rejected"]),input = app.secureTextFields["game-session-code"]
        input.tap();input.typeText("invalid-code");app.buttons["import-game-session"].tap()
        let result = app.staticTexts["session-import-result"];XCTAssertTrue(result.waitForExistence(timeout:10))
        XCTAssertEqual(result.label,"PC用EXEで取得した接続コードを貼り付けてください。")
    }
}
