import XCTest
final class SeasonCharacterTests: XCTestCase {
    private func open(extra: [String] = []) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-season-characters"] + extra;app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap();return app
    }
    private func reveal(_ element: XCUIElement,app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    func testPastCharacterResultsUseTheirSeasonAndCampAndExcludeDrawsFromTheRate() {
        let app = open(),link = app.buttons["profile-seasons"]
        XCTAssertTrue(link.waitForExistence(timeout:10));reveal(link,app:app);link.tap()
        let mercenary = app.descendants(matching:.any)["season-character-rate-25"].firstMatch
        XCTAssertTrue(mercenary.waitForExistence(timeout:10));reveal(mercenary,app:app)
        XCTAssertTrue(app.staticTexts["傭兵"].exists);XCTAssertEqual(mercenary.value as? String,"80.0%")
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "profile-season-characters";capture.lifetime = .keepAlways;add(capture)
        reveal(app.buttons["profile-season-picker"],app:app);app.buttons["profile-season-picker"].tap();app.buttons["S35"].tap()
        XCTAssertTrue(app.staticTexts["season-characters-unavailable"].waitForExistence(timeout:10));XCTAssertFalse(app.staticTexts["傭兵"].exists)
        app.segmentedControls["season-camp"].buttons["ハンター"].tap()
        XCTAssertTrue(app.staticTexts["復讐者"].waitForExistence(timeout:10));XCTAssertFalse(app.staticTexts["幸運児"].exists)
    }
    func testEmptyReceivedRecordsAndHiddenStatisticsDoNotInventCharacterResults() {
        let empty = open(extra:["--ui-season-characters-empty"]),link = empty.buttons["profile-seasons"]
        XCTAssertTrue(link.waitForExistence(timeout:10));reveal(link,app:empty);link.tap()
        XCTAssertTrue(empty.staticTexts["season-characters-empty"].waitForExistence(timeout:10));XCTAssertFalse(empty.staticTexts["傭兵"].exists);empty.terminate()
        let hidden = open(extra:["--ui-hidden-statistics"])
        XCTAssertTrue(hidden.staticTexts["対戦データの公開範囲を確認できません"].waitForExistence(timeout:10));XCTAssertFalse(hidden.buttons["profile-seasons"].exists)
    }
}
