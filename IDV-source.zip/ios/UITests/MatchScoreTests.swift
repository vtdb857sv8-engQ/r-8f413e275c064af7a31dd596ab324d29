import XCTest
final class MatchScoreTests: XCTestCase {
    private func open(unavailable: Bool = false) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing"] + (unavailable ? ["--ui-score-unavailable"] : []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.buttons["戦績"].waitForExistence(timeout:15));app.buttons["戦績"].tap()
        let match = app.buttons["match-record-demo"];XCTAssertTrue(match.waitForExistence(timeout:10));match.tap()
        XCTAssertTrue(app.staticTexts["本人の得点"].waitForExistence(timeout:10));return app
    }
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            let start = scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72))
            let end = scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46))
            start.press(forDuration:0.01,thenDragTo:end)
        }
        XCTAssertTrue(element.isHittable)
    }
    func testBothCampsUseTheirOwnScoreCategoriesAndParticipantProfileStillOpens() {
        let app = open()
        let map = app.descendants(matching:.any)["match-map-preview"].firstMatch
        XCTAssertTrue(map.waitForExistence(timeout:10));XCTAssertLessThanOrEqual(map.frame.height,88);XCTAssertLessThanOrEqual(map.frame.width,160)
        let heading = app.staticTexts["本人の得点内訳"];XCTAssertTrue(heading.waitForExistence(timeout:10));reveal(heading,app:app)
        for label in ["冷静","執着","友好","勇敢"] { XCTAssertTrue(app.staticTexts[label].exists) }
        reveal(app.staticTexts["勇敢"],app:app)
        let own = XCTAttachment(screenshot:app.screenshot());own.name = "match-score-survivor";own.lifetime = .keepAlways;add(own)
        let disclosure = app.buttons["match-score-30"];reveal(disclosure,app:app);disclosure.tap()
        for label in ["屈強","鋭敏","威嚇","狡猾"] { XCTAssertTrue(app.staticTexts[label].exists) }
        reveal(app.staticTexts["狡猾"],app:app)
        let other = XCTAttachment(screenshot:app.screenshot());other.name = "match-score-hunter";other.lifetime = .keepAlways;add(other)
        let peer = app.buttons["match-participant-30"];reveal(peer,app:app);peer.tap()
        XCTAssertTrue(app.staticTexts["集計相手"].waitForExistence(timeout:10));XCTAssertTrue(app.staticTexts["プロフィールの記録"].exists)
    }
    func testUnreceivedBreakdownDoesNotTurnIntoFourZeroScores() {
        let app = open(unavailable:true)
        XCTAssertFalse(app.staticTexts["本人の得点内訳"].exists)
        XCTAssertFalse(app.buttons["match-score-30"].exists)
        XCTAssertFalse(app.staticTexts["冷静"].exists);XCTAssertFalse(app.staticTexts["屈強"].exists)
    }
}
