import XCTest
final class FrequentCharacterTests: XCTestCase {
    private func open(extra: [String] = []) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-frequent-characters"] + extra;app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap();return app
    }
    func testOriginalCharacterNamesAppearInTheAggregateUsageOrder() {
        let app = open()
        XCTAssertTrue(app.staticTexts["使用回数が最も多い"].waitForExistence(timeout:10))
        for (id,name) in [(80,"狂眼"),(2,"道化師"),(129,"オペラ歌手"),(3,"幸運児")] {
            let item = app.descendants(matching:.any)["frequent-character-\(id)"].firstMatch
            XCTAssertTrue(item.exists);XCTAssertEqual(item.label,name)
        }
        let image = XCTAttachment(screenshot:app.screenshot());image.name = "profile-frequent-characters";image.lifetime = .keepAlways;add(image)
    }
    func testHiddenOrUnreceivedUsageNeverDisplaysTheReceivedCharacterList() {
        let hidden = open(extra:["--ui-hidden-statistics"])
        XCTAssertTrue(hidden.staticTexts["対戦データの公開範囲を確認できません"].waitForExistence(timeout:10))
        XCTAssertFalse(hidden.staticTexts["使用回数が最も多い"].exists);hidden.terminate()
        let missing = open(extra:["--ui-frequent-unavailable"])
        XCTAssertTrue(missing.staticTexts["frequent-characters-unavailable"].waitForExistence(timeout:10))
        XCTAssertFalse(missing.descendants(matching:.any)["frequent-character-80"].exists)
    }
}
