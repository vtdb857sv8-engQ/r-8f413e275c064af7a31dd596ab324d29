import XCTest
final class CurrentSeasonTests: XCTestCase {
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    private func open(_ flags: [String] = []) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-current-season"]+flags;app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.staticTexts["プロフィールの記録"].waitForExistence(timeout:15));return app
    }
    func testCumulativeAndCurrentSeasonCountsRemainSeparateAndPreserveZero() {
        let app = open(),picker = app.segmentedControls["profile-statistics-period"]
        reveal(picker,app:app);XCTAssertTrue(picker.buttons["累計"].isSelected);XCTAssertTrue(app.staticTexts["52"].exists)
        picker.buttons["現シーズン"].tap()
        let total = app.descendants(matching:.any)["current-season-survivor-normal-total"].firstMatch
        XCTAssertTrue(total.waitForExistence(timeout:5));XCTAssertEqual(total.value as? String,"5")
        XCTAssertEqual(app.descendants(matching:.any)["current-season-survivor-rank-total"].firstMatch.value as? String,"0")
        reveal(total,app:app)
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "profile-current-season";capture.lifetime = .keepAlways;add(capture)
        reveal(picker,app:app);picker.buttons["累計"].tap();XCTAssertFalse(total.exists);XCTAssertTrue(app.staticTexts["52"].exists)
    }
    func testUnavailableAndHiddenCurrentSeasonStatisticsAreNotFabricated() {
        var app = open(["--ui-current-season-unavailable"]),picker = app.segmentedControls["profile-statistics-period"]
        reveal(picker,app:app);picker.buttons["現シーズン"].tap()
        XCTAssertTrue(app.staticTexts["この陣営の現シーズン記録は未取得です"].firstMatch.exists)
        XCTAssertFalse(app.descendants(matching:.any)["current-season-survivor-normal-total"].firstMatch.exists)
        app.terminate();app = open(["--ui-hidden-statistics"]);picker = app.segmentedControls["profile-statistics-period"]
        XCTAssertFalse(picker.exists);XCTAssertTrue(app.staticTexts["対戦データの公開範囲を確認できません"].exists)
    }
}
