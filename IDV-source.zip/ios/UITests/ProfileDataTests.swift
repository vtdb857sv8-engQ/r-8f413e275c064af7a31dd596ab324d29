import XCTest
final class ProfileDataTests: XCTestCase {
    private func openProfile(hidden: Bool = false) -> XCUIApplication {
        let app = XCUIApplication(); app.launchArguments = ["--ui-testing"] + (hidden ? ["--ui-hidden-statistics"] : []); app.launch()
        let button = app.buttons["home-profile"]; XCTAssertTrue(button.waitForExistence(timeout:15)); button.tap()
        XCTAssertTrue(app.staticTexts["プロフィールの記録"].waitForExistence(timeout:15))
        return app
    }
    func testAcceptedProfileCountsAndHistoricalMatchDetailsAreVisible() {
        let app = openProfile()
        XCTAssertTrue(app.staticTexts["総対戦数"].exists)
        XCTAssertTrue(app.staticTexts["MVP回数"].exists)
        XCTAssertTrue(app.staticTexts["所持キャラクター"].exists)
        app.buttons["戦績"].tap()
        let record = app.buttons["match-record-demo"]; XCTAssertTrue(record.waitForExistence(timeout:10)); record.tap()
        XCTAssertTrue(app.staticTexts["本人の得点"].waitForExistence(timeout:10))
        XCTAssertTrue(app.staticTexts["開始日時"].exists)
        app.scrollViews.firstMatch.swipeUp()
        XCTAssertTrue(app.staticTexts["当時の段位"].exists)
        XCTAssertTrue(app.staticTexts["五段III"].exists)
        XCTAssertTrue(app.staticTexts["MVP"].exists)
        let capture = XCTAttachment(screenshot:app.screenshot()); capture.name = "match-details"; capture.lifetime = .keepAlways; add(capture)
    }
    func testHiddenStatisticsStayHiddenEvenIfFixtureContainsCounts() {
        let app = openProfile(hidden:true)
        XCTAssertTrue(app.staticTexts["対戦データの公開範囲を確認できません"].exists)
        XCTAssertFalse(app.staticTexts["総対戦数"].exists)
        XCTAssertFalse(app.staticTexts["MVP回数"].exists)
        XCTAssertFalse(app.staticTexts["通常戦の対戦数"].exists)
        XCTAssertTrue(app.staticTexts["いいね"].exists)
    }
    func testCharacterRankingSelectionLoadsItsOwnScoreAndProfile() {
        let app = XCUIApplication(); app.launchArguments = ["--ui-testing"]; app.launch()
        app.buttons["検索"].firstMatch.tap()
        app.buttons["ランキング"].tap()
        app.segmentedControls["ranking-board"].buttons["キャラ別"].tap()
        XCTAssertTrue(app.staticTexts["14487"].waitForExistence(timeout:10))
        app.buttons["ranking-character"].tap()
        let character = app.buttons["choose-character-15"]; XCTAssertTrue(character.waitForExistence(timeout:10)); character.tap()
        XCTAssertTrue(app.staticTexts["12345"].waitForExistence(timeout:10))
        let capture = XCTAttachment(screenshot:app.screenshot()); capture.name = "character-ranking"; capture.lifetime = .keepAlways; add(capture)
        app.buttons.matching(NSPredicate(format:"label CONTAINS %@", "表示テスト")).firstMatch.tap()
        XCTAssertTrue(app.staticTexts["プロフィールの記録"].waitForExistence(timeout:10))
    }
    func testCopyNameAndModeSelectionThenTapTheWholeMatchRow() {
        let app = openProfile();let copy = app.buttons["copy-player-name"];copy.tap();XCTAssertEqual(copy.value as? String,"コピー済み")
        app.buttons["戦績"].tap()
        let picker = app.buttons["match-mode"];XCTAssertTrue(picker.waitForExistence(timeout:10));picker.tap();app.buttons["カスタム"].tap()
        let custom = app.buttons["match-record-custom-demo"];XCTAssertTrue(custom.waitForExistence(timeout:10));XCTAssertFalse(app.buttons["match-record-demo"].exists)
        picker.tap();app.buttons["マルチ"].tap()
        let multi = app.buttons["match-record-demo"];XCTAssertTrue(multi.waitForExistence(timeout:10));XCTAssertFalse(custom.exists)
        multi.coordinate(withNormalizedOffset:CGVector(dx:0.25,dy:0.5)).tap()
        XCTAssertTrue(app.staticTexts["本人の得点"].waitForExistence(timeout:10))
    }
}
