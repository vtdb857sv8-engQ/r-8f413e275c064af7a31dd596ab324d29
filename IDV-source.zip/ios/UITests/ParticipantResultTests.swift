import XCTest
final class ParticipantResultTests: XCTestCase {
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    private func open(unknown: Bool = false) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-participant-results"] + (unknown ? ["--ui-personal-result-unknown"] : []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.buttons["戦績"].waitForExistence(timeout:15));app.buttons["戦績"].tap()
        let match = app.buttons["match-record-demo"];XCTAssertTrue(match.waitForExistence(timeout:10));match.tap()
        XCTAssertTrue(app.staticTexts["本人の得点"].waitForExistence(timeout:10));return app
    }
    func testPersonalResultsPreserveOriginalNamesAndRemainSeparateFromTeamVictory() {
        let app = open(),own = app.descendants(matching:.any)["personal-result-owner"].firstMatch
        XCTAssertTrue(own.waitForExistence(timeout:5));XCTAssertEqual(own.value as? String,"行方不明")
        let peer = app.descendants(matching:.any)["personal-result-participant-30"].firstMatch
        XCTAssertTrue(peer.waitForExistence(timeout:5));XCTAssertEqual(peer.value as? String,"辛勝")
        reveal(peer,app:app)
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "participant-results";capture.lifetime = .keepAlways;add(capture)
        let participant = app.buttons["match-participant-30"];reveal(participant,app:app);participant.tap()
        XCTAssertTrue(app.staticTexts["プロフィールの記録"].waitForExistence(timeout:10))
    }
    func testMissingAndUnverifiedResultsNeverBecomeWinsOrLosses() {
        let app = open(unknown:true)
        XCTAssertEqual(app.descendants(matching:.any)["personal-result-owner"].firstMatch.value as? String,"未取得")
        XCTAssertEqual(app.descendants(matching:.any)["personal-result-participant-30"].firstMatch.value as? String,"未確認")
        XCTAssertFalse(app.staticTexts["行方不明"].exists);XCTAssertFalse(app.staticTexts["辛勝"].exists)
    }
}
