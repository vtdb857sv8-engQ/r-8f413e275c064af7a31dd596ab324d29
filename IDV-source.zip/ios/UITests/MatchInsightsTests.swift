import XCTest

final class MatchInsightsTests: XCTestCase {
    private func open(unavailable: Bool = false) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing"] + (unavailable ? ["--ui-analysis-unavailable"] : []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.buttons["分析"].waitForExistence(timeout:15));app.buttons["分析"].tap()
        let link = app.buttons["analysis-insights"];XCTAssertTrue(link.waitForExistence(timeout:10));reveal(link,app:app);link.tap()
        XCTAssertTrue(app.segmentedControls["recent-window"].waitForExistence(timeout:10));return app
    }
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<20 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    func testRecentWindowsMetricsAndModeSpecificCustomSample() {
        let app = open()
        XCTAssertTrue(app.staticTexts["直近10試合"].exists)
        app.segmentedControls["recent-window"].buttons["20試合"].tap()
        XCTAssertTrue(app.staticTexts["直近20試合"].exists)
        let streak = app.staticTexts["2連勝"];reveal(streak,app:app)
        let recentCapture = XCTAttachment(screenshot:app.screenshot());recentCapture.name = "match-insights-recent";recentCapture.lifetime = .keepAlways;add(recentCapture)
        let score = app.staticTexts["平均得点"];reveal(score,app:app)
        XCTAssertTrue(app.staticTexts["得点を確認できた31試合を集計"].exists)
        let mvp = app.staticTexts["12回 / 判定取得30試合 · 未取得5試合"];reveal(mvp,app:app)
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "match-insights-metrics";capture.lifetime = .keepAlways;add(capture)
        let hour = app.staticTexts["21時台"];reveal(hour,app:app)
        XCTAssertTrue(app.staticTexts["試合の終了時刻で集計 · Asia/Tokyo"].exists)
        app.navigationBars.buttons.element(boundBy:0).tap()
        let mode = app.buttons["match-mode"]
        for _ in 0..<10 { if mode.isHittable { break };app.scrollViews.firstMatch.swipeDown() }
        XCTAssertTrue(mode.isHittable);mode.tap();app.buttons["カスタム"].tap()
        let link = app.buttons["analysis-insights"];XCTAssertTrue(link.waitForExistence(timeout:10));reveal(link,app:app);link.tap()
        XCTAssertTrue(app.staticTexts["直近1試合"].waitForExistence(timeout:10))
        XCTAssertTrue(app.staticTexts["カスタム · 取得できた1試合から計算"].exists)
        let customCapture = XCTAttachment(screenshot:app.screenshot());customCapture.name = "match-insights-custom";customCapture.lifetime = .keepAlways;add(customCapture)
    }
    func testMissingResultTimeScoreAndMvpStayUnknown() {
        let app = open(unavailable:true)
        XCTAssertTrue(app.staticTexts["終了日時から試合順を確認できないため、直近成績は集計できません。"].exists)
        let unknown = app.staticTexts["0回 / 判定取得0試合 · 未取得3試合"];reveal(unknown,app:app)
        XCTAssertTrue(app.staticTexts.matching(identifier:"未取得").count >= 2)
        XCTAssertFalse(app.staticTexts["0.0%"].exists)
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "match-insights-unknown";capture.lifetime = .keepAlways;add(capture)
    }
}
