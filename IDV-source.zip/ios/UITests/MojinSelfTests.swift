import XCTest
final class MojinSelfTests: XCTestCase {
    private func open(unavailable: Bool = false,historyError: Bool = false,careersUnavailable: Bool = false) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing"] + (unavailable ? ["--ui-mojin-unavailable"] : []) + (historyError ? ["--ui-mojin-history-error"] : []) + (careersUnavailable ? ["--ui-mojin-careers-unavailable"] : []);app.launch()
        let profile = app.buttons["home-profile"];XCTAssertTrue(profile.waitForExistence(timeout:15));profile.tap()
        let link = app.buttons["own-mojin"];XCTAssertTrue(link.waitForExistence(timeout:15))
        for _ in 0..<6 { if link.isHittable { break };app.scrollViews.firstMatch.swipeUp() }
        XCTAssertTrue(link.isHittable);link.tap();return app
    }
    func testOwnMojinSummaryAndSeasonSelection() {
        let app = open();XCTAssertTrue(app.staticTexts["S1-燐光症"].waitForExistence(timeout:10))
        XCTAssertTrue(app.staticTexts["50.0%"].exists);XCTAssertTrue(app.staticTexts["18,600"].exists)
        let period = app.segmentedControls["mojin-period"];period.buttons["現シーズン"].tap()
        XCTAssertTrue(app.staticTexts["未取得"].exists);XCTAssertFalse(app.staticTexts["50.0%"].exists)
        XCTAssertTrue(app.staticTexts["この期間の職業使用記録はありません"].exists)
        XCTAssertFalse(app.descendants(matching:.any)["mojin-career-1"].firstMatch.exists)
        period.buttons["S0"].tap();XCTAssertTrue(app.staticTexts["50.0%"].exists)
        let career = app.descendants(matching:.any)["mojin-career-1"].firstMatch
        for _ in 0..<6 { if career.isHittable { break };app.scrollViews.firstMatch.swipeUp() }
        XCTAssertTrue(career.isHittable);XCTAssertEqual(career.value as? String,"2回")
        let careerCapture = XCTAttachment(screenshot:app.screenshot());careerCapture.name = "mojin-careers";careerCapture.lifetime = .keepAlways;add(careerCapture)
        let items = app.descendants(matching:.any)["mojin-stat-total_bring_out_item_count"].firstMatch
        let distance = app.descendants(matching:.any)["mojin-stat-total_move_distance"].firstMatch
        for _ in 0..<6 { if distance.isHittable { break };app.scrollViews.firstMatch.swipeUp() }
        XCTAssertTrue(items.exists);XCTAssertEqual(items.value as? String,"3")
        XCTAssertTrue(distance.isHittable);XCTAssertEqual(distance.value as? String,"61 m")
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "mojin-self";capture.lifetime = .keepAlways;add(capture)
    }
    func testUnreceivedOwnMojinDataDoesNotBecomeZeroStatistics() {
        let app = open(unavailable:true);XCTAssertTrue(app.staticTexts["手記の加筆の自己データは未受信です。"].waitForExistence(timeout:10))
        XCTAssertFalse(app.segmentedControls["mojin-period"].exists);XCTAssertFalse(app.staticTexts["50.0%"].exists)
    }
    func testUnreceivedCareerDataDoesNotBecomeAnEmptyUsagePeriod() {
        let app = open(careersUnavailable:true)
        let notice = app.staticTexts["職業データを確認できません"]
        for _ in 0..<6 { if notice.isHittable { break };app.scrollViews.firstMatch.swipeUp() }
        XCTAssertTrue(notice.isHittable)
        XCTAssertFalse(app.staticTexts["この期間の職業使用記録はありません"].exists)
        XCTAssertFalse(app.descendants(matching:.any)["mojin-career-1"].firstMatch.exists)
    }
    func testMojinHistoryDetailsAndParticipantProfile() {
        let app = open();app.buttons["mojin-history"].tap()
        let row = app.buttons["mojin-record-0"];XCTAssertTrue(row.waitForExistence(timeout:10));row.tap()
        XCTAssertTrue(app.staticTexts["0分43秒"].exists)
        let player = app.buttons["mojin-player-0"]
        for _ in 0..<6 { if player.isHittable { break };app.scrollViews.firstMatch.swipeUp() }
        XCTAssertTrue(app.staticTexts["智者"].exists);XCTAssertTrue(player.isHittable)
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "mojin-history-detail";capture.lifetime = .keepAlways;add(capture)
        player.tap();XCTAssertTrue(app.staticTexts["ID 30"].waitForExistence(timeout:10))
    }
    func testMojinHistoryFailureIsNotShownAsNoRecords() {
        let app = open(historyError:true);app.buttons["mojin-history"].tap()
        XCTAssertTrue(app.staticTexts["手記の加筆の自己戦績を取得できませんでした。"].waitForExistence(timeout:10))
        XCTAssertFalse(app.staticTexts["返された戦績はありません"].exists)
    }
}
