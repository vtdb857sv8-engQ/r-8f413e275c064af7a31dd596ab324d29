import XCTest
final class ProfileSeasonTests: XCTestCase {
    private func open(_ flags: [String] = []) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-profile-seasons"]+flags;app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.staticTexts["プロフィールの記録"].waitForExistence(timeout:15));return app
    }
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    func testPastSeasonAndCampSelectionPreserveCountsAndUnknownValues() {
        let app = open(),link = app.buttons["profile-seasons"];XCTAssertTrue(link.waitForExistence(timeout:10));reveal(link,app:app);link.tap()
        XCTAssertTrue(app.staticTexts["シーズン最高"].waitForExistence(timeout:10));XCTAssertTrue(app.staticTexts["五段III"].exists);XCTAssertTrue(app.staticTexts["星 25"].exists)
        let rankTotal = app.descendants(matching:.any)["season-rank-total"].firstMatch
        XCTAssertEqual(rankTotal.value as? String,"12")
        let capture = XCTAttachment(screenshot:app.screenshot());capture.name = "profile-seasons";capture.lifetime = .keepAlways;add(capture)
        app.buttons["profile-season-picker"].tap();app.buttons["S35"].tap()
        XCTAssertTrue(app.staticTexts["未取得"].firstMatch.exists);XCTAssertEqual(app.descendants(matching:.any)["season-normal-total"].firstMatch.value as? String,"0")
        app.segmentedControls["season-camp"].buttons["ハンター"].tap()
        XCTAssertTrue(app.staticTexts["三段V"].exists);XCTAssertEqual(rankTotal.value as? String,"4");XCTAssertFalse(app.staticTexts["五段III"].exists)
    }
    func testMissingSeasonsAndHiddenStatisticsDoNotDisplayFabricatedRecords() {
        var app = open(["--ui-season-empty"]),link = app.buttons["profile-seasons"];reveal(link,app:app);link.tap()
        XCTAssertTrue(app.staticTexts["この陣営の過去シーズン記録は未取得です"].waitForExistence(timeout:10));XCTAssertFalse(app.buttons["profile-season-picker"].exists)
        app.terminate();app = open(["--ui-hidden-statistics"]);link = app.buttons["profile-seasons"]
        XCTAssertFalse(link.exists);XCTAssertTrue(app.staticTexts["対戦データの公開範囲を確認できません"].exists)
    }
}
