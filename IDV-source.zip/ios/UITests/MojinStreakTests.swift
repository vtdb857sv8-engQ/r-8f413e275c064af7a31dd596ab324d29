import XCTest
final class MojinStreakTests: XCTestCase {
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    private func open(missing: Bool = false) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-mojin-streak"] + (missing ? ["--ui-mojin-streak-unavailable"] : []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        let link = app.buttons["own-mojin"];XCTAssertTrue(link.waitForExistence(timeout:15));reveal(link,app:app);link.tap()
        XCTAssertTrue(app.staticTexts["S1-燐光症"].waitForExistence(timeout:10));return app
    }
    func testSeasonPeaksPreserveZeroAndOneWithoutManufacturingAnAllTimeMaximum() {
        let app = open(),peak = app.descendants(matching:.any)["mojin-longest-streak"].firstMatch,period = app.segmentedControls["mojin-period"]
        XCTAssertTrue(peak.waitForExistence(timeout:5));XCTAssertEqual(peak.label,"最長連続真相解明回数");XCTAssertEqual(peak.value as? String,"期間未確認")
        reveal(period,app:app);period.buttons["現シーズン"].tap();XCTAssertEqual(peak.value as? String,"0");reveal(peak,app:app)
        let current = XCTAttachment(screenshot:app.screenshot());current.name = "mojin-streak-current";current.lifetime = .keepAlways;add(current)
        reveal(period,app:app);period.buttons["S0"].tap();XCTAssertEqual(peak.value as? String,"1");reveal(peak,app:app)
        let past = XCTAttachment(screenshot:app.screenshot());past.name = "mojin-streak-past";past.lifetime = .keepAlways;add(past)
        reveal(period,app:app);period.buttons["累計"].tap();XCTAssertEqual(peak.value as? String,"期間未確認")
    }
    func testUnreceivedPeakRemainsUnknownInBothCurrentAndHistoricalPeriods() {
        let app = open(missing:true),peak = app.descendants(matching:.any)["mojin-longest-streak"].firstMatch,period = app.segmentedControls["mojin-period"]
        XCTAssertTrue(peak.waitForExistence(timeout:5));reveal(period,app:app);period.buttons["現シーズン"].tap();XCTAssertEqual(peak.value as? String,"未取得")
        period.buttons["S0"].tap();XCTAssertEqual(peak.value as? String,"未取得")
    }
}
