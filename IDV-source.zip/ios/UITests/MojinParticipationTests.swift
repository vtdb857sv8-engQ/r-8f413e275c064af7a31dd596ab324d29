import XCTest
final class MojinParticipationTests: XCTestCase {
    private func open(missing: Bool = false) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-mojin-participation"] + (missing ? ["--ui-mojin-participation-missing"] : []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        let link = app.buttons["own-mojin"];XCTAssertTrue(link.waitForExistence(timeout:15))
        for _ in 0..<12 { if link.isHittable { break };app.swipeUp() };link.tap()
        XCTAssertTrue(app.staticTexts["S1-燐光症"].waitForExistence(timeout:10));return app
    }
    func testParticipationCountsUseTheOriginalLabelAndChangeWithThePeriod() {
        let app = open(),row = app.descendants(matching:.any)["mojin-participation-counts"].firstMatch,period = app.segmentedControls["mojin-period"]
        XCTAssertTrue(row.waitForExistence(timeout:5));XCTAssertEqual(row.label,"サバイバー/ハンターモード累計参加回数");XCTAssertEqual(row.value as? String,"2 / 0")
        period.buttons["現シーズン"].tap();XCTAssertEqual(row.value as? String,"0 / 0")
        period.buttons["S0"].tap();XCTAssertEqual(row.value as? String,"2 / 0")
        let image = XCTAttachment(screenshot:app.screenshot());image.name = "mojin-participation";image.lifetime = .keepAlways;add(image)
    }
    func testAnUnreceivedCampDoesNotReplaceAnExplicitZeroInTheOtherCamp() {
        let app = open(missing:true),row = app.descendants(matching:.any)["mojin-participation-counts"].firstMatch
        XCTAssertTrue(row.waitForExistence(timeout:5));XCTAssertEqual(row.value as? String,"未取得 / 0")
        app.segmentedControls["mojin-period"].buttons["現シーズン"].tap();XCTAssertEqual(row.value as? String,"未取得 / 0")
    }
}
