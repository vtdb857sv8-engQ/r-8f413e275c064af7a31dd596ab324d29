import XCTest
final class MatchActionTests: XCTestCase {
    private func open(unavailable: Bool = false) -> XCUIApplication {
        let app = XCUIApplication();app.launchArguments = ["--ui-testing","--ui-match-actions"] + (unavailable ? ["--ui-actions-unavailable"] : []);app.launch()
        XCTAssertTrue(app.buttons["home-profile"].waitForExistence(timeout:15));app.buttons["home-profile"].tap()
        XCTAssertTrue(app.buttons["戦績"].waitForExistence(timeout:15));app.buttons["戦績"].tap()
        let match = app.buttons["match-record-demo"];XCTAssertTrue(match.waitForExistence(timeout:10));match.tap()
        XCTAssertTrue(app.staticTexts["本人の得点"].waitForExistence(timeout:10));return app
    }
    private func reveal(_ element: XCUIElement, app: XCUIApplication) {
        for _ in 0..<24 {
            if element.isHittable { return }
            let scroll = app.scrollViews.firstMatch,down = element.frame.midY < scroll.frame.midY
            scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.36 : 0.72)).press(forDuration:0.01,thenDragTo:scroll.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:down ? 0.62 : 0.46)))
        }
        XCTAssertTrue(element.isHittable)
    }
    func testBothCampsShowOriginalActionNamesAndReceivedValues() {
        let app = open(),own = app.buttons["own-match-actions"];XCTAssertTrue(own.waitForExistence(timeout:10));reveal(own,app:app);own.tap()
        let progress = app.descendants(matching:.any)["match-action-1"].firstMatch;XCTAssertTrue(progress.waitForExistence(timeout:10));XCTAssertEqual(progress.value as? String,"160%")
        XCTAssertEqual(app.descendants(matching:.any)["match-action-12"].firstMatch.value as? String,"87秒")
        XCTAssertEqual(app.descendants(matching:.any)["match-action-20"].firstMatch.value as? String,"0")
        let first = XCTAttachment(screenshot:app.screenshot());first.name = "match-actions-survivor";first.lifetime = .keepAlways;add(first)
        app.navigationBars.buttons.element(boundBy:0).tap()
        let peer = app.buttons["match-actions-30"];XCTAssertTrue(peer.waitForExistence(timeout:10));reveal(peer,app:app);peer.tap()
        let hit = app.descendants(matching:.any)["match-action-502"].firstMatch;XCTAssertTrue(hit.waitForExistence(timeout:10));XCTAssertEqual(hit.value as? String,"19")
        XCTAssertEqual(app.descendants(matching:.any)["match-action-501"].firstMatch.value as? String,"0");XCTAssertFalse(app.descendants(matching:.any)["match-action-1"].firstMatch.exists)
        let second = XCTAttachment(screenshot:app.screenshot());second.name = "match-actions-hunter";second.lifetime = .keepAlways;add(second)
    }
    func testUnreceivedActionRecordsDoNotBecomeZeroValues() {
        let app = open(unavailable:true),link = app.buttons["own-match-actions"];XCTAssertTrue(link.waitForExistence(timeout:10));reveal(link,app:app);link.tap()
        XCTAssertTrue(app.staticTexts["行動記録は未取得です"].waitForExistence(timeout:10));XCTAssertFalse(app.descendants(matching:.any)["match-action-1"].firstMatch.exists)
    }
}
