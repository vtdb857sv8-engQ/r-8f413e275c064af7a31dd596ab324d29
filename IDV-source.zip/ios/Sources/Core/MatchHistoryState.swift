import Foundation

/// Keep an accepted page during transient refresh failures; revoke it on a privacy decision.
public struct MatchHistoryState: Sendable {
    public private(set) var items: [MatchRecord] = []
    public private(set) var nextCursor: String?
    public private(set) var message = "読み込み中"
    public private(set) var stale = false
    public init() {}
    public mutating func accept(_ page: Page<MatchRecord>, more: Bool) {
        var result = more ? items : []
        for record in page.items {
            if let index = result.firstIndex(where: { $0.id == record.id }) { result[index] = record }
            else { result.append(record) }
        }
        items = result; nextCursor = page.nextCursor; stale = false
        message = items.isEmpty ? "表示できる戦績がありません" : ""
    }
    public mutating func fail(code: String?, message: String) {
        if ["HISTORY_PRIVATE", "HISTORY_PERMISSION_UNKNOWN", "MOJIN_DATA_PRIVATE", "MOJIN_PERMISSION_UNKNOWN", "PROFILE_VERSION_UNSUPPORTED", "PLAYER_NOT_FOUND"].contains(code ?? "") {
            items = []; nextCursor = nil; stale = false
        } else { stale = !items.isEmpty }
        self.message = stale ? "更新できませんでした。前回取得した戦績を表示中です。" : message
    }
}
