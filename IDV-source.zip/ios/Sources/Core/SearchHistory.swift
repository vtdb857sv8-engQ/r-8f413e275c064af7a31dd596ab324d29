import Foundation

public enum SearchHistory {
    // Persist identity only. A reopened profile always fetches current statistics and visibility.
    public static func encode(_ profiles: [Profile]) throws -> Data {
        var seen = Set<String>()
        let rows = profiles.filter { seen.insert($0.playerId).inserted }.prefix(30).map { p -> JSONValue in
            var row: [String: JSONValue] = ["player_id": .string(p.playerId)]
            if let name = p.name { row["name"] = .string(name) }
            if let face = p.faceId { row["face_id"] = .number(Double(face)) }
            if let frame = p.frameId { row["face_frame_id"] = .number(Double(frame)) }
            return .object(row)
        }
        let encoder = JSONEncoder();encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(rows)
    }
    public static func decode(_ data: Data?) -> [Profile] {
        guard let data else { return [] }
        return (try? JSONDecoder().decode([Profile].self, from: data)) ?? []
    }
}
