import Foundation

public enum JSONValue: Codable, Equatable, Sendable {
    case object([String: JSONValue]), array([JSONValue]), string(String), number(Double), bool(Bool), null
    public init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { self = .null }
        else if let v = try? c.decode(Bool.self) { self = .bool(v) }
        else if let v = try? c.decode(Double.self) { self = .number(v) }
        else if let v = try? c.decode(String.self) { self = .string(v) }
        else if let v = try? c.decode([JSONValue].self) { self = .array(v) }
        else { self = .object(try c.decode([String: JSONValue].self)) }
    }
    public func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch self { case .object(let v): try c.encode(v); case .array(let v): try c.encode(v); case .string(let v): try c.encode(v); case .number(let v): try c.encode(v); case .bool(let v): try c.encode(v); case .null: try c.encodeNil() }
    }
    public subscript(_ key: String) -> JSONValue { if case .object(let v) = self { return v[key] ?? .null }; return .null }
    public var text: String? { switch self { case .string(let v): return v; case .number(let v): return v.rounded() == v ? String(format: "%.0f", v) : String(format: "%.2f", v); default: return nil } }
    public var number: Double? { if case .number(let v) = self { return v }; return nil }
    public var flag: Bool? { if case .bool(let v) = self { return v }; return nil }
    public var array: [JSONValue] { if case .array(let v) = self { return v }; return [] }
}
public struct Envelope<T: Decodable>: Decodable { public let data: T }
public struct Page<T: Decodable>: Decodable {
    public let items: [T]
    public let nextCursor: String?
    public let totalReceived: Int?
    enum CodingKeys: String, CodingKey { case items, nextCursor = "next_cursor", totalReceived = "total_received" }
}
public struct Presence: Codable, Sendable {
    public let state: String?
    public let visibility: String?
    public let lastLoginAt: String?
    public let lastLogoutAt: String?
    public let observedAt: String?
    public let lastLoginObservedAt: String?
    public let lastLogoutObservedAt: String?
    enum CodingKeys: String, CodingKey { case state, visibility, lastLoginAt = "last_login_at", lastLogoutAt = "last_logout_at", observedAt = "observed_at", lastLoginObservedAt = "last_login_observed_at", lastLogoutObservedAt = "last_logout_observed_at" }
    public var label: String { visibility == "hidden" ? "非表示" : StateLabels.name(state ?? "unknown") }
}
public enum StateLabels {
    public static func name(_ state: String) -> String { ["online":"オンライン", "offline":"オフライン", "idle":"待機中", "busy":"取り込み中", "in_match":"対戦中", "in_team":"チーム参加中", "matching":"マッチング中", "reserved":"予約中", "custom_room":"カスタムルーム", "visiting":"訪問中", "spectating":"観戦中", "recruiting":"募集中", "unknown":"不明"][state] ?? "不明" }
    public static func visibility(_ state: String?) -> String { ["hidden":"非表示", "visible":"表示", "unknown":"公開状態不明"][state ?? "unknown"] ?? "不明" }
}
public struct Profile: Decodable, Identifiable, Sendable {
    public let playerId: String
    public let name: String?
    public let presence: Presence?
    public let fieldAccess: [String: String]?
    public let civilianData: JSONValue?
    public let butcherData: JSONValue?
    public let battleCount: Int?
    public let mvp: Int?
    public let characterCount: Int?
    public let likes: Int?
    public let faceId: Int?
    public let frameId: Int?
    public let ranks: JSONValue?
    public let seasonHistory: JSONValue?
    public let currentSeasonStatistics: JSONValue?
    public let mostUsedCharacters: JSONValue?
    public let appearance: JSONValue?
    public let profileTags: JSONValue?
    public var id: String { playerId }
    public var displayName: String { name?.isEmpty == false ? name! : "名前未取得" }
    public var canShowStatistics: Bool { ["self", "permitted"].contains(fieldAccess?["statistics"] ?? "unknown") }
    public var portraitAsset: String? { appearance?["portrait"].text ?? faceId.map { "face-\($0)" } }
    public var frameAsset: String? { appearance?["frame"].text ?? frameId.map { "frame-\($0)" } }
    enum CodingKeys: String, CodingKey { case playerId = "player_id", name, presence, fieldAccess = "field_access", civilianData = "civilian_data", butcherData = "butcher_data", battleCount = "battle_count", mvp, characterCount = "character_num", likes, faceId = "face_id", frameId = "face_frame_id", ranks, seasonHistory = "season_history", currentSeasonStatistics = "current_season_statistics", mostUsedCharacters = "most_used_characters", appearance, profileTags = "profile_tag_info" }
}
public struct ServiceStatus: Decodable, Sendable {
    public let connected: Bool
    public let pushConfigured: Bool
    public let lastSuccessAt: String?
    public let lastError: String?
    public let sessionRecovery: SessionRecoveryStatus?
    public var loginFailureMessage: String? {
        guard !connected else { return nil }
        switch sessionRecovery?.loginFailure?.reason {
        case "sdk_auth_failed": return "SDK認証を確認できません。PC版でログインし直してから接続してください。"
        case "login_rejected": return "ゲーム側でログインが受け付けられませんでした。PC版でログインできるか確認してください。"
        case "unverified_reply": return "ゲームのログイン応答を確認できませんでした。"
        default: return nil
        }
    }
    enum CodingKeys: String, CodingKey { case connected, pushConfigured = "push_configured", lastSuccessAt = "last_success_at", lastError = "last_error", sessionRecovery = "session_recovery" }
}
public struct SessionRecoveryStatus: Decodable, Sendable {
    public let loginFailure: LoginFailure?
    enum CodingKeys: String, CodingKey { case loginFailure = "login_failure" }
}
public struct LoginFailure: Decodable, Sendable {
    public let reason: String
    public let serverCode: Int?
    enum CodingKeys: String, CodingKey { case reason, serverCode = "server_code" }
}
public struct Watch: Decodable, Identifiable, Sendable {
    public let playerId: String
    public let notify: Int
    public let profile: Profile?
    public let presence: Presence?
    public let fresh: Bool?
    public let rules: [String: Bool]?
    public var id: String { playerId }
    enum CodingKeys: String, CodingKey { case playerId = "player_id", notify, profile, presence, fresh, rules }
}
public struct PresenceEvent: Codable, Identifiable, Sendable {
    public let id: Int
    public let playerId: String
    public let previousState: String
    public let state: String
    public let observedAt: String
    public let previousVisibility: String?
    public let visibility: String?
    public let notificationSelected: Bool?
    enum CodingKeys: String, CodingKey { case id, playerId = "player_id", previousState = "previous_state", state, observedAt = "observed_at", previousVisibility = "previous_visibility", visibility, notificationSelected = "notification_selected" }
    public var changeText: String {
        if state == previousState && visibility != previousVisibility { return "\(StateLabels.visibility(previousVisibility)) → \(StateLabels.visibility(visibility))" }
        return "\(StateLabels.name(previousState)) → \(StateLabels.name(state))"
    }
}
public struct Ranking: Decodable, Identifiable, Sendable {
    public let position: Int
    public let playerId: String
    public let name: String?
    public let part: Int?
    public let partLv: Int?
    public let sumStar: Int?
    public let faceId: Int?
    public let frameId: Int?
    public let characterScore: Int?
    public let rank: JSONValue?
    public func rankAsset(_ camp: String) -> String? { rank?["asset"].text ?? part.map { "rank-\(camp)-\(min($0,7))" } }
    public var id: String { "\(position)-\(playerId)" }
      public var rankLabel: String {
          guard let part, part > 0 else { return "段位未取得" }
          if part >= 7 { return rank?["stars"].text.map { "★\($0)" } ?? "星数未取得" }
        let numbers = ["", "一", "二", "三", "四", "五", "六", "七", "八"], divisions = ["", "I", "II", "III", "IV", "V", "VI"]
        let tier = part < numbers.count ? numbers[part] : String(part)
        let division = part < 7 && (1..<divisions.count).contains(partLv ?? 0) ? divisions[partLv!] : ""
        return tier + "段" + division
    }
    enum CodingKeys: String, CodingKey { case position, playerId = "player_id", name, part, partLv = "part_lv", sumStar = "sum_star", faceId = "face_id", frameId = "face_frame_id", characterScore = "character_score", rank }
}
public struct GameCharacter: Decodable, Identifiable, Sendable {
    public let id: Int
    public let name: String?
    public let camp: String?
    public let asset: String?
}
public struct GameCatalog: Decodable, Sendable { public let characters: [String: GameCharacter];public let avatarMasks: [String:String]?;enum CodingKeys:String,CodingKey { case characters,avatarMasks = "avatar_masks" } }
public struct ChatMessage: Decodable, Identifiable, Sendable {
    public struct Author: Decodable, Sendable { public let playerId: String; public let name: String?;public let faceId:Int?;public let frameId:Int?;enum CodingKeys:String,CodingKey { case playerId = "player_id",name,faceId = "face_id",frameId = "face_frame_id" } }
    public let messageId: String?
    public let content: String
    public let sentAt: String?
    public let sequence: Int
    public let author: Author
    public var id: Int { sequence }
    enum CodingKeys: String, CodingKey { case messageId = "message_id", content, sentAt = "sent_at", sequence, author }
}
public struct Recruitment: Decodable, Identifiable, Sendable {
    public struct Owner: Decodable, Sendable { public let playerId: String; public let name: String?; enum CodingKeys: String, CodingKey { case playerId = "player_id", name } }
    public let recruitmentId: String?
    public let owner: Owner
    public let conditions: JSONValue?
    public let teamNum: [Int]?
    public let timeoutTm: Double?
    public var id: String { recruitmentId ?? owner.playerId }
    enum CodingKeys: String, CodingKey { case recruitmentId = "recruitment_id", owner, conditions, teamNum = "team_num", timeoutTm = "timeout_tm" }
}
public struct HistoryAccess: Decodable, Sendable { public let allowed: Bool; public let visibility: String; public let reason: String }
public struct MatchRecord: Decodable, Identifiable, Sendable {
    public let record: JSONValue
    public init(from decoder: Decoder) throws { record = try JSONValue(from: decoder) }
    public var id: String { record["record_id"].text ?? record["common_info"]["battle_id"].text ?? String(record["common_info"]["end_time"].number ?? 0) }
    public var endedAt: Date? { record["common_info"]["end_time"].number.map(Date.init(timeIntervalSince1970:)) }
    public var startedAt: Date? { record["common_info"]["start_time"].number.map(Date.init(timeIntervalSince1970:)) }
    public var duration: Int? { record["common_info"]["battle_time_exclude_pause"].number.map(Int.init) }
    public var players: [JSONValue] { record["all_pl_info"].array }
    public var summary: JSONValue { record["summary"] }
    public var selfPlayer: JSONValue? { summary["players"].array.first { $0["is_self"].flag == true } }
    public var resultLabel: String { summary["result_label"].text ?? ["win":"勝利","loss":"敗北","draw":"引き分け"][summary["result"].text ?? ""] ?? "結果不明" }
    public var mapLabel: String { summary["map_name"].text ?? summary["map_id"].text.map { "マップ \($0)" } ?? "マップ未取得" }
    public var modeLabel: String { summary["mode_name"].text ?? summary["mode_id"].text.map { "モード \($0)" } ?? "モード未取得" }
}
public enum DateText {
    public static func string(_ iso: String?) -> String { guard let iso else { return "未取得" }; let f = ISO8601DateFormatter(); f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]; let date = f.date(from: iso) ?? ISO8601DateFormatter().date(from: iso); return date?.formatted(date: .abbreviated, time: .shortened) ?? "未取得" }
}
