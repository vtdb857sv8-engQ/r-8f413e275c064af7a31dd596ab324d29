import Foundation
public enum EndpointPolicy {
    public static func validate(_ value: String) throws -> URL {
        guard let u = URL(string: value.trimmingCharacters(in: .whitespacesAndNewlines)), let host = u.host, !host.isEmpty, u.user == nil, u.password == nil, u.query == nil, u.fragment == nil, u.path.isEmpty || u.path == "/" else { throw EndpointError.invalid }
        if u.scheme == "https" { return u }
        if u.scheme == "http" && isLocal(host) { return u }
        throw EndpointError.httpsRequired
    }
    public static func isLocal(_ host: String) -> Bool {
        let h = host.lowercased()
        if h == "localhost" || h == "::1" || h.hasSuffix(".local") { return true }
        let p = h.split(separator: ".").compactMap { Int($0) }
        guard p.count == 4, p.allSatisfy({ (0...255).contains($0) }), h.split(separator: ".").count == 4 else { return false }
        return p[0] == 10 || p[0] == 127 || p[0] == 192 && p[1] == 168 || p[0] == 172 && (16...31).contains(p[1]) || p[0] == 169 && p[1] == 254
    }
    public static func sameOrigin(_ a: URL, _ b: URL) -> Bool { a.scheme?.lowercased() == b.scheme?.lowercased() && a.host?.lowercased() == b.host?.lowercased() && (a.port ?? (a.scheme == "https" ? 443 : 80)) == (b.port ?? (b.scheme == "https" ? 443 : 80)) }
}
public enum EndpointError: LocalizedError { case invalid, httpsRequired
    public var errorDescription: String? { self == .invalid ? "PCのAPIのURLを入力してください。URLには鍵やパスを含めないでください。" : "インターネットの接続先にはHTTPSを使用してください。" }
}
public struct SSEParser {
    private var data: [String] = []
    private var event = "message"
    public init() {}
    public mutating func accept(_ line: String) -> PresenceEvent? {
        if line.isEmpty {
            defer { data = []; event = "message" }
            guard event == "presence", let bytes = data.joined(separator: "\n").data(using: .utf8) else { return nil }
            return try? JSONDecoder().decode(PresenceEvent.self, from: bytes)
        }
        if line.hasPrefix(":") { return nil }
        let pair = line.split(separator: ":", maxSplits: 1, omittingEmptySubsequences: false)
        let value = pair.count == 2 ? String(pair[1]).replacingOccurrences(of: "^ ", with: "", options: .regularExpression) : ""
        if pair[0] == "event" { event = value }
        if pair[0] == "data" { if data.joined().utf8.count + value.utf8.count <= 32768 { data.append(value) } else { event = "invalid"; data = [] } }
        return nil
    }
}
