import SwiftUI

struct ProfileSeasonsView: View {
    let data: JSONValue
    @State private var camp = "survivor"
    @State private var season = ""
    private var rows: [JSONValue] { data[camp].array }
    private var selected: JSONValue? { rows.first { $0["season_id"].text == season } ?? rows.first }
    var body: some View {
        IDVPage {
            IDVHeading(title:"シーズン別の記録")
            Picker("陣営",selection:$camp) {
                Text("サバイバー").tag("survivor");Text("ハンター").tag("hunter")
            }.pickerStyle(.segmented).accessibilityIdentifier("season-camp")
            if let row = selected {
                Picker("シーズン",selection:Binding(get:{ selected?["season_id"].text ?? "" },set:{ season = $0 })) {
                    ForEach(Array(rows.enumerated()),id:\.offset) { _,value in Text("S\(value["season_id"].text ?? "")").tag(value["season_id"].text ?? "") }
                }.tint(Theme.text).accessibilityIdentifier("profile-season-picker")
                HStack(alignment:.top,spacing:18) {
                    rank("記録段位",row["recorded_rank"])
                    rank("シーズン最高",row["highest_rank"])
                }.padding(.vertical,10)
                ForEach(Array(row["statistics"].array.enumerated()),id:\.offset) { _,stat in
                    VStack(alignment:.leading,spacing:8) {
                        IDVSectionHeading(title:stat["label"].text ?? "")
                        IDVValueRow(title:"対戦数",value:stat["total"].text ?? "未取得")
                            .accessibilityElement(children:.combine).accessibilityLabel("対戦数")
                            .accessibilityValue(stat["total"].text ?? "未取得").accessibilityIdentifier("season-\(stat["mode"].text ?? "")-total")
                        IDVValueRow(title:"勝利数",value:stat["wins"].text ?? "未取得")
                        IDVValueRow(title:"敗北数",value:stat["losses"].text ?? "未取得")
                        if stat["consistent"].flag == false { Text("受信した件数の整合性を確認できません").font(Theme.font(11)).foregroundStyle(Theme.muted) }
                    }
                }
                if case .object = row["rank_characters"] {
                    SeasonCharacterRecords(data:row["rank_characters"])
                }
            } else { Text("この陣営の過去シーズン記録は未取得です").font(Theme.font(12)).foregroundStyle(Theme.muted) }
            Text("プロフィールで受信した過去シーズンの記録です。全体ランキングの過去順位や、全期間の個別戦績ではありません。未取得の値は補いません。")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
        }.navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
            .onChange(of:camp) { _ in season = "" }
    }
    private func rank(_ title: String,_ value: JSONValue) -> some View {
        VStack(alignment:.leading,spacing:9) {
            Text(title).font(Theme.font(11)).foregroundStyle(Theme.muted)
            GameArt(key:value["asset"].text,size:38,showsMissing:false)
            Text(value["label"].text ?? "未取得").font(Theme.font(14,.medium))
            if let stars = value["stars"].text { Text("星 \(stars)").font(Theme.font(11)).foregroundStyle(Theme.muted) }
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
}

private struct SeasonCharacterRecords: View {
    let data: JSONValue
    var body: some View {
        VStack(alignment:.leading,spacing:12) {
            IDVSectionHeading(title:"キャラ別ランク戦")
            if data["status"].text == "available" {
                if data["items"].array.isEmpty {
                    Text("受信したキャラ別記録はありません").font(Theme.font(12)).foregroundStyle(Theme.muted)
                        .accessibilityIdentifier("season-characters-empty")
                } else {
                    ForEach(Array(data["items"].array.enumerated()),id:\.offset) { _,item in
                        VStack(alignment:.leading,spacing:6) {
                            HStack(spacing:10) {
                                GameArt(key:item["asset"].text,size:38,showsMissing:false)
                                Text(item["name"].text ?? "名前未取得").font(Theme.font(14,.medium))
                                Spacer(minLength:0)
                            }
                            IDVValueRow(title:"対戦数",value:item["battle_count"].text ?? "未取得")
                            IDVValueRow(title:"勝利 / 引分",value:"\(item["wins"].text ?? "—") / \(item["draws"].text ?? "—")")
                            IDVValueRow(title:"勝率（引分除外）",value:item["win_rate_display"].text ?? "未取得")
                                .accessibilityElement(children:.combine).accessibilityLabel("勝率（引分除外）")
                                .accessibilityValue(item["win_rate_display"].text ?? "未取得")
                                .accessibilityIdentifier("season-character-rate-\(item["character_id"].text ?? "")")
                            Divider().overlay(Theme.line)
                        }.accessibilityElement(children:.contain).accessibilityIdentifier("season-character-\(item["character_id"].text ?? "")")
                    }
                    Text("このシーズンで受信したキャラの記録です。勝率は引分を除いて計算し、分母が0の場合はゲーム表示と同じ0.0%です。")
                        .font(Theme.font(11)).foregroundStyle(Theme.muted)
                }
            } else {
                Text("キャラ別の記録を確認できません").font(Theme.font(12)).foregroundStyle(Theme.muted)
                    .accessibilityIdentifier("season-characters-unavailable")
            }
        }.padding(.top,8)
    }
}
