import SwiftUI
import UserNotifications

final class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey:Any]? = nil) -> Bool { UNUserNotificationCenter.current().delegate = self; return true }
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) { NotificationCenter.default.post(name: .init("ManorLinkPushToken"), object: deviceToken.map { String(format: "%02x", $0) }.joined()) }
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) { NotificationCenter.default.post(name: .init("ManorLinkPushFailure"), object: nil) }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) { completionHandler([.banner,.sound,.list]) }
}
@main struct IDVApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var model = AppModel()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(model).tint(Theme.accent).preferredColorScheme(.dark)
                .task { if model.configured { await model.refresh(); model.startStream() } }
                .onChange(of: phase) { value in if value == .active { if model.configured { model.startStream(); Task { await model.refresh() } } } else if value == .background { model.stopStream() } }
                .onReceive(NotificationCenter.default.publisher(for: .init("ManorLinkPushToken"))) { note in if let token = note.object as? String { Task { await model.registerDevice(token) } } }
                .onReceive(NotificationCenter.default.publisher(for: .init("ManorLinkPushFailure"))) { _ in model.pushMessage = "この署名ではプッシュ通知を登録できません。通知履歴はアプリを開いて確認できます。" }
                .alert("確認", isPresented: Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })) { Button("閉じる", role: .cancel) { model.errorMessage = nil } } message: { Text(model.errorMessage ?? "") }
        }
    }
}
