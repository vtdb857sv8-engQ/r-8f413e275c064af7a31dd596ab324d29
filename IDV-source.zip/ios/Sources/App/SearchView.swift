import SwiftUI

struct SearchView: View {
    @EnvironmentObject var model: AppModel
    @State private var query = ""
    @State private var results: [Profile]?
    @State private var busy = false
    var body: some View {
        IDVPage {
            HStack {
                IDVHeading(title:"検索"); Spacer()
                NavigationLink("ランキング") { RankingsView() }.font(Theme.font(12)).foregroundStyle(Theme.muted).frame(minHeight:44)
            }
            HStack(spacing:10) {
                Image(systemName:"magnifyingglass").foregroundStyle(Theme.muted)
                TextField("ID・プレイヤー名",text:$query).textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.search).onSubmit(find)
                Button("検索",action:find).font(Theme.font(13,.medium)).frame(minWidth:44,minHeight:44).disabled(busy || query.trimmingCharacters(in:.whitespaces).isEmpty)
            }.padding(.horizontal,12).background(Theme.card,in:RoundedRectangle(cornerRadius:7))
            if busy { ProgressView() }
            if let results {
                IDVSectionHeading(title:"検索結果",detail:"\(results.count)件")
                rows(results,kind:"result")
                if results.isEmpty { Text("見つかりませんでした").font(Theme.font(13)).foregroundStyle(Theme.muted) }
            }
            if !model.searchHistory.isEmpty {
                HStack {
                    IDVSectionHeading(title:"検索履歴")
                    Button("消去") { model.clearSearchHistory() }.font(Theme.font(12)).foregroundStyle(Theme.muted).frame(minHeight:44)
                }
                rows(model.searchHistory,kind:"history")
            }
        }.navigationDestination(for:String.self) { id in
            ProfileView(playerId:id,remembersSearch:true).id(id)
        }
    }
    private func rows(_ items: [Profile],kind: String) -> some View {
        VStack(spacing:5) {
            ForEach(items) { p in
                NavigationLink(value:p.playerId) {
                    HStack(spacing:12) {
                        GameAvatar(profile:p)
                        VStack(alignment:.leading,spacing:5) {
                            Text(p.displayName).font(Theme.font(14,.medium))
                            Text("ID \(p.playerId)").font(Theme.font(11)).foregroundStyle(Theme.muted)
                        }
                        Spacer(); Image(systemName:"chevron.right").font(Theme.font(12)).foregroundStyle(Theme.muted)
                    }.frame(maxWidth:.infinity,minHeight:70).contentShape(Rectangle())
                }.accessibilityIdentifier("search-\(kind)-\(p.playerId)")
                Divider().overlay(Theme.line).padding(.leading,54)
            }
        }
    }
    private func find() {
        guard let client = model.client, !busy else { return }
        let q = query.trimmingCharacters(in:.whitespacesAndNewlines); guard !q.isEmpty else { return }
        busy = true
        Task {
            defer { busy = false }
            do {
                let found: [Profile] = try await client.data("/v1/players",query:[.init(name:"query",value:q)])
                results = found
                if found.count == 1,let p = found.first { model.rememberSearch(p) }
            } catch { model.show(error) }
        }
    }
}
