#if DEBUG
import Foundation

enum AnalysisFixture {
    static func data(mode: String, unavailable: Bool, peer: [String:Any]) -> [String:Any] {
        let custom = mode == "custom", empty = !["all","multi","custom"].contains(mode)
        let total = unavailable ? 3 : empty ? 0 : custom ? 1 : 35
        let win = unavailable || empty ? 0 : custom ? 1 : 17
        var data: [String:Any] = ["total":total,"win":win,"draw":custom || empty || unavailable ? 0 : 8,"loss":custom || empty || unavailable ? 0 : 10,"unknown":unavailable ? 3 : 0,"by_map":[],"by_character":[],"by_mode":[],"by_party_partner":custom || empty || unavailable ? [] : [peer],"by_teammate":custom || empty || unavailable ? [] : [peer],"partner_coverage":["public_party_matches":custom || empty || unavailable ? 0 : 35,"identifiable_matches":custom || empty || unavailable ? 0 : 35]]
        if !unavailable && !empty { data["win_rate"] = custom ? 100.0 : 48.57142857;data["average_duration"] = 240 }
        data["chronology"] = ["status":unavailable ? "missing_timestamps" : "available","dated_matches":unavailable ? 0 : total,"undated_matches":unavailable ? total : 0]
        data["recent"] = unavailable ? [] : [10,20,50].map { n -> [String:Any] in
            let count = min(n,total), wins = empty ? 0 : custom ? 1 : n == 10 ? 6 : n == 20 ? 12 : 17
            let draws = custom || empty ? 0 : n == 10 ? 1 : n == 20 ? 2 : 8
            var row: [String:Any] = ["requested_matches":n,"total":count,"known_results":count,"unknown":0,"win":wins,"draw":draws,"loss":count-wins-draws]
            if count > 0 { row["win_rate"] = Double(wins)/Double(count)*100 }
            return row
        }
        data["streaks"] = unavailable || empty ? [:] : ["current":["kind":"win","count":custom ? 1 : 2],"longest_win":custom ? 1 : 4,"longest_loss":custom ? 0 : 3]
        var metrics: [String:Any] = ["mvp_count":custom || unavailable || empty ? 0 : 12,"mvp_known_matches":unavailable || empty ? 0 : custom ? 1 : 30,"mvp_unknown_matches":unavailable ? total : empty || custom ? 0 : 5,"scored_matches":unavailable || empty ? 0 : custom ? 1 : 31]
        if !unavailable && !empty { metrics["average_score"] = custom ? 1200.0 : 9234.5;metrics["mvp_rate"] = custom ? 0.0 : 40.0 }
        data["self_performance"] = metrics
        data["hourly"] = ["time_zone":"Asia/Tokyo","dated_matches":unavailable ? 0 : total,"undated_matches":unavailable ? total : 0,"items":unavailable || empty ? [] : [["hour":21,"total":total,"known_results":total,"win":win,"draw":custom ? 0 : 8,"loss":custom ? 0 : 10,"unknown":0,"win_rate":custom ? 100.0 : 48.57142857]]]
        return data
    }
}
#endif
