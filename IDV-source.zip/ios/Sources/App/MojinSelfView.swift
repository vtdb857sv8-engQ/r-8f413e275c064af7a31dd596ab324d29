import SwiftUI

struct MojinSelfView: View {
    var playerId: String? = nil
    @EnvironmentObject var model: AppModel
    @State private var info: JSONValue?
    @State private var selection = "all"
    @State private var loading = false
    @State private var failure: String?
    private var rows: [JSONValue] { info?["statistics"].array ?? [] }
    private func key(_ row: JSONValue) -> String { row["scope"].text == "season" ? "season-\(row["season_id"].text ?? "")" : row["scope"].text ?? "" }
    private var selected: JSONValue { rows.first { key($0) == selection } ?? .null }
    private var detailRows: [JSONValue] { selected["additional_statistics"].array }
    private var streak: JSONValue { selected["longest_success_streak"] }
    private var participation: JSONValue { selected["participation_counts"] }
    private var participationValue: String { "\(participation["survivor"].text ?? "未取得") / \(participation["hunter"].text ?? "未取得")" }
    private var streakValue: String {
        if streak["status"].text == "received" { return streak["value"].text ?? "未取得" }
        return streak["status"].text == "unverified_period" ? "期間未確認" : "未取得"
    }
    var body: some View {
        IDVPage {
            IDVHeading(title:"手記の加筆")
            NavigationLink { MojinHistoryView(playerId:playerId) } label: {
                HStack { Text("探索の戦績"); Spacer(); Image(systemName:"chevron.right") }.font(Theme.font(14)).foregroundStyle(Theme.text).padding(.vertical,12).frame(maxWidth:.infinity,minHeight:44).contentShape(Rectangle())
            }.accessibilityIdentifier("mojin-history")
            if loading { ProgressView("探索情報を取得中") }
            if let failure { Text(failure).font(Theme.font(12)).foregroundStyle(Theme.muted) }
            if let info {
                IDVSectionHeading(title:"探索情報",detail:info["season_name"].text ?? "シーズン未取得")
                HStack(alignment:.top,spacing:16) { rank("現シーズン",value:info["current_rank"]); rank("最高段位",value:info["highest_rank"]) }
                    .padding(.vertical,8).accessibilityIdentifier("mojin-ranks")
                Picker("集計期間",selection:$selection) {
                    ForEach(Array(rows.enumerated()),id:\.offset) { _, row in
                        Text(row["scope"].text == "all" ? "累計" : row["scope"].text == "current" ? "現シーズン" : "S\(row["season_id"].text ?? "?")").tag(key(row))
                    }
                }.pickerStyle(.segmented).accessibilityIdentifier("mojin-period")
                VStack(spacing:0) {
                    IDVValueRow(title:"総探索回数",value:count("total_actions"))
                    IDVValueRow(title:"探索成功率",value:selected["success_rate"].number.map { String(format:"%.1f%%",$0) } ?? "未取得")
                    IDVValueRow(title:"累計詞章価値",value:count("total_deliver_value"))
                    IDVValueRow(title:"平均探索時間",value:selected["average_duration_seconds"].number.map { "\(Int($0) / 60)分\(Int($0) % 60)秒" } ?? "未取得")
                }.accessibilityIdentifier("mojin-statistics")
                if let label = participation["label"].text {
                    IDVValueRow(title:label,value:participationValue)
                        .accessibilityElement(children:.combine).accessibilityLabel(label)
                        .accessibilityValue(participationValue)
                        .accessibilityIdentifier("mojin-participation-counts")
                }
                ForEach([("survivor","サバイバー"),("hunter","ハンター")],id:\.0) { camp,title in
                    IDVSectionHeading(title:title)
                    IDVValueRow(title:"成功 / 失敗",value:"\(selected[camp]["successful"].text ?? "未取得") / \(selected[camp]["failed"].text ?? "未取得")")
                }
                if let title = selected["frequent_careers"]["label"].text {
                    IDVSectionHeading(title:title)
                    if selected["frequent_careers"]["status"].text == "available", selected["frequent_careers"]["items"].array.isEmpty {
                        Text("この期間の職業使用記録はありません").font(Theme.font(12)).foregroundStyle(Theme.muted).accessibilityIdentifier("mojin-careers-empty")
                    } else if ["available","partial"].contains(selected["frequent_careers"]["status"].text ?? "") {
                        ForEach(Array(selected["frequent_careers"]["items"].array.enumerated()),id:\.offset) { _, career in
                            HStack(spacing:12) {
                                GameArt(key:career["asset"].text,size:38)
                                Text(career["name"].text ?? "職業名未取得").font(Theme.font(14))
                                Spacer()
                                Text(career["use_count"].text.map { "\($0)回" } ?? "未取得").font(Theme.font(14)).monospacedDigit()
                            }.padding(.vertical,4).accessibilityElement(children:.combine)
                                .accessibilityLabel(career["name"].text ?? "職業名未取得")
                                .accessibilityValue(career["use_count"].text.map { "\($0)回" } ?? "未取得")
                                .accessibilityIdentifier("mojin-career-\(career["career_id"].text ?? "")")
                        }
                    } else {
                        Text("職業データを確認できません").font(Theme.font(12)).foregroundStyle(Theme.muted).accessibilityIdentifier("mojin-careers-unavailable")
                    }
                }
                MojinFavoriteWeapons(data:selected["favorite_weapons"])
                if let label = streak["label"].text {
                    IDVValueRow(title:label,value:streakValue)
                        .accessibilityElement(children:.combine).accessibilityLabel(label)
                        .accessibilityValue(streakValue)
                        .accessibilityIdentifier("mojin-longest-streak")
                }
                if !detailRows.isEmpty {
                    IDVSectionHeading(title:"探索の詳細")
                    ForEach(Array(detailRows.enumerated()),id:\.offset) { _, row in
                        IDVValueRow(title:row["label"].text ?? "",value:row["display_value"].text ?? "未取得")
                            .accessibilityElement(children:.combine)
                            .accessibilityLabel(row["label"].text ?? "")
                            .accessibilityValue(row["display_value"].text ?? "未取得")
                            .accessibilityIdentifier("mojin-stat-\(row["field"].text ?? "")")
                    }
                }
                Text("取得時点のデータ · \(DateText.string(info["received_at"].text))").font(Theme.font(10)).foregroundStyle(Theme.muted)
            }
            Button("再読み込み") { Task { await load() } }.buttonStyle(IDVActionStyle(primary:false)).disabled(loading)
        }.navigationTitle(playerId == nil ? "自分の探索情報" : "探索情報").navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
            .task { await load() }.refreshable { await load() }
    }
    private func count(_ field: String) -> String { selected[field].number.map { $0.formatted(.number.precision(.fractionLength(0))) } ?? "未取得" }
    private func rank(_ title: String,value: JSONValue) -> some View {
        VStack(alignment:.leading,spacing:7) {
            Text(title).font(Theme.font(12)).foregroundStyle(Theme.muted)
            HStack(spacing:8) { GameArt(key:value["asset"].text,size:42); VStack(alignment:.leading,spacing:4) { Text(value["label"].text ?? "未取得").font(Theme.font(18,.medium)); Text(value["stars"].text.map { "星 \($0)" } ?? "星未取得").font(Theme.font(11)).foregroundStyle(Theme.muted) } }
            Text(value["season_id"].text.map { "S\($0)" } ?? "シーズン未取得").font(Theme.font(10)).foregroundStyle(Theme.muted)
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
    private func load() async {
        guard let client = model.client, !loading else { return }
        loading = true; failure = nil; info = nil
        defer { loading = false }
        do { let value: JSONValue = try await client.data(playerId.map { "/v1/players/\($0)/mojin" } ?? "/v1/me/mojin"); guard !Task.isCancelled else { return }; info = value }
        catch { if !Task.isCancelled { failure = error.localizedDescription } }
    }
}
private struct MojinFavoriteWeapons: View {
    let data: JSONValue
    var body: some View {
        if let title = data["label"].text {
            IDVSectionHeading(title:title)
            if data["status"].text == "available",data["items"].array.isEmpty {
                Text("この期間の得意武器の記録はありません").font(Theme.font(12)).foregroundStyle(Theme.muted).accessibilityIdentifier("mojin-weapons-empty")
            } else if ["available","partial"].contains(data["status"].text ?? "") {
                ForEach(Array(data["items"].array.enumerated()),id:\.offset) { _, item in
                    HStack(spacing:12) {
                        GameArt(key:item["asset"].text,size:38,showsMissing:false)
                        Text(item["name"].text ?? "武器名未取得").font(Theme.font(14))
                        Spacer()
                    }.padding(.vertical,4).accessibilityElement(children:.combine)
                        .accessibilityLabel(item["name"].text ?? "武器名未取得")
                        .accessibilityIdentifier("mojin-weapon-\(item["item_id"].text ?? "")")
                }
            } else {
                Text("武器データを確認できません").font(Theme.font(12)).foregroundStyle(Theme.muted).accessibilityIdentifier("mojin-weapons-unavailable")
            }
        }
    }
}
