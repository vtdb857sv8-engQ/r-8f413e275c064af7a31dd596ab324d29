import SwiftUI

struct GameSessionImportView: View {
    @EnvironmentObject var model: AppModel
    @State private var code = ""
    @State private var importing = false
    @State private var message: String?
    var body: some View {
        IDVPage {
            IDVHeading(title:"ゲームの接続コード")
            Text("PC用EXEで「取得」→「コピー」を押し、ここに貼り付けます。")
                .font(Theme.font(13)).foregroundStyle(Theme.muted)
            SecureField("接続コード",text:$code).textInputAutocapitalization(.never).autocorrectionDisabled()
                .privacySensitive().accessibilityIdentifier("game-session-code")
            PasteButton(payloadType:String.self) { values in if let value = values.first { code = value } }
                .disabled(importing)
            Text("PCのゲームを終了してから接続してください。")
                .font(Theme.font(12)).foregroundStyle(Theme.muted)
            if let message { Text(message).font(Theme.font(13)).foregroundStyle(Theme.muted).accessibilityIdentifier("session-import-result") }
            Button(importing ? "接続中…" : "保存して接続") { Task { await save() } }
                .buttonStyle(IDVActionStyle()).disabled(importing || code.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
                .accessibilityIdentifier("import-game-session")
        }.navigationTitle("ログイン情報の更新").navigationBarTitleDisplayMode(.inline)
            .onDisappear { code = "" }
    }
    private func save() async {
        guard let client = model.client else { message = "PCのAPIとの接続を設定してください。";return }
        importing = true;message = nil
        defer { importing = false }
        var stored = false
        do {
            try await client.command("/v1/session/import",body:.object(["code":.string(code.trimmingCharacters(in:.whitespacesAndNewlines))]))
            code = "";stored = true
            try await client.command("/v1/session/connect",body:.object(["replace_existing":.bool(false)]))
            message = "ログイン情報を更新して接続しました。"
        } catch { message = (stored ? "コードを保存しました。" : "") + error.localizedDescription }
        await model.refresh()
    }
}
