import SwiftUI

struct PartnerAnalysisView: View {
    let data: JSONValue
    var exploration = false
    @State private var scope = "party"
    @State private var order = "count"
    @State private var limit = 20
    private var peers: [JSONValue] {
        let rows = data[scope == "party" ? "by_party_partner" : "by_teammate"].array
        return order == "count" ? rows : rows.sorted { a,b in
            let x = a["win_rate"].number ?? -1, y = b["win_rate"].number ?? -1
            return x == y ? (a["total"].number ?? 0) > (b["total"].number ?? 0) : x > y
        }
    }
    var body: some View {
        VStack(alignment:.leading,spacing:14) {
            IDVSectionHeading(title:"一緒に組んだ相手")
            Picker("相手の集計範囲",selection:$scope) { Text("パーティー").tag("party"); Text("同じチーム").tag("team") }.pickerStyle(.segmented)
                .accessibilityIdentifier("partner-scope")
            Text(scope == "party" ? "公開されたパーティー記録で、一緒に組んだことを確認できた相手です。" : "同じチームで戦った相手です。野良でのマッチングも含みます。")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
            if let count = data["partner_coverage"][scope == "party" ? "public_party_matches" : "identifiable_matches"].text {
                Text("対象 \(count)試合 · 公開IDがある相手のみ").font(Theme.font(11)).foregroundStyle(Theme.muted)
            }
            Picker("並び順",selection:$order) { Text("回数順").tag("count"); Text(exploration ? "成功率順" : "勝率順").tag("rate") }.pickerStyle(.segmented)
            if peers.isEmpty {
                Text(scope == "party" ? "パーティーを確認できる記録がありません" : "相手を特定できる記録がありません").font(Theme.font(12)).foregroundStyle(Theme.muted)
            } else {
                ForEach(Array(peers.prefix(limit).enumerated()),id:\.offset) { index,peer in
                    NavigationLink { ProfileView(playerId:peer["player_id"].text ?? "") } label: {
                        HStack(spacing:12) {
                            Text(String(index+1)).font(Theme.font(12)).foregroundStyle(Theme.muted).frame(width:20)
                            AvatarArtwork(portrait:peer["portrait"].text,frame:peer["frame"].text,size:42)
                            VStack(alignment:.leading,spacing:5) {
                                Text(peer["name"].text ?? peer["player_id"].text ?? "名前未取得").font(Theme.font(14,.medium)).lineLimit(1)
                                Text("\(peer["wins"].text ?? "0")勝 / \(peer["draws"].text ?? "0")分 / \(peer["losses"].text ?? "0")敗").font(Theme.font(11)).foregroundStyle(Theme.muted)
                                if (peer["unknown"].number ?? 0) > 0 { Text("結果不明 \(peer["unknown"].text ?? "")試合").font(Theme.font(10)).foregroundStyle(Theme.muted) }
                            }
                            Spacer(minLength:4)
                            VStack(alignment:.trailing,spacing:5) {
                                Text("\(peer["total"].text ?? "0")試合").font(Theme.font(14,.medium))
                                Text(peer["win_rate"].number.map { String(format:"%.1f%%",$0) } ?? "勝率未取得").font(Theme.font(12)).foregroundStyle(Theme.muted)
                            }
                        }.padding(.vertical,8).contentShape(Rectangle())
                    }.accessibilityIdentifier("\(scope)-peer-\(peer["player_id"].text ?? "")")
                    Divider().overlay(Theme.line)
                }
                if peers.count > limit { Button("さらに表示") { limit += 20 }.font(Theme.font(12)).frame(maxWidth:.infinity,minHeight:44) }
                Text("勝率＝勝利数÷勝敗・引分が分かる試合数。少ない試合数の相手も含みます。").font(Theme.font(10)).foregroundStyle(Theme.muted)
            }
        }.onChange(of:scope) { _ in limit = 20 }.onChange(of:order) { _ in limit = 20 }
    }
}

struct BadgeCollectionView: View {
    let profile: Profile
    @State private var period = "current"
    var body: some View {
        VStack(alignment:.leading,spacing:16) {
            Picker("徽章の期間",selection:$period) { Text("現在").tag("current"); Text("過去").tag("history") }.pickerStyle(.segmented).accessibilityIdentifier("badge-period")
            if period == "current" { CurrentBadges(profile:profile) }
            else if ["self","permitted"].contains(profile.fieldAccess?["history_badges"] ?? "unknown") { HistoricalBadgesView(playerId:profile.playerId) }
            else { Text(profile.fieldAccess?["history_badges"] == "hidden" ? "過去徽章は非公開です" : "過去徽章の公開範囲を確認できません").font(Theme.font(12)).foregroundStyle(Theme.muted) }
        }
    }
}

struct HistoricalBadgesView: View {
    @EnvironmentObject var model: AppModel
    let playerId: String
    @State private var data: JSONValue?
    @State private var failure: String?
    @State private var camp = "all"
    @State private var query = ""
    @State private var loading = false
    private var rows: [JSONValue] { (data?["items"].array ?? []).filter { (camp == "all" || $0["camp"].text == camp) && (query.isEmpty || $0["character_name"].text?.localizedCaseInsensitiveContains(query) == true) } }
    var body: some View {
        VStack(alignment:.leading,spacing:14) {
            HStack { IDVSectionHeading(title:"キャラ別の過去徽章",detail:data?["total_received"].text.map { "\($0)キャラ" }); Button("更新") { Task { await load() } }.font(Theme.font(12)).frame(minHeight:44).disabled(loading) }
            Picker("陣営",selection:$camp) { Text("すべて").tag("all"); Text("サバイバー").tag("survivor"); Text("ハンター").tag("hunter") }.pickerStyle(.segmented)
            TextField("キャラ名で絞り込む",text:$query).font(Theme.font(13)).padding(12).background(Theme.card,in:RoundedRectangle(cornerRadius:7)).autocorrectionDisabled()
            if loading { ProgressView() }
            else if let failure { Text(failure).font(Theme.font(12)).foregroundStyle(Theme.muted) }
            else if data != nil {
                if rows.isEmpty { Text("該当する過去徽章がありません").font(Theme.font(12)).foregroundStyle(Theme.muted) }
                ForEach(Array(rows.enumerated()),id:\.offset) { _,row in HistoricalBadgeRow(item:row); Divider().overlay(Theme.line) }
            }
        }.task(id:playerId) { await load() }
    }
    private func load() async {
        guard let client = model.client else { return }
        loading = true; data = nil; failure = nil
        defer { loading = false }
        do { let fetched: JSONValue = try await client.data("/v1/players/\(playerId)/badges/history"); try Task.checkCancellation(); data = fetched }
        catch { if !Task.isCancelled { failure = error.localizedDescription } }
    }
}

private struct HistoricalBadgeRow: View {
    let item: JSONValue
    @State private var expanded = false
    var body: some View {
        VStack(alignment:.leading,spacing:12) {
            Button { expanded.toggle() } label: {
                HStack(spacing:12) {
                    GameArt(key:item["character_asset"].text,size:46)
                    VStack(alignment:.leading,spacing:5) {
                        Text(item["character_name"].text ?? "キャラ \(item["character_id"].text ?? "")").font(Theme.font(15,.medium))
                        Text(item["highest_grade"].text.map { "最高 \($0)徽章" } ?? "最高徽章未取得").font(Theme.font(11)).foregroundStyle(Theme.muted)
                    }
                    Spacer(minLength:4)
                    GameArt(key:item["highest_asset"].text,size:37)
                    Image(systemName:expanded ? "chevron.up" : "chevron.down").font(Theme.font(11)).foregroundStyle(Theme.muted)
                }.frame(maxWidth:.infinity,minHeight:64).contentShape(Rectangle())
            }.accessibilityIdentifier("history-badge-\(item["character_id"].text ?? "")")
            if expanded {
                if let score = item["highest_score"].text { IDVValueRow(title:"最高認知ポイント",value:score) }
                ForEach(Array(item["grades"].array.enumerated()),id:\.offset) { _,grade in
                    HStack(spacing:10) {
                        GameArt(key:grade["asset"].text,size:30)
                        Text("\(grade["grade"].text ?? "") × \(grade["count"].text ?? "—")").font(Theme.font(13))
                        Spacer()
                        if let date = grade["latest_date"].text { Text("最終獲得日 \(date)").font(Theme.font(10)).foregroundStyle(Theme.muted) }
                    }.padding(.vertical,4)
                }
            }
        }
    }
}
