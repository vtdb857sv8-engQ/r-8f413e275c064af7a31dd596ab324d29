import SwiftUI

struct MatchActionsView: View {
    let details: JSONValue
    var playerName: String?
    var body: some View {
        IDVPage {
            IDVHeading(title:"行動記録")
            if let playerName { Text(playerName).font(Theme.font(13)).foregroundStyle(Theme.muted) }
            if details["status"].text != "received" {
                Text("行動記録は未取得です").font(Theme.font(12)).foregroundStyle(Theme.muted)
            } else {
                ForEach(Array(details["items"].array.enumerated()),id:\.offset) { _,row in
                    IDVValueRow(title:row["label"].text ?? "",value:row["display_value"].text ?? "未取得")
                        .accessibilityElement(children:.combine).accessibilityLabel(row["label"].text ?? "")
                        .accessibilityValue(row["display_value"].text ?? "未取得").accessibilityIdentifier("match-action-\(row["action_id"].text ?? "")")
                }
            }
            if ["received","unavailable"].contains(details["titles_status"].text ?? "") {
                IDVSectionHeading(title:"この試合の称号")
                if details["titles_status"].text == "unavailable" {
                    Text("称号記録は未取得です").font(Theme.font(12)).foregroundStyle(Theme.muted)
                } else if details["titles"].array.isEmpty,details["unverified_title_records"].number == 0 {
                    Text("この試合の称号はありません").font(Theme.font(12)).foregroundStyle(Theme.muted)
                }
                ForEach(Array(details["titles"].array.enumerated()),id:\.offset) { _,title in
                    HStack(spacing:12) {
                        GameArt(key:title["asset"].text,size:34,showsMissing:false)
                        VStack(alignment:.leading,spacing:6) {
                            Text(title["label"].text ?? "").font(Theme.font(14,.medium))
                            Text(title["description"].text ?? "").font(Theme.font(11)).foregroundStyle(Theme.muted)
                        }
                        Spacer(minLength:0)
                    }.padding(.vertical,7).accessibilityElement(children:.combine)
                        .accessibilityLabel(title["label"].text ?? "").accessibilityValue(title["description"].text ?? "")
                        .accessibilityIdentifier("match-title-\(title["id"].text ?? "")")
                }
                if let count = details["unverified_title_records"].number,count > 0 {
                    Text("内容を確認できていない称号記録が\(Int(count))件あります").font(Theme.font(11)).foregroundStyle(Theme.muted)
                }
            }
            Text("その試合で受信した行動の記録です。未取得の項目は0にせず、解読進捗と牽制時間はゲームと同じ整数表示にしています。")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
        }.navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
    }
}
