import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var model: AppModel
    let playerId: String
    var remembersSearch = false
    @State private var profile: Profile?
    @State private var loadingProfile = true
    @State private var profileFailure: String?
    @State private var profileRequestId = UUID()
    @State private var historyState = MatchHistoryState()
    @State private var tab = "概要"
    @State private var mode = "all"
    @State private var loadingHistory = false
    @State private var requestId = UUID()
    @State private var historyMode: String?
    private var historyRequestKey: String { "\(playerId)|\(profile?.playerId ?? "")|\(tab)|\(mode)" }
    var body: some View {
        IDVPage {
            if let p = profile {
                IdentityView(profile:p,copyName:true)
                if p.playerId != model.me?.playerId {
                    Button { Task { await model.setWatch(p.playerId,enabled:!model.isWatching(p.playerId)) } } label: {
                        Label(model.isWatching(p.playerId) ? "通知 ON" : "通知を有効にする",systemImage:model.isWatching(p.playerId) ? "bell.badge" : "bell")
                    }.buttonStyle(IDVActionStyle(primary:!model.isWatching(p.playerId)))
                }
                DocumentTabs(selection:$tab,titles:["概要","戦績","分析","徽章"])
                if ["戦績","分析"].contains(tab) {
                    HStack {
                        Text("ゲームモード").font(Theme.font(12)).foregroundStyle(Theme.muted)
                        Spacer()
                        Picker("ゲームモード",selection:$mode) {
                            ForEach([("all","全て"),("multi","マルチ"),("rank","ランク"),("duo","28"),("mojin","手記"),("custom","カスタム"),("other","その他")],id:\.0) { value,title in Text(title).tag(value) }
                        }.tint(Theme.text).accessibilityIdentifier("match-mode")
                    }
                    if mode == "all" { Text("カスタム戦は「カスタム」で表示・集計します").font(Theme.font(11)).foregroundStyle(Theme.muted) }
                }
                if tab == "概要" { overview(p) }
                else if tab == "戦績" { history }
                else if tab == "分析" { AnalysisView(playerId:playerId,mode:mode).id(mode) }
                else { BadgeCollectionView(profile:p) }
            } else if loadingProfile {
                ProgressView("プロフィールを取得中").accessibilityIdentifier("profile-loading")
            } else {
                Text(profileFailure ?? "プロフィールを表示できません。再読み込みしてください。")
                    .font(Theme.font(13)).foregroundStyle(Theme.muted).accessibilityIdentifier("profile-load-error")
                Button("再読み込み") { Task { await load() } }.buttonStyle(IDVActionStyle(primary:false)).accessibilityIdentifier("reload-profile")
            }
        }.navigationTitle("個人資料").navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
            .task(id:playerId) { await load() }
            .task(id:historyRequestKey) { if profile != nil, tab == "戦績" { await loadHistory(more:false) } }
            .refreshable { await load() }
    }
    private func overview(_ p: Profile) -> some View {
        Group {
            DocumentSection { RankGrid(profile:p) }
            DocumentSection { CurrentBadges(profile:p);ProfileFrequentCharacters(profile:p) }
            DocumentSection { ProfileStatisticsView(profile:p) }
            if p.canShowStatistics,let seasons = p.seasonHistory {
                NavigationLink { ProfileSeasonsView(data:seasons) } label: {
                    HStack { Text("シーズン別の記録").font(Theme.font(15,.medium));Spacer();Image(systemName:"chevron.right").font(Theme.font(11)).foregroundStyle(Theme.muted) }.frame(minHeight:54).contentShape(Rectangle())
                }.accessibilityIdentifier("profile-seasons")
            }
            Group {
                NavigationLink { MojinSelfView(playerId:p.playerId == model.me?.playerId ? nil : p.playerId) } label: {
                    HStack { Text("手記の加筆").font(Theme.font(15,.medium));Spacer();Text(p.playerId == model.me?.playerId ? "自分の探索情報" : "探索情報").font(Theme.font(11)).foregroundStyle(Theme.muted);Image(systemName:"chevron.right").font(Theme.font(11)).foregroundStyle(Theme.muted) }.frame(minHeight:54).contentShape(Rectangle())
                }.accessibilityIdentifier("own-mojin")
            }
            DocumentSection { VStack(spacing:2) {
                IDVSectionHeading(title:"状態")
                IDVValueRow(title:"現在",value:p.presence?.label ?? "未取得")
                IDVValueRow(title:"ログイン時刻",value:p.presence?.visibility == "hidden" ? "非表示" : DateText.string(p.presence?.lastLoginAt))
                IDVValueRow(title:"ログアウト時刻",value:p.presence?.visibility == "hidden" ? "非表示" : DateText.string(p.presence?.lastLogoutAt))
                IDVValueRow(title:"表示設定",value:StateLabels.visibility(p.presence?.visibility))
            } }
        }
    }
    private var history: some View {
        VStack(spacing:12) {
            IDVSectionHeading(title:"戦績",detail:"\(historyState.items.count)試合")
            if loadingHistory { ProgressView() }
            if !historyState.message.isEmpty { Text(historyState.message).font(Theme.font(12)).foregroundStyle(Theme.muted) }
            ForEach(historyState.items) { record in
                NavigationLink {
                    if case .object = record.record["mojin_record"] { MojinRecordDetailView(record:record.record["mojin_record"]) }
                    else { MatchDetailView(record:record) }
                } label: {
                    HStack(spacing:12) {
                        VStack(spacing:7) {
                            Text(record.resultLabel).font(Theme.font(13,.medium)).foregroundStyle(record.summary["result"].text == "win" ? Theme.positive : Theme.warning)
                            if let owner = record.selfPlayer { GameArt(key:owner["character_asset"].text,size:33,showsMissing:false) }
                        }.frame(width:46)
                        VStack(alignment:.leading,spacing:4) {
                            Text(record.mapLabel).font(Theme.font(14,.medium))
                            Text([record.modeLabel,record.selfPlayer?["character_name"].text].compactMap { $0 }.joined(separator:" · ")).font(Theme.font(11)).foregroundStyle(Theme.muted)
                            Text(record.endedAt?.formatted(date:.abbreviated,time:.shortened) ?? "日時未取得").font(Theme.font(11)).foregroundStyle(Theme.muted)
                        }
                        Spacer(minLength:0);Image(systemName:"chevron.right").font(Theme.font(12)).foregroundStyle(Theme.muted)
                    }.padding(.horizontal,15).padding(.vertical,12).frame(maxWidth:.infinity,minHeight:88,alignment:.leading).background(Theme.card,in:RoundedRectangle(cornerRadius:5)).overlay(alignment:.leading) { (record.summary["result"].text == "win" ? Theme.positive : Theme.warning).opacity(0.6).frame(width:2) }.contentShape(Rectangle())
                }.buttonStyle(.plain).accessibilityIdentifier("match-record-\(record.id)")
                Divider().overlay(Theme.line)
            }
            if historyState.nextCursor != nil { Button("続きを表示") { Task { await loadHistory(more:true) } }.buttonStyle(IDVActionStyle(primary:false)).disabled(loadingHistory) }
        }
    }
    private func load() async {
        let id = UUID(),target = playerId
        profileRequestId = id;loadingProfile = true;profileFailure = nil;profile = nil
        historyState = MatchHistoryState();historyMode = nil;requestId = UUID();loadingHistory = false
        defer { if profileRequestId == id { loadingProfile = false } }
        guard let client = model.client else { profileFailure = "PCのAPIとの接続を設定してください。";return }
        do {
            let loaded: Profile = try await client.data("/v1/players/\(target)")
            try Task.checkCancellation()
            guard profileRequestId == id,playerId == target,model.client === client else { return }
            guard loaded.playerId == target else { throw APIProblem(code:"PROFILE_RESPONSE_MISMATCH",message:"プロフィールの応答を確認できませんでした。再読み込みしてください。") }
            profile = loaded
            if remembersSearch { model.rememberSearch(loaded) }
        } catch {
            guard profileRequestId == id,playerId == target,!Task.isCancelled else { return }
            if let problem = error as? APIProblem { profileFailure = problem.message }
            else if let network = error as? URLError,network.code == .timedOut { profileFailure = "プロフィールの取得がタイムアウトしました。再読み込みしてください。" }
            else { profileFailure = "プロフィールを取得できませんでした。PCのAPIとの接続を確認して再読み込みしてください。" }
        }
    }
    private func loadHistory(more: Bool) async {
        guard let client = model.client,!(more && loadingHistory) else { return }
        let requestedMode = mode,id = UUID();requestId = id;loadingHistory = true
        if !more && historyMode != requestedMode { historyState = MatchHistoryState();historyMode = requestedMode }
        defer { if requestId == id { loadingHistory = false } }
        do {
            var query = [URLQueryItem(name:"limit",value:"30"),.init(name:"mode",value:requestedMode)]
            if more,let cursor = historyState.nextCursor { query.append(.init(name:"cursor",value:cursor)) }
            let page: Page<MatchRecord> = try await client.data("/v1/players/\(playerId)/history",query:query)
            try Task.checkCancellation();guard mode == requestedMode,requestId == id else { return }
            historyState.accept(page,more:more)
        } catch {
            guard !Task.isCancelled,mode == requestedMode,requestId == id else { return }
            let problem = error as? APIProblem;historyState.fail(code:problem?.code,message:problem?.message ?? "戦績を取得できませんでした")
        }
    }
}
