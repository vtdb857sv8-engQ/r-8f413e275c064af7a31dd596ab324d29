import SwiftUI

struct RootView: View {
    @EnvironmentObject var model: AppModel
    @State private var tab = 0
    @State private var settings = false
    private let tabs = [("ホーム","house"),("検索","magnifyingglass"),("チャット","bubble.left.and.bubble.right"),("通知","bell")]
    var body: some View {
        Group {
            if model.configured {
                VStack(spacing:0) {
                    HStack {
                        HStack(spacing:10) { Theme.accent.frame(width:3,height:18);Text("IDV").font(.system(size:20,weight:.medium,design:.serif)).tracking(3) }
                        Spacer()
                        HStack(spacing:6) { Circle().fill(model.status?.connected == true ? Theme.positive : Theme.muted).frame(width:5,height:5);Text(model.status?.connected == true ? "接続済み" : "未接続").font(Theme.font(10)) }.foregroundStyle(Theme.muted)
                        Button { settings = true } label: { Image(systemName:"gearshape").frame(width:44,height:44) }.accessibilityLabel("接続と設定")
                    }.padding(.leading,20).padding(.trailing,8).frame(height:53).overlay(alignment:.bottom) { Theme.line.opacity(0.6).frame(height:0.5) }
                    NavigationStack {
                        Group {
                            switch tab {
                            case 1: SearchView()
                            case 2: ChatView()
                            case 3: NotificationsView()
                            default: HomeView()
                            }
                        }.toolbar(.hidden,for:.navigationBar)
                    }.id(tab).frame(maxWidth:.infinity,maxHeight:.infinity)
                    tabBar
                }.sheet(isPresented:$settings) { NavigationStack { SettingsView() } }
            } else { NavigationStack { ConnectionView() } }
        }.background(Theme.background).foregroundStyle(Theme.text).buttonStyle(.plain)
    }
    private var tabBar: some View {
        HStack(spacing:0) {
            ForEach(tabs.indices,id:\.self) { i in
                Button { tab = i } label: {
                    VStack(spacing:6) {
                        Image(systemName:tabs[i].1).font(.system(size:18,weight:tab == i ? .medium : .regular))
                        Text(tabs[i].0).font(Theme.font(11))
                    }.foregroundStyle(tab == i ? Theme.accent : Theme.muted).frame(maxWidth:.infinity,minHeight:54)
                        .overlay(alignment:.top) { if tab == i { Theme.accent.frame(width:25,height:2).offset(y:-9) } }
                }.accessibilityAddTraits(tab == i ? .isSelected : [])
            }
        }.padding(.horizontal,10).padding(.top,9).fixedSize(horizontal:false,vertical:true)
        .background(Theme.card).overlay(alignment:.top) { Theme.line.frame(height:1) }
    }
}
struct ConnectionView: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var url = ""
    @State private var key = ""
    @State private var busy = false
    @State private var failure: String?
    var body: some View { IDVPage { IDVHeading(title:"接続"); VStack(alignment:.leading,spacing:10) { Text("APIのURL").font(Theme.font(12)).foregroundStyle(Theme.muted); TextField("http://PCのアドレス:8787",text:$url).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled().padding(13).background(Theme.card,in:RoundedRectangle(cornerRadius:7)); Text("API認証キー").font(Theme.font(12)).foregroundStyle(Theme.muted).padding(.top,9); SecureField("認証キー",text:$key).textInputAutocapitalization(.never).autocorrectionDisabled().padding(13).background(Theme.card,in:RoundedRectangle(cornerRadius:7)) }; if let failure { Text(failure).font(Theme.font(12)).foregroundStyle(Theme.danger) }; Button { busy = true; Task { defer { busy = false }; do { try await model.configure(url:url,key:key); dismiss() } catch { failure = error.localizedDescription } } } label: { HStack { if busy { ProgressView().tint(Theme.background) }; Text("接続する") } }.buttonStyle(IDVActionStyle()).disabled(busy || key.isEmpty || url.isEmpty) }.onAppear { url = model.serverURL }.navigationBarTitleDisplayMode(.inline) }
}
struct IdentityView: View {
    let profile: Profile
    var copyName = false
    @State private var copied = false
    var body: some View {
        HStack(spacing:22) {
            GameAvatar(profile:profile,size:72)
            VStack(alignment:.leading,spacing:6) {
                Text("IDENTITY V").font(Theme.font(9,.medium)).tracking(2).foregroundStyle(Theme.accent)
                HStack(spacing:5) {
                Text(profile.displayName).font(.system(size:24,weight:.medium,design:.serif)).lineLimit(2).minimumScaleFactor(0.8).textSelection(.enabled)
                    if copyName,let name = profile.name,!name.isEmpty {
                        Button { UIPasteboard.general.string = name;copied = true } label: { Image(systemName:copied ? "checkmark" : "doc.on.doc").font(Theme.font(13)).frame(width:36,height:44) }.accessibilityLabel("名前をコピー").accessibilityValue(copied ? "コピー済み" : "").accessibilityIdentifier("copy-player-name")
                    }
                }
                Text("ID  \(profile.playerId)").font(Theme.font(11)).monospacedDigit().foregroundStyle(Theme.muted).textSelection(.enabled)
                StateBadge(presence:profile.presence)
            }
            Spacer(minLength:0)
        }.padding(.horizontal,22).padding(.vertical,24).frame(maxWidth:.infinity,alignment:.leading)
            .background(Theme.card,in:RoundedRectangle(cornerRadius:5))
            .overlay(alignment:.topLeading) { Theme.accent.frame(width:36,height:2).padding(.leading,22) }
    }
}
struct HomeView: View {
    @EnvironmentObject var model: AppModel
    var body: some View { IDVPage {
        if let me = model.me { NavigationLink { ProfileView(playerId:me.playerId) } label: { HStack { IdentityView(profile:me); Image(systemName:"chevron.right").font(Theme.font(12)).foregroundStyle(Theme.muted) } }.accessibilityIdentifier("home-profile"); RankGrid(profile:me); CurrentBadges(profile:me) }
        else if model.status?.connected == true { ProgressView("プロフィールを取得中") }
        if model.status?.connected != true { Button("ゲームサーバーに接続") { Task { await model.connect() } }.buttonStyle(IDVActionStyle()) }
        if let message = model.status?.loginFailureMessage { LoginFailureNote(message:message) }
        VStack(spacing:12) { IDVSectionHeading(title:"フレンド",detail:"\(model.friends.filter { !["offline","unknown"].contains($0.presence?.state ?? "unknown") }.count) / \(model.friends.count) オンライン"); ForEach(model.friends) { p in HStack(spacing:8) { NavigationLink { ProfileView(playerId:p.playerId) } label: { PlayerRow(player:p) }; NavigationLink { FriendChatView(friend:p) } label: { Image(systemName:"bubble.left").font(Theme.font(17)).frame(width:44,height:44) }.accessibilityLabel("\(p.displayName)とチャット") }; if p.id != model.friends.last?.id { Divider().overlay(Theme.line).padding(.leading,54) } }; if model.friends.isEmpty { Text("フレンドは未取得です").font(Theme.font(12)).foregroundStyle(Theme.muted).frame(maxWidth:.infinity).padding(.vertical,20) } }
    }.refreshable { await model.refresh() } }
}
struct ParticipantView: View {
    @EnvironmentObject var model: AppModel
    let participant: JSONValue
    @State private var results: [Profile] = []
    @State private var loading = true
    var body: some View { Group { if let id = participant["player_id"].text { ProfileView(playerId:id) } else if results.count == 1, let p = results.first { ProfileView(playerId:p.playerId) } else { IDVPage { IDVHeading(title:participant["name"].text ?? "プレイヤー"); if loading { ProgressView() } else if results.isEmpty { Text("プロフィールを特定できませんでした").font(Theme.font(12)).foregroundStyle(Theme.muted) }; ForEach(results) { p in NavigationLink { ProfileView(playerId:p.playerId) } label: { PlayerRow(player:p) } } } } }.task { guard participant["player_id"].text == nil, let name = participant["name"].text, let client = model.client else { loading = false; return }; defer { loading = false }; do { results = try await client.data("/v1/players",query:[.init(name:"query",value:name)]) } catch { model.show(error) } } }
}
struct NotificationsView: View {
    @EnvironmentObject var model: AppModel
    @State private var history = false
    var body: some View { IDVPage { HStack { IDVHeading(title:"通知"); Spacer(); NavigationLink { NotificationSettingsView() } label: { Image(systemName:"slider.horizontal.3").frame(width:44,height:44) }.accessibilityLabel("通知条件") }; Picker("表示",selection:$history) { Text("プレイヤー").tag(false); Text("履歴").tag(true) }.pickerStyle(.segmented); if history { ForEach(model.events.filter { event in model.watches.contains { $0.playerId == event.playerId && $0.notify == 1 } }) { event in NavigationLink { ProfileView(playerId:event.playerId) } label: { VStack(alignment:.leading,spacing:6) { Text(model.watches.first { $0.playerId == event.playerId }?.profile?.displayName ?? event.playerId).font(Theme.font(14,.medium)); Text(event.changeText).font(Theme.font(12)).foregroundStyle(Theme.muted); Text(DateText.string(event.observedAt)).font(Theme.font(11)).foregroundStyle(Theme.muted) }.frame(maxWidth:.infinity,alignment:.leading).padding(.vertical,10) }; Divider().overlay(Theme.line) } } else { ForEach(model.watches.filter { $0.notify == 1 }) { watch in VStack(spacing:12) { HStack { NavigationLink { ProfileView(playerId:watch.playerId) } label: { VStack(alignment:.leading,spacing:5) { if let p = watch.profile { HStack(spacing:12) { GameAvatar(profile:p); VStack(alignment:.leading,spacing:5) { Text(p.displayName).font(Theme.font(14,.medium)); StateBadge(presence:watch.presence) } } } else { Text(watch.playerId).font(Theme.font(14)) } } }; Spacer(); Button { Task { await model.setWatch(watch.playerId,enabled:false) } } label: { Image(systemName:"bell.badge").frame(width:44,height:44) }.accessibilityLabel("通知を解除") }; HStack { time("ログイン時刻",value:watch.presence?.lastLoginAt,hidden:watch.presence?.visibility == "hidden"); time("ログアウト時刻",value:watch.presence?.lastLogoutAt,hidden:watch.presence?.visibility == "hidden") }; HStack { Text("表示設定 : \(StateLabels.visibility(watch.presence?.visibility))"); Spacer(); Text(watch.fresh == true ? "更新済み" : "最終取得") }.font(Theme.font(11)).foregroundStyle(Theme.muted) }.padding(.vertical,12); Divider().overlay(Theme.line) }; if model.watches.filter({ $0.notify == 1 }).isEmpty { Text("通知するプレイヤーがいません").font(Theme.font(13)).foregroundStyle(Theme.muted).padding(.vertical,25) } } }.refreshable { await model.refresh() } }
    private func time(_ label: String,value: String?,hidden: Bool) -> some View { VStack(alignment:.leading,spacing:4) { Text(label).font(Theme.font(11)).foregroundStyle(Theme.muted); Text(hidden ? "非表示" : DateText.string(value)).font(Theme.font(12)).lineLimit(2) }.frame(maxWidth:.infinity,alignment:.leading) }
}
struct NotificationSettingsView: View {
    @EnvironmentObject var model: AppModel
    private let rules = [("login","ログイン"),("logout","ログアウト"),("match_start","対戦開始"),("match_end","対戦終了"),("visibility","表示・非表示"),("team","チーム参加・退出"),("matching","マッチング"),("spectating","観戦"),("busy","取り込み中"),("other_state","その他の公開状態")]
    var body: some View { IDVPage { ForEach(rules,id:\.0) { key,label in Toggle(label,isOn:Binding(get:{model.notificationRules[key] ?? false},set:{ value in Task { await model.setRule(key,enabled:value) } })).font(Theme.font(14)).tint(Theme.positive).padding(.vertical,7) }; Button("iPhoneの通知を許可") { Task { await model.requestPush() } }.buttonStyle(IDVActionStyle(primary:false)); if let message = model.pushMessage { Text(message).font(Theme.font(12)).foregroundStyle(Theme.muted) } }.navigationTitle("通知条件").navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar) }
}
struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    var body: some View { IDVPage { IDVValueRow(title:"API",value:model.serverURL); IDVValueRow(title:"ゲーム接続",value:model.status?.connected == true ? "接続中" : "未接続"); if let message = model.status?.loginFailureMessage { LoginFailureNote(message:message) }; IDVValueRow(title:"プッシュ設定",value:model.status?.pushConfigured == true ? "設定済み" : "未設定"); Button("更新") { Task { await model.refresh() } }.buttonStyle(IDVActionStyle(primary:false)); if model.status?.connected != true { Button("接続する") { Task { await model.connect() } }.buttonStyle(IDVActionStyle()); Button("PCゲームからAPIへ切り替える") { Task { await model.connect(replace:true) } }.buttonStyle(IDVActionStyle(primary:false)) }; NavigationLink("ゲームの接続コードを入力") { GameSessionImportView() }.font(Theme.font(14)).accessibilityIdentifier("session-code-settings"); NavigationLink("通知条件") { NotificationSettingsView() }.font(Theme.font(14)); NavigationLink("接続先を変更") { ConnectionView() }.font(Theme.font(14)); Button("接続設定を削除",role:.destructive) { model.forgetConnection(); dismiss() }.font(Theme.font(13)) }.navigationTitle("設定").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement:.confirmationAction) { Button("閉じる") { dismiss() } } } }
}
private struct LoginFailureNote: View {
    let message: String
    var body: some View { Text(message).font(Theme.font(12)).foregroundStyle(Theme.muted).frame(maxWidth:.infinity,alignment:.leading).padding(.vertical,8).accessibilityIdentifier("login-failure-note") }
}
