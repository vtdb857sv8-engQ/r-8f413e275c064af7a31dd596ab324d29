import SwiftUI

struct PersonaView: View {
    @EnvironmentObject var model: AppModel
    let playerId: String
    var playerName: String? = nil
    var initialCharacterId: Int? = nil
    var camp = "survivor"
    @State private var characters: [GameCharacter] = []
    @State private var characterId: Int?
    @State private var choosingCharacter = false
    @State private var data: JSONValue?
    @State private var failure: String?
    @State private var busy = false
    private var choices: [GameCharacter] { characters.filter { $0.camp == camp && $0.name != nil }.sorted { $0.id < $1.id } }
    private var selected: GameCharacter? { choices.first { $0.id == (characterId ?? initialCharacterId) } ?? choices.first }
    var body: some View {
        IDVPage {
            VStack(alignment:.leading,spacing:7) {
                IDVHeading(title:"人格構成")
                Text(playerName ?? "ID \(playerId)").font(Theme.font(13)).foregroundStyle(Theme.muted)
            }
            Button { choosingCharacter = true } label: {
                HStack(spacing:12) { GameArt(key:selected?.asset,size:44);Text(selected?.name ?? "キャラクターを選択").font(Theme.font(15,.medium));Spacer();Image(systemName:"chevron.down").font(.caption) }.frame(minHeight:54).contentShape(Rectangle())
            }.accessibilityIdentifier("persona-character")
            Text("選択したキャラクターに現在設定されている構成").font(Theme.font(11)).foregroundStyle(Theme.muted)
            if busy { ProgressView("人格を取得中") }
            if let failure { IDVNotice(symbol:"eye.slash",text:failure).accessibilityIdentifier("persona-access-message") }
            if let data {
                if data["status"].text == "received" {
                    HStack {
                        Text(camp == "hunter" ? "ハンター" : "サバイバー").font(Theme.font(12)).foregroundStyle(Theme.muted)
                        Spacer()
                        if let points = data["used_points"].text { Text("消費人格点 \(points)").font(Theme.font(15,.medium)).monospacedDigit() }
                    }
                    DocumentSection {
                        if data["items"].array.isEmpty { Text((data["unmapped_count"].number ?? 0) > 0 ? "構成の内容を確認できません" : "受信した構成に獲得済みの人格はありません").font(Theme.font(12)).foregroundStyle(Theme.muted) }
                        ForEach(Array(data["items"].array.enumerated()),id:\.offset) { _,item in
                            HStack(spacing:12) {
                                GameArt(key:item["asset"].text,size:36,showsMissing:false)
                                VStack(alignment:.leading,spacing:5) {
                                    Text(item["name"].text ?? "名称未取得").font(Theme.font(14,.medium))
                                    if let note = item["description"].text { Text(note).font(Theme.font(11)).foregroundStyle(Theme.muted).fixedSize(horizontal:false,vertical:true) }
                                }
                                Spacer(minLength:4)
                                Text("Lv.\(item["level"].text ?? "—")").font(Theme.font(12)).monospacedDigit().foregroundStyle(Theme.accent)
                            }.padding(.vertical,5).accessibilityElement(children:.combine).accessibilityIdentifier("persona-node-\(item["id"].text ?? "")")
                        }
                    }
                    if let count = data["unmapped_count"].number,count > 0 { Text("名称や内容を確認できない人格が\(Int(count))件あります").font(Theme.font(11)).foregroundStyle(Theme.muted) }
                } else { IDVNotice(symbol:"doc",text:"このページの人格構成は未取得です") }
            }
            Button("再読み込み") { Task { await load() } }.buttonStyle(IDVActionStyle(primary:false)).disabled(busy || selected == nil)
        }.navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
            .task { await loadCatalog() }.task(id:"\(playerId)|\(selected?.id ?? 0)") { await load() }
            .sheet(isPresented:$choosingCharacter) { CharacterRankingPicker(characters:choices,selectedId:selected?.id) { value in characterId = value.id;choosingCharacter = false }.environmentObject(model) }
    }
    private func loadCatalog() async {
        guard let client = model.client else { return }
        do { let value: GameCatalog = try await client.data("/v1/catalog");try Task.checkCancellation();characters = Array(value.characters.values) }
        catch { if !Task.isCancelled { failure = error.localizedDescription } }
    }
    private func load() async {
        data = nil;failure = nil
        guard let client = model.client,let selected else { return }
        let id = selected.id;busy = true
        defer { if self.selected?.id == id { busy = false } }
        do {
            let fetched: JSONValue = try await client.data("/v1/players/\(playerId)/persona",query:[.init(name:"character_id",value:String(id))])
            try Task.checkCancellation();guard self.selected?.id == id,model.client === client else { return }
            guard fetched["player_id"].text == playerId,fetched["character_id"].number == Double(id),["self","permitted","hidden"].contains(fetched["access"].text ?? "") else { failure = "人格の閲覧範囲を確認できません";return }
            data = fetched
        } catch { if !Task.isCancelled,self.selected?.id == id { data = nil;failure = error.localizedDescription } }
    }
}
