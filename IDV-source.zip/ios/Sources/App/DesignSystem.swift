import SwiftUI
import UIKit
enum Theme {
    static let background = Color(hex: 0x121416), card = Color(hex: 0x1a1e21), line = Color(hex: 0x373d40)
    static let text = Color(hex: 0xeee9df), muted = Color(hex: 0xaaa9a3), accent = Color(hex: 0xc7b99d)
    static let parchment = Color(hex: 0xd8cfb8)
    static let positive = Color(hex: 0x9db6a1), warning = Color(hex: 0xc2aa83), danger = Color(hex: 0xd6aaa3)
    static let raised = Color(hex: 0x242a2e), sidebar = background
    static func font(_ size: CGFloat, _ weight: Font.Weight = .regular, relativeTo style: Font.TextStyle = .body) -> Font { .system(size: size, weight: weight) }
}
private extension Color { init(hex: UInt32) { self.init(red: Double((hex >> 16) & 255) / 255, green: Double((hex >> 8) & 255) / 255, blue: Double(hex & 255) / 255) } }
struct IDVPage<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View { ScrollView { VStack(alignment: .leading, spacing: 22) { content }.padding(.horizontal, 20).padding(.vertical, 22).frame(maxWidth: 680).frame(maxWidth: .infinity) }.background(Theme.background).foregroundStyle(Theme.text) }
}
struct IDVPanel<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View { VStack(alignment: .leading, spacing: 16) { content }.frame(maxWidth: .infinity, alignment: .leading) }
}
struct IDVHeading: View { let title: String; var body: some View { VStack(alignment:.leading,spacing:10) { Theme.accent.frame(width:28,height:2);Text(title).font(.system(size:27,weight:.medium,design:.serif)).tracking(1) }.accessibilityAddTraits(.isHeader) } }
struct IDVSectionHeading: View {
    let title: String; var detail: String? = nil
    var body: some View { HStack(spacing:10) { Text(title).font(Theme.font(15, .semibold)); Spacer(); if let detail { Text(detail).font(Theme.font(11)).foregroundStyle(Theme.muted).monospacedDigit() } }.padding(.bottom,5).accessibilityAddTraits(.isHeader) }
}
struct DocumentSection<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View { VStack(alignment:.leading,spacing:15) { content }.padding(18).frame(maxWidth:.infinity,alignment:.leading).background(Theme.card,in:RoundedRectangle(cornerRadius:5)).overlay(alignment:.top) { Theme.line.frame(height:1).padding(.horizontal,5) } }
}
struct DocumentTabs: View {
    @Binding var selection: String
    let titles: [String]
    var body: some View {
        HStack(spacing:0) {
            ForEach(titles,id:\.self) { title in
                Button { selection = title } label: {
                    Text(title).font(Theme.font(14,selection == title ? .semibold : .regular)).foregroundStyle(selection == title ? Theme.text : Theme.muted)
                        .frame(maxWidth:.infinity,minHeight:48).background(selection == title ? Theme.raised : Color.clear).contentShape(Rectangle())
                        .overlay(alignment:.bottom) { if selection == title { Theme.accent.frame(height:2).padding(.horizontal,20) } }
                }.accessibilityAddTraits(selection == title ? .isSelected : [])
            }
        }.overlay(alignment:.bottom) { Theme.line.frame(height:0.5) }
    }
}
struct IDVActionStyle: ButtonStyle {
    var primary = true
    func makeBody(configuration: Configuration) -> some View { configuration.label.font(Theme.font(13, .medium)).frame(maxWidth: .infinity, minHeight: 44).foregroundStyle(primary ? Theme.background : Theme.text).background(primary ? Theme.text : Theme.card, in: RoundedRectangle(cornerRadius: 7)).overlay { RoundedRectangle(cornerRadius: 7).stroke(primary ? Color.clear : Theme.line, lineWidth: 1) }.opacity(configuration.isPressed ? 0.7 : 1) }
}
struct IDVValueRow: View {
    let title: String; let value: String
    var body: some View { HStack(alignment: .firstTextBaseline, spacing: 12) { Text(title).font(Theme.font(12)).foregroundStyle(Theme.muted); Spacer(minLength: 4); Text(value).font(Theme.font(14,.medium)).multilineTextAlignment(.trailing).monospacedDigit() }.padding(.vertical, 10).overlay(alignment:.bottom) { Theme.line.opacity(0.35).frame(height:0.5) } }
}
struct IDVNotice: View { let symbol: String; let text: String; var body: some View { Label(text, systemImage: symbol).font(Theme.font(12)).foregroundStyle(Theme.muted).fixedSize(horizontal: false, vertical: true) } }
struct EmptyPanel: View { let symbol: String; let title: String; let detail: String; var body: some View { VStack(spacing: 10) { Text(title).font(Theme.font(15, .medium)); if !detail.isEmpty { Text(detail).font(Theme.font(12)).foregroundStyle(Theme.muted).multilineTextAlignment(.center) } }.frame(maxWidth: .infinity).padding(.vertical, 24) } }
struct StateBadge: View {
    let presence: Presence?
    private var color: Color { presence?.visibility == "hidden" || ["offline","unknown"].contains(presence?.state ?? "unknown") ? Theme.muted : ["in_match","matching"].contains(presence?.state ?? "") ? Theme.warning : Theme.positive }
    var body: some View { HStack(spacing: 6) { if presence?.visibility == "hidden" { Image(systemName: "eye.slash").font(.system(size: 10)) } else { Circle().fill(color).frame(width: 5, height: 5) }; Text(presence?.label ?? "未取得").font(Theme.font(11)) }.foregroundStyle(color).padding(.horizontal,8).padding(.vertical,5).background(color.opacity(0.08),in:RoundedRectangle(cornerRadius:4)) }
}
struct GameArt: View {
    @EnvironmentObject var model: AppModel
    let key: String?; var size: CGFloat = 40; var showsMissing = true
    var width: CGFloat? = nil; var height: CGFloat? = nil
    @State private var image: UIImage?
    private static let cache = NSCache<NSString, UIImage>()
    var body: some View { Group { if let image { Image(uiImage: image).resizable().scaledToFit() } else if showsMissing { Text("未取得").font(Theme.font(10)).foregroundStyle(Theme.muted) } else { Color.clear } }.frame(width: width ?? size, height: height ?? size).task(id: "\(model.serverURL)/\(key ?? "")") { image = nil; guard let key, let client = model.client else { return }; let id = "\(model.serverURL)/\(key)" as NSString; if let saved = Self.cache.object(forKey: id) { image = saved; return }; if let data = try? await client.image(key), let decoded = UIImage(data: data) { Self.cache.setObject(decoded, forKey: id); image = decoded } }.accessibilityHidden(true) }
}
struct MatchMapPreview: View {
    let key: String
    var body: some View { GameArt(key:key,showsMissing:false,width:160,height:88).frame(maxWidth:.infinity).accessibilityElement(children:.ignore).accessibilityHidden(false).accessibilityLabel("マップ画像").accessibilityIdentifier("match-map-preview") }
}
struct ScoreArtwork: View {
    let key: String?
    var body: some View { GameArt(key:key,size:25,showsMissing:false).frame(width:34,height:34).background(Theme.parchment,in:RoundedRectangle(cornerRadius:5)).overlay { RoundedRectangle(cornerRadius:5).stroke(Theme.accent.opacity(0.65),lineWidth:0.5) } }
}
struct GameAvatar: View {
    let profile: Profile; var size: CGFloat = 44
    var body: some View { AvatarArtwork(portrait:profile.portraitAsset,frame:profile.frameAsset,size:size) }
}
struct AvatarArtwork: View {
    @EnvironmentObject var model: AppModel
    let portrait: String?
    let frame: String?
    var size: CGFloat = 44
    var body: some View {
        ZStack {
            if let mask = frame.flatMap({ model.avatarMasks[$0] }) {
                GameArt(key:portrait,size:size * 0.88).mask { GameArt(key:mask,size:size * 1.5,showsMissing:false) }
            } else { GameArt(key:portrait,size:frame == nil ? size : size * 0.88).clipped() }
            GameArt(key:frame,size:size * 1.5,showsMissing:false)
        }.frame(width:size,height:size)
    }
}
struct RankGrid: View {
    let profile: Profile
    var body: some View { HStack(alignment: .top, spacing: 20) { column("現シーズン", key: "current"); column("最高段位", key: "highest") }.padding(.vertical, 4).padding(.bottom, 10).overlay(alignment: .bottom) { Theme.line.frame(height: 1) } }
    private func column(_ title: String, key: String) -> some View { VStack(alignment: .leading, spacing: 15) { Text(title).font(Theme.font(12)).foregroundStyle(Theme.muted); rank("サバイバー", camp: "survivor", key: key); rank("ハンター", camp: "hunter", key: key) }.frame(maxWidth: .infinity, alignment: .leading) }
    private func rank(_ title: String, camp: String, key: String) -> some View { let value = profile.canShowStatistics ? profile.ranks?[camp][key] ?? .null : .null; let label = (value["part"].number ?? 0) >= 7 ? value["stars"].text.map { "★ \($0)" } ?? "星数未取得" : value["label"].text ?? "未取得"; return HStack(spacing: 8) { GameArt(key: value["asset"].text, size: 38); VStack(alignment: .leading, spacing: 4) { Text(title).font(Theme.font(10)).foregroundStyle(Theme.muted); Text(label).font(Theme.font(20, .medium)).lineLimit(1).minimumScaleFactor(0.75); Text(value["season_id"].text.map { "S\($0)" } ?? "シーズン未取得").font(Theme.font(10)).foregroundStyle(Theme.muted) } }.frame(maxWidth: .infinity, alignment: .leading) }
}
struct CurrentBadges: View {
    let profile: Profile
    private var rows: [JSONValue] { ["self","permitted"].contains(profile.fieldAccess?["profile_tags"] ?? "unknown") ? profile.profileTags?["character_badges"].array ?? [] : [] }
    private var received: Bool { if case .array = profile.profileTags?["character_badges"] ?? .null { return true }; return false }
    var body: some View { VStack(alignment: .leading, spacing: 12) { IDVSectionHeading(title: "現在の徽章"); if rows.isEmpty { Text(profile.fieldAccess?["profile_tags"] == "hidden" ? "非公開" : received ? "表示できる徽章がありません" : "未取得").font(Theme.font(12)).foregroundStyle(Theme.muted) } else { ForEach(Array(rows.enumerated()), id: \.offset) { _, item in HStack { GameArt(key: item["asset"].text, size: 38); VStack(alignment:.leading,spacing:4) { Text(item["label"].text ?? "徽章").font(Theme.font(13)); if let expiry = item["expires_at"].text { Text("有効期限 \(DateText.string(expiry))").font(Theme.font(10)).foregroundStyle(Theme.muted) } }; Spacer() } } } }.padding(.bottom, 15).overlay(alignment: .bottom) { Theme.line.frame(height: 1) } }
}
struct PlayerRow: View {
    let player: Profile
    var body: some View { HStack(spacing: 12) { GameAvatar(profile: player); VStack(alignment: .leading, spacing: 5) { Text(player.displayName).font(Theme.font(14, .medium)).lineLimit(1); StateBadge(presence: player.presence) }; Spacer(minLength: 4) }.foregroundStyle(Theme.text).frame(minHeight: 64).contentShape(Rectangle()) }
}
