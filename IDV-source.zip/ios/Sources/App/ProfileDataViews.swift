import SwiftUI

struct ProfileStatisticsView: View {
    let profile: Profile
    @State private var period = "cumulative"
    var body: some View {
        VStack(alignment:.leading,spacing:14) {
            IDVSectionHeading(title:"プロフィールの記録")
            if let likes = profile.likes { IDVValueRow(title:"いいね",value:String(likes)) }
            if profile.canShowStatistics {
                if let count = profile.battleCount { IDVValueRow(title:"総対戦数",value:String(count)) }
                if let mvp = profile.mvp { IDVValueRow(title:"MVP回数",value:String(mvp)) }
                if let count = profile.characterCount { IDVValueRow(title:"所持キャラクター",value:String(count)) }
                Picker("陣営別記録の期間",selection:$period) {
                    Text("累計").tag("cumulative");Text("現シーズン").tag("current")
                }.pickerStyle(.segmented).accessibilityIdentifier("profile-statistics-period")
                if period == "current" {
                    currentCamp(title:"サバイバー",key:"survivor")
                    currentCamp(title:"ハンター",key:"hunter")
                    Text("累計と保存された過去シーズンの記録から算出します。必要な記録が欠ける項目は未取得と表示します。")
                        .font(Theme.font(11)).foregroundStyle(Theme.muted)
                } else {
                    camp(title:"サバイバー",data:profile.civilianData)
                    camp(title:"ハンター",data:profile.butcherData)
                }
            } else {
                Text(profile.fieldAccess?["statistics"] == "hidden" ? "対戦データは非公開です" : "対戦データの公開範囲を確認できません")
                    .font(Theme.font(12)).foregroundStyle(Theme.muted)
            }
        }
    }
    @ViewBuilder private func currentCamp(title: String,key: String) -> some View {
        let data = profile.currentSeasonStatistics?[key] ?? .null
        IDVSectionHeading(title:title).padding(.top,6)
        if let season = data["season_id"].text {
            Text("S\(season)").font(Theme.font(12)).foregroundStyle(Theme.muted)
            ForEach(Array(data["statistics"].array.enumerated()),id:\.offset) { _,row in
                ForEach([("対戦数","total"),("勝利数","wins"),("敗北数","losses")],id:\.1) { label,field in
                    IDVValueRow(title:"\(row["label"].text ?? "")の\(label)",value:row[field].text ?? "未取得")
                        .accessibilityElement(children:.combine).accessibilityLabel("\(row["label"].text ?? "")の\(label)")
                        .accessibilityValue(row[field].text ?? "未取得").accessibilityIdentifier("current-season-\(key)-\(row["mode"].text ?? "")-\(field)")
                }
                if row["consistent"].flag == false { Text("受信した件数の整合性を確認できません").font(Theme.font(11)).foregroundStyle(Theme.muted) }
            }
        } else { Text("この陣営の現シーズン記録は未取得です").font(Theme.font(12)).foregroundStyle(Theme.muted) }
    }
    @ViewBuilder private func camp(title: String,data: JSONValue?) -> some View {
        if let data, case .object = data {
            IDVSectionHeading(title:title).padding(.top,6)
            ForEach([("通常戦の対戦数","normal_battle_cnt"),("通常戦の勝利数","normal_battle_win_cnt"),("通常戦の敗北数","normal_battle_lose_cnt"),("ランク戦の対戦数","rank_battle_cnt"),("ランク戦の勝利数","rank_battle_win_cnt"),("ランク戦の敗北数","rank_battle_lose_cnt")],id:\.1) { title,key in
                if let value = data[key].text { IDVValueRow(title:title,value:value) }
            }
        }
    }
}

struct MatchOutcomeHeader: View {
    let record: MatchRecord
    var body: some View {
        HStack(alignment:.center,spacing:16) {
            VStack(alignment:.leading,spacing:8) {
                Text(record.resultLabel).font(.system(size:30,weight:.medium,design:.serif)).foregroundStyle(record.summary["result"].text == "win" ? Theme.positive : Theme.warning)
                Text(record.mapLabel).font(Theme.font(15,.medium))
                Text(record.modeLabel).font(Theme.font(11)).foregroundStyle(Theme.muted)
            }.frame(maxWidth:.infinity,alignment:.leading)
            if let key = record.summary["map_asset"].text { GameArt(key:key,showsMissing:false,width:132,height:80).accessibilityElement(children:.ignore).accessibilityHidden(false).accessibilityLabel("マップ画像").accessibilityIdentifier("match-map-preview") }
        }.padding(.vertical,8)
    }
}
struct MatchDetailView: View {
    let record: MatchRecord
    var body: some View {
        IDVPage {
            IDVHeading(title:"戦績の詳細")
            MatchOutcomeHeader(record:record)
            DocumentSection { VStack(spacing:0) {
                IDVValueRow(title:"マップ",value:record.mapLabel)
                IDVValueRow(title:"モード",value:record.modeLabel)
                IDVValueRow(title:"結果",value:record.resultLabel)
                if let started = record.startedAt { IDVValueRow(title:"開始日時",value:started.formatted(date:.abbreviated,time:.shortened)) }
                if let ended = record.endedAt { IDVValueRow(title:"終了日時",value:ended.formatted(date:.abbreviated,time:.shortened)) }
                IDVValueRow(title:"対戦時間",value:record.duration.map { "\($0 / 60)分\($0 % 60)秒" } ?? "未取得")
                if let owner = record.selfPlayer {
                    if let name = owner["character_name"].text { IDVValueRow(title:"本人の使用キャラ",value:name) }
                    if let score = owner["score"].text { IDVValueRow(title:"本人の得点",value:score) }
                    if let camp = owner["camp"].text { IDVValueRow(title:"本人の陣営",value:camp == "hunter" ? "ハンター" : "サバイバー") }
                    MatchPersonalResult(result:owner["participant_result"],title:"本人の個別結果",identifier:"owner")
                }
            } }
            if let owner = record.selfPlayer,!owner["score_breakdown"].array.isEmpty {
                DocumentSection {
                    IDVSectionHeading(title:"本人の得点内訳")
                    MatchScoreRows(rows:owner["score_breakdown"].array)
                }.accessibilityIdentifier("self-score-breakdown")
            }
            if let owner = record.selfPlayer,case .object = owner["action_details"] {
                NavigationLink { MatchActionsView(details:owner["action_details"],playerName:owner["name"].text) } label: {
                    HStack { Text("行動記録");Spacer();Image(systemName:"chevron.right") }.font(Theme.font(13)).frame(minHeight:44).contentShape(Rectangle())
                }.accessibilityIdentifier("own-match-actions")
            }
            if let owner = record.selfPlayer,case .object = owner["rank_change"] {
                NavigationLink { RankChangeView(change:owner["rank_change"],playerName:owner["name"].text) } label: {
                    HStack { Text("段位の変化");Spacer();Image(systemName:"chevron.right") }.font(Theme.font(13)).frame(minHeight:44).contentShape(Rectangle())
                }.accessibilityIdentifier("own-rank-change")
            }
            IDVSectionHeading(title:"参加プレイヤー",detail:"\(record.summary["players"].array.count)人")
            ForEach(Array(record.summary["players"].array.enumerated()),id:\.offset) { _, player in
                NavigationLink { ParticipantView(participant:player) } label: { MatchParticipantRow(player:player) }
                    .accessibilityIdentifier("match-participant-\(player["player_id"].text ?? "unknown")")
                if player["is_self"].flag != true,!player["score_breakdown"].array.isEmpty {
                    DisclosureGroup("得点内訳") { MatchScoreRows(rows:player["score_breakdown"].array).padding(.top,8) }
                        .font(Theme.font(12)).tint(Theme.muted).accessibilityIdentifier("match-score-\(player["player_id"].text ?? "unknown")")
                }
                if player["is_self"].flag != true,case .object = player["action_details"] {
                    NavigationLink { MatchActionsView(details:player["action_details"],playerName:player["name"].text) } label: {
                        HStack { Text("行動記録");Spacer();Image(systemName:"chevron.right") }.font(Theme.font(12)).frame(minHeight:44).contentShape(Rectangle())
                    }.accessibilityIdentifier("match-actions-\(player["player_id"].text ?? "unknown")")
                }
                if player["is_self"].flag != true,case .object = player["rank_change"] {
                    NavigationLink { RankChangeView(change:player["rank_change"],playerName:player["name"].text) } label: {
                        HStack { Text("段位の変化");Spacer();Image(systemName:"chevron.right") }.font(Theme.font(12)).frame(minHeight:44).contentShape(Rectangle())
                    }.accessibilityIdentifier("rank-change-\(player["player_id"].text ?? "unknown")")
                }
                Divider().overlay(Theme.line)
            }
        }.navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
    }
}
private struct MatchPersonalResult: View {
    let result: JSONValue
    let title: String
    let identifier: String
    private var value: String {
        if result["status"].text == "received" { return result["label"].text ?? "未取得" }
        return result["status"].text == "unverified" ? "未確認" : "未取得"
    }
    var body: some View {
        if case .object = result {
            IDVValueRow(title:title,value:value)
                .accessibilityElement(children:.combine).accessibilityLabel(title).accessibilityValue(value)
                .accessibilityIdentifier("personal-result-\(identifier)")
        }
    }
}
private struct MatchScoreRows: View {
    let rows: [JSONValue]
    var body: some View {
        VStack(spacing:4) {
            ForEach(Array(rows.enumerated()),id:\.offset) { _,row in
                HStack(spacing:10) {
                    ScoreArtwork(key:row["asset"].text)
                    Text(row["label"].text ?? "").foregroundStyle(Theme.muted)
                    Spacer()
                    Text(row["value"].text ?? "未取得").monospacedDigit()
                }.font(Theme.font(13)).padding(.vertical,5)
            }
        }
    }
}
private struct MatchParticipantRow: View {
    let player: JSONValue
    var body: some View {
        HStack(alignment:.top,spacing:12) {
            VStack(spacing:8) {
                AvatarArtwork(portrait:player["portrait"].text,frame:player["frame"].text,size:46)
                GameArt(key:player["character_asset"].text,size:30)
            }
            VStack(alignment:.leading,spacing:7) {
                HStack(spacing:6) {
                    Text(player["name"].text ?? "名前未取得").font(Theme.font(14,.medium))
                    if player["is_self"].flag == true { tag("本人") }
                    if player["mvp"].flag == true { tag("MVP") }
                    if player["is_bot"].flag == true { tag("BOT") }
                }
                Text(player["character_name"].text ?? player["character_id"].text.map { "キャラ \($0)" } ?? "キャラ未取得").font(Theme.font(12)).foregroundStyle(Theme.muted)
                MatchPersonalResult(result:player["participant_result"],title:"個別結果",identifier:"participant-\(player["player_id"].text ?? "unknown")")
                if let rank = player["match_rank"]["label"].text {
                    HStack(spacing:5) {
                        GameArt(key:player["match_rank"]["asset"].text,size:22,showsMissing:false)
                        Text("当時の段位").foregroundStyle(Theme.muted)
                        Text(rank)
                    }.font(Theme.font(11))
                }
                if let score = player["score"].text { Text("得点 \(score)").font(Theme.font(11)).foregroundStyle(Theme.muted) }
                if let level = player["level"].text { Text("プレイヤーレベル \(level)").font(Theme.font(11)).foregroundStyle(Theme.muted) }
            }
            Spacer(minLength:0)
            Image(systemName:"chevron.right").font(Theme.font(11)).foregroundStyle(Theme.muted).padding(.top,5)
        }.frame(maxWidth:.infinity,alignment:.leading).padding(.vertical,8).contentShape(Rectangle())
    }
    private func tag(_ title: String) -> some View { Text(title).font(Theme.font(10,.medium)).foregroundStyle(Theme.warning) }
}

struct AnalysisView: View {
    @EnvironmentObject var model: AppModel
    let playerId: String
    var mode = "all"
    @State private var data: JSONValue?
    @State private var failure: String?
    var body: some View {
        VStack(alignment:.leading,spacing:15) {
            if let data {
                IDVSectionHeading(title:"取得できた戦績の集計",detail:data["total"].text.map { "\($0)試合" })
                IDVValueRow(title:mode == "mojin" ? "探索成功率" : "勝率",value:data["win_rate"].text.map { "\($0)%" } ?? "未取得")
                IDVValueRow(title:mode == "mojin" ? "成功 / 引分 / 失敗" : "勝利 / 引分 / 敗北",value:"\(data["win"].text ?? "0") / \(data["draw"].text ?? "0") / \(data["loss"].text ?? "0")")
                if let seconds = data["average_duration"].number { IDVValueRow(title:"平均対戦時間",value:"\(Int(seconds) / 60)分\(Int(seconds) % 60)秒") }
                if let unknown = data["unknown"].number,unknown > 0 { IDVValueRow(title:"結果不明",value:"\(Int(unknown))試合") }
                PartnerAnalysisView(data:data,exploration:mode == "mojin")
                NavigationLink { MatchInsightsView(data:data,mode:mode) } label: {
                    HStack(spacing:12) {
                        VStack(alignment:.leading,spacing:5) {
                            Text("成績の推移").font(Theme.font(15,.medium))
                            Text("直近の成績・連勝連敗・得点・MVP・時間帯").font(Theme.font(11)).foregroundStyle(Theme.muted)
                        }
                        Spacer(minLength:0)
                        Image(systemName:"chevron.right").font(Theme.font(12)).foregroundStyle(Theme.muted)
                    }.frame(maxWidth:.infinity,minHeight:62,alignment:.leading).contentShape(Rectangle())
                }.buttonStyle(.plain).accessibilityIdentifier("analysis-insights")
                breakdown("モード別",rows:data["by_mode"].array,fallback:"モード")
                breakdown("マップ別",rows:data["by_map"].array,fallback:"マップ")
                breakdown("キャラ別",rows:data["by_character"].array,fallback:"キャラ")
            } else if let failure { Text(failure).font(Theme.font(12)).foregroundStyle(Theme.muted) }
            else { ProgressView() }
        }.task(id:playerId+mode) {
            data = nil;failure = nil
            guard let client = model.client else { failure = "PCのAPIとの接続を設定してください。";return }
            do { let fetched: JSONValue = try await client.data("/v1/players/\(playerId)/analysis",query:[.init(name:"mode",value:mode),.init(name:"timezone",value:TimeZone.current.identifier)]); try Task.checkCancellation(); data = fetched }
            catch { if !Task.isCancelled { failure = error.localizedDescription } }
        }
    }
    @ViewBuilder private func breakdown(_ title: String,rows: [JSONValue],fallback: String) -> some View {
        if !rows.isEmpty {
            IDVSectionHeading(title:title)
            ForEach(Array(rows.enumerated()),id:\.offset) { _, row in
                VStack(alignment:.leading,spacing:3) {
                    IDVValueRow(title:row["name"].text ?? "\(fallback) \(row["id"].text ?? "—")",value:"\(row["total"].text ?? "0")戦 · \(row["win_rate"].text ?? "—")%")
                    Text("\(row["wins"].text ?? "0")勝 / \(row["draws"].text ?? "0")分 / \(row["losses"].text ?? "0")敗").font(Theme.font(11)).foregroundStyle(Theme.muted)
                }
            }
        }
    }
}
