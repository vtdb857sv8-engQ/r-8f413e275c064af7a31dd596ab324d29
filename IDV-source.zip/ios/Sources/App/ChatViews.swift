import SwiftUI

private struct ChatRooms: Decodable { struct Room: Decodable, Identifiable { let id: String; let name: String }; let server: String; let currentRoom: String; let rooms: [Room]; enum CodingKeys: String,CodingKey { case server,rooms,currentRoom = "current_room" } }
struct ChatView: View {
    @EnvironmentObject var model: AppModel
    @State private var rooms: ChatRooms?
    @State private var room = ""
    var body: some View {
        VStack(spacing:0) {
            HStack {
                IDVHeading(title:"全体チャット")
                Spacer(minLength:8)
                if let rooms {
                    Picker("チャンネル",selection:$room) {
                        ForEach(rooms.rooms) { Text($0.name).tag($0.id) }
                    }.tint(Theme.text)
                }
            }.padding(.horizontal,21).padding(.vertical,12)
            MessageList(path:"/v1/chat/global",room:room).id(room)
        }.frame(maxWidth:.infinity,maxHeight:.infinity)
        .task {
            guard let client = model.client else { return }
            do { let fetched: ChatRooms = try await client.data("/v1/chat/rooms"); rooms = fetched; room = fetched.currentRoom }
            catch { if !Task.isCancelled { model.show(error) } }
        }
    }
}
struct FriendChatView: View {
    let friend: Profile
    var body: some View {
        VStack(alignment:.leading,spacing:0) {
            StateBadge(presence:friend.presence).padding(.horizontal,21).padding(.vertical,10)
            MessageList(path:"/v1/friends/\(friend.playerId)/chat",room:"").id(friend.playerId)
        }.frame(maxWidth:.infinity,maxHeight:.infinity)
        .navigationTitle(friend.displayName).navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
    }
}
private struct PendingChat: Identifiable { let id: String; let content: String }
struct MessageList: View {
    @EnvironmentObject var model: AppModel
    let path: String
    let room: String
    @State private var messages: [ChatMessage] = []
    @State private var pending: [PendingChat] = []
    @State private var draft = ""
    @State private var busy = false
    @State private var failure: String?
    @FocusState private var editing: Bool
    private var latest: String { pending.last?.id ?? messages.last.map { String($0.id) } ?? "" }
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment:.leading,spacing:20) {
                    if let failure { Text(failure).font(Theme.font(12)).foregroundStyle(Theme.warning) }
                    ForEach(messages) { message in
                        VStack(alignment:.leading,spacing:7) {
                            HStack {
                                NavigationLink { ProfileView(playerId:message.author.playerId) } label: {
                                    HStack(spacing:10) {
                                        AvatarArtwork(portrait:message.author.faceId.map { "face-\($0)" },frame:message.author.frameId.map { "frame-\($0)" },size:34)
                                            .accessibilityElement(children:.ignore).accessibilityLabel("ゲーム内アイコン").accessibilityIdentifier("chat-avatar-\(message.id)")
                                        Text(message.author.name ?? message.author.playerId).font(Theme.font(12,.medium))
                                    }.contentShape(Rectangle())
                                }
                                Spacer()
                                Text(DateText.string(message.sentAt)).font(Theme.font(10)).foregroundStyle(Theme.muted)
                            }
                            Text(message.content).font(Theme.font(14)).frame(maxWidth:.infinity,alignment:.leading).textSelection(.enabled)
                        }
                    }
                    ForEach(pending) { item in
                        VStack(alignment:.trailing,spacing:5) {
                            Text(item.content).font(Theme.font(14))
                            Text("送信確認中").font(Theme.font(10)).foregroundStyle(Theme.muted)
                        }.frame(maxWidth:.infinity,alignment:.trailing)
                    }
                    Color.clear.frame(height:1).id("chat-bottom")
                }.padding(.horizontal,21).padding(.vertical,16)
            }.accessibilityIdentifier("chat-messages")
            .scrollDismissesKeyboard(.interactively)
            .safeAreaInset(edge:.bottom,spacing:0) { composer }
            .onChange(of:latest) { _ in proxy.scrollTo("chat-bottom",anchor:.bottom) }
        }.frame(maxWidth:.infinity,maxHeight:.infinity)
        .task(id:path+room) {
            while !Task.isCancelled {
                await load()
                do { try await Task.sleep(nanoseconds:5_000_000_000) } catch { break }
            }
        }
    }
    private var composer: some View {
        HStack(alignment:.bottom,spacing:10) {
            TextField("メッセージを入力",text:$draft,axis:.vertical)
                .lineLimit(1...4).focused($editing)
                .accessibilityIdentifier("chat-draft")
                .padding(12).background(Theme.card,in:RoundedRectangle(cornerRadius:7))
            Button("送信",action:send).font(Theme.font(13,.medium))
                .frame(minWidth:48,minHeight:44).contentShape(Rectangle())
                .accessibilityIdentifier("chat-send")
                .disabled(busy || draft.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
        }.padding(.horizontal,16).padding(.vertical,10)
        .background(Theme.background).overlay(alignment:.top) { Theme.line.frame(height:1) }
    }
    private func load() async {
        guard let client = model.client else { return }
        do {
            let page: Page<ChatMessage> = try await client.data(path,query:room.isEmpty ? [.init(name:"limit",value:"100")] : [.init(name:"room",value:room),.init(name:"limit",value:"100")])
            try Task.checkCancellation()
            messages = page.items
            let confirmed = Set(messages.compactMap(\.messageId)); pending.removeAll { confirmed.contains($0.id) }; failure = nil
        } catch { if !Task.isCancelled { failure = error.localizedDescription } }
    }
    private func send() {
        guard let client = model.client,!busy else { return }
        let content = draft.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !content.isEmpty else { return }
        let id = UUID().uuidString; busy = true
        Task {
            defer { busy = false }
            do {
                var body: [String:JSONValue] = ["content":.string(content),"client_message_id":.string(id)]
                if !room.isEmpty { body["room"] = .string(room) }
                try await client.command(path,body:.object(body))
                pending.append(.init(id:id,content:content))
                if draft.trimmingCharacters(in:.whitespacesAndNewlines) == content { draft = "" }
                await load()
            } catch { model.show(error) }
        }
    }
}
