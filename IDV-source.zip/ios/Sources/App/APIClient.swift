import Foundation

struct APIProblem: Error, LocalizedError {
    let code: String
    let message: String
    var errorDescription: String? { message }
}
private struct ErrorEnvelope: Decodable { struct Problem: Decodable { let code: String; let message: String }; let error: Problem }
final class RedirectGuard: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    let origin: URL
    init(_ origin: URL) { self.origin = origin }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(request.url.map { EndpointPolicy.sameOrigin(origin, $0) } == true ? request : nil) }
}
final class APIClient: @unchecked Sendable {
    let base: URL
    private let key: String
    private let session: URLSession
    init(url: String, key: String) throws {
        base = try EndpointPolicy.validate(url)
        guard key.count >= 32, !key.contains("\n"), !key.contains("\r") else { throw APIProblem(code: "KEY_REQUIRED", message: "API認証鍵を入力してください。") }
        self.key = key
        let config = URLSessionConfiguration.ephemeral
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--ui-testing") { config.protocolClasses = [ChatFixtureProtocol.self] }
        #endif
        config.urlCache = nil; config.requestCachePolicy = .reloadIgnoringLocalCacheData; config.timeoutIntervalForRequest = 40; config.timeoutIntervalForResource = 120
        session = URLSession(configuration: config, delegate: RedirectGuard(base), delegateQueue: nil)
    }
    deinit { session.invalidateAndCancel() }
    private func request(_ path: String, query: [URLQueryItem] = [], method: String = "GET", body: JSONValue? = nil) throws -> URLRequest {
        var c = URLComponents(url: base, resolvingAgainstBaseURL: false)!
        c.path = path; c.queryItems = query.isEmpty ? nil : query
        var r = URLRequest(url: c.url!); r.httpMethod = method
        r.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization"); r.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body { r.setValue("application/json", forHTTPHeaderField: "Content-Type"); r.httpBody = try JSONEncoder().encode(body) }
        return r
    }
    func value<T: Decodable>(_ path: String, query: [URLQueryItem] = [], method: String = "GET", body: JSONValue? = nil, as: T.Type = T.self) async throws -> T {
        let (data, response) = try await session.data(for: request(path, query: query, method: method, body: body))
        guard let h = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        if !(200...299).contains(h.statusCode) {
            if let e = try? JSONDecoder().decode(ErrorEnvelope.self, from: data) { throw APIProblem(code: e.error.code, message: e.error.message) }
            throw APIProblem(code: "HTTP_ERROR", message: "APIから正常な応答を受け取れませんでした（\(h.statusCode)）。")
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
    func data<T: Decodable>(_ path: String, query: [URLQueryItem] = [], as: T.Type = T.self) async throws -> T { let e: Envelope<T> = try await value(path, query: query); return e.data }
    func command(_ path: String, method: String = "POST", body: JSONValue? = nil) async throws { let _: JSONValue = try await value(path, method: method, body: body) }
    func image(_ key: String) async throws -> Data {
        guard key.range(of: "^[a-z0-9-]{1,80}$", options: .regularExpression) != nil else { throw URLError(.badURL) }
        let (data,response) = try await session.data(for: request("/v1/assets/\(key).png"))
        guard let http = response as? HTTPURLResponse, http.statusCode == 200, http.value(forHTTPHeaderField: "Content-Type") == "image/png", data.count < 20_000_000 else { throw URLError(.cannotDecodeContentData) }
        return data
    }
    func events(after: Int, consume: @escaping @Sendable (PresenceEvent) async -> Void) async throws {
        var r = try request("/v1/events/stream"); r.setValue("text/event-stream", forHTTPHeaderField: "Accept"); r.setValue(String(after), forHTTPHeaderField: "Last-Event-ID"); r.timeoutInterval = 3600
        let (bytes, response) = try await session.bytes(for: r)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw APIProblem(code: "STREAM_UNAVAILABLE", message: "通知の接続を再試行しています。") }
        var parser = SSEParser()
        for try await line in bytes.lines { try Task.checkCancellation(); if let event = parser.accept(line) { await consume(event) } }
    }
}
