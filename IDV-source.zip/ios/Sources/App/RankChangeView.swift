import SwiftUI

struct RankChangeView: View {
    let change: JSONValue
    var playerName: String?
    var body: some View {
        IDVPage {
            IDVHeading(title:"段位の変化")
            if let playerName { Text(playerName).font(Theme.font(13)).foregroundStyle(Theme.muted) }
            HStack(alignment:.top,spacing:16) {
                rank("対戦前",data:change["before"])
                Image(systemName:"arrow.right").font(Theme.font(13)).foregroundStyle(Theme.muted).padding(.top,30)
                rank("対戦後",data:change["after"])
            }
            IDVSectionHeading(title:"段位ポイントの内訳")
            if change["details_received"].flag != true {
                Text("ポイント内訳は未取得です").font(Theme.font(12)).foregroundStyle(Theme.muted)
            } else if change["details"].array.isEmpty {
                Text("表示できる増減理由はありません").font(Theme.font(12)).foregroundStyle(Theme.muted)
            }
            ForEach(Array(change["details"].array.enumerated()),id:\.offset) { _,row in
                IDVValueRow(title:row["label"].text ?? "",value:signed(row["points"]))
            }
            if let count = change["unlabelled_reasons"].number,count > 0 {
                Text("項目名・表示形式を確認できていない理由が\(Int(count))件あります").font(Theme.font(11)).foregroundStyle(Theme.muted)
            }
            if let count = change["invalid_reasons"].number,count > 0 {
                Text("値を確認できていない理由が\(Int(count))件あります").font(Theme.font(11)).foregroundStyle(Theme.muted)
            }
            Text("受信できた増減理由を表示しています。昇段・降段をまたぐ増減の総計と、保護カードの補正は確認できていません。")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
        }.navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
    }
    private func rank(_ title: String,data: JSONValue) -> some View {
        VStack(alignment:.leading,spacing:10) {
            Text(title).font(Theme.font(11)).foregroundStyle(Theme.muted)
            HStack(spacing:8) {
                GameArt(key:data["asset"].text,size:32,showsMissing:false)
                VStack(alignment:.leading,spacing:5) {
                    Text(data["label"].text ?? "段位未取得").font(Theme.font(14,.medium))
                    if let stars = data["stars"].text { Text("星 \(stars)").font(Theme.font(11)).foregroundStyle(Theme.muted) }
                }
            }
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
    private func signed(_ value: JSONValue) -> String { guard let number = value.number,let text = value.text else { return "未取得" };return (number >= 0 ? "+" : "")+text }
}
