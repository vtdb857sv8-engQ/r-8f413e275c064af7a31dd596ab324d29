import SwiftUI

@MainActor final class RankingPresenceModel: ObservableObject {
    struct Response: Decodable { let data: Presence; let fresh: Bool }
    @Published private(set) var items: [String: Response] = [:]
    private var fetched: [String: Date] = [:]
    private var active = 0
    func load(_ id: String, client: APIClient) async {
        if let at = fetched[id], Date().timeIntervalSince(at) < 30 { return }
        while active >= 3 {
            do { try await Task.sleep(nanoseconds: 200_000_000) } catch { return }
        }
        guard !Task.isCancelled else { return }
        active += 1
        defer { active -= 1 }
        if let result: Response = try? await client.value("/v1/players/\(id)/presence") {
            guard !Task.isCancelled else { return }
            items[id] = result; fetched[id] = Date()
        }
    }
}

struct RankingsView: View {
    @EnvironmentObject var model: AppModel
    @StateObject private var presence = RankingPresenceModel()
    @State private var kind = "survivor"
    @State private var board = "rank"
    @State private var characters: [GameCharacter] = []
    @State private var characterId: Int?
    @State private var choosingCharacter = false
    @State private var items: [Ranking] = []
    @State private var loading = false
    @State private var failure: String?
    private var choices: [GameCharacter] { characters.filter { $0.camp == kind && $0.name != nil }.sorted { $0.id < $1.id } }
    private var selected: GameCharacter? { choices.first { $0.id == characterId } ?? choices.first }
    private var requestKey: String { "\(kind)-\(board)-\(board == "character" ? selected?.id ?? 0 : 0)" }
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 12) {
                Picker("ランキング種別", selection: $board) { Text("段位").tag("rank"); Text("キャラ別").tag("character") }.pickerStyle(.segmented).accessibilityIdentifier("ranking-board")
                Picker("陣営", selection: $kind) { Text("サバイバー").tag("survivor"); Text("ハンター").tag("hunter") }.pickerStyle(.segmented)
                if board == "character" {
                    Button { choosingCharacter = true } label: {
                        HStack { GameArt(key: selected?.asset, size: 42); Text(selected?.name ?? "キャラクターを選択").font(Theme.font(15, .medium)); Spacer(); Image(systemName:"chevron.down").font(.caption) }.frame(maxWidth:.infinity,minHeight:54).contentShape(Rectangle())
                    }.accessibilityIdentifier("ranking-character")
                }
                IDVSectionHeading(title: "現シーズン", detail: "取得分 \(items.count)人")
                if loading { ProgressView() }
                if let failure { Text(failure).font(Theme.font(12)).foregroundStyle(Theme.muted) }
                ForEach(items) { item in
                    HStack(spacing:8) {
                        NavigationLink { ProfileView(playerId: item.playerId) } label: { row(item) }
                        .task(id: item.playerId) { if let client = model.client { await presence.load(item.playerId, client: client) } }
                        NavigationLink { PersonaView(playerId:item.playerId,playerName:item.name,initialCharacterId:board == "character" ? selected?.id : nil,camp:kind) } label: {
                            Text("人格").font(Theme.font(11,.medium)).foregroundStyle(Theme.accent).frame(width:44,height:44).contentShape(Rectangle())
                        }.accessibilityLabel("\(item.name ?? item.playerId)の人格").accessibilityIdentifier("ranking-persona-\(item.playerId)")
                    }
                    Divider().overlay(Theme.line)
                }
            }.padding(21)
        }.background(Theme.background).foregroundStyle(Theme.text)
            .navigationTitle("ランキング").navigationBarTitleDisplayMode(.inline).toolbar(.visible, for: .navigationBar)
            .task { await loadCatalog() }
            .task(id: requestKey) { await load() }.refreshable { await load() }
            .sheet(isPresented: $choosingCharacter) {
                CharacterRankingPicker(characters: choices, selectedId: selected?.id) { character in characterId = character.id; choosingCharacter = false }
                    .environmentObject(model)
            }
    }
    private func row(_ item: Ranking) -> some View {
        HStack(spacing: 12) {
            Text(String(item.position)).font(Theme.font(13)).monospacedDigit().foregroundStyle(Theme.muted).frame(width: 29)
            AvatarArtwork(portrait:item.faceId.map { "face-\($0)" },frame:item.frameId.map { "frame-\($0)" },size:38)
            VStack(alignment: .leading, spacing: 5) {
                Text(item.name ?? item.playerId).font(Theme.font(14, .medium)).lineLimit(1)
                StateBadge(presence: presence.items[item.playerId]?.fresh == true ? presence.items[item.playerId]?.data : nil)
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 3) {
                if board == "character" { Text(item.characterScore.map { String($0) } ?? "—").font(Theme.font(16, .medium)).monospacedDigit(); Text("認知ポイント").font(Theme.font(10)).foregroundStyle(Theme.muted) }
                if item.part != nil { GameArt(key:item.rankAsset(kind),size:28);Text(item.rankLabel).font(Theme.font(11)).lineLimit(1) }
            }
        }.frame(minHeight: 65).contentShape(Rectangle())
    }
    private func load() async {
        guard let client = model.client else { return }
        let requestKind = kind, key = requestKey
        let requestedCharacter = board == "character" ? selected?.id : nil
        if board == "character" && requestedCharacter == nil { return }
        loading = true; failure = nil; items = []
        defer { if key == requestKey { loading = false } }
        var query = [URLQueryItem(name: "kind", value: requestKind), .init(name: "limit", value: "100")]
        if let requestedCharacter { query.append(.init(name: "character_id", value: String(requestedCharacter))) }
        do { let page: Page<Ranking> = try await client.data("/v1/rankings", query: query); guard !Task.isCancelled, key == requestKey else { return }; items = page.items }
        catch { if !Task.isCancelled && key == requestKey { failure = error.localizedDescription } }
    }
    private func loadCatalog() async {
        guard let client = model.client else { return }
        do { let catalog: GameCatalog = try await client.data("/v1/catalog"); guard !Task.isCancelled else { return }; characters = Array(catalog.characters.values) }
        catch { if !Task.isCancelled { failure = error.localizedDescription } }
    }
}

struct CharacterRankingPicker: View {
    let characters: [GameCharacter]
    let selectedId: Int?
    let select: (GameCharacter) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    private var filtered: [GameCharacter] { query.isEmpty ? characters : characters.filter { $0.name?.localizedCaseInsensitiveContains(query) == true } }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing:0) {
                    ForEach(filtered) { character in
                        Button { select(character) } label: { HStack(spacing:12) { GameArt(key: character.asset, size:44); Text(character.name ?? "").font(Theme.font(15)); Spacer(); if character.id == selectedId { Image(systemName:"checkmark").foregroundStyle(Theme.accent) } }.padding(.vertical,8).contentShape(Rectangle()) }
                            .buttonStyle(.plain).accessibilityLabel(character.name ?? "").accessibilityIdentifier("choose-character-\(character.id)")
                        Divider().overlay(Theme.line)
                    }
                }.padding(.horizontal,21)
            }.background(Theme.background).foregroundStyle(Theme.text)
                .searchable(text:$query, prompt:"キャラクター名")
                .navigationTitle("キャラクターを選択").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement:.navigationBarTrailing) { Button("閉じる") { dismiss() } } }
        }.preferredColorScheme(.dark)
    }
}
