import SwiftUI
struct ProfileFrequentCharacters: View {
    let profile: Profile
    var body: some View {
        if profile.canShowStatistics,["self","permitted"].contains(profile.fieldAccess?["frequent_characters"] ?? "unknown"),let data = profile.mostUsedCharacters,let label = data["label"].text {
            VStack(alignment:.leading,spacing:10) {
                IDVSectionHeading(title:label)
                if data["status"].text == "available" {
                    if data["items"].array.isEmpty {
                        Text("受信した集計に常用キャラの記録はありません").font(Theme.font(12)).foregroundStyle(Theme.muted)
                    } else {
                        HStack(alignment:.top,spacing:8) {
                            ForEach(Array(data["items"].array.prefix(4).enumerated()),id:\.offset) { _, item in
                                VStack(spacing:7) {
                                    GameArt(key:item["asset"].text,size:46,showsMissing:false)
                                    Text(item["name"].text ?? "名前未取得").font(Theme.font(11)).lineLimit(2).multilineTextAlignment(.center)
                                }.frame(maxWidth:.infinity).accessibilityElement(children:.combine)
                                    .accessibilityLabel(item["name"].text ?? "名前未取得")
                                    .accessibilityIdentifier("frequent-character-\(item["character_id"].text ?? "")")
                            }
                        }
                    }
                } else {
                    Text("使用集計を確認できません").font(Theme.font(12)).foregroundStyle(Theme.muted).accessibilityIdentifier("frequent-characters-unavailable")
                }
            }.accessibilityElement(children:.contain).accessibilityIdentifier("profile-frequent-characters")
        }
    }
}
