import SwiftUI
import UserNotifications
import UIKit

@MainActor final class AppModel: ObservableObject {
    @Published var configured = false
    @Published var status: ServiceStatus?
    @Published var me: Profile?
    @Published var friends: [Profile] = []
    @Published var watches: [Watch] = []
    @Published var events: [PresenceEvent] = []
    @Published var errorMessage: String?
    @Published var streamConnected = false
    @Published var refreshing = false
    @Published var pushMessage: String?
    @Published var notificationRules: [String: Bool] = [:]
    @Published var searchHistory: [Profile] = []
    @Published var avatarMasks: [String:String] = [:]
    private var catalogServer: String?
    private(set) var client: APIClient?
    private var streamTask: Task<Void, Never>?
    private var cursor = 0
    var serverURL: String { UserDefaults.standard.string(forKey: "serverURL") ?? "" }
    init() {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--ui-testing") {
            client = try? APIClient(url:"http://127.0.0.1:8787",key:String(repeating:"fixture",count:8)); configured = true
            if ProcessInfo.processInfo.arguments.contains("--ui-search-history") {
                searchHistory = SearchHistory.decode(Data(#"[{"player_id":"31","name":"別の保存名"},{"player_id":"30","name":"以前の名前"}]"#.utf8))
            }
            return
        }
        #endif
        if let key = Keychain.read("api-key"), let c = try? APIClient(url: serverURL, key: key) { client = c; configured = true }
        loadSearchHistory()
    }
    func configure(url: String, key: String) async throws {
        let c = try APIClient(url: url, key: key.trimmingCharacters(in: .whitespacesAndNewlines))
        let checked: ServiceStatus = try await c.value("/v1/status")
        try Keychain.save(key.trimmingCharacters(in: .whitespacesAndNewlines), account: "api-key")
        streamTask?.cancel(); streamTask = nil; streamConnected = false; cursor = 0; events = []; friends = []; me = nil; watches = []
        UserDefaults.standard.set(c.base.absoluteString, forKey: "serverURL")
        client = c; status = checked; configured = true; loadSearchHistory()
        await refresh(); startStream()
    }
    func pair(url: String, ticket: String) async throws {
        let base = try EndpointPolicy.validate(url)
        var request = URLRequest(url: base.appendingPathComponent("v1/pairing/redeem")); request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type"); request.httpBody = try JSONEncoder().encode(["ticket":ticket.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()]); request.timeoutInterval = 20
        let config = URLSessionConfiguration.ephemeral
        let session = URLSession(configuration: config, delegate: RedirectGuard(base), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw APIProblem(code: "PAIRING_FAILED", message: "接続コードを確認してください。期限切れの場合はPCで発行し直してください。") }
        struct Result: Decodable { let apiKey: String; enum CodingKeys: String, CodingKey { case apiKey = "api_key" } }
        let result = try JSONDecoder().decode(Result.self, from: data)
        try await configure(url: url, key: result.apiKey)
    }
    func refresh() async {
        guard let client, !refreshing else { return }; refreshing = true; defer { refreshing = false }
        do {
            status = try await client.value("/v1/status")
            watches = try await client.data("/v1/watches")
            notificationRules = try await client.data("/v1/notifications/settings")
            if catalogServer != serverURL, let catalog: GameCatalog = try? await client.data("/v1/catalog") { avatarMasks = catalog.avatarMasks ?? [:];catalogServer = serverURL }
            let page: [PresenceEvent] = try await client.data("/v1/events", query: [.init(name: "after", value: String(max(cursor, 0))), .init(name: "limit", value: "500")])
            for event in page { accept(event) }
            if status?.connected == true {
                friends = try await client.data("/v1/friends")
                me = try await client.data("/v1/me")
            }
        } catch { show(error) }
    }
    func connect(replace: Bool = false) async {
        guard let client else { return }
        do { try await client.command("/v1/session/connect", body: .object(["replace_existing":.bool(replace)])); await refresh(); startStream() } catch { show(error); await refresh() }
    }
    func disconnect() async { guard let client else { return }; do { try await client.command("/v1/session/disconnect"); await refresh() } catch { show(error) } }
    func isWatching(_ id: String) -> Bool { watches.contains { $0.playerId == id && $0.notify == 1 } }
    private var historyKey: String { "idv-search-history:" + serverURL }
    private func loadSearchHistory() { searchHistory = SearchHistory.decode(UserDefaults.standard.data(forKey: historyKey)) }
    func rememberSearch(_ profile: Profile) {
        var rows = searchHistory.filter { $0.playerId != profile.playerId }; rows.insert(profile,at:0)
        guard let data = try? SearchHistory.encode(rows),data != UserDefaults.standard.data(forKey:historyKey) else { return }
        UserDefaults.standard.set(data,forKey:historyKey);searchHistory = SearchHistory.decode(data)
    }
    func clearSearchHistory() { searchHistory = []; UserDefaults.standard.removeObject(forKey: historyKey) }
    func setWatch(_ id: String, enabled: Bool, notify: Bool = true) async {
        guard let client else { return }
        do { try await client.command("/v1/watches/\(id)", method: enabled ? "PUT" : "DELETE", body: enabled ? .object(["notify":.bool(notify)]) : nil); watches = try await client.data("/v1/watches") } catch { show(error) }
    }
    func setRule(_ key: String, enabled: Bool) async {
        guard let client else { return }
        do { try await client.command("/v1/notifications/settings", method: "PUT", body: .object([key:.bool(enabled)])); notificationRules = try await client.data("/v1/notifications/settings") } catch { show(error) }
    }
    func reloadWatches() async { guard let client else { return }; do { watches = try await client.data("/v1/watches") } catch { show(error) } }
    func show(_ error: Error) {
        if error is CancellationError || (error as? URLError)?.code == .cancelled { return }
        if let e = error as? APIProblem { errorMessage = e.message }
        else if let e = error as? URLError, [.cannotConnectToHost,.notConnectedToInternet,.cannotFindHost,.timedOut].contains(e.code) { errorMessage = "PCのAPIに接続できません。同じネットワークに接続し、PCのAPIが起動しているか確認してください。" }
        else { errorMessage = "データを取得できませんでした。時間を置いて更新してください。" }
    }
    func startStream() {
        guard streamTask == nil, let client else { return }
        streamTask = Task { [weak self] in
            var delay: UInt64 = 1
            while !Task.isCancelled {
                guard let self else { return }
                do {
                    self.streamConnected = true
                    try await client.events(after: self.cursor) { [weak self] event in await self?.accept(event, notify: true) }
                    self.streamConnected = false
                } catch { self.streamConnected = false; if Task.isCancelled { return } }
                try? await Task.sleep(nanoseconds: delay * 1_000_000_000); delay = min(delay * 2, 30)
            }
        }
    }
    func stopStream() { streamTask?.cancel(); streamTask = nil; streamConnected = false }
    private func accept(_ event: PresenceEvent, notify: Bool = false) {
        guard !events.contains(where: { $0.id == event.id }) else { return }
        cursor = max(cursor, event.id); events.insert(event, at: 0); events.sort { $0.id > $1.id }; events = Array(events.prefix(500))
        if notify && status?.pushConfigured != true && event.notificationSelected == true && UIApplication.shared.applicationState == .active { let content = UNMutableNotificationContent(); content.title = watches.first { $0.playerId == event.playerId }?.profile?.displayName ?? event.playerId; content.body = event.changeText; content.sound = .default; UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "presence-\(event.id)", content: content, trigger: nil)) }
        Task { await reloadWatches() }
    }
    func requestPush() async {
        do {
            let granted = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound,.badge])
            if granted { UIApplication.shared.registerForRemoteNotifications(); pushMessage = "通知を登録しています…" }
            else { pushMessage = "通知が許可されていません。iPhoneの設定から変更できます。" }
        } catch { pushMessage = "通知の許可を確認できませんでした。" }
    }
    func registerDevice(_ token: String) async {
        guard let client else { return }
        do {
            var id = Keychain.read("device-id")
            if id == nil { id = UUID().uuidString; try Keychain.save(id!, account: "device-id") }
            let environment = UserDefaults.standard.string(forKey: "pushEnvironment") ?? "sandbox"
            try await client.command("/v1/devices", body: .object(["device_id":.string(id!), "token":.string(token), "environment":.string(environment)]))
            pushMessage = status?.pushConfigured == true ? "通知用の端末を登録しました。" : "端末登録済みです。PC側のAPNs設定が必要です。"
        } catch { pushMessage = "端末の登録に失敗しました。APIの接続を確認してください。" }
    }
    func forgetConnection() {
        stopStream(); Keychain.remove("api-key"); UserDefaults.standard.removeObject(forKey: "serverURL"); client = nil; configured = false; status = nil; friends = []; me = nil; events = []; watches = []; cursor = 0
    }
}
