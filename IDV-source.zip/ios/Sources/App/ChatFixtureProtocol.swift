#if DEBUG
import Foundation
// In-process simulator fixtures. Release builds contain no fixture server or launch switch.
final class ChatFixtureProtocol: URLProtocol {
    private static let attemptLock = NSLock()
    private static var profileAttempts = 0
    private static var personaAttempts = 0
    private let deliveryLock = NSLock()
    private var stopped = false
    private var pendingDelivery: DispatchWorkItem?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let path = request.url!.path
        let hidden = ProcessInfo.processInfo.arguments.contains("--ui-hidden-statistics")
        let badgesHidden = ProcessInfo.processInfo.arguments.contains("--ui-hidden-badges")
        var profile: [String:Any] = ["player_id":"20","name":"表示テスト","presence":["state":"online","visibility":"visible"],"likes":15,"battle_count":120,"mvp":12,"character_num":8,"field_access":["statistics":hidden ? "unknown" : "self","profile_tags":"self","frequent_characters":hidden ? "unknown" : "self","history_badges":badgesHidden ? "unknown" : "self"],"civilian_data":["normal_battle_cnt":80,"normal_battle_win_cnt":40,"normal_battle_lose_cnt":20,"rank_battle_cnt":40,"rank_battle_win_cnt":20,"rank_battle_lose_cnt":10]]
        if ProcessInfo.processInfo.arguments.contains("--ui-profile-seasons") {
            profile["season_history"] = ["survivor":[["season_id":43,"recorded_rank":["label":"五段III","stars":3],"highest_rank":["label":"七段","stars":25],"statistics":[["mode":"normal","label":"通常戦","total":18,"wins":10,"losses":5,"consistent":true],["mode":"rank","label":"ランク戦","total":12,"wins":7,"losses":3,"consistent":true]]],["season_id":35,"statistics":[["mode":"normal","label":"通常戦","total":0,"wins":0,"consistent":true],["mode":"rank","label":"ランク戦","consistent":true]]]],"hunter":[["season_id":40,"recorded_rank":["label":"三段V","stars":2],"statistics":[["mode":"rank","label":"ランク戦","total":4,"wins":1,"losses":2,"consistent":true]]]]]
            if ProcessInfo.processInfo.arguments.contains("--ui-season-empty") { profile["season_history"] = ["survivor":[],"hunter":[]] }
        }
        if ProcessInfo.processInfo.arguments.contains("--ui-season-characters") {
            let chars: [String:Any] = ["status":"available","items":[
                ["character_id":25,"name":"傭兵","asset":"character-25","battle_count":6,"wins":4,"draws":1,"win_rate_display":"80.0%"],
                ["character_id":3,"name":"幸運児","asset":"character-3","battle_count":2,"wins":2,"draws":0,"win_rate_display":"100.0%"]]]
            let hunter: [String:Any] = ["status":"available","items":[["character_id":1,"name":"復讐者","asset":"character-1","battle_count":1,"wins":1,"draws":0,"win_rate_display":"100.0%"]]]
            profile["season_history"] = ["survivor":[["season_id":37,"rank_characters":chars],["season_id":35,"rank_characters":["status":"unavailable"]]],"hunter":[["season_id":35,"rank_characters":hunter]]]
            if ProcessInfo.processInfo.arguments.contains("--ui-season-characters-empty") {
                profile["season_history"] = ["survivor":[["season_id":37,"rank_characters":["status":"available","items":[]]]],"hunter":[]]
            }
        }
        if ProcessInfo.processInfo.arguments.contains("--ui-current-season") {
            profile["civilian_data"] = ["normal_battle_cnt":52,"normal_battle_win_cnt":49,"normal_battle_lose_cnt":2]
            if !ProcessInfo.processInfo.arguments.contains("--ui-current-season-unavailable") {
                profile["current_season_statistics"] = ["survivor":["season_id":44,"statistics":[["mode":"normal","label":"通常戦","total":5,"wins":4,"losses":0,"consistent":true],["mode":"rank","label":"ランク戦","total":0,"wins":0,"losses":0,"consistent":true]]],"hunter":["season_id":44,"statistics":[["mode":"normal","label":"通常戦","total":1,"wins":1,"losses":0,"consistent":true],["mode":"rank","label":"ランク戦","consistent":true]]]]
            }
        }
        if ProcessInfo.processInfo.arguments.contains("--ui-frequent-characters") {
            let unavailable = ProcessInfo.processInfo.arguments.contains("--ui-frequent-unavailable")
            profile["most_used_characters"] = ["label":"使用回数が最も多い","status":unavailable ? "unavailable" : "available","items":unavailable ? [] : [(80,"狂眼"),(2,"道化師"),(129,"オペラ歌手"),(3,"幸運児")].map { id,name -> [String:Any] in ["character_id":id,"name":name,"asset":"character-\(id)"] }]
        }
        var peerProfile = profile; peerProfile["player_id"] = "30"; peerProfile["name"] = "集計相手"
        let peer: [String:Any] = ["player_id":"30","name":"集計相手","total":35,"wins":17,"draws":8,"losses":10,"unknown":0,"win_rate":48.57142857]
        let historicalBadge: [String:Any] = ["character_id":14,"character_name":"医師","camp":"survivor","highest_grade":"A","highest_score":7335,"grades":[["grade":"A","count":4,"latest_date":"2025-06-16"],["grade":"B","count":2]]]
        var match: [String:Any] = ["record_id":"demo","common_info":["start_time":1793879700,"end_time":1793879940,"battle_time_exclude_pause":240],"summary":["map_name":"レオの思い出","mode_name":"マルチ戦モード","mode_id":1,"is_custom":false,"result":"win","players":[["player_id":"20","name":"表示テスト","character_id":89,"character_name":"曲芸師","camp":"survivor","is_self":true,"score":1200,"mvp":true,"match_rank":["label":"五段III"]]]]]
        var matchSummary = match["summary"] as! [String:Any]
        matchSummary["map_asset"] = "map-33"
        var matchPlayers = matchSummary["players"] as! [[String:Any]]
        var hunter: [String:Any] = ["player_id":"30","name":"集計相手","camp":"hunter","is_self":false,"score":10000]
        if ProcessInfo.processInfo.arguments.contains("--ui-participant-results") {
            matchPlayers[0]["participant_result"] = ["status":"received","code":1,"label":"行方不明"]
            hunter["participant_result"] = ["status":"received","code":10,"label":"辛勝"]
            if ProcessInfo.processInfo.arguments.contains("--ui-personal-result-unknown") {
                matchPlayers[0]["participant_result"] = ["status":"unavailable"]
                hunter["participant_result"] = ["status":"unverified"]
            }
        }
        if !ProcessInfo.processInfo.arguments.contains("--ui-score-unavailable") {
            matchPlayers[0]["score_breakdown"] = ["冷静","執着","友好","勇敢"].enumerated().map { i,label -> [String:Any] in ["category_id":i+1,"label":label,"value":[100,0,200,900][i],"asset":"match-score-survivor-\(i+1)"] }
            hunter["score_breakdown"] = ["屈強","鋭敏","威嚇","狡猾"].enumerated().map { i,label -> [String:Any] in ["category_id":i+1,"label":label,"value":[3000,3000,1000,3000][i],"asset":"match-score-hunter-\(i+1)"] }
        }
        if ProcessInfo.processInfo.arguments.contains("--ui-match-actions") {
            if ProcessInfo.processInfo.arguments.contains("--ui-actions-unavailable") {
                matchPlayers[0]["action_details"] = ["status":"unavailable","items":[]]
                hunter["action_details"] = ["status":"unavailable","items":[]]
            } else {
                matchPlayers[0]["action_details"] = ["status":"received","items":[["action_id":1,"label":"解読進捗","display_value":"160%"],["action_id":20,"label":"板命中","display_value":"0"],["action_id":7,"label":"援助","display_value":"1"],["action_id":8,"label":"治療","display_value":"2"],["action_id":12,"label":"ハンターへの牽制","display_value":"87秒"]]]
                hunter["action_details"] = ["status":"received","items":[["action_id":501,"label":"残り暗号機","display_value":"0"],["action_id":2,"label":"板の破壊","display_value":"6"],["action_id":502,"label":"サバイバーに命中","display_value":"19"],["action_id":10,"label":"恐怖の一撃","display_value":"2"],["action_id":500,"label":"ダウンさせる","display_value":"7"]]]
            }
        }
        if ProcessInfo.processInfo.arguments.contains("--ui-match-titles"),var actions = matchPlayers[0]["action_details"] as? [String:Any] {
            actions["items"] = [["action_id":1,"label":"解読進捗","display_value":"350%"],["action_id":20,"label":"板命中","display_value":"3"],["action_id":7,"label":"援助","display_value":"3"],["action_id":8,"label":"治療","display_value":"3"],["action_id":12,"label":"ハンターへの牽制","display_value":"190秒"]]
            actions["titles_status"] = "received";actions["unverified_title_records"] = 0
            actions["titles"] = [(1,"解読マスター","解読進捗が300%に到達"),(2,"地形マスター","板命中回数が3回に到達"),(3,"援助マスター","仲間救出回数が3回に到達"),(4,"医療マスター","仲間治療回数が3回に到達"),(5,"牽制マスター","ハンターへの牽制時間が180秒に到達")].map { id,label,description -> [String:Any] in ["id":id,"label":label,"description":description,"asset":"match-performance-\(id)"] }
            if ProcessInfo.processInfo.arguments.contains("--ui-titles-empty") { actions["titles"] = [] }
            if ProcessInfo.processInfo.arguments.contains("--ui-titles-unavailable") { actions["titles_status"] = "unavailable";actions["titles"] = [] }
            if ProcessInfo.processInfo.arguments.contains("--ui-titles-unknown") { actions["titles"] = [];actions["unverified_title_records"] = 1 }
            matchPlayers[0]["action_details"] = actions
        }
        if ProcessInfo.processInfo.arguments.contains("--ui-rank-change") {
            matchSummary["mode_id"] = 2;matchSummary["mode_name"] = "ランク戦モード"
            matchPlayers[0]["rank_change"] = ["before":["label":"五段IV","stars":4],"after":["label":"五段III","stars":0],"details_received":true,"details":[["label":"勝利","points":8],["label":"サバイバー演繹得点第1位","points":4]],"unlabelled_reasons":0,"invalid_reasons":0]
            hunter["rank_change"] = ["before":["label":"三段V","stars":3],"after":["label":"三段V","stars":2],"details_received":true,"details":[["label":"失敗（一人残留）","points":-7],["label":"失敗ガード（3段）","points":4]],"unlabelled_reasons":0,"invalid_reasons":0]
        }
        matchPlayers.append(hunter);matchSummary["players"] = matchPlayers;match["summary"] = matchSummary
        var data: Any = [:]
        var status = 200
        func mojinDetails(current: Bool = false) -> [[String:Any]] {
            [("total_kill_monster_count","異象累計撃破数",0),
             ("total_kill_ai_survivor_count","配役探索者累計撃破数",0),
             ("total_put_panel_count","木の板を落とした回数",0),
             ("total_break_panel_count","木の板を破壊した回数",0),
             ("total_kill_boss_count","エンディングクリア回数",0),
             ("total_bring_out_item_count","累計詞章解明数",current ? 0 : 3),
             ("total_move_distance","累計移動距離",current ? 0 : 61)].map { field,label,value in
                ["field":field,"label":label,"value":value,"display_value":field == "total_move_distance" ? "\(value) m" : String(value)]
            }
        }
        func mojinCareers(current: Bool = false) -> [String:Any] {
            let missing = ProcessInfo.processInfo.arguments.contains("--ui-mojin-careers-unavailable")
            let items: [[String:Any]] = current || missing ? [] : [["career_id":1,"name":"智者","asset":"career-mojin-1","use_count":2]]
            return ["label":"常用職業","status":missing ? "unavailable" : "available","items":items]
        }
        func mojinWeapons(current: Bool = false) -> [String:Any] {
            guard ProcessInfo.processInfo.arguments.contains("--ui-mojin-weapons") else { return [:] }
            let missing = ProcessInfo.processInfo.arguments.contains("--ui-mojin-weapons-unavailable")
            let empty = ProcessInfo.processInfo.arguments.contains("--ui-mojin-weapons-empty")
            let partial = ProcessInfo.processInfo.arguments.contains("--ui-mojin-weapons-partial")
            let items: [[String:Any]] = current || missing || empty ? [] : partial ? [["item_id":99999999,"recorded_count":1]] : [["item_id":60012001,"name":"庇護者の杖","asset":"item-mojin-60012001","recorded_count":9],["item_id":60012002,"name":"燃える怨恨","asset":"item-mojin-60012002","recorded_count":3]]
            return ["label":"得意武器","status":missing ? "unavailable" : partial ? "partial" : "available","items":items]
        }
        func mojinStreak(scope: String) -> [String:Any] {
            guard ProcessInfo.processInfo.arguments.contains("--ui-mojin-streak") else { return [:] }
            if scope == "all" { return ["label":"最長連続真相解明回数","status":"unverified_period"] }
            if ProcessInfo.processInfo.arguments.contains("--ui-mojin-streak-unavailable") { return ["label":"最長連続真相解明回数","status":"unavailable"] }
            return ["label":"最長連続真相解明回数","status":"received","value":scope == "current" ? 0 : 1]
        }
        func mojinParticipation(scope: String) -> [String:Any] {
            guard ProcessInfo.processInfo.arguments.contains("--ui-mojin-participation") else { return [:] }
            var result: [String:Any] = ["label":"サバイバー/ハンターモード累計参加回数","hunter":0]
            if !ProcessInfo.processInfo.arguments.contains("--ui-mojin-participation-missing") { result["survivor"] = scope == "current" ? 0 : 2 }
            return result
        }
        switch path {
        case "/v1/session/import":
            if ProcessInfo.processInfo.arguments.contains("--ui-session-import-rejected") { status = 400;data = ["error":["code":"SESSION_CODE_INVALID","message":"PC用EXEで取得した接続コードを貼り付けてください。"]] }
            else { data = ["stored":true,"verified":false] }
        case "/v1/session/connect": data = ["connected":true,"push_configured":false]
        case "/v1/status":
            if ProcessInfo.processInfo.arguments.contains("--ui-login-rejected") {
                let unknown = ProcessInfo.processInfo.arguments.contains("--ui-login-rejected-other")
                data = ["connected":false,"push_configured":false,"last_error":unknown ? "GAME_LOGIN_REJECTED" : "SDK_AUTH_REJECTED","session_recovery":["login_failure":["reason":unknown ? "login_rejected" : "sdk_auth_failed","server_code":unknown ? 999 : 6]]]
            } else { data = ["connected":true,"push_configured":false] }
        case "/v1/me": data = ["data":profile]
        case "/v1/me/mojin/history", "/v1/players/30/mojin/history":
            if ProcessInfo.processInfo.arguments.contains("--ui-mojin-history-error") { status = 502;data = ["error":["code":"MOJIN_HISTORY_UNAVAILABLE","message":"手記の加筆の自己戦績を取得できませんでした。"]] }
            else { data = ["data":["scope":"self","total_received":1,"received_at":"2026-11-05T23:00:00Z","items":[["record_id":"fixture-mojin","mode_name":"手記の加筆（サバイバー）","map_name":"災いの女","map_asset":"map-mojin-1","result_label":"失敗","duration_seconds":43,"started_at":"2026-10-13T00:00:00Z","ended_at":"2026-10-13T00:00:55Z","players":[["player_id":"30","name":"集計相手","character_name":"医師","career_name":"智者","career_asset":"career-mojin-1","survive_time_seconds":26.19,"deliver_value":0,"result_label":"失敗"]]]]]] }
        case "/v1/me/mojin", "/v1/players/30/mojin":
            if ProcessInfo.processInfo.arguments.contains("--ui-mojin-unavailable") { status = 409; data = ["error":["code":"MOJIN_SELF_DATA_UNAVAILABLE","message":"手記の加筆の自己データは未受信です。"]] }
            else { data = ["data":["mode_name":"手記の加筆","scope":"self","received_at":"2026-11-05T22:00:00Z","season_name":"S1-燐光症","current_rank":["label":"一段III","asset":"rank-mojin-1","stars":0,"season_id":1],"highest_rank":["label":"一段III","asset":"rank-mojin-1","stars":0],"statistics":[["scope":"all","participation_counts":mojinParticipation(scope:"all"),"longest_success_streak":mojinStreak(scope:"all"),"total_actions":2,"success_rate":50,"total_deliver_value":18600,"average_duration_seconds":21,"additional_statistics":mojinDetails(),"frequent_careers":mojinCareers(),"favorite_weapons":mojinWeapons(),"survivor":["successful":1,"failed":1],"hunter":["successful":0,"failed":0]],["scope":"current","participation_counts":mojinParticipation(scope:"current"),"longest_success_streak":mojinStreak(scope:"current"),"season_id":1,"total_actions":0,"total_deliver_value":0,"additional_statistics":mojinDetails(current:true),"frequent_careers":mojinCareers(current:true),"favorite_weapons":mojinWeapons(current:true),"survivor":["successful":0,"failed":0],"hunter":["successful":0,"failed":0]],["scope":"season","participation_counts":mojinParticipation(scope:"season"),"longest_success_streak":mojinStreak(scope:"season"),"season_id":0,"total_actions":2,"success_rate":50,"total_deliver_value":18600,"average_duration_seconds":21,"additional_statistics":mojinDetails(),"frequent_careers":mojinCareers(),"favorite_weapons":mojinWeapons(),"survivor":["successful":1,"failed":1],"hunter":["successful":0,"failed":0]]]]] }
        case "/v1/players/20": data = ["data":profile]
        case "/v1/players/30":
            Self.attemptLock.lock();Self.profileAttempts += 1;let attempt = Self.profileAttempts;Self.attemptLock.unlock()
            if ProcessInfo.processInfo.arguments.contains("--ui-profile-fails-once"),attempt == 1 {
                status = 504;data = ["error":["code":"GAME_RESPONSE_TIMEOUT","message":"ゲームサーバーから応答がありません。再読み込みしてください。"]]
            } else { data = ["data":peerProfile] }
        case "/v1/players/31":
            var other = peerProfile;other["player_id"] = "31";other["name"] = "履歴の別プレイヤー";data = ["data":other]
        case "/v1/players/31/history": data = ["data":["items":[]]]
        case "/v1/players/30/history": data = ["data":["items":[]]]
        case "/v1/players/20/history":
            let mode = URLComponents(url:request.url!,resolvingAgainstBaseURL:false)?.queryItems?.first { $0.name == "mode" }?.value
            if mode == "custom" { var custom = match;custom["record_id"] = "custom-demo";data = ["data":["items":[custom]]] }
            else if ["rank","duo","mojin","other"].contains(mode ?? "") { data = ["data":["items":[]]] }
            else { data = ["data":["items":[match]]] }
        case "/v1/players/20/analysis":
            let mode = URLComponents(url:request.url!,resolvingAgainstBaseURL:false)?.queryItems?.first { $0.name == "mode" }?.value ?? "all"
            data = ["data":AnalysisFixture.data(mode:mode,unavailable:ProcessInfo.processInfo.arguments.contains("--ui-analysis-unavailable"),peer:peer)]
        case "/v1/players/20/badges/history": data = ["data":["access":"self","items":[historicalBadge],"total_received":1]]
        case "/v1/friends": data = ["data":[profile]]
        case "/v1/players/20/persona":
            Self.attemptLock.lock();Self.personaAttempts += 1;let attempt = Self.personaAttempts;Self.attemptLock.unlock()
            let revoked = ProcessInfo.processInfo.arguments.contains("--ui-persona-revoked") && attempt > 1
            if revoked || ProcessInfo.processInfo.arguments.contains("--ui-persona-private") {
                status = 409;data = ["error":["code":"PERSONA_PERMISSION_UNKNOWN","message":"人格の公開範囲を確認できません。"]]
            } else {
                let id = Int(URLComponents(url:request.url!,resolvingAgainstBaseURL:false)?.queryItems?.first { $0.name == "character_id" }?.value ?? "14") ?? 14
                data = ["data":["player_id":"20","character_id":id,"access":"permitted","status":"received","used_points":5,"items":[["id":1,"level":1,"name":"群集心理","asset":"persona-survivor-1-1"]]]]
            }
        case "/v1/catalog": data = ["data":["characters":["14":["id":14,"name":"医師","camp":"survivor","asset":"character-14"],"15":["id":15,"name":"弁護士","camp":"survivor","asset":"character-15"]]]]
        case "/v1/rankings":
            let character = URLComponents(url:request.url!,resolvingAgainstBaseURL:false)?.queryItems?.first { $0.name == "character_id" }?.value
            let score = character == "15" ? 12345 : 14487
            data = ["data":["items":[["position":1,"player_id":"20","name":"表示テスト","character_score":score]]]]
        case "/v1/players/20/presence": data = ["data":["state":"online","visibility":"visible"],"fresh":true]
        case "/v1/watches", "/v1/events": data = ["data":[]]
        case "/v1/notifications/settings": data = ["data":[:]]
        case "/v1/chat/rooms": data = ["data":["server":"asia","current_room":"3","rooms":[["id":"3","name":"日本語"]]]]
        case "/v1/chat/global", "/v1/friends/20/chat":
            if request.httpMethod == "POST" { data = ["data":["accepted":true]] }
            else {
                let messages: [[String:Any]] = (1...100).map { ["message_id":"fixture-\($0)","sequence":$0,"content":"表示確認メッセージ \($0)","sent_at":"2026-11-05T12:00:00Z","author":["player_id":"20","name":"表示テスト","face_id":8,"face_frame_id":1]] }
                data = ["data":["items":messages]]
            }
        default: status = 404; data = ["error":["code":"FIXTURE_ONLY","message":"表示テスト"]]
        }
        let bytes = try! JSONSerialization.data(withJSONObject:data)
        let response = HTTPURLResponse(url:request.url!,statusCode:status,httpVersion:nil,headerFields:["Content-Type":"application/json"])!
        let delivery = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.deliveryLock.lock();let stopped = self.stopped;self.deliveryLock.unlock()
            guard !stopped else { return }
            self.client?.urlProtocol(self,didReceive:response,cacheStoragePolicy:.notAllowed)
            self.client?.urlProtocol(self,didLoad:bytes);self.client?.urlProtocolDidFinishLoading(self)
        }
        deliveryLock.lock();pendingDelivery = delivery;deliveryLock.unlock()
        if path == "/v1/players/30",ProcessInfo.processInfo.arguments.contains("--ui-profile-slow") {
            DispatchQueue.main.asyncAfter(deadline:.now()+0.75,execute:delivery)
        } else { delivery.perform() }
    }
    override func stopLoading() { deliveryLock.lock();stopped = true;let delivery = pendingDelivery;deliveryLock.unlock();delivery?.cancel() }
}
#endif
