import SwiftUI

struct MatchInsightsView: View {
    let data: JSONValue
    let mode: String
    @State private var recent = 10
    private var exploration: Bool { mode == "mojin" }
    private var sample: JSONValue? { data["recent"].array.first { $0["requested_matches"].number == Double(recent) } }
    private var currentStreak: String {
        let row = data["streaks"]["current"]
        guard let count = row["count"].text else { return "未確認" }
        switch row["kind"].text {
        case "win": return "\(count)連\(exploration ? "続成功" : "勝")"
        case "loss": return "\(count)連\(exploration ? "続失敗" : "敗")"
        case "none": return "継続なし（直近は引分）"
        default: return "未確認"
        }
    }
    var body: some View {
        IDVPage {
            IDVHeading(title:"成績の推移")
            Text("\(modeName) · 取得できた\(data["total"].text ?? "—")試合から計算")
                .font(Theme.font(12)).foregroundStyle(Theme.muted)
            Text("サーバーが返した範囲の集計です。過去の全試合の記録ではありません。勝率は結果が判明した試合を分母にし、引分を含めます。")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
            IDVSectionHeading(title:"直近の成績")
            Picker("集計する試合数",selection:$recent) {
                ForEach([10,20,50],id:\.self) { Text("\($0)試合").tag($0) }
            }.pickerStyle(.segmented).accessibilityIdentifier("recent-window")
            if let sample {
                IDVValueRow(title:"集計対象",value:"直近\(sample["total"].text ?? "—")試合")
                IDVValueRow(title:exploration ? "探索成功率" : "勝率",value:percent(sample["win_rate"]))
                IDVValueRow(title:exploration ? "成功 / 引分 / 失敗" : "勝利 / 引分 / 敗北",value:"\(sample["win"].text ?? "—") / \(sample["draw"].text ?? "—") / \(sample["loss"].text ?? "—")")
                Text("結果判明 \(sample["known_results"].text ?? "0")試合・不明 \(sample["unknown"].text ?? "0")試合")
                    .font(Theme.font(11)).foregroundStyle(Theme.muted)
            } else {
                Text("終了日時から試合順を確認できないため、直近成績は集計できません。")
                    .font(Theme.font(12)).foregroundStyle(Theme.muted)
            }
            IDVSectionHeading(title:exploration ? "連続成功・失敗" : "連勝・連敗")
            IDVValueRow(title:"直近の継続",value:currentStreak)
            IDVValueRow(title:exploration ? "取得範囲の最長連続成功" : "取得範囲の最長連勝",value:streakCount("longest_win"))
            IDVValueRow(title:exploration ? "取得範囲の最長連続失敗" : "取得範囲の最長連敗",value:streakCount("longest_loss"))
            Text("引分と結果不明で継続を区切ります。日時が欠ける場合や試合順を確定できない場合は未確認になります。")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
            IDVSectionHeading(title:"本人の得点・MVP",detail:"選択モードの取得全試合")
            performance(data["self_performance"])
            IDVSectionHeading(title:"時間帯別の成績")
            Text("試合の終了時刻で集計 · \(data["hourly"]["time_zone"].text ?? "未確認")")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
            ForEach(Array(data["hourly"]["items"].array.enumerated()),id:\.offset) { _, row in
                HStack(alignment:.top) {
                    Text(String(format:"%02d時台",Int(row["hour"].number ?? 0))).font(Theme.font(13,.medium))
                    Spacer()
                    VStack(alignment:.trailing,spacing:4) {
                        Text("\(row["total"].text ?? "—")試合 · \(percent(row["win_rate"]))").font(Theme.font(13))
                        Text("\(row["win"].text ?? "—")\(exploration ? "成功" : "勝") / \(row["draw"].text ?? "—")分 / \(row["loss"].text ?? "—")\(exploration ? "失敗" : "敗") · 不明\(row["unknown"].text ?? "0")")
                            .font(Theme.font(10)).foregroundStyle(Theme.muted)
                    }
                }.padding(.vertical,6)
            }
            if data["hourly"]["items"].array.isEmpty { Text("日時を確認できた試合がありません").font(Theme.font(12)).foregroundStyle(Theme.muted) }
            if let count = data["hourly"]["undated_matches"].number,count > 0 {
                Text("終了日時が未取得の\(Int(count))試合は時間帯の集計に含めていません。")
                    .font(Theme.font(11)).foregroundStyle(Theme.muted)
            }
        }.navigationTitle("分析").navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
    }
    private func performance(_ row: JSONValue) -> some View {
        VStack(alignment:.leading,spacing:10) {
            IDVValueRow(title:"平均得点",value:row["average_score"].number.map { $0.formatted(.number.precision(.fractionLength(1))) } ?? "未取得")
            Text("得点を確認できた\(row["scored_matches"].text ?? "0")試合を集計")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
            IDVValueRow(title:"MVP率",value:percent(row["mvp_rate"]))
            Text("\(row["mvp_count"].text ?? "0")回 / 判定取得\(row["mvp_known_matches"].text ?? "0")試合 · 未取得\(row["mvp_unknown_matches"].text ?? "0")試合")
                .font(Theme.font(11)).foregroundStyle(Theme.muted)
        }
    }
    private func percent(_ value: JSONValue) -> String { value.number.map { String(format:"%.1f%%",$0) } ?? "未取得" }
    private func streakCount(_ key: String) -> String { data["streaks"][key].text.map { "\($0)回" } ?? "未確認" }
    private var modeName: String { ["all":"全て（カスタム除外）","multi":"マルチ","rank":"ランク","duo":"28","mojin":"手記","custom":"カスタム","other":"その他"][mode] ?? "選択モード" }
}
