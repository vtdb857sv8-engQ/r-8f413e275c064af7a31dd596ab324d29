import SwiftUI

struct MojinHistoryView: View {
    var playerId: String? = nil
    @EnvironmentObject var model: AppModel
    @State private var data: JSONValue?
    @State private var failure: String?
    @State private var loading = false
    var body: some View {
        IDVPage {
            IDVHeading(title:"探索の戦績")
            if loading { ProgressView("戦績を取得中") }
            if let failure { Text(failure).font(Theme.font(12)).foregroundStyle(Theme.muted) }
            if let data {
                IDVSectionHeading(title:"手記の加筆",detail:"\(data["total_received"].text ?? "—")件")
                if data["items"].array.isEmpty { Text("返された戦績はありません").font(Theme.font(13)).foregroundStyle(Theme.muted) }
                ForEach(Array(data["items"].array.enumerated()),id:\.offset) { index,record in
                    NavigationLink { MojinRecordDetailView(record:record) } label: {
                        HStack(spacing:12) {
                            GameArt(key:record["map_asset"].text,size:54)
                            VStack(alignment:.leading,spacing:6) {
                                Text(record["map_name"].text ?? "マップ名未取得").font(Theme.font(15,.medium))
                                Text(record["mode_name"].text ?? "モード名未取得").font(Theme.font(11)).foregroundStyle(Theme.muted)
                                Text(DateText.string(record["ended_at"].text)).font(Theme.font(10)).foregroundStyle(Theme.muted)
                            }
                            Spacer(minLength:0)
                            Text(record["result_label"].text ?? "結果未取得").font(Theme.font(13,.medium)).foregroundStyle(Theme.warning)
                            Image(systemName:"chevron.right").font(Theme.font(10)).foregroundStyle(Theme.muted)
                        }.foregroundStyle(Theme.text).padding(.vertical,10).contentShape(Rectangle())
                    }.accessibilityIdentifier("mojin-record-\(index)")
                    Divider().overlay(Theme.line)
                }
                Text("サーバーから返された範囲 · \(DateText.string(data["received_at"].text))").font(Theme.font(10)).foregroundStyle(Theme.muted)
            }
            Button("再読み込み") { Task { await load() } }.buttonStyle(IDVActionStyle(primary:false)).disabled(loading)
        }.navigationTitle(playerId == nil ? "自分の探索戦績" : "探索の戦績").navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
            .task { await load() }.refreshable { await load() }
    }
    private func load() async {
        guard let client = model.client,!loading else { return }
        loading = true;failure = nil;data = nil
        defer { loading = false }
        do { let value: JSONValue = try await client.data(playerId.map { "/v1/players/\($0)/mojin/history" } ?? "/v1/me/mojin/history");try Task.checkCancellation();data = value }
        catch { if !Task.isCancelled { failure = error.localizedDescription } }
    }
}

struct MojinRecordDetailView: View {
    let record: JSONValue
    var body: some View {
        IDVPage {
            IDVHeading(title:record["map_name"].text ?? "探索の詳細")
            if let asset = record["map_asset"].text { MatchMapPreview(key:asset) }
            IDVValueRow(title:"モード",value:record["mode_name"].text ?? "未取得")
            IDVValueRow(title:"結果",value:record["result_label"].text ?? "未取得")
            IDVValueRow(title:"開始日時",value:DateText.string(record["started_at"].text))
            IDVValueRow(title:"終了日時",value:DateText.string(record["ended_at"].text))
            IDVValueRow(title:"探索時間",value:duration(record["duration_seconds"]))
            IDVSectionHeading(title:"参加プレイヤー",detail:"\(record["players"].array.count)人")
            ForEach(Array(record["players"].array.enumerated()),id:\.offset) { index,player in
                VStack(alignment:.leading,spacing:7) {
                    if player["player_id"].text != nil {
                        NavigationLink { ParticipantView(participant:player) } label: { playerHeading(player) }.accessibilityIdentifier("mojin-player-\(index)")
                    } else { playerHeading(player) }
                    HStack(spacing:6) {
                        GameArt(key:player["career_asset"].text,size:22,showsMissing:false)
                        Text(player["career_name"].text ?? "職業未取得").font(Theme.font(12)).foregroundStyle(Theme.muted)
                    }
                    IDVValueRow(title:"結果",value:player["result_label"].text ?? "未取得")
                    IDVValueRow(title:"詞章価値",value:player["deliver_value"].number.map { $0.formatted(.number.precision(.fractionLength(0))) } ?? "未取得")
                    IDVValueRow(title:"生存時間",value:duration(player["survive_time_seconds"]))
                }.padding(.vertical,10)
                Divider().overlay(Theme.line)
            }
        }.navigationTitle("探索の詳細").navigationBarTitleDisplayMode(.inline).toolbar(.visible,for:.navigationBar)
    }
    private func playerHeading(_ player: JSONValue) -> some View {
        HStack(spacing:10) {
            AvatarArtwork(portrait:player["portrait"].text,frame:player["frame"].text,size:44)
            VStack(alignment:.leading,spacing:4) {
                Text(player["name"].text ?? "名前未取得").font(Theme.font(14,.medium))
                Text(player["character_name"].text ?? "キャラクター名未取得").font(Theme.font(11)).foregroundStyle(Theme.muted)
            }
            Spacer()
            if player["is_self"].flag == true { Text("本人").font(Theme.font(10)).foregroundStyle(Theme.warning) }
            if player["player_id"].text != nil { Image(systemName:"chevron.right").font(Theme.font(10)).foregroundStyle(Theme.muted) }
        }.foregroundStyle(Theme.text).frame(maxWidth:.infinity).contentShape(Rectangle())
    }
    private func duration(_ value: JSONValue) -> String { value.number.map { "\(Int($0) / 60)分\(Int($0) % 60)秒" } ?? "未取得" }
}
