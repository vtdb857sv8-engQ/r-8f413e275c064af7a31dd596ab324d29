// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "ManorLinkCore", platforms: [.macOS(.v13), .iOS(.v16)], products: [.library(name: "ManorLinkCore", targets: ["ManorLinkCore"])], targets: [.target(name: "ManorLinkCore", path: "Sources/Core"), .testTarget(name: "ManorLinkCoreTests", dependencies: ["ManorLinkCore"], path: "Tests")])
