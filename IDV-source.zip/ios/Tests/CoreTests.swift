import XCTest
@testable import ManorLinkCore
final class CoreTests: XCTestCase {
    func testRankPeakAssetAndChatAppearanceRemainReceivedFields() throws {
        let rank = try JSONDecoder().decode(Ranking.self,from:Data("{\"position\":1,\"player_id\":\"1\",\"part\":7,\"rank\":{\"asset\":\"rank-survivor-peak\",\"stars\":25}}".utf8))
        XCTAssertEqual(rank.rankAsset("survivor"),"rank-survivor-peak");XCTAssertEqual(rank.rankLabel,"★25")
        let missing = try JSONDecoder().decode(Ranking.self,from:Data("{\"position\":1,\"player_id\":\"1\",\"part\":7}".utf8))
        XCTAssertEqual(missing.rankLabel,"星数未取得")
        let message = try JSONDecoder().decode(ChatMessage.self,from:Data("{\"sequence\":1,\"content\":\"test\",\"author\":{\"player_id\":\"2\",\"face_id\":8,\"face_frame_id\":1}}".utf8))
        XCTAssertEqual(message.author.faceId,8);XCTAssertEqual(message.author.frameId,1)
    }
    func testAdditionalProfileFieldsAndMatchOwnerUseReceivedValues() throws {
        let p = try JSONDecoder().decode(Profile.self,from:Data("{\"player_id\":\"1\",\"mvp\":12,\"character_num\":8,\"battle_count\":120}".utf8))
        XCTAssertEqual(p.mvp,12); XCTAssertEqual(p.characterCount,8); XCTAssertEqual(p.battleCount,120)
        let r = try JSONDecoder().decode(MatchRecord.self,from:Data("{\"common_info\":{\"battle_id\":\"server-battle\",\"start_time\":100,\"end_time\":340},\"summary\":{\"players\":[{\"is_self\":false,\"name\":\"other\"},{\"is_self\":true,\"name\":\"owner\",\"score\":1200}]}}".utf8))
        XCTAssertEqual(r.id,"server-battle"); XCTAssertEqual(r.startedAt,Date(timeIntervalSince1970:100)); XCTAssertEqual(r.selfPlayer?["name"].text,"owner")
    }
    func testHistoryKeepsAcceptedPageOnNetworkFailureAndClearsOnPrivacyChange() throws {
        let page = try JSONDecoder().decode(Page<MatchRecord>.self,from:Data("{\"items\":[{\"record_id\":\"battle-a\"}],\"next_cursor\":\"30\"}".utf8))
        var state = MatchHistoryState(); state.accept(page,more:false)
        state.fail(code:nil,message:"通信失敗")
        XCTAssertEqual(state.items.map(\.id),["battle-a"]); XCTAssertEqual(state.nextCursor,"30"); XCTAssertTrue(state.stale)
        state.accept(page,more:true); XCTAssertEqual(state.items.count,1); XCTAssertFalse(state.stale)
        for code in ["HISTORY_PRIVATE","HISTORY_PERMISSION_UNKNOWN","MOJIN_DATA_PRIVATE","MOJIN_PERMISSION_UNKNOWN"] {
            state.accept(page,more:false); state.fail(code:code,message:"表示不可")
            XCTAssertTrue(state.items.isEmpty); XCTAssertNil(state.nextCursor); XCTAssertFalse(state.stale)
        }
        let empty = try JSONDecoder().decode(Page<MatchRecord>.self,from:Data("{\"items\":[]}".utf8))
        state.accept(page,more:false); state.accept(empty,more:false); XCTAssertTrue(state.items.isEmpty)
    }
    func testSearchHistorySurvivesRestartDeduplicatesAndDoesNotKeepOldState() throws {
        let p = try JSONDecoder().decode(Profile.self, from: Data("{\"player_id\":\"42\",\"name\":\"テスト\",\"face_id\":7,\"face_frame_id\":8,\"presence\":{\"state\":\"online\"},\"civilian_data\":{\"part\":5}}".utf8))
        let saved = try SearchHistory.encode([p,p])
        XCTAssertEqual(saved,try SearchHistory.encode([p]))
        XCTAssertEqual(saved,try SearchHistory.encode([p,p]))
        let restored = SearchHistory.decode(saved)
        XCTAssertEqual(restored.count, 1)
        XCTAssertEqual(restored[0].playerId, "42")
        XCTAssertEqual(restored[0].displayName, "テスト")
        XCTAssertEqual(restored[0].portraitAsset, "face-7")
        XCTAssertEqual(restored[0].frameAsset, "frame-8")
        XCTAssertNil(restored[0].presence)
        XCTAssertNil(restored[0].civilianData)
        XCTAssertTrue(SearchHistory.decode(Data("broken".utf8)).isEmpty)
    }
    func testEndpointPolicy() throws {
        XCTAssertNoThrow(try EndpointPolicy.validate("https://example.com:8787"))
        XCTAssertNoThrow(try EndpointPolicy.validate("http://192.168.1.20:8787"))
        XCTAssertNoThrow(try EndpointPolicy.validate("http://pc.local:8787"))
        for url in ["http://example.com", "https://secret@example.com", "https://example.com?key=secret", "https://example.com/api", "file:///tmp/x", "http://192.168.999.1"] { XCTAssertThrowsError(try EndpointPolicy.validate(url)) }
    }
    func testRedirectsMustKeepOrigin() throws {
        let u = try EndpointPolicy.validate("https://api.example.com")
        XCTAssertTrue(EndpointPolicy.sameOrigin(u, URL(string: "https://api.example.com:443/v1/me")!))
        XCTAssertFalse(EndpointPolicy.sameOrigin(u, URL(string: "https://evil.example.com/v1/me")!))
        XCTAssertFalse(EndpointPolicy.sameOrigin(u, URL(string: "http://api.example.com/v1/me")!))
    }
    func testPrivacyGroupsMustBePermittedEvenIfPayloadContainsStats() throws {
        for access in ["hidden", "unknown"] {
            let data = Data("{\"player_id\":\"1\",\"field_access\":{\"statistics\":\"\(access)\"},\"civilian_data\":{\"part\":99}}".utf8)
            XCTAssertFalse(try JSONDecoder().decode(Profile.self, from: data).canShowStatistics)
        }
        let p = try JSONDecoder().decode(Profile.self, from: Data("{\"player_id\":\"1\",\"field_access\":{\"statistics\":\"self\"}}".utf8))
        XCTAssertTrue(p.canShowStatistics)
    }
    func testSSECommentsAndEventFraming() throws {
        var parser = SSEParser()
        XCTAssertNil(parser.accept(": heartbeat")); XCTAssertNil(parser.accept("event: presence")); XCTAssertNil(parser.accept("id: 7"))
        XCTAssertNil(parser.accept("data: {\"id\":7,\"player_id\":\"2\",\"previous_state\":\"online\",\"state\":\"offline\",\"observed_at\":\"2026-01-01T00:00:00Z\"}"))
        XCTAssertEqual(parser.accept("")?.id, 7)
        XCTAssertNil(parser.accept(""))
    }
    func testHiddenPresenceLabelDoesNotExposeRealState() throws {
        let p = try JSONDecoder().decode(Presence.self, from: Data("{\"state\":\"online\",\"visibility\":\"hidden\"}".utf8))
        XCTAssertEqual(p.label, "非表示")
    }
    func testVisibilityOnlyEventUsesVisibilityLabels() throws {
        let e = try JSONDecoder().decode(PresenceEvent.self, from: Data("{\"id\":1,\"player_id\":\"2\",\"previous_state\":\"unknown\",\"state\":\"unknown\",\"previous_visibility\":\"hidden\",\"visibility\":\"visible\",\"observed_at\":\"now\"}".utf8))
        XCTAssertEqual(e.changeText, "非表示 → 表示")
    }
    func testServerAndObservedTimestampsStaySeparate() throws {
        let p = try JSONDecoder().decode(Presence.self, from: Data("{\"last_logout_at\":\"2026-01-01T00:00:00Z\",\"last_logout_observed_at\":\"2026-01-01T00:01:00Z\"}".utf8))
        XCTAssertNotEqual(p.lastLogoutAt, p.lastLogoutObservedAt)
    }
    func testDynamicMatchPayload() throws {
        let r = try JSONDecoder().decode(MatchRecord.self, from: Data("{\"record_id\":\"match\",\"common_info\":{\"end_time\":100,\"battle_time_exclude_pause\":60},\"all_pl_info\":[{\"player_name\":\"A\",\"total_score\":1000}]}".utf8))
        XCTAssertEqual(r.id, "match"); XCTAssertEqual(r.duration, 60); XCTAssertEqual(r.players.first?["player_name"].text, "A")
    }
    func testLoginFailureStatusRemainsCompatibleWithOlderResponsesAndClearsWhenConnected() throws {
        let old = try JSONDecoder().decode(ServiceStatus.self,from:Data(#"{"connected":false,"push_configured":false}"#.utf8))
        XCTAssertNil(old.sessionRecovery);XCTAssertNil(old.loginFailureMessage)
        let connected = try JSONDecoder().decode(ServiceStatus.self,from:Data(#"{"connected":true,"push_configured":false,"session_recovery":{"login_failure":{"reason":"sdk_auth_failed","server_code":6}}}"#.utf8))
        XCTAssertNil(connected.loginFailureMessage)
        let unknown = try JSONDecoder().decode(ServiceStatus.self,from:Data(#"{"connected":false,"push_configured":false,"session_recovery":{"login_failure":{"reason":"future_reason"}}}"#.utf8))
        XCTAssertNil(unknown.loginFailureMessage)
    }
    func testSdkFailureShowsAnActionWithoutInferringExpiryOrAccountPunishment() throws {
        let status = try JSONDecoder().decode(ServiceStatus.self,from:Data(#"{"connected":false,"push_configured":false,"session_recovery":{"login_failure":{"reason":"sdk_auth_failed","server_code":6}}}"#.utf8))
        XCTAssertEqual(status.sessionRecovery?.loginFailure?.serverCode,6)
        XCTAssertEqual(status.loginFailureMessage,"SDK認証を確認できません。PC版でログインし直してから接続してください。")
        XCTAssertFalse(status.loginFailureMessage!.contains("期限切れ"));XCTAssertFalse(status.loginFailureMessage!.contains("利用停止"))
    }
}
