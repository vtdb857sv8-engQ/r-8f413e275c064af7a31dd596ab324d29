$ErrorActionPreference = 'Stop'
$idvRoot = Split-Path -Parent $PSScriptRoot
$idvCompiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
if (-not (Test-Path -LiteralPath $idvCompiler)) { throw '.NET Framework C# compiler is unavailable.' }
New-Item -ItemType Directory -Path (Join-Path $idvRoot 'dist') -Force | Out-Null
& $idvCompiler /nologo /target:winexe /platform:x64 /optimize+ /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll ('/out:' + (Join-Path $idvRoot 'dist/IDV-Session-Capture.exe')) (Join-Path $idvRoot 'windows/SessionCapture.cs')
if ($LASTEXITCODE -ne 0) { throw 'Session capture build failed.' }
