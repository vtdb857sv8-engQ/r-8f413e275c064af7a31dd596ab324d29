#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p dist
xcrun simctl list devices available --json > dist/simulators.json
python3 - <<'PY' > dist/test-devices.txt
import json
groups=json.load(open('dist/simulators.json'))['devices']
for runtime in sorted(groups,reverse=True):
    phones=[d for d in groups[runtime] if d.get('isAvailable') and d['name'].startswith('iPhone')]
    if phones:
        small=next((d for d in phones if 'SE' in d['name'] or 'mini' in d['name']),phones[0])
        normal=next((d for d in phones if d['name']=='iPhone 16'),phones[-1])
        for d in {d['udid']:d for d in [small,normal]}.values(): print(d['udid'])
        break
PY
test -s dist/test-devices.txt
while read -r device; do
  set +e
  xcodebuild test -project ios/IDV.xcodeproj -scheme IDV -configuration Debug \
    -destination "platform=iOS Simulator,id=$device" -derivedDataPath dist/SimulatorData \
    -resultBundlePath "dist/chat-$device.xcresult" -parallel-testing-enabled NO \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO 2>&1 | tee -a dist/build.log
  test_status=${PIPESTATUS[0]}
  set -e
  mkdir -p "dist/qa/$device"
  xcrun xcresulttool export attachments --path "dist/chat-$device.xcresult" --output-path "dist/qa/$device"
  (cd dist && /usr/bin/zip -qry chat-layout-qa.zip qa)
  if [ "$test_status" -ne 0 ]; then exit "$test_status"; fi
done < dist/test-devices.txt
xcodebuild -project ios/IDV.xcodeproj -scheme IDV -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath dist/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build 2>&1 | tee -a dist/build.log
app='dist/DerivedData/Build/Products/Release-iphoneos/IDV.app'
test -x "$app/IDV"
/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$app/Info.plist"
xcrun lipo "$app/IDV" -verify_arch arm64
mkdir -p dist/package/Payload
ditto "$app" dist/package/Payload/IDV.app
(cd dist/package && /usr/bin/zip -qry ../IDV-unsigned.ipa Payload)
/usr/bin/unzip -t dist/IDV-unsigned.ipa
shasum -a 256 dist/IDV-unsigned.ipa
# The existing workflow collects this ZIP inside its single build-log artifact.
(cd dist && /usr/bin/zip -qry chat-layout-qa.zip qa)
