param([string]$GameDirectory = 'C:\Loading Bay Games\Identity V')
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Split-Path -Parent $PSScriptRoot)
$assetDirectory = Join-Path (Get-Location) '.data/game-assets'
New-Item -ItemType Directory -Path $assetDirectory -Force | Out-Null
foreach ($entry in @(@('resources/gateway.example.json','.data/gateway.json'),@('resources/game-catalog.json','.data/game-assets/catalog.json'))) {
    if (-not (Test-Path -LiteralPath $entry[1])) { Copy-Item -LiteralPath $entry[0] -Destination $entry[1] }
}
$sourceFile = Join-Path $assetDirectory 'source.json'
if (-not (Test-Path -LiteralPath $sourceFile)) {
    if (-not (Test-Path -LiteralPath (Join-Path $GameDirectory 'res'))) { throw 'Specify the installed game directory with -GameDirectory.' }
    $sourceJson = @{ game_directory = (Resolve-Path -LiteralPath $GameDirectory).Path } | ConvertTo-Json
    [IO.File]::WriteAllText($sourceFile, $sourceJson, (New-Object Text.UTF8Encoding $false))
}
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
$nodePath = if ($nodeCommand) { $nodeCommand.Source } else { Join-Path $env:ProgramFiles 'nodejs/node.exe' }
if (-not (Test-Path -LiteralPath $nodePath)) { throw 'Node.js 24 or later is required.' }
& $nodePath src/cli.mjs init
if ($LASTEXITCODE -ne 0) { throw 'API initialization failed.' }
Write-Output 'Source initialized. Import your own game connection code from the iPhone app.'
