param([string]$ListenAddress = '0.0.0.0', [int]$Port = 8787)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Split-Path -Parent $PSScriptRoot)
if (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) {
    throw "Port $Port is already in use. Close the existing API before starting this script."
}
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
$nodePath = if ($nodeCommand) { $nodeCommand.Source } else { Join-Path $env:ProgramFiles 'nodejs/node.exe' }
if (-not (Test-Path -LiteralPath $nodePath)) { throw 'Node.js 24 or later is required.' }
$env:HOST = $ListenAddress
$env:PORT = [string]$Port
& $nodePath src/main.mjs
