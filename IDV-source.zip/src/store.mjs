import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import path from 'node:path';
import {defaultNotificationRules,notificationRules,shouldNotify,eventTypes} from './notification-rules.mjs';
const concealedPresence=value=>({state:'unknown',visibility:value?.visibility==='hidden'?'hidden':'unknown'});
const publicEvent=event=>({...event,...(['unknown','hidden'].includes(event.previous_visibility)?{previous_state:'unknown'}:{}),...(['unknown','hidden'].includes(event.visibility)?{state:'unknown'}:{})});
export class Store {
  constructor(filename) {
    if (filename !== ':memory:') mkdirSync(path.dirname(filename), { recursive: true, mode: 0o700 });
    this.db = new DatabaseSync(filename);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS watches (player_id TEXT PRIMARY KEY, notify INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS presence (player_id TEXT PRIMARY KEY, state TEXT NOT NULL, observed_at TEXT NOT NULL, last_login_observed_at TEXT, last_logout_observed_at TEXT);
      CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, player_id TEXT NOT NULL, previous_state TEXT NOT NULL, state TEXT NOT NULL, observed_at TEXT NOT NULL, source TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS devices (id TEXT PRIMARY KEY, token TEXT NOT NULL, environment TEXT NOT NULL, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS deliveries (event_id INTEGER NOT NULL REFERENCES events(id), device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, next_attempt INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(event_id,device_id));
      CREATE TABLE IF NOT EXISTS settings (name TEXT PRIMARY KEY, value TEXT NOT NULL);`);
    this.db.exec('CREATE TABLE IF NOT EXISTS player_identities (player_id TEXT PRIMARY KEY, profile TEXT NOT NULL, updated_at TEXT NOT NULL)');
    this.db.exec(`CREATE TABLE IF NOT EXISTS presence_details (player_id TEXT PRIMARY KEY, visibility TEXT, last_login_at TEXT, last_logout_at TEXT, online_stat INTEGER, battle_stat INTEGER);`);
    if(!this.db.prepare('PRAGMA table_info(presence_details)').all().some(x=>x.name==='notice_status'))this.db.exec('ALTER TABLE presence_details ADD COLUMN notice_status INTEGER');
    const eventColumns=new Set(this.db.prepare('PRAGMA table_info(events)').all().map(x=>x.name));
    for(const column of ['previous_visibility','visibility'])if(!eventColumns.has(column))this.db.exec(`ALTER TABLE events ADD COLUMN ${column} TEXT`);
  }
  setting(name, value) {
    if (value === undefined) return this.db.prepare('SELECT value FROM settings WHERE name=?').get(name)?.value ?? null;
    this.db.prepare('INSERT INTO settings VALUES (?,?) ON CONFLICT(name) DO UPDATE SET value=excluded.value').run(name, value);
  }
  watches() { return this.db.prepare('SELECT player_id,notify,created_at FROM watches ORDER BY created_at').all(); }
  notificationSettings(value){
    if(value!==undefined){const updated=notificationRules(value,this.notificationSettings());this.setting('notification_rules',JSON.stringify(updated));return updated;}
    try{return notificationRules(JSON.parse(this.setting('notification_rules')||'{}'));}catch{return {...defaultNotificationRules};}
  }
  watchRules(id,value){
    const key='watch_rules:'+id;
    if(value!==undefined){const updated=notificationRules(value,this.notificationSettings());this.setting(key,JSON.stringify(updated));return updated;}
    try{return notificationRules(JSON.parse(this.setting(key)||'{}'),this.notificationSettings());}catch{return this.notificationSettings();}
  }
  cacheIdentity(profile){
    if(!/^\d{1,20}$/.test(profile?.player_id))return;
    const safe=Object.fromEntries(['player_id','name','face_id','face_frame_id','face_vfx_id'].filter(k=>profile[k]!==undefined).map(k=>[k,profile[k]]));
    this.db.prepare('INSERT INTO player_identities VALUES (?,?,?) ON CONFLICT(player_id) DO UPDATE SET profile=excluded.profile,updated_at=excluded.updated_at').run(safe.player_id,JSON.stringify(safe),new Date().toISOString());
  }
  identity(id){const row=this.db.prepare('SELECT profile FROM player_identities WHERE player_id=?').get(id);return row?JSON.parse(row.profile):{player_id:id,name:null};}
  notificationAllowed(event){return Boolean(this.db.prepare('SELECT notify FROM watches WHERE player_id=?').get(event.player_id)?.notify)&&shouldNotify(event,this.watchRules(event.player_id));}
  watch(id, notify) {
    this.db.prepare('INSERT INTO watches VALUES (?,?,?) ON CONFLICT(player_id) DO UPDATE SET notify=excluded.notify').run(id, notify ? 1 : 0, new Date().toISOString());
  }
  unwatch(id) { this.db.prepare('DELETE FROM watches WHERE player_id=?').run(id);this.db.prepare('DELETE FROM settings WHERE name=?').run('watch_rules:'+id); }
  presence(id) { return this.db.prepare('SELECT * FROM presence WHERE player_id=?').get(id) ?? null; }
  presenceDetails(id){const value=this.db.prepare('SELECT visibility,last_login_at,last_logout_at,online_stat,battle_stat,notice_status AS avatar_notice_status FROM presence_details WHERE player_id=?').get(id);return value?(value.visibility==='visible'?value:{...concealedPresence(value),last_login_observed_at:null,last_logout_observed_at:null}):null;}
  savePresenceDetails(item){
    this.db.prepare(`INSERT INTO presence_details VALUES (?,?,?,?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET visibility=excluded.visibility,last_login_at=excluded.last_login_at,last_logout_at=excluded.last_logout_at,online_stat=excluded.online_stat,battle_stat=excluded.battle_stat,notice_status=excluded.notice_status`).run(item.player_id,item.visibility??null,item.last_login_at??null,item.last_logout_at??null,item.online_stat??null,item.battle_stat??null,item.avatar_notice_status??null);
  }
  observe(id, state, observedAt, source = 'game', details = null) {
    const before = this.presence(id);
    const previousDetails=this.presenceDetails(id);
    // Discard older observations; losing contact must never become an inferred logout.
    if (before && Date.parse(observedAt) <= Date.parse(before.observed_at)) return null;
    const visibilityChanged=before&&details?.visibility!==undefined&&previousDetails?.visibility!=null&&details.visibility!==previousDetails.visibility;
    const changed = before && (before.state !== state || visibilityChanged);
    const online = s => !['offline','unknown'].includes(s);
    let login = before?.last_login_observed_at ?? null, logout = before?.last_logout_observed_at ?? null;
    if (changed && before.state === 'offline' && online(state)) login = observedAt;
    if (changed && online(before.state) && state === 'offline') logout = observedAt;
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db.prepare(`INSERT INTO presence VALUES (?,?,?,?,?) ON CONFLICT(player_id) DO UPDATE SET state=excluded.state,observed_at=excluded.observed_at,last_login_observed_at=excluded.last_login_observed_at,last_logout_observed_at=excluded.last_logout_observed_at`).run(id,state,observedAt,login,logout);
      if(details)this.savePresenceDetails(details);
      let event = null;
      if (changed) {
        const result = this.db.prepare('INSERT INTO events(player_id,previous_state,state,observed_at,source,previous_visibility,visibility) VALUES (?,?,?,?,?,?,?)').run(id,before.state,state,observedAt,source,previousDetails?.visibility??null,details?.visibility??previousDetails?.visibility??null);
        event = this.db.prepare('SELECT * FROM events WHERE id=?').get(result.lastInsertRowid);
        if (this.notificationAllowed(event))
          this.db.prepare(`INSERT INTO deliveries(event_id,device_id,status) SELECT ?,id,'pending' FROM devices`).run(event.id);
      }
      this.db.exec('COMMIT'); return event?{...publicEvent(event),event_types:eventTypes(event),notification_selected:this.notificationAllowed(event)}:null;
    } catch (error) { this.db.exec('ROLLBACK'); throw error; }
  }
  events(after = 0, limit = 100, playerId) {
    const rows=playerId ? this.db.prepare('SELECT * FROM events WHERE id>? AND player_id=? ORDER BY id LIMIT ?').all(after,playerId,limit) : this.db.prepare('SELECT * FROM events WHERE id>? ORDER BY id LIMIT ?').all(after,limit);
    return rows.map(event=>({...publicEvent(event),event_types:eventTypes(event),notification_selected:this.notificationAllowed(event)}));
  }
  registerDevice(id,token,environment) {
    this.db.prepare('INSERT INTO devices VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET token=excluded.token,environment=excluded.environment').run(id,token,environment,new Date().toISOString());
  }
  deleteDevice(id) { this.db.prepare('DELETE FROM devices WHERE id=?').run(id); }
  pendingDeliveries() { return this.db.prepare(`SELECT deliveries.*,devices.token,devices.environment,events.player_id,events.previous_state,events.state,events.observed_at,events.previous_visibility,events.visibility FROM deliveries JOIN devices ON devices.id=deliveries.device_id JOIN events ON events.id=deliveries.event_id WHERE deliveries.status='pending' AND deliveries.next_attempt<=? ORDER BY deliveries.event_id LIMIT 50`).all(Date.now()); }
  delivered(eventId, deviceId, status, retryAt = 0) { this.db.prepare('UPDATE deliveries SET status=?,attempts=attempts+1,next_attempt=? WHERE event_id=? AND device_id=?').run(status,retryAt,eventId,deviceId); }
  close() { this.db.close(); }
}
