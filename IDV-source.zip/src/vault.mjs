import { execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import path from 'node:path';
// CurrentUser DPAPI: encrypted data is usable only under the same Windows account.
// Secrets pass through stdin/stdout pipes and are never command-line arguments.
export class WindowsVault {
  constructor(directory) { this.directory = directory; }
  crypt(operation, input) {
    if (process.platform !== 'win32') throw new Error('Windows DPAPI is required; provide a platform vault for other systems.');
    const script = `Add-Type -AssemblyName System.Security; $s=[Console]::In.ReadToEnd(); $e=[Text.Encoding]::UTF8; ${operation === 'protect'
      ? '$b=$e.GetBytes($s); $v=[Security.Cryptography.ProtectedData]::Protect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write([Convert]::ToBase64String($v))'
      : '$b=[Convert]::FromBase64String($s); $v=[Security.Cryptography.ProtectedData]::Unprotect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write($e.GetString($v))'}`;
    try { return execFileSync('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script], { input, encoding: 'utf8', windowsHide: true, timeout: 15000, maxBuffer: 1024 * 1024, stdio: ['pipe', 'pipe', 'pipe'] }); }
    catch { throw new Error('DPAPI vault operation failed. No secret was logged.'); }
  }
  filename(name) {
    if (!/^[a-z][a-z0-9-]*$/.test(name)) throw new Error('Invalid vault name');
    return path.join(this.directory, `${name}.dpapi`);
  }
  has(name) { return existsSync(this.filename(name)); }
  set(name, value) {
    mkdirSync(this.directory, { recursive: true, mode: 0o700 });
    const target = this.filename(name), tmp = `${target}.tmp`;
    writeFileSync(tmp, this.crypt('protect', JSON.stringify(value)), { mode: 0o600 });
    renameSync(tmp, target);
  }
  get(name) {
    if (!this.has(name)) return null;
    return JSON.parse(this.crypt('unprotect', readFileSync(this.filename(name), 'utf8')));
  }
}
