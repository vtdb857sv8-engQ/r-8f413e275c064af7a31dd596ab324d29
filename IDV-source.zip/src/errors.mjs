export class ApiError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
export function requireText(value, label, max = 100) {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\x00-\x1f]/.test(value))
    throw new ApiError(400, 'INVALID_INPUT', `${label}の形式が不正です。`);
  return value.trim();
}
