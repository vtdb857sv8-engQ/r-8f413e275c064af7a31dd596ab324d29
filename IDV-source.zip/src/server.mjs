import http from 'node:http';
import https from 'node:https';
import { createHash, timingSafeEqual } from 'node:crypto';
import { ApiError, requireText } from './errors.mjs';
import {presentProfile,presentMatch,presentHistoryBadges,analyzeMatches,rankOf} from './game/presentation.mjs';
import {presentMojinSelf} from './game/mojin-data.mjs';
import {presentMojinRecords} from './game/mojin-records.mjs';
import {modeRecords} from './game/mode-records.mjs';
import {modeFilter} from './game/match-modes.mjs';
import {analysisTimeZone} from './game/match-insights.mjs';
import {sessionCodeCredentials} from './session-code.mjs';
import {presentPersona} from './game/persona.mjs';
const hash = text => createHash('sha256').update(text).digest();
const integer = (s, fallback, min, max) => {
  if(s===null||s===undefined)return fallback;
  if(!/^\d+$/.test(s)||!Number.isSafeInteger(Number(s))||Number(s)<min||Number(s)>max)throw new ApiError(400,'INVALID_INPUT','数値パラメータが範囲外です。');
  return Number(s);
};
const playerId = value => {
  if(!/^\d{1,20}$/.test(value))throw new ApiError(400,'INVALID_PLAYER_ID','数字のプレイヤーIDを指定してください。');return value;
};
async function body(req) {
  if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||''))throw new ApiError(415,'JSON_REQUIRED','Content-Type: application/json を指定してください。');
  if(Number(req.headers['content-length'])>16384){req.resume();throw new ApiError(413,'BODY_TOO_LARGE','本文が大きすぎます。');}
  let length=0;const chunks=[];
  for await(const b of req){length+=b.length;if(length>16384)throw new ApiError(413,'BODY_TOO_LARGE','本文が大きすぎます。');chunks.push(b);}
  try{const value=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();return value;}
  catch{throw new ApiError(400,'INVALID_JSON','JSONオブジェクトを指定してください。');}
}
export function createApi({store,provider,monitor,vault,apiKey,openapi,tls=null,assets=null}) {
  if(typeof apiKey!=='string'||apiKey.length<32)throw new Error('A strong API key is required.');
  const expected=hash(apiKey),streams=new Set();let sessionMutation=Promise.resolve();
  const serial = fn => { const next=sessionMutation.then(fn,fn);sessionMutation=next.catch(()=>{});return next; };
  const handler=async(req,res)=>{
    const json=(status,data)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(JSON.stringify(data));};
    try{
      const url=new URL(req.url,'http://localhost');const p=url.pathname,method=req.method;
      if(p==='/health'&&method==='GET')return json(200,{status:'ok',service:'identity-v-companion-api'});
      if(!timingSafeEqual(hash((req.headers.authorization||'').replace(/^Bearer /,'')),expected))throw new ApiError(401,'UNAUTHORIZED','API認証が必要です。');
      if(req.headers.origin)throw new ApiError(403,'NATIVE_CLIENT_ONLY','このAPIはネイティブクライアント用です。');
      if(method==='GET'&&p==='/openapi.json')return json(200,openapi);
      if(method==='GET'&&p==='/v1/catalog')return json(200,{data:assets?.publicCatalog()??{characters:{},maps:{},asset_count:0}});
      const assetPath=p.match(/^\/v1\/assets\/([a-z0-9-]+)\.png$/);
      if(method==='GET'&&assetPath){if(!assets)throw new ApiError(404,'GAME_ASSET_UNAVAILABLE','ゲーム内素材が未設定です。');const image=assets.image(assetPath[1]);res.writeHead(200,{'content-type':'image/png','cache-control':'private, max-age=86400','x-content-type-options':'nosniff','content-length':image.length});res.end(image);return;}
      if(method==='GET'&&p==='/v1/status')return json(200,{service:'identity-v-companion-api',...monitor.status(),credentials_stored:vault.has('game-session'),independent_game_connection_verified:Boolean(provider.independentVerified)});
      if(p==='/v1/notifications/settings'&&method==='GET')return json(200,{data:store.notificationSettings()});
      if(p==='/v1/notifications/settings'&&method==='PUT')return json(200,{data:store.notificationSettings(await body(req))});
      if(p==='/v1/session/import'&&method==='POST'){
        const credentials=sessionCodeCredentials((await body(req)).code);
        await serial(async()=>{vault.set('game-session',credentials);});
        return json(200,{stored:true,verified:false,captured_at:credentials.captured_at});
      }
      if(p==='/v1/session/credentials'&&method==='PUT'){
        const data=await body(req);const serverName=requireText(data.server,'server',30);
        if(!['asia','na-eu','china'].includes(serverName))throw new ApiError(400,'INVALID_SERVER','asia / na-eu / china を指定してください。');
        const info=data.login_info?.info;let sdk;
        try{sdk=JSON.parse(info?.sauth_json);}catch{}
        if(!info||typeof info.sdkuid!=='string'||typeof info.sessionid!=='string'||typeof info.full_uid!=='string'||!Number.isInteger(info.client_version)||!sdk||sdk.sdkuid!==info.sdkuid||sdk.sessionid!==info.sessionid)
          throw new ApiError(400,'SDK_SESSION_REQUIRED','login_info.info に完全なSDKセッションを指定してください。');
        await serial(async()=>{vault.set('game-session',{credential_type:'netease-sdk-session',login_info:data.login_info,server:serverName,imported_at:new Date().toISOString(),verified:false});});
        return json(200,{stored:true,verified:false});
      }
      if(p==='/v1/session/connect'&&method==='POST'){
        const options=Number(req.headers['content-length'])>0?await body(req):{};
        if(options.replace_existing!==undefined&&typeof options.replace_existing!=='boolean')throw new ApiError(400,'INVALID_INPUT','replace_existing は true / false を指定してください。');
        return await serial(async()=>{const credentials=vault.get('game-session');if(!credentials)throw new ApiError(409,'CREDENTIALS_REQUIRED','認証情報が未登録です。');await monitor.connect(credentials,{replaceExisting:options.replace_existing===true});vault.set('game-session',{...credentials,verified:true,last_verified_at:new Date().toISOString()});return json(200,monitor.status());});
      }
      if(p==='/v1/session/disconnect'&&method==='POST'){await serial(()=>monitor.disconnect());return json(200,monitor.status());}
      const remember=profile=>{store.cacheIdentity(profile);return presentProfile(profile,assets?.catalog);};
      if(method==='GET'&&p==='/v1/players')return json(200,{source:'game',data:(await provider.searchPlayers(requireText(url.searchParams.get('query'),'query',100))).map(remember)});
      if(method==='GET'&&p==='/v1/me')return json(200,{source:'game',data:remember(await provider.getProfile(provider.selfId))});
      if(method==='GET'&&p==='/v1/me/mojin')return json(200,{source:'game',data:presentMojinSelf(provider.getMojinSelf(),assets?.catalog)});
      if(method==='GET'&&p==='/v1/me/mojin/history')return json(200,{source:'game',data:presentMojinRecords(await provider.getMojinHistory(),assets?.catalog)});
      const playerMojin=p.match(/^\/v1\/players\/(\d+)\/mojin(?:\/(history))?$/);
      if(playerMojin&&method==='GET'){
        const id=playerId(playerMojin[1]);
        return json(200,{source:'game',data:playerMojin[2]?presentMojinRecords(await provider.getPlayerMojinHistory(id),assets?.catalog):presentMojinSelf(await provider.getPlayerMojin(id),assets?.catalog)});
      }
      const historyCheck=p.match(/^\/v1\/players\/(\d+)\/history\/access$/);
      const persona=p.match(/^\/v1\/players\/(\d+)\/persona$/);
      if(persona&&method==='GET'){
        const characterId=integer(url.searchParams.get('character_id'),null,1,10000);
        if(!assets?.catalog.characters?.[characterId]?.camp)throw new ApiError(400,'INVALID_CHARACTER','キャラクターを選択してください。');
        return json(200,{source:'game',data:presentPersona(await provider.getPersona(playerId(persona[1]),{characterId}),assets.catalog)});
      }
      if(historyCheck&&method==='GET')return json(200,{source:'game',data:await provider.getHistoryAccess(playerId(historyCheck[1]))});
      const analysis=p.match(/^\/v1\/players\/(\d+)\/analysis$/);
      const historyBadges=p.match(/^\/v1\/players\/(\d+)\/badges\/history$/);
      if(historyBadges&&method==='GET')return json(200,{source:'game',data:presentHistoryBadges(await provider.getHistoryBadges(playerId(historyBadges[1])),assets?.catalog)});
      if(analysis&&method==='GET'){const timeZone=analysisTimeZone(url.searchParams.get('timezone')??undefined),page=await modeRecords(provider,playerId(analysis[1]),url.searchParams.get('mode'),assets?.catalog);return json(200,{source:'game',data:{...page,...analyzeMatches(page.items,{mode:page.mode_filter,timeZone}),items:undefined,total_received:page.items.length,next_cursor:null}});}
      const player=p.match(/^\/v1\/players\/(\d+)(?:\/(history|presence))?$/);
      if(player&&method==='GET'){
        const id=playerId(player[1]);
        if(player[2]==='presence'){
          if(monitor.connected&&provider.capabilities().presence)for(const item of await provider.pollPresence([id]))monitor.record(item);
          const saved=store.presence(id);
          return json(200,{source:'game_and_observations',data:{...(saved??{player_id:id,state:'unknown',observed_at:null,last_login_observed_at:null,last_logout_observed_at:null}),...store.presenceDetails(id)},fresh:!!saved&&monitor.connected&&Date.now()-Date.parse(saved.observed_at)<=monitor.intervalMs*2,timestamp_fields:{last_login_at:'server',last_logout_at:'server',last_login_observed_at:'observation',last_logout_observed_at:'observation'}});
        }
        if(player[2]==='history'){const mode=modeFilter(url.searchParams.get('mode')),page=await modeRecords(provider,id,mode,assets?.catalog);return json(200,{source:'game',data:{...page,...provider.page(page.items,{limit:integer(url.searchParams.get('limit'),50,1,100),cursor:url.searchParams.get('cursor')})}});}
        return json(200,{source:'game',data:remember(await provider.getProfile(id))});
      }
      if(method==='GET'&&p==='/v1/rankings'){
        const kind=url.searchParams.get('kind')||'survivor';if(!['survivor','hunter'].includes(kind))throw new ApiError(400,'INVALID_INPUT','kind が不正です。');
        const character_id=url.searchParams.has('character_id')?integer(url.searchParams.get('character_id'),null,1,10000):null;
        if(character_id!==null&&(!assets?.catalog.characters?.[character_id]?.name||assets.catalog.characters[character_id].camp!==kind))throw new ApiError(400,'INVALID_CHARACTER','選択した陣営のキャラクターを指定してください。');
        const page=await provider.getRankings({kind,character_id,limit:integer(url.searchParams.get('limit'),50,1,100),cursor:url.searchParams.get('cursor')});return json(200,{source:'game',data:{...page,items:page.items.map(row=>({...row,rank:rankOf(row,kind,row.season_id,assets?.catalog)}))}});
      }
      if(method==='GET'&&p==='/v1/friends')return json(200,{source:'game',data:(await provider.getFriends()).map(remember)});
      if(method==='GET'&&p==='/v1/ugc/play-history')return json(200,{source:'game',data:await provider.getUGCPlayHistory()});
      if(method==='GET'&&p==='/v1/ugc/rankings')return json(200,{source:'game',data:await provider.getUGCRankings({period:url.searchParams.get('period')||'week',tag:integer(url.searchParams.get('tag'),1000,1,1000)})});
      const ugcMapRanking=p.match(/^\/v1\/ugc\/maps\/([^/]+)\/rankings$/);
      if(method==='GET'&&ugcMapRanking)return json(200,{source:'game',data:await provider.getUGCMapRanking(ugcMapRanking[1])});
      if(method==='GET'&&p==='/v1/chat/rooms')return json(200,{data:provider.chatRooms()});
      if(method==='GET'&&p==='/v1/chat/global')return json(200,{source:'game',data:await provider.getGlobalChat({room:url.searchParams.get('room'),channel:url.searchParams.get('channel'),cursor:url.searchParams.get('cursor'),limit:integer(url.searchParams.get('limit'),50,1,100)})});
      if(method==='POST'&&p==='/v1/chat/global'){const data=await body(req);return json(202,{data:await provider.sendChat({content:data.content,room:data.room,clientMessageId:data.client_message_id})});}
      const friendChat=p.match(/^\/v1\/friends\/(\d+)\/chat$/);
      if(friendChat&&method==='GET')return json(200,{data:await provider.getFriendChat(playerId(friendChat[1]),{cursor:url.searchParams.get('cursor'),limit:integer(url.searchParams.get('limit'),50,1,100)})});
      if(friendChat&&method==='POST'){const data=await body(req);return json(202,{data:await provider.sendChat({friendId:playerId(friendChat[1]),content:data.content,clientMessageId:data.client_message_id})});}
      if(method==='GET'&&p==='/v1/recruitments')return json(200,{source:'game',data:await provider.getRecruitments({mode:url.searchParams.get('mode'),cursor:url.searchParams.get('cursor'),limit:integer(url.searchParams.get('limit'),50,1,100)})});
      if(p==='/v1/watches'&&method==='GET')return json(200,{tracking_active:monitor.connected&&provider.capabilities().presence,data:store.watches().map(w=>{const presence=store.presence(w.player_id);return {...w,profile:store.identity(w.player_id),presence:{...presence,...store.presenceDetails(w.player_id)},fresh:Boolean(presence&&monitor.connected&&Date.now()-Date.parse(presence.observed_at)<=monitor.intervalMs*2),rules:store.watchRules(w.player_id)};})});
      const watch=p.match(/^\/v1\/watches\/([^/]+)$/);
      if(watch&&method==='PUT'){
        const id=playerId(watch[1]),data=await body(req);if(typeof data.notify!=='boolean')throw new ApiError(400,'INVALID_INPUT','notify は true / false を指定してください。');
        if(!store.watches().some(x=>x.player_id===id)&&store.watches().length>=100)throw new ApiError(409,'WATCH_LIMIT','登録上限は100件です。');
        if(data.rules!==undefined)store.watchRules(id,data.rules);
        store.watch(id,data.notify);return json(200,{player_id:id,notify:data.notify,rules:store.watchRules(id),tracking_active:monitor.connected&&provider.capabilities().presence});
      }
      if(watch&&method==='DELETE'){store.unwatch(playerId(watch[1]));return json(200,{removed:true});}
      if(p==='/v1/events'&&method==='GET')return json(200,{data:store.events(integer(url.searchParams.get('after'),0,0,Number.MAX_SAFE_INTEGER),integer(url.searchParams.get('limit'),100,1,500),url.searchParams.has('player_id')?playerId(url.searchParams.get('player_id')):undefined)});
      if(p==='/v1/events/stream'&&method==='GET'){
        if(streams.size>=10)throw new ApiError(429,'STREAM_LIMIT','同時接続の上限です。');
        let cursor=integer(req.headers['last-event-id']??url.searchParams.get('after'),0,0,Number.MAX_SAFE_INTEGER),blocked=false;
        res.writeHead(200,{'content-type':'text/event-stream; charset=utf-8','cache-control':'no-store','connection':'keep-alive','x-accel-buffering':'no'});res.write(': connected\n\n');streams.add(res);
        const flush=()=>{
          if(blocked||res.destroyed)return;
          for(const event of store.events(cursor,500)){
            cursor=event.id;
            if(!res.write(`id: ${event.id}\nevent: presence\ndata: ${JSON.stringify(event)}\n\n`)){blocked=true;return;}
          }
        };
        const drain=()=>{blocked=false;flush();};res.on('drain',drain);
        const timer=setInterval(()=>{if(!blocked)res.write(': heartbeat\n\n');flush();},15000);timer.unref();monitor.on('presence',flush);flush();
        res.on('close',()=>{clearInterval(timer);monitor.off('presence',flush);streams.delete(res);});return;
      }
      if(p==='/v1/devices'&&method==='POST'){
        const data=await body(req),id=requireText(data.device_id,'device_id',100),token=requireText(data.token,'token',512);
        if(!/^[a-f0-9]{32,512}$/i.test(token)||!['sandbox','production'].includes(data.environment))throw new ApiError(400,'INVALID_INPUT','APNsのデバイストークンまたは環境が不正です。');
        store.registerDevice(id,vault.crypt('protect',token),data.environment);
        return json(200,{registered:true,push_configured:Boolean(monitor.apns),tracking_active:monitor.connected&&provider.capabilities().presence});
      }
      const device=p.match(/^\/v1\/devices\/([^/]+)$/);
      if(device&&method==='DELETE'){store.deleteDevice(requireText(decodeURIComponent(device[1]),'device_id',100));return json(200,{removed:true});}
      throw new ApiError(404,'NOT_FOUND','該当するAPIはありません。');
    }catch(error){
      if(res.headersSent){res.destroy();return;}
      if(error instanceof ApiError)return json(error.status,{error:{code:error.code,message:error.message}});
      return json(500,{error:{code:'INTERNAL_ERROR',message:'処理に失敗しました。認証情報はログに記録していません。'}});
    }
  };
  const server=tls?https.createServer({...tls,minVersion:'TLSv1.2'},handler):http.createServer(handler);
  server.headersTimeout=10000;server.requestTimeout=30000;server.maxHeadersCount=50;
  server.on('close',()=>{for(const res of streams)res.destroy();});
  server.closeStreams=()=>{for(const res of streams)res.destroy();};
  return server;
}
