const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
const validCount=v=>Number.isSafeInteger(v)&&v>=0;
// The game merges the two camps, filters player_release_data, and ranks by
// old_battle_cnt + new_battle_cnt. Its profile displays the first four IDs.
export function frequentCharacters(profile,catalog={}){
  if(!['self','permitted'].includes(profile?.field_access?.statistics)||!(profile.field_access.statistics==='self'||profile.field_access.frequent_characters==='permitted'))return null;
  const settings=catalog.profile_most_used??{},result=(status,items=[])=>({label:settings.label??null,status,items,scope:profile.field_access.statistics==='self'?'self_profile_aggregate':'public_profile_aggregate',source_field:'pid_cnt_all'});
  if(!Array.isArray(settings.released_character_ids)||!settings.released_character_ids.length)return result('unavailable');
  const released=new Set(settings.released_character_ids),rows=[],seen=new Set();
  for(const [field,camp]of [['civilian_data','survivor'],['butcher_data','hunter']]){
    const data=profile[field]?.pid_cnt_all;if(data===undefined)return result('unavailable');if(!object(data))return result('invalid');
    for(const [key,row]of Object.entries(data)){
      if(!/^[1-9]\d{0,8}$/.test(key))return result('invalid');
      const id=Number(key);if(!released.has(id))continue;
      if(seen.has(id))return result('invalid');seen.add(id);
      if(!object(row))return result('invalid');
      if(row.old_battle_cnt===undefined||row.new_battle_cnt===undefined)return result('unavailable');
      if(!validCount(row.old_battle_cnt)||!validCount(row.new_battle_cnt)||!validCount(row.old_battle_cnt+row.new_battle_cnt))return result('invalid');
      const character=catalog.characters?.[id];
      if(!character||character.camp!==camp||!character.name||!character.asset)return result('unavailable');
      rows.push({weight:row.old_battle_cnt+row.new_battle_cnt,item:{character_id:id,name:character.name,asset:character.asset,camp}});
    }
  }
  // The exact order of the game's ties is unverified after object decoding.
  rows.sort((a,b)=>b.weight-a.weight||a.item.character_id-b.item.character_id);
  return result('available',rows.slice(0,4).map(x=>x.item));
}
