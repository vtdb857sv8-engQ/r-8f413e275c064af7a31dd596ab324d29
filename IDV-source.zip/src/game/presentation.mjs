import {matchesMode} from './match-modes.mjs';
import {matchInsights} from './match-insights.mjs';
import {matchScoreBreakdown} from './match-scores.mjs';
import {matchActionDetails} from './match-actions.mjs';
import {rankChangeDetails} from './rank-changes.mjs';
import {historicalRankData,profileSeasons} from './profile-seasons.mjs';
import {currentSeasonStatistics} from './current-season.mjs';
import {participantResult} from './participant-results.mjs';
import {frequentCharacters} from './frequent-characters.mjs';
const numerals=['','一','二','三','四','五','六','七','八'];
const roman=['','I','II','III','IV','V','VI'];
export function rankOf(data,camp,season,catalog={}){
  if(!data||!Number.isInteger(data.part)||data.part<1)return null;
  const part=data.part,level=Number.isInteger(data.part_lv)?data.part_lv:null;
  const divisor=catalog.rank_rules?.star_scores?.[part],stars=Number.isFinite(data.star_count)?data.star_count:Number.isFinite(data.part_star)&&divisor>0?Math.trunc(data.part_star/divisor):null;
  const peak=part===7&&stars!==null&&Number.isInteger(catalog.rank_rules?.peak_stars)&&stars>=catalog.rank_rules.peak_stars;
  return {camp,part,level,stars,season_id:Number.isInteger(season)?season:Number.isInteger(data.season_id)?data.season_id:null,label:(numerals[part]||String(part))+'段'+(part<7?(roman[level]||''):''),asset:`rank-${camp}-${peak?'peak':Math.min(part,7)}`};
}
const strength=r=>r?[r.part,-(r.level??0),r.stars??0]:[-1,0,0];
const compare=(a,b)=>{const x=strength(a),y=strength(b);return x[0]-y[0]||x[1]-y[1]||x[2]-y[2];};
function peakOf(data,camp,catalog){
  if(!data)return null;const candidates=[rankOf(data,camp,undefined,catalog)];
  for(const [season,info]of Object.entries(data.history_season_data??{})){if(!info||typeof info!=='object'||Array.isArray(info))continue;const r=historicalRankData(info.season_max_part_record);candidates.push(rankOf(r??info,camp,Number(season),catalog));}
  let best=candidates.filter(Boolean).sort((a,b)=>compare(b,a)||(b.season_id??0)-(a.season_id??0))[0]??null;
  const max=historicalRankData(data.max_part_record);if(max){const historical=rankOf(max,camp,undefined,catalog);if(compare(historical,best)>0)best=historical;}
  return best;
}
export function presentProfile(profile,catalog={}){
  const allowed=['self','permitted'].includes(profile.field_access?.statistics),ranks=allowed?{survivor:{current:rankOf(profile.civilian_data,'survivor',undefined,catalog),highest:peakOf(profile.civilian_data,'survivor',catalog)},hunter:{current:rankOf(profile.butcher_data,'hunter',undefined,catalog),highest:peakOf(profile.butcher_data,'hunter',catalog)}}:null;
  const badgeAllowed=['self','permitted'].includes(profile.field_access?.profile_tags);
  const badges=badgeAllowed&&profile.badge_records&&typeof profile.badge_records==='object'?Object.entries(profile.badge_records).filter(([id,v])=>/^\d+$/.test(id)&&Array.isArray(v)&&v[1]>Date.now()/1000).map(([id,v])=>{const character=catalog.characters?.[id],grade=({1:'C',2:'B',3:'A',4:'S'})[v[0]]??null;return{character_id:Number(id),grade,asset:character?.camp&&grade?`badge-${character.camp}-${grade.toLowerCase()}`:null,label:(character?.name??`キャラ ${id}`)+(grade?` ${grade}徽章`:' 徽章'),expires_at:new Date(v[1]*1000).toISOString()};}):null;
  const {badge_records:discard,...base}=profile;
  return {...base,...(badges!==null?{profile_tag_info:{...profile.profile_tag_info,character_badges:badges}}:{}),appearance:{portrait:profile.face_id!==undefined?`face-${profile.face_id}`:null,frame:profile.face_frame_id!==undefined?`frame-${profile.face_frame_id}`:null},ranks,season_history:profileSeasons(profile,rankOf,catalog),current_season_statistics:currentSeasonStatistics(profile),most_used_characters:frequentCharacters(profile,catalog)};
}
export function presentMatch(record,catalog={}){
  const common=record.common_info??{},isOwner=x=>common.self_eid!=null&&x.eid!=null&&String(x.eid)===String(common.self_eid),self=(record.all_pl_info??[]).find(isOwner),camp=self?.utype===1?'hunter':self?.utype===2?'survivor':null;
  const resultValue=camp==='hunter'?common.wdf?.[1]:camp==='survivor'?common.wdf?.[0]:null;
  const visibleParty=x=>typeof x?.team_uid==='string'&&x.team_uid.length>0&&[undefined,true,1].includes(x.show_team);
  const players=(record.all_pl_info??[]).map(x=>{const change=rankChangeDetails(x,record,catalog);const rankChange=change?{...change,before:rankOf(change.before,x.utype===1?'hunter':'survivor',undefined,catalog),after:rankOf(change.after,x.utype===1?'hunter':'survivor',undefined,catalog)}:null;const camp=x.utype===1?'hunter':x.utype===2?'survivor':null;return{player_id:x.unique_id!==undefined?String(x.unique_id):x.uid!==undefined?String(x.uid):null,name:x.player_name??null,portrait:x.face!==undefined?`face-${x.face}`:null,frame:x.face_frame!==undefined?`frame-${x.face_frame}`:null,character_id:x.pid,character_name:catalog.characters?.[x.pid]?.name??null,character_asset:catalog.characters?.[x.pid]?.asset??null,camp,score:x.total_score??null,participant_result:participantResult(x,common.match_type,catalog),score_breakdown:matchScoreBreakdown(x,common.match_type,catalog),action_details:matchActionDetails(x,common.match_type,catalog),rank_change:rankChange,mvp:typeof x.mvp==='boolean'?x.mvp:null,is_bot:typeof x.bot==='boolean'?x.bot:null,level:Number.isInteger(x.lv)?x.lv:null,match_rank:camp?rankOf(x.rank_info,camp,undefined,catalog):null,is_self:isOwner(x),premade_with_owner:!isOwner(x)&&visibleParty(self)&&visibleParty(x)?x.team_uid===self.team_uid:null};});
  const publicRecords=(record.all_pl_info??[]).map(({team_uid,is_team_match,is_captain,show_team,character_value_info:unverifiedReportValues,...x})=>x);
  return {...record,all_pl_info:publicRecords,summary:{map_id:common.scene_id,map_name:catalog.maps?.[common.scene_id]?.name??null,map_asset:catalog.maps?.[common.scene_id]?.asset??null,mode_id:common.match_type,is_custom:catalog.mode_rules?.[common.match_type]?.is_custom??common.match_type===4,mode_name:catalog.modes?.[common.match_type]??null,camp,result:resultValue===1?'win':resultValue===-1?'loss':resultValue===0?'draw':'unknown',ended_at:typeof common.end_time==='number'?new Date(common.end_time*1000).toISOString():null,duration:common.battle_time_exclude_pause??null,character_id:self?.pid??null,players}};
}
export function presentHistoryBadges(data,catalog={}){
  const num=v=>Number.isFinite(v)&&v>=0?v:null,grades=['S','A','B','C'];
  const items=Object.entries(data.records).filter(([id,v])=>/^\d+$/.test(id)&&v&&typeof v==='object').map(([id,info])=>{
    const character=catalog.characters?.[id],grade=info.highest_badge?.grade;
    const countsKnown=info.badge_info&&typeof info.badge_info==='object'&&!Array.isArray(info.badge_info);
    return {character_id:Number(id),character_name:character?.name??null,character_asset:character?.asset??null,camp:character?.camp??null,highest_grade:grades.includes(grade)?grade:null,highest_asset:character?.camp&&grades.includes(grade)?`badge-${character.camp}-${grade.toLowerCase()}-history`:null,highest_score:num(info.hightest_rank_score),grades:grades.map(grade=>({grade,count:countsKnown?num(info.badge_info[grade]?.num??0):null,latest_date:typeof info.badge_info?.[grade]?.latest_date==='string'?info.badge_info[grade].latest_date:null,asset:character?.camp?`badge-${character.camp}-${grade.toLowerCase()}-history`:null}))};
  }).sort((a,b)=>(grades.indexOf(a.highest_grade)===-1?9:grades.indexOf(a.highest_grade))-(grades.indexOf(b.highest_grade)===-1?9:grades.indexOf(b.highest_grade))||(b.highest_score??-1)-(a.highest_score??-1)||a.character_id-b.character_id);
  return {player_id:data.player_id,access:data.access,items,total_received:items.length};
}
export function analyzeMatches(records,{mode='all',timeZone='Asia/Tokyo'}={}){
  records=records.filter(r=>matchesMode(r,mode));
  const seen=new Set();records=records.filter(r=>{const key=r.record_id??r.common_info?.battle_id;if(!key)return true;if(seen.has(key))return false;seen.add(key);return true;});
  const rows=records.map(x=>x.summary).filter(Boolean),counts={win:0,draw:0,loss:0,unknown:0};const maps=new Map(),characters=new Map(),modes=new Map();
  const add=(table,key,name,result)=>{if(key===undefined||key===null)return;const value=table.get(key)??{id:key,name:name??null,total:0,wins:0,draws:0,losses:0};value.total++;if(result==='win')value.wins++;if(result==='draw')value.draws++;if(result==='loss')value.losses++;table.set(key,value);};
  for(const r of rows){counts[Object.hasOwn(counts,r.result)?r.result:'unknown']++;add(maps,r.map_id,r.map_name,r.result);add(characters,r.character_id,r.players?.find(p=>p.is_self)?.character_name,r.result);add(modes,r.mode_id,r.mode_name,r.result);}
  const known=counts.win+counts.draw+counts.loss,durations=rows.map(r=>r.duration).filter(v=>Number.isFinite(v)&&v>0);
  const summarize=table=>[...table.values()].map(x=>({...x,win_rate:x.wins+x.draws+x.losses?100*x.wins/(x.wins+x.draws+x.losses):null})).sort((a,b)=>b.total-a.total);
  const teammates=new Map(),parties=new Map();let identifiableMatches=0,partyMatches=0;
  const addPeer=(table,p,r)=>{const old=table.get(p.player_id)??{player_id:p.player_id,name:p.name,portrait:p.portrait,frame:p.frame,total:0,wins:0,draws:0,losses:0,unknown:0,last_played_at:null};old.total++;if(r.result==='win')old.wins++;else if(r.result==='draw')old.draws++;else if(r.result==='loss')old.losses++;else old.unknown++;if(!old.last_played_at||r.ended_at>old.last_played_at){old.last_played_at=r.ended_at??old.last_played_at;old.name=p.name??old.name;old.portrait=p.portrait??old.portrait;old.frame=p.frame??old.frame;}table.set(p.player_id,old);};
  for(const r of rows){
    const owner=r.players?.find(p=>p.is_self);if(!owner?.camp||![1,2,3,4,6,8,9,10,80,81,90,100,102,103].includes(r.mode_id))continue;
    const peers=[...new Map((r.players??[]).filter(p=>!p.is_self&&!p.is_bot&&p.camp===owner.camp&&/^[1-9]\d{0,19}$/.test(p.player_id??'')&&p.player_id!==owner.player_id).map(p=>[p.player_id,p])).values()];
    if(peers.length)identifiableMatches++;if(peers.some(p=>p.premade_with_owner===true))partyMatches++;
    for(const p of peers){addPeer(teammates,p,r);if(p.premade_with_owner===true)addPeer(parties,p,r);}
  }
  const peers=table=>[...table.values()].map(p=>({...p,known_results:p.wins+p.draws+p.losses,win_rate:p.wins+p.draws+p.losses?100*p.wins/(p.wins+p.draws+p.losses):null})).sort((a,b)=>b.total-a.total||(b.win_rate??-1)-(a.win_rate??-1)||a.player_id.localeCompare(b.player_id));
  return {total:rows.length,known_results:known,...counts,win_rate:known?counts.win/known*100:null,average_duration:durations.length?Math.round(durations.reduce((a,b)=>a+b,0)/durations.length):null,by_map:summarize(maps),by_character:summarize(characters),by_mode:summarize(modes),by_teammate:peers(teammates),by_party_partner:peers(parties),partner_coverage:{identifiable_matches:identifiableMatches,public_party_matches:partyMatches,team_modes:[1,2,3,4,6,8,9,10,80,81,90,100,102,103]},coverage:'server_returned_records',public_participant_ids_available:rows.some(r=>r.players?.some(p=>p.player_id&&!p.is_self)),identity_based_partner_analysis_available:parties.size>0,...matchInsights(rows,{timeZone})};
}
