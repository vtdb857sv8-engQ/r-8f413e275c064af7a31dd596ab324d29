// Wire primitives for the protocol observed in the installed client.
export function varint(value) {
  let n=BigInt(value);if(n<0n)n=BigInt.asUintN(64,n);const out=[];
  do{let b=Number(n&127n);n>>=7n;if(n)b|=128;out.push(b);}while(n);
  return Buffer.from(out);
}
export function protobuf(fields) {
  return Buffer.concat(fields.map(([id,value])=>{
    if(!Number.isInteger(id)||id<1||id>0x1fffffff)throw new Error('Invalid protobuf field');
    if(Buffer.isBuffer(value)||typeof value==='string'){
      const b=Buffer.isBuffer(value)?value:Buffer.from(value);return Buffer.concat([varint(id*8+2),varint(b.length),b]);
    }
    return Buffer.concat([varint(id*8),varint(value)]);
  }));
}
export function parseProtobuf(buffer) {
  let p=0;const fields=new Map();
  function read(){let n=0n;for(let i=0;i<10;i++){if(p>=buffer.length)throw new Error('Truncated protobuf');const b=buffer[p++];n|=BigInt(b&127)<<(BigInt(i)*7n);if(!(b&128))return n;}throw new Error('Invalid varint');}
  while(p<buffer.length){
    const tag=read(),id=Number(tag>>3n),wire=Number(tag&7n);let value;
    if(!id)throw new Error('Invalid protobuf tag');
    if(wire===0)value=read();
    else if(wire===2){const n=Number(read());if(!Number.isSafeInteger(n)||p+n>buffer.length)throw new Error('Truncated protobuf');value=buffer.subarray(p,p+n);p+=n;}
    else if(wire===1||wire===5){const n=wire===1?8:4;if(p+n>buffer.length)throw new Error('Truncated protobuf');value=buffer.subarray(p,p+n);p+=n;}
    else throw new Error('Unsupported protobuf wire type');
    if(!fields.has(id))fields.set(id,[]);fields.get(id).push(value);
  }
  return fields;
}
export function frame(opcode,payload=Buffer.alloc(0)) {
  if(!Number.isInteger(opcode)||opcode<0||opcode>65535||payload.length>8*1024*1024-2)throw new Error('Invalid RPC frame');
  const b=Buffer.alloc(payload.length+6);b.writeUInt32LE(payload.length+2);b.writeUInt16LE(opcode,4);payload.copy(b,6);return b;
}
export class FrameDecoder {
  buffer=Buffer.alloc(0);
  push(bytes) {
    this.buffer=Buffer.concat([this.buffer,bytes]);const frames=[];
    while(this.buffer.length>=4){
      const n=this.buffer.readUInt32LE(0);if(n<2||n>8*1024*1024)throw new Error('Invalid RPC length');
      if(this.buffer.length<n+4)break;
      frames.push({opcode:this.buffer.readUInt16LE(4),payload:Buffer.from(this.buffer.subarray(6,n+4))});this.buffer=this.buffer.subarray(n+4);
    }
    return frames;
  }
}
// Used solely to interoperate with the game's existing transport.
export class Rc4 {
  constructor(key){
    if(!key?.length)throw new Error('Empty RC4 key');this.s=Uint8Array.from({length:256},(_,i)=>i);this.i=0;this.j=0;
    for(let i=0,j=0;i<256;i++){j=(j+this.s[i]+key[i%key.length])&255;[this.s[i],this.s[j]]=[this.s[j],this.s[i]];}
  }
  update(bytes){
    const out=Buffer.alloc(bytes.length);
    for(let n=0;n<bytes.length;n++){this.i=(this.i+1)&255;this.j=(this.j+this.s[this.i])&255;[this.s[this.i],this.s[this.j]]=[this.s[this.j],this.s[this.i]];out[n]=bytes[n]^this.s[(this.s[this.i]+this.s[this.j])&255];}
    return out;
  }
}
