const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const count=x=>Number.isSafeInteger(x)&&x>=0;
// UIRankSeasonReview uses each received season's pid_data_rank directly.
// Its character win rate excludes draws, unlike the match-history analysis.
export function seasonRankCharacters(profile,season,camp,catalog={}){
  if(!['self','permitted'].includes(profile?.field_access?.statistics)||!(profile.field_access.statistics==='self'||profile.field_access.season_characters==='permitted'))return null;
  const result=(status,items=[])=>({status,mode:'rank',source_field:'pid_data_rank',rate_basis:'wins_over_battles_minus_draws',items});
  const data=season?.pid_data_rank;
  if(data===undefined)return result('unavailable');
  if(!object(data))return result('invalid');
  const items=[];
  for(const [id,row]of Object.entries(data)){
    if(!/^[1-9]\d{0,8}$/.test(id)||!object(row))return result('invalid');
    const values=[row.battle_cnt,row.win_cnt,row.draw_cnt];
    if(values.includes(undefined))return result('unavailable');
    if(!values.every(count)||row.draw_cnt>row.battle_cnt||row.win_cnt>row.battle_cnt-row.draw_cnt)return result('invalid');
    const character=catalog.characters?.[id];
    if(!character?.name||!character.asset||character.camp!==camp)return result('unavailable');
    const decisive=row.battle_cnt-row.draw_cnt,rate=decisive?row.win_cnt/decisive*100:0;
    items.push({character_id:Number(id),name:character.name,asset:character.asset,camp,
      battle_count:row.battle_cnt,wins:row.win_cnt,draws:row.draw_cnt,decisive_matches:decisive,
      win_rate:Number(rate.toFixed(1)),win_rate_display:rate.toFixed(1)+'%',
      zero_denominator:decisive===0});
  }
  // The game sorts by battle count; ID makes ties deterministic in this app.
  items.sort((a,b)=>b.battle_count-a.battle_count||a.character_id-b.character_id);
  return result('available',items);
}
