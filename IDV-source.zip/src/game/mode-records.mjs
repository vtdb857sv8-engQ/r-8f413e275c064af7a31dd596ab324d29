import {ApiError} from '../errors.mjs';
import {presentMatch} from './presentation.mjs';
import {presentMojinRecords,mojinMatchRecord} from './mojin-records.mjs';
import {modeFilter,matchesMode} from './match-modes.mjs';

export async function modeRecords(provider,id,requested,catalog={}){
  const mode=modeFilter(requested),self=String(id)===String(provider.selfId),session=provider.session;
  let records=[],normalReceived=0,mojinReceived=null,mojinState='not_requested',access,visibility;
  if(mode!=='mojin'){
    const page=await provider.getMatchHistory(id,{limit:1000,cursor:null});normalReceived=page.total_received??page.items.length;
    access=page.access;visibility=page.visibility;
    records=page.items.map(r=>presentMatch(r,catalog));
  }
  if(provider.session!==session)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
  if(['all','mojin'].includes(mode)){
    try{
      const page=presentMojinRecords(await(self?provider.getMojinHistory():provider.getPlayerMojinHistory(id)),catalog);
      if(page.player_id!==String(id)||provider.session!==session)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
      mojinReceived=page.total_received;mojinState='received';
      records.push(...page.items.map(mojinMatchRecord));
    }catch(error){if(mode==='mojin'||error.code==='GAME_SESSION_CHANGED')throw error;mojinState=error.code??'unavailable';}
  }
  const seen=new Set();
  if(provider.session!==session)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
  records=records.filter(r=>{if(!matchesMode(r,mode))return false;const key=r.record_id??r.common_info?.battle_id;if(!key)return true;if(seen.has(key))return false;seen.add(key);return true;}).sort((a,b)=>(b.common_info?.end_time??0)-(a.common_info?.end_time??0));
  return {items:records,access,visibility,mode_filter:mode,coverage:'server_returned_records',custom_excluded:mode!=='custom',received_by_source:{normal:normalReceived,mojin:mojinReceived},mojin_status:mojinState};
}
