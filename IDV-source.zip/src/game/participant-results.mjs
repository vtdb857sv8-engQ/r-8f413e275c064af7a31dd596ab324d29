// Original PlayerInfoItemBase._update_result_personal uses RES_TXT[res_type].
// Its free-exit override uses BTN_QUIT; that button wording has not been
// verified as a personal result, so suppress it rather than invent a label.
export function participantResult(player,mode,catalog={}){
 if(![1,2,4,8,9,100,101].includes(mode)||![1,2].includes(player.utype))return null;
 const code=Number.isInteger(player.res_type)&&player.res_type>=0?player.res_type:null;
 const empty=status=>({status,code,label:null,label_key:null});
 if(player.res_type===undefined||player.res_type===null)return empty('unavailable');
 if(code===null)return empty('unverified');
 if(player.is_free_exit===undefined||player.is_free_exit===null)return empty('unavailable');
 if(![false,0].includes(player.is_free_exit))return empty('unverified');
 const original=catalog.match_result_labels?.[code];
 if(typeof original?.label!=='string'||!original.label||typeof original.label_key!=='string')return empty('unverified');
 return {status:'received',code,label:original.label,label_key:original.label_key};
}
