const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
function counters(value){
  if(value===undefined)return {status:'unavailable'};
  if(!object(value)||Object.keys(value).length>1024)return {status:'invalid'};
  const result=new Map();
  for(const [id,count]of Object.entries(value)){
    if(!/^[1-9]\d{0,8}$/.test(id)||!Number.isSafeInteger(count)||count<0)return {status:'invalid'};
    result.set(id,count);
  }
  return {status:'available',values:result};
}
export function presentMojinCareers(common,scope,seasonId,settings={}){
  const response=(status,items=[])=>({label:settings.career_usage_label??null,status,items});
  if(!object(common))return response('unavailable');
  let selected;
  if(scope==='season')selected=counters(common.history_season_data?.[seasonId]?.career_usage);
  else selected=counters(common.career_usage);
  if(selected.status!=='available')return response(selected.status);
  if(scope==='current'){
    const history=common.history_season_data;
    if(history===undefined)return response('unavailable');
    if(!object(history)||Object.keys(history).length>1024)return response('invalid');
    for(const period of Object.values(history)){
      if(!object(period))return response('invalid');
      const old=counters(period.career_usage);
      if(old.status!=='available')return response(old.status);
      for(const [id,count]of old.values){
        const remaining=selected.values.get(id)??0;
        if(count>remaining)return response('invalid');
        if(selected.values.has(id))selected.values.set(id,remaining-count);
      }
    }
  }
  const items=[...selected.values].filter(([,count])=>count>0).sort((a,b)=>b[1]-a[1]||Number(a[0])-Number(b[0])).slice(0,2).map(([id,use_count])=>({career_id:Number(id),name:settings.careers?.[id]?.name??null,asset:settings.careers?.[id]?.asset??null,use_count}));
  return response(items.some(x=>!x.name)?'partial':'available',items);
}
