import {ApiError} from '../errors.mjs';

export function analysisTimeZone(value='Asia/Tokyo'){
  if(typeof value!=='string'||value.length>100)throw new ApiError(400,'INVALID_TIMEZONE','有効なタイムゾーンを指定してください。');
  try{return new Intl.DateTimeFormat('en',{timeZone:value}).resolvedOptions().timeZone;}
  catch{throw new ApiError(400,'INVALID_TIMEZONE','有効なタイムゾーンを指定してください。');}
}
const time=row=>typeof row.ended_at==='string'&&Number.isFinite(Date.parse(row.ended_at))?Date.parse(row.ended_at):null;
const validNumber=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0;
function performance(rows){
  const owners=rows.map(r=>r.players?.find(p=>p.is_self===true));
  const mvp=owners.filter(p=>typeof p?.mvp==='boolean'),scores=owners.map(p=>p?.score).filter(validNumber);
  const durations=rows.map(r=>r.duration).filter(v=>validNumber(v)&&v>0);
  return {mvp_count:mvp.filter(p=>p.mvp).length,mvp_known_matches:mvp.length,mvp_unknown_matches:rows.length-mvp.length,mvp_rate:mvp.length?100*mvp.filter(p=>p.mvp).length/mvp.length:null,average_score:scores.length?scores.reduce((a,b)=>a+b,0)/scores.length:null,scored_matches:scores.length,score_unknown_matches:rows.length-scores.length,average_duration:durations.length?Math.round(durations.reduce((a,b)=>a+b,0)/durations.length):null,duration_known_matches:durations.length};
}
function results(rows){
  const counts={win:0,draw:0,loss:0,unknown:0};
  for(const row of rows)counts[Object.hasOwn(counts,row.result)?row.result:'unknown']++;
  const known=counts.win+counts.draw+counts.loss;
  return {total:rows.length,known_results:known,...counts,win_rate:known?100*counts.win/known:null};
}
// Input has already passed history permissions, mode filtering and record deduplication.
// These are calculations over the returned sample, never lifetime/account records.
export function matchInsights(rows,{timeZone='Asia/Tokyo'}={}){
  const zone=analysisTimeZone(timeZone),dated=rows.filter(r=>time(r)!==null).sort((a,b)=>time(b)-time(a));
  const missing=rows.length-dated.length,ambiguous=new Set(dated.map(time)).size!==dated.length;
  const status=missing?'missing_timestamps':ambiguous?'ambiguous_timestamps':'available';
  let current=null,longestWin=null,longestLoss=null;
  if(status==='available'){
    longestWin=0;longestLoss=0;let win=0,loss=0;
    for(const row of dated){win=row.result==='win'?win+1:0;loss=row.result==='loss'?loss+1:0;longestWin=Math.max(longestWin,win);longestLoss=Math.max(longestLoss,loss);}
    if(!dated.some(r=>['win','draw','loss'].includes(r.result))){longestWin=null;longestLoss=null;}
    const kind=dated[0]?.result;
    current=!dated.length?null:['win','loss'].includes(kind)?{kind,count:dated.findIndex(r=>r.result!==kind)===-1?dated.length:dated.findIndex(r=>r.result!==kind)}:kind==='draw'?{kind:'none',count:0}:{kind:'unknown',count:null};
  }
  const formatter=new Intl.DateTimeFormat('en-GB',{timeZone:zone,hour:'2-digit',hourCycle:'h23'}),hours=new Map();
  for(const row of dated){const hour=Number(formatter.format(new Date(time(row))));if(!hours.has(hour))hours.set(hour,[]);hours.get(hour).push(row);}
  return {
    calculation_source:'received_match_records',self_performance:performance(rows),
    chronology:{status,dated_matches:dated.length,undated_matches:missing,timestamp_basis:'match_end'},
    recent:status==='available'?[10,20,50].map(n=>({requested_matches:n,...results(dated.slice(0,n)),...performance(dated.slice(0,n))})):[],
    streaks:{current,longest_win:longestWin,longest_loss:longestLoss,scope:'returned_records',draw_and_unknown_break:true},
    hourly:{time_zone:zone,timestamp_basis:'match_end',dated_matches:dated.length,undated_matches:missing,items:[...hours.entries()].sort(([a],[b])=>a-b).map(([hour,items])=>({hour,...results(items)}))}
  };
}
