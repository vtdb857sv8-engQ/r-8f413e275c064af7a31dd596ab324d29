import net from 'node:net';
import { createHash, createPublicKey, randomBytes, publicEncrypt, constants } from 'node:crypto';
import { FrameDecoder, Rc4, protobuf, parseProtobuf, frame } from './wire.mjs';
import zlib from 'node:zlib';
export class Gateway {
  constructor(){this.decoder=new FrameDecoder();this.queue=[];this.waiters=[];this.failed=null;this.tx=null;this.rx=null;}
  async open(host,port) {
    this.socket=net.createConnection({host,port});
    this.socket.setNoDelay(true);
    this.socket.on('data',bytes=>{
      const decoded=this.rx?this.rx.update(bytes):bytes;
      if(this.inflater)this.inflater.write(decoded);else this.receive(decoded);
    });
    this.socket.on('error',()=>this.fail(new Error('GATEWAY_NETWORK_ERROR')));
    this.socket.on('close',()=>this.fail(new Error('GATEWAY_CLOSED')));
    await new Promise((resolve,reject)=>{
      const timeout=setTimeout(()=>{this.close();reject(new Error('GATEWAY_CONNECT_TIMEOUT'));},6000);
      this.socket.once('connect',()=>{clearTimeout(timeout);resolve();});
      this.socket.once('error',()=>{clearTimeout(timeout);reject(new Error('GATEWAY_CONNECT_FAILED'));});
    });
  }
  receive(decoded){
    try{for(const item of this.decoder.push(decoded)){const waiter=this.waiters.shift();if(waiter)waiter.resolve(item);else{this.queue.push(item);if(this.queue.length>1000)throw new Error('Queue overflow');}}}
    catch{this.lastFrameError={bytes:decoded.length,length_word:decoded.length>=4?decoded.readUInt32LE():null};this.fail(new Error('GATEWAY_FRAME_INVALID'));}
  }
  enableCompression(){
    this.inflater=zlib.createInflate();this.deflater=zlib.createDeflate({windowBits:12,level:8});
    this.inflater.on('data',b=>this.receive(b));this.inflater.on('error',()=>this.fail(new Error('GATEWAY_DECOMPRESS_FAILED')));
    this.deflater.on('data',b=>this.socket.write(this.tx?this.tx.update(b):b));this.deflater.on('error',()=>this.fail(new Error('GATEWAY_COMPRESS_FAILED')));
  }
  fail(error){if(this.failed)return;this.failed=error;for(const w of this.waiters.splice(0))w.reject(error);this.socket?.destroy();}
  send(opcode,payload){if(this.failed)throw this.failed;const raw=frame(opcode,payload);if(this.deflater){this.deflater.write(raw);this.deflater.flush(zlib.constants.Z_SYNC_FLUSH);}else this.socket.write(this.tx?this.tx.update(raw):raw);}
  async next(timeoutMs=6000){
    if(this.queue.length)return this.queue.shift();if(this.failed)throw this.failed;
    return new Promise((resolve,reject)=>{
      const waiter={resolve:item=>{clearTimeout(timer);resolve(item);},reject:error=>{clearTimeout(timer);reject(error);}};
      const timer=setTimeout(()=>{this.waiters=this.waiters.filter(w=>w!==waiter);reject(new Error('GATEWAY_RESPONSE_TIMEOUT'));},timeoutMs);this.waiters.push(waiter);
    });
  }
  async handshake(publicKey){
    this.send(0,Buffer.alloc(0));
    const reply=await this.next();if(reply.opcode!==0)throw new Error('GATEWAY_SEED_UNEXPECTED');
    const seed=parseProtobuf(reply.payload).get(1)?.[0];if(typeof seed!=='bigint')throw new Error('GATEWAY_SEED_INVALID');
    const key=createHash('sha1').update(randomBytes(32)).digest();
    const session=protobuf([[1,randomBytes(16)],[2,key],[3,seed],[4,randomBytes(16)]]);
    if(publicKey.toString().startsWith('ssh-rsa ')){
      const b=Buffer.from(publicKey.toString().split(/\s+/)[1],'base64');let pos=0;
      const read=()=>{if(pos+4>b.length)throw new Error('Invalid SSH key');const n=b.readUInt32BE(pos);pos+=4;if(pos+n>b.length)throw new Error('Invalid SSH key');let v=b.subarray(pos,pos+n);pos+=n;while(v.length>1&&v[0]===0)v=v.subarray(1);return v;};
      if(read().toString()!=='ssh-rsa')throw new Error('Invalid SSH key');const e=read(),n=read();
      publicKey=createPublicKey({key:{kty:'RSA',e:e.toString('base64url'),n:n.toString('base64url')},format:'jwk'});
    }
    const encrypted=publicEncrypt({key:publicKey,padding:constants.RSA_PKCS1_OAEP_PADDING,oaepHash:'sha1'},session);
    this.send(1,protobuf([[1,encrypted]]));this.sessionKey=key;this.tx=new Rc4(key);this.rx=new Rc4(key);
    const accepted=await this.next();if(accepted.opcode!==1)throw new Error('GATEWAY_SESSION_UNEXPECTED');
    return {encrypted_session:true};
  }
  close(){this.fail(new Error('GATEWAY_CLOSED'));this.inflater?.destroy();this.deflater?.destroy();this.sessionKey?.fill(0);}
}
