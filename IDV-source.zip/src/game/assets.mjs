import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {decodeStage,unwrap} from './asset-pack.mjs';
import {texturePNG} from './texture.mjs';
import {ApiError} from '../errors.mjs';
export class GameAssets{
  constructor(directory){
    this.directory=directory;this.catalog=fs.existsSync(path.join(directory,'catalog.json'))?JSON.parse(fs.readFileSync(path.join(directory,'catalog.json'),'utf8')):{assets:{},characters:{},maps:{}};
    const displayFile=new URL('../../resources/persona-display.json',import.meta.url);
    if(fs.existsSync(displayFile)){
      const display=JSON.parse(fs.readFileSync(displayFile,'utf8'));this.catalog.persona??=display.persona;
      for(const [key,item]of Object.entries(display.assets))this.catalog.assets[key]??=item;
    }
    this.source=fs.existsSync(path.join(directory,'source.json'))?JSON.parse(fs.readFileSync(path.join(directory,'source.json'),'utf8')):null;
  }
  locate(md5){
    if(this.source?.locations?.[md5])return this.source.locations[md5];
    if(!this.source?.game_directory)return null;
    for(const dir of ['Documents/res','res'])for(const group of ['ui','tex_critical','special_icon','common']){
      const file=path.join(this.source.game_directory,dir,group+'.idx');if(!fs.existsSync(file))continue;
      const index=fs.readFileSync(file);if(index.length<32)continue;
      for(let i=0;i<index.readUInt32LE(12)&&68+i*36<=index.length;i++){
        const row=index.subarray(32+i*36,68+i*36);
        if(row.subarray(0,16).toString('hex')!==md5)continue;
        const location={dir,group,pkg:row[20],offset:row.readUInt32LE(24)+row.readUInt16LE(32),size:row.readUInt32LE(28)};
        this.source.locations??={};this.source.locations[md5]=location;return location;
      }
    }
    return null;
  }
  descriptor(key){return this.catalog.assets[key];}
  image(key){
    if(!/^[a-z0-9-]{1,80}$/.test(key)||!this.descriptor(key))throw new ApiError(404,'GAME_ASSET_UNAVAILABLE','ゲーム内素材を取得できません。');
    const file=path.join(this.directory,'cache',key+'.png');if(fs.existsSync(file))return fs.readFileSync(file);
    const item=this.descriptor(key),location=this.locate(item.md5);if(!location)throw new ApiError(404,'GAME_ASSET_UNAVAILABLE','ゲーム内素材を取得できません。');
    const input=path.join(this.source.game_directory,location.dir,`${location.group}${location.pkg}.wpk`);let fd;
    try{fd=fs.openSync(input,'r');const b=Buffer.alloc(location.size);if(fs.readSync(fd,b,0,b.length,location.offset)!==b.length)throw new Error('TRUNCATED_ASSET');const original=unwrap(decodeStage(b));if(createHash('md5').update(original).digest('hex')!==item.md5)throw new Error('GAME_ASSET_HASH_MISMATCH');const png=texturePNG(original);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,png);return png;}
    catch{throw new ApiError(404,'GAME_ASSET_UNAVAILABLE','このゲーム内素材を読み込めません。');}finally{if(fd!==undefined)fs.closeSync(fd);}
  }
  publicCatalog(){return {characters:this.catalog.characters,maps:this.catalog.maps,modes:this.catalog.modes,avatar_masks:this.catalog.avatar_masks??{},asset_count:Object.keys(this.catalog.assets).length};}
}
