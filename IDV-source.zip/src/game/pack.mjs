import {encode} from '@msgpack/msgpack';
// Python's numeric dictionary keys must retain their wire type.
export function pack(value,depth=0){
  if(depth>64)throw new Error('MSGPACK_DEPTH');
  const header=(small,tag16,tag32,n)=>{if(n<16)return Buffer.from([small|n]);if(n<65536){const b=Buffer.alloc(3);b[0]=tag16;b.writeUInt16BE(n,1);return b;}const b=Buffer.alloc(5);b[0]=tag32;b.writeUInt32BE(n,1);return b;};
  if(Array.isArray(value))return Buffer.concat([header(0x90,0xdc,0xdd,value.length),...value.map(v=>pack(v,depth+1))]);
  if(value instanceof Map||value&&Object.getPrototypeOf(value)===Object.prototype){
    const entries=value instanceof Map?[...value]:Object.entries(value);
    return Buffer.concat([header(0x80,0xde,0xdf,entries.length),...entries.flatMap(([k,v])=>[pack(k,depth+1),pack(v,depth+1)])]);
  }
  return Buffer.from(encode(value,{useBigInt64:true}));
}
