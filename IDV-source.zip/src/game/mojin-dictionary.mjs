const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
function counters(value){
 if(value===undefined)return {status:'unavailable'};
 if(!object(value)||Object.keys(value).length>1024)return {status:'invalid'};
 const values=new Map();
 for(const [id,count]of Object.entries(value)){
  if(!/^[1-9]\d{0,8}$/.test(id)||!Number.isSafeInteger(count)||count<0)return {status:'invalid'};
  values.set(id,count);
 }
 return {status:'available',values};
}
export function mojinPeriodDictionary(common,key,scope,seasonId){
 if(!object(common))return {status:'unavailable'};
 if(!['all','current','season'].includes(scope))return {status:'invalid'};
 const selected=counters(scope==='season'?common.history_season_data?.[seasonId]?.[key]:common[key]);
 if(selected.status!=='available'||scope!=='current')return selected;
 const history=common.history_season_data;
 if(history===undefined)return {status:'unavailable'};
 if(!object(history)||Object.keys(history).length>1024)return {status:'invalid'};
 for(const period of Object.values(history)){
  if(!object(period))return {status:'invalid'};
  const old=counters(period[key]);if(old.status!=='available')return old;
  for(const [id,count]of old.values){const remaining=selected.values.get(id)??0;if(count>remaining)return {status:'invalid'};if(selected.values.has(id))selected.values.set(id,remaining-count);}
 }
 return selected;
}
