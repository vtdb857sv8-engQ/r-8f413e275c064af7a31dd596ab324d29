import {seasonRankCharacters} from './season-characters.mjs';
const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
const count=x=>Number.isSafeInteger(x)&&x>=0?x:null;
// PartUtil.get_max_part_info uses tuple slot 4 (raw rank score), not slot 2.
export function historicalRankData(record){
  if(!Array.isArray(record)||record.length<2)return null;
  return {part:record[0],part_lv:record[1],part_star:record.length>=5&&count(record[4])!==null?record[4]:null};
}
export function profileSeasons(profile,rank,catalog={}){
  if(!['self','permitted'].includes(profile.field_access?.statistics))return null;
  const camps={};
  for(const [camp,key]of [['survivor','civilian_data'],['hunter','butcher_data']]){
    const data=profile[key],history=object(data?.history_season_data)?data.history_season_data:{};
    camps[camp]=Object.entries(history).filter(([id,v])=>/^[1-9]\d{0,4}$/.test(id)&&object(v)&&(!Number.isInteger(data.season_id)||Number(id)<data.season_id)).map(([id,v])=>({
      season_id:Number(id),recorded_rank:rank(v,camp,Number(id),catalog),highest_rank:rank(historicalRankData(v.season_max_part_record),camp,Number(id),catalog),
      rank_characters:seasonRankCharacters(profile,v,camp,catalog),
      statistics:[['normal','通常戦'],['rank','ランク戦']].map(([mode,label])=>{
        const total=count(v[`${mode}_battle_cnt`]),wins=count(v[`${mode}_battle_win_cnt`]),losses=count(v[`${mode}_battle_lose_cnt`]);
        const consistent=(total===null||wins===null||wins<=total)&&(total===null||losses===null||losses<=total)&&(total===null||wins===null||losses===null||wins+losses<=total);
        return {mode,label,total:consistent?total:null,wins:consistent?wins:null,losses:consistent?losses:null,consistent};
      })
    })).sort((a,b)=>b.season_id-a.season_id);
  }
  return {...camps,coverage:'received_past_seasons'};
}
