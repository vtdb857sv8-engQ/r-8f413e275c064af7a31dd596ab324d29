import {inflateSync} from 'node:zlib';
import {ApiError} from '../errors.mjs';

const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
const number=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0?value:null;
const id=value=>typeof value==='string'&&/^\d{1,20}$/.test(value)?value:Number.isSafeInteger(value)&&value>=0?String(value):null;
const time=value=>number(value)!==null&&value>0&&value<8640000000000?new Date(value*1000).toISOString():null;
const invalid=()=>new ApiError(502,'MOJIN_RECORD_FORMAT_UNSUPPORTED','手記の加筆の戦績形式を確認できません。');

// Shared records use their own envelope, not the ordinary battle_records format.
// Return only the fields used by the self-history screen; never forward raw mode data.
export function presentMojinRecords({player_id,records,received_at,scope},catalog={}){
  if(!id(player_id)||!Array.isArray(records)||records.length>1000)throw invalid();
  const items=records.map(wrapper=>{
    if(!object(wrapper)||!(wrapper.shared_data instanceof Uint8Array))throw invalid();
    let record;
    try{record=JSON.parse(inflateSync(wrapper.shared_data,{maxOutputLength:2*1024*1024}).toString('utf8'));}catch{throw invalid();}
    if(!object(record)||!object(record.common_info)||!Array.isArray(record.all_pl_info)||![102,103].includes(record.common_info.match_type))throw invalid();
    const remap=object(wrapper.gm_clone_uid_map)?wrapper.gm_clone_uid_map:{};
    const mappedId=value=>id(remap[String(value)]??value);
    if(!record.all_pl_info.some(p=>object(p)&&mappedId(p.unique_id)===String(player_id)))throw invalid();
    const players=record.all_pl_info.map(p=>{
      if(!object(p))throw invalid();
      const mode=object(p.mode_info)?p.mode_info:{},pid=mappedId(p.unique_id),character=catalog.characters?.[p.pid],career=catalog.mojin?.careers?.[mode.career_id];
      const result=mode.battle_result===2?'success':mode.battle_result===1?'failure':'unknown';
      return {player_id:pid,name:typeof p.player_name==='string'?p.player_name:null,is_self:pid===String(player_id),portrait:Number.isSafeInteger(p.face)?`face-${p.face}`:null,frame:Number.isSafeInteger(p.face_frame)?`frame-${p.face_frame}`:null,character_id:Number.isSafeInteger(p.pid)?p.pid:null,character_name:character?.name??null,character_asset:character?.asset??null,career_id:Number.isSafeInteger(mode.career_id)?mode.career_id:null,career_name:career?.name??null,career_asset:career?.asset??null,result,result_label:catalog.mojin?.record_labels?.[result]??null,deliver_value:number(mode.deliver_amount),survive_time_seconds:number(mode.survive_time),ranked:typeof p.gold_rush_rank_mode==='boolean'?p.gold_rush_rank_mode:null};
    });
    const owner=record.all_pl_info.find(p=>mappedId(p.unique_id)===String(player_id));
    const visibleParty=p=>typeof p?.team_uid==='string'&&p.team_uid.length>0&&[undefined,true,1].includes(p.show_team);
    for(const [index,p]of players.entries()){const raw=record.all_pl_info[index];p.is_bot=raw.bot===true;p.premade_with_owner=!p.is_self&&visibleParty(owner)&&visibleParty(raw)?owner.team_uid===raw.team_uid:null;}
    const common=record.common_info,self=players.find(p=>p.is_self),level=catalog.mojin?.levels?.[common.level_id];
    return {record_id:typeof wrapper.bid==='string'?wrapper.bid:null,mode_id:common.match_type,mode_name:catalog.modes?.[common.match_type]??null,level_id:Number.isSafeInteger(common.level_id)?common.level_id:null,map_name:level?.map_name??null,map_asset:level?.map_asset??null,started_at:time(common.start_time),ended_at:time(common.end_time),duration_seconds:number(common.battle_time_exclude_pause),result:self.result,result_label:self.result_label,deliver_value:self.deliver_value,players};
  });
  return {scope:scope==='public'?'public':'self',player_id:String(player_id),source:scope==='public'?'request_friend_gold_rush_records':'request_self_gold_rush_records',received_at:received_at??null,coverage:'server_returned_records',items,total_received:items.length};
}

export function mojinMatchRecord(row){
  const result=row.result==='success'?'win':row.result==='failure'?'loss':'unknown';
  return {record_id:row.record_id,mojin_record:row,common_info:{start_time:row.started_at?Date.parse(row.started_at)/1000:null,end_time:row.ended_at?Date.parse(row.ended_at)/1000:null,battle_time_exclude_pause:row.duration_seconds},summary:{mode_id:row.mode_id,mode_name:row.mode_name,is_custom:false,map_id:row.level_id,map_name:row.map_name,map_asset:row.map_asset,result,result_label:row.result_label,duration:row.duration_seconds,ended_at:row.ended_at,character_id:row.players.find(p=>p.is_self)?.character_id??null,players:row.players.map(p=>({...p,camp:p.is_self||p.premade_with_owner===true?'mojin':null}))}};
}
