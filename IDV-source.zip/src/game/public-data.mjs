import {inflateSync} from 'node:zlib';
export const pick=(value,keys)=>Object.fromEntries(keys.filter(k=>value?.[k]!==undefined).map(k=>[k,clean(value[k])]));
const forbidden=/token|session|sauth|password|secret|device|^ip$|realname|birth|^account|^username$|logout_time_no_hide|real_stat|sign$|hide_score|^real_uid$|^fake_uid$|^character_value_info$/i;
export function clean(value,depth=0){
  if(depth>24)return null;
  if(typeof value==='bigint')return value.toString();
  if(value instanceof Uint8Array)return null;
  if(Array.isArray(value))return value.slice(0,1000).map(v=>clean(v,depth+1));
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).filter(([k])=>!forbidden.test(k)&&!['__proto__','constructor','prototype'].includes(k)).slice(0,1000).map(([k,v])=>[k,clean(v,depth+1)]));
  return value;
}
export function presenceOf(info,selfId){
  const rawState=info?.state_info,stateInfo=rawState&&typeof rawState==='object'&&!Array.isArray(rawState)?rawState:{};
  const known=Object.hasOwn(stateInfo,'state')&&[0,1,2].includes(stateInfo.state);
  const viewer=typeof selfId==='string'||typeof selfId==='number'||typeof selfId==='bigint'?String(selfId):null;
  const validViewer=viewer!==null&&/^[1-9]\d{0,19}$/.test(viewer);
  const owner=validViewer&&info?.unique_id!=null&&String(info.unique_id)===viewer;
  // Unknown disclosure flags are not permission to reveal another player's
  // state or timestamps. The authenticated account can still read its own data.
  if(!known&&!owner)return {state:'unknown',visibility:'unknown'};
  const excepted=key=>validViewer&&Array.isArray(stateInfo[key])&&stateInfo[key].some(id=>['string','number','bigint'].includes(typeof id)&&String(id)===viewer);
  const hidden=stateInfo.state===1&&!excepted('hide_show');
  if(hidden)return{state:'unknown',visibility:'hidden'};
  const code=info?.online_state??info?.online_stat;
  let state=code===0?'offline':typeof code==='number'&&code>0?'online':'unknown';
  const busy=stateInfo.state===2&&!excepted('busy_show');
  const notices={1:'idle',2:'in_team',3:'in_match',4:'in_match',5:'matching',6:'matching',7:'reserved',8:'reserved',9:'custom_room',10:'visiting',11:'visiting',12:'spectating',13:'online',14:'in_team'};
  if(state==='online')state=busy?'busy':notices[info?.avatar_notice_status]??state;
  return{state,visibility:known?'visible':'unknown',...(!busy?pick(info,['online_stat','battle_stat','avatar_notice_status']):{}),last_login_at:epoch(info?.login_time),last_logout_at:epoch(info?.logout_time)};
}
export function epoch(value){return typeof value==='number'&&value>0&&value<253402300800?new Date(value*1000).toISOString():null;}
export function profileOf(info,selfId,fallbackId,{completeProfile=false,specialFriendIds}={}){
  const id=String(info.unique_id??info.uid??info._id??fallbackId),owner=id===String(selfId),settings=info.setting_show_info;
  const known=!!settings&&typeof settings==='object'&&!Array.isArray(settings);
  const flag=(key,fallback)=>{if(!Object.hasOwn(settings??{},key))return fallback;const v=settings[key];return v===true||v===1?true:v===false||v===0?false:undefined;};
  const statFlags=[flag('open_char_data',true),...['hide_max_history_rank','hide_battle_page_info','hide_fre_used_role_info'].map(k=>flag(k,false))],tagFlags=['hide_badge','hide_history_badge'].map(k=>flag(k,false));
  // Policy: data received from the game is displayed even when the target's
  // privacy setting explicitly hides the group. Only unreadable disclosure
  // settings (unknown) keep suppressing the groups.
  const stats=owner?'self':!known||statFlags.includes(undefined)?'unknown':'permitted',tags=owner?'self':!known||tagFlags.includes(undefined)?'unknown':'permitted';
  const historyFlag=flag('hide_history_badge',false),historyBadges=owner?'self':!known||historyFlag===undefined?'unknown':'permitted';
  const data={player_id:id,name:info.name??info.nickname??null,...pick(info,['face_id','face_frame_id','face_vfx_id','gender','likes','sum_exp_score']),presence:presenceOf(info,selfId),field_access:{statistics:stats,profile_tags:tags,history_badges:historyBadges}};
  const characterAccess=owner?'self':stats!=='permitted'?stats:!completeProfile?'unknown':'permitted';
  data.field_access.frequent_characters=characterAccess;data.field_access.season_characters=characterAccess;
  const talent=flag('open_talent',true);
  data.field_access.persona=owner?'self':!known||talent===undefined?'unknown':!completeProfile?'unknown':'permitted';
  Object.assign(data,pick(stats==='unknown'?[]:info,['civilian_data','butcher_data','ladder_rank_data','battle_count','mvp','character_num','character_ladder_score_list']));
  Object.assign(data,pick(tags==='unknown'?[]:info,['profile_tag_info']));
  if(tags!=='unknown'&&info.time_limited_article&&typeof info.time_limited_article==='object')data.badge_records=clean(info.time_limited_article['50']??{});
  if(owner)Object.assign(data,pick(info,['setting_show_info']));
  return data;
}
// Raw game responses stay in memory. Apply the received disclosure rules and
// the fresh rules before exposing any profile group to an API client.
export function profileAfterReceipt(received,latest,selfId,options={}){
  const first=profileOf(received,selfId,undefined,options),current=profileOf(latest,selfId,undefined,options);
  const allowed=value=>['self','permitted'].includes(value);
  for(const key of Object.keys(first.field_access)){
    const a=first.field_access[key],b=current.field_access[key];
    first.field_access[key]=!allowed(b)?b:!allowed(a)?a:b;
  }
  if(!allowed(first.field_access.statistics))for(const key of ['civilian_data','butcher_data','ladder_rank_data','battle_count','mvp','character_num','character_ladder_score_list'])delete first[key];
  if(!allowed(first.field_access.profile_tags)){delete first.profile_tag_info;delete first.badge_records;}
  first.presence=current.presence;
  first.disclosure={checked_at:new Date().toISOString(),policy:'after_receipt'};
  return first;
}
export function decodeRecords(records){
  const result=[];
  for(let record of records??[]){
    const wrapper=record;
    if(Array.isArray(record)&&record.length===2)record=record[1];
    if(record?.origin_data!==undefined)record=record.origin_data;
    if(record instanceof Uint8Array){
      try{record=JSON.parse(inflateSync(record,{maxOutputLength:2*1024*1024}).toString('utf8'));}catch{throw new Error('BATTLE_RECORD_DECODE_FAILED');}
    }
    if(record&&typeof record==='object'&&!Array.isArray(record))result.push({...clean(record),...(wrapper?.tm?{recorded_at:epoch(wrapper.tm)}:{}),...(wrapper?.uuid?{record_id:wrapper.uuid}:{})});
  }
  return result;
}
export function chatOf(info){
  return{message_id:info.msg_uuid??null,channel:String(info.channel??''),content:typeof info.content==='string'?info.content:'',sent_at:epoch(info.time),author:{player_id:String(info.unique_id??''),...pick(info,['name','face_id','face_frame_id'])},...pick(info,['quote_content','province_id','chatroom_id'])};
}
