import {EventEmitter} from 'node:events';
import {ApiError} from '../errors.mjs';
import {GameSession} from './session.mjs';
import {profileOf,profileAfterReceipt,presenceOf,decodeRecords,chatOf,pick,clean} from './public-data.mjs';
import {setTimeout as delay} from 'node:timers/promises';
import {historyAccess} from './history-access.mjs';
import {randomUUID} from 'node:crypto';
import {ugcRankMetadata,presentUGCMapRanking} from './ugc-data.mjs';
import {publicMojinProfile,publicMojinHistory} from './mojin-public.mjs';
const featureNames=['authentication','rankings','friends','globalChat','recruitments','search','profiles','matchHistory','presence'];
const timeoutError=()=>new ApiError(504,'GAME_RESPONSE_TIMEOUT','ゲームサーバーから応答がありません。再接続してください。');
const retryableDisconnects=new Set(['GATEWAY_NETWORK_ERROR','GATEWAY_CLOSED','GATEWAY_RESPONSE_TIMEOUT','GAME_RESPONSE_TIMEOUT','GAME_SEND_FAILED']);
const disconnectDetail=(code,request)=>({code,retryable:retryableDisconnects.has(code),...(request?{request_method:request.method,request_callback:request.callback}:{})});
const loginFailureReasons={SDK_AUTH_REJECTED:'sdk_auth_failed',GAME_LOGIN_REJECTED:'login_rejected',GAME_LOGIN_RESPONSE_INVALID:'unverified_reply'};
export class LiveGameProvider extends EventEmitter{
  constructor(config,{sessionFactory=()=>new GameSession(config),requestTimeoutMs=10000,searchIntervalMs=5000,ugcInfoIntervalMs=5000,onDiagnostics=()=>{}}={}){
    super();this.config=config;this.sessionFactory=sessionFactory;this.requestTimeoutMs=requestTimeoutMs;this.searchIntervalMs=searchIntervalMs;this.ugcInfoIntervalMs=ugcInfoIntervalMs;this.onDiagnostics=onDiagnostics;this.connected=false;this.independentVerified=false;this.verified=new Set();this.serial=Promise.resolve();this.queued=0;this.cache=new Map();this.chat=[];this.friends=new Map();this.chatSequence=0;this.publicChannels=new Set();this.privateChats=new Map();this.outgoing=new Map();
  }
  capabilities(){return Object.fromEntries(featureNames.map(k=>[k,this.verified.has(k)]));}
  requireConnected(){if(!this.connected)throw new ApiError(503,'GAME_NOT_CONNECTED','ゲームセッションに接続してください。');}
  async connect(credentials,{replaceExisting=false}={}){
    await this.disconnect();
    if(credentials?.server&&credentials.server!==(this.config.server??'asia'))throw new ApiError(409,'GATEWAY_REGION_MISMATCH','認証情報とゲーム接続先の地域が一致しません。');
    if(!credentials?.login_info?.info)throw new ApiError(409,'SDK_SESSION_REQUIRED','保存されたSDKセッションが必要です。');
    this.friends.clear();this.cache.clear();this.chat=[];this.chatRoom=null;this.publicChannels.clear();this.privateChats.clear();this.outgoing.clear();this.readyFlags=new Set();this.session=this.sessionFactory();const session=this.session;
    try{
      const result=await session.login({...credentials.login_info,login_confirm:replaceExisting});
      if(!result.authenticated)throw new ApiError(409,'GAME_ALREADY_ONLINE','PC側がログイン中です。replace_existing: true でAPI側へ切り替えられます。');
      this.selfId=String(result.avatar_info.unique_id);this.hostNum=result.avatar_info.host_num??configHost(this.config);this.connected=true;this.independentVerified=true;this.verified.add('authentication');
      this.lastReceived=Date.now();this.reader=this.readLoop(session);
      await this.waitReady();
      this.heartbeat=setInterval(()=>{try{session.sendEntity(session.avatar,'heart_beat',{});}catch{this.lost(session,disconnectDetail('GAME_SEND_FAILED'));}},10000);this.heartbeat.unref();
    }catch(error){if(this.session===session){const code=error.code??(retryableDisconnects.has(error.message)?error.message:'GAME_LOGIN_FAILED'),detail=disconnectDetail(code);if(Object.hasOwn(loginFailureReasons,code))detail.login_failure={reason:loginFailureReasons[code],server_code:Number.isSafeInteger(error.serverLoginCode)&&error.serverLoginCode>=0&&error.serverLoginCode<=0x7fffffff?error.serverLoginCode:null};this.lost(session,detail);}throw error instanceof ApiError?error:new ApiError(502,'GAME_LOGIN_FAILED','独立ログインに失敗しました。SDKセッションの期限と接続先を確認してください。');}
  }
  waitReady(){
    this.requireConnected();
    if(this.readyFlags.size===2)return Promise.resolve();
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{cleanup();reject(timeoutError());},10000);
      const ready=()=>{if(this.readyFlags.size===2){cleanup();resolve();}},lost=()=>{cleanup();reject(new ApiError(502,'GAME_DISCONNECTED','ゲーム接続が終了しました。'));};
      const cleanup=()=>{clearTimeout(timer);this.off('ready',ready);this.off('disconnected',lost);};this.on('ready',ready);this.on('disconnected',lost);
    });
  }
  async readLoop(session){
    while(this.connected&&this.session===session){
      try{const event=await session.receive(30000);this.lastReceived=Date.now();this.handle(event);}
      catch(error){if(error.message==='GATEWAY_RESPONSE_TIMEOUT'&&Date.now()-this.lastReceived<90000)continue;this.lost(session,disconnectDetail(retryableDisconnects.has(error.message)?error.message:'GAME_PROTOCOL_ERROR',this.pending));break;}
    }
  }
  lost(session,detail=disconnectDetail('GAME_DISCONNECTED')){
    if(this.session!==session)return;this.connected=false;this.lastDisconnect={...detail,at:new Date().toISOString()};clearInterval(this.heartbeat);this.heartbeat=null;this.pending?.reject(new ApiError(502,'GAME_DISCONNECTED','ゲーム接続が終了しました。'));this.pending=null;session?.close();this.session=null;try{this.onDiagnostics(session.events??[],this.lastDisconnect);}catch{}this.emit('disconnected',this.lastDisconnect);
  }
  async disconnect(){const old=this.session;if(old)this.lost(old,disconnectDetail('SESSION_DISCONNECTED'));if(this.reader)await this.reader;this.reader=null;}
  handle(event){
    if(event.kind!=='rpc')return;
    const {name,parameters:p}=event,info=p.info;
    if(['notify_role_online_confirm','on_replace_login_cancel'].includes(name)){this.lost(this.session,disconnectDetail('GAME_ALREADY_ONLINE'));return;}
    if(name==='init_player'){this.selfInfo=info;this.selfInfoReceivedAt=new Date().toISOString();this.readyFlags.add('self');this.emit('ready');}
    if(name==='notify_friends_info'){
      const entries=info?.[1]??{};this.friends=new Map(Object.entries(entries));this.verified.add('friends');this.verified.add('presence');this.readyFlags.add('friends');this.emit('ready');
    }
    if(name==='request_friend_status_info_cb')for(const [id,updates] of Object.entries(info??{})){const entry=this.friends.get(id);if(entry){Object.assign(entry,updates);this.emitFriend(entry);}}
    if(name==='notify_friend_on_off'&&Array.isArray(info)){
      const [id,status,,updates]=info,entry=this.friends.get(String(id));if(entry){Object.assign(entry,updates??{});entry.online_stat=status;this.emitFriend(entry);}
    }
    if(name==='notify_udpate_friend_info')for(const [id,updates] of Object.entries(p.update_info??{})){
      const entry=this.friends.get(String(id));if(entry){for(const [k,v] of Object.entries(updates)){if(v===null)delete entry[k];else entry[k]=v;}this.emitFriend(entry);}
    }
    if(name==='update_friends_info_attr'){
      const entry=this.friends.get(String(info?.uid));if(entry){for(const [k,v] of Object.entries(info.update_info??{}))this.deepSet(entry,k,v);this.emitFriend(entry);}
    }
    if(name==='on_receive_region_chat_lst')this.addChats(info?.chat_info_lst??[],true);
    if(name==='reply_enter_province_chatroom'){
      this.publicChannels.add('4');this.chatRoom={province_id:info.province_id??this.lastRequestedProvince,chatroom_id:info.chatroom_id};this.addChats(info.chat_info_lst??[],true);this.verified.add('globalChat');
    }
    if(name==='on_receive_chat')this.addChats([info]);
    if(name==='on_receive_chat_lst')this.addChats(info?.chat_info_lst??info?.chat_lst??[]);
    if(name==='on_friend_chat')this.addFriendChat(info);
    // History disclosure is evaluated by fetchHistory after receipt. Do not
    // mutate the received payload before that permission decision.
    if(this.pending?.predicate(event)){this.pending.resolve(p);this.pending=null;}
  }
  deepSet(target,key,value){
    const parts=String(key).split('.');if(parts.some(k=>['__proto__','prototype','constructor'].includes(k)))return;
    let cursor=target;for(const part of parts.slice(0,-1)){if(!cursor[part]||typeof cursor[part]!=='object')cursor[part]={};cursor=cursor[part];}cursor[parts.at(-1)]=value;
  }
  emitFriend(entry){this.emit('presence',{player_id:String(entry.unique_id),...presenceOf(entry,this.selfId),observed_at:new Date().toISOString()});}
  addChats(items,publicRoom=false){
    for(const item of items){if(!item||!['number','string'].includes(typeof item.channel))continue;
      if(publicRoom)this.publicChannels.add(String(item.channel));
      if(!this.publicChannels.has(String(item.channel)))continue;
      if(item.msg_uuid&&this.chat.some(c=>c.message_id===item.msg_uuid))continue;
      this.chat.push({...chatOf(item),province_id:String(item.province_id??this.chatRoom?.province_id??''),sequence:++this.chatSequence});
    }
    this.chat=this.chat.slice(-500);if(this.chat.length)this.verified.add('globalChat');
  }
  request(method,parameters,callback,predicate=()=>true){
    const originSession=this.session;
    if(this.queued>=20)return Promise.reject(new ApiError(429,'GAME_QUEUE_FULL','処理待ちが多いため、少し待ってください。'));this.queued++;
    const run=async()=>{
      this.requireConnected();
      if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が更新されました。読み込みをやり直してください。');
      if(method==='search_uid'||method==='search_name'){
        const wait=this.searchIntervalMs-(Date.now()-(this.lastSearchAt??0));if(wait>0)await delay(wait);this.requireConnected();if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が更新されました。読み込みをやり直してください。');this.lastSearchAt=Date.now();
      }
      if(method==='client_server_gen_rpc_method'&&parameters.info?.methodname==='get_ugc_map_info'){
        const wait=this.ugcInfoIntervalMs-(Date.now()-(this.lastUGCInfoAt??0));if(wait>0)await delay(wait);this.requireConnected();if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が更新されました。読み込みをやり直してください。');this.lastUGCInfoAt=Date.now();
      }
      const session=this.session;
      if(method==='request_enter_province_chatroom'){const wait=5000-(Date.now()-(this.lastRoomChangeAt??0));if(wait>0)await delay(wait);this.requireConnected();if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が更新されました。読み込みをやり直してください。');this.lastRequestedProvince=parameters.info.province_id;this.lastRoomChangeAt=Date.now();}
      return new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{if(this.pending===pending)this.pending=null;reject(timeoutError());this.lost(session,disconnectDetail('GAME_RESPONSE_TIMEOUT',{method,callback}));},this.requestTimeoutMs);
        const pending={method,callback,predicate:e=>e.kind==='rpc'&&e.name===callback&&predicate(e.parameters),resolve:p=>{clearTimeout(timer);resolve(p);},reject:e=>{clearTimeout(timer);reject(e);}};
        this.pending=pending;try{session.sendEntity(session.avatar,method,parameters);}catch{this.pending=null;pending.reject(new ApiError(502,'GAME_SEND_FAILED','ゲームへの要求を送信できませんでした。'));this.lost(session,disconnectDetail('GAME_SEND_FAILED',{method,callback}));}
      });
    };
    const result=this.serial.then(run,run);this.serial=result.catch(()=>{});return result.finally(()=>{this.queued--;});
  }
  async cached(key,ttl,load){
    const old=this.cache.get(key);if(old&&old.expires>Date.now())return old.value;
    const value=Promise.resolve().then(load);this.cache.set(key,{expires:Date.now()+ttl,value});
    if(this.cache.size>256)this.cache.delete(this.cache.keys().next().value);
    try{return await value;}catch(e){this.cache.delete(key);throw e;}
  }
  page(items,{limit=50,cursor=null}={}){
    if(cursor!==null&&!/^\d{1,6}$/.test(cursor))throw new ApiError(400,'INVALID_CURSOR','cursor が不正です。');
    const offset=Number(cursor??0);return{items:items.slice(offset,offset+limit),next_cursor:offset+limit<items.length?String(offset+limit):null,total_received:items.length};
  }
  async getFriends(){this.requireConnected();return [...this.friends.values()].map(v=>profileOf(v,this.selfId));}
  getMojinSelf(){
    this.requireConnected();
    if(!this.selfInfo?.gold_rush_common_data||typeof this.selfInfo.gold_rush_common_data!=='object'||Array.isArray(this.selfInfo.gold_rush_common_data))throw new ApiError(409,'MOJIN_SELF_DATA_UNAVAILABLE','手記の加筆の自己データは未受信です。');
    return {player_id:this.selfId,received_at:this.selfInfoReceivedAt,common:this.selfInfo.gold_rush_common_data,survivor:this.selfInfo.gold_rush_data,hunter:this.selfInfo.gold_rush_butcher_data};
  }
  async getPlayerMojin(id){return publicMojinProfile(this,id);}
  async getPlayerMojinHistory(id){return publicMojinHistory(this,id);}
  async getMojinHistory(){
    this.requireConnected();
    return await this.cached('mojin:self-history',15000,async()=>{
      const player_id=this.selfId,callbackid=this.genericCallbackSequence=(this.genericCallbackSequence??0)+1;
      const reply=await this.request('client_server_gen_rpc_method',{info:{callbackid,methodname:'request_self_gold_rush_records',args:[],kwargs:{}}},'rpc_callback',p=>p.info?.callbackid===callbackid);
      const res=reply.info?.res;
      if(!Array.isArray(res)||res[0]!==0)throw new ApiError(502,'MOJIN_HISTORY_UNAVAILABLE','手記の加筆の自己戦績を取得できませんでした。');
      const records=Array.isArray(res[1])?res[1]:res[1]?.records;
      if(!Array.isArray(records))throw new ApiError(502,'MOJIN_RECORD_FORMAT_UNSUPPORTED','手記の加筆の戦績形式を確認できません。');
      return {player_id,records,received_at:new Date().toISOString()};
    });
  }
  async searchPlayers(query){
    this.requireConnected();const numeric=/^\d+$/.test(query),reply=await this.cached('search:'+query,5000,()=>this.request(numeric?'search_uid':'search_name',numeric?{uid:query}:{name:query},'reply_friend_search'));
    this.verified.add('search');return(reply.info??[]).map(v=>profileOf(v,this.selfId));
  }
  async getProfile(id,{fresh=false}={}){
    this.requireConnected();const origin=this.session;
    const load=()=>this.request('ask_player_cil_butcher_data',{uid:id},'reply_cil_butcher_data');
    const reply=fresh||id!==this.selfId?await load():await this.cached('profile:'+id,15000,load);
    const unpack=reply=>{
      const data=reply.info??{};
      if(data._high_version)throw new ApiError(409,'PROFILE_VERSION_UNSUPPORTED','プロフィールの形式が更新されています。');
      if(!data.base_info&&!data.civilian_data&&!data.butcher_data)throw new ApiError(404,'PLAYER_NOT_FOUND','プロフィールを取得できませんでした。');
      const target=data.base_info?.unique_id??data.unique_id;
      if(target!=null&&String(target)!==String(id))throw new ApiError(502,'PROFILE_RESPONSE_MISMATCH','プロフィールの応答対象を確認できません。');
      return {...((id===this.selfId)?this.selfInfo:{}),...data,...(data.base_info??{}),unique_id:id};
    };
    const data=unpack(reply),latest=id===this.selfId?data:unpack(await load());
    if(this.session!==origin)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    this.verified.add('profiles');return profileAfterReceipt(data,latest,this.selfId,{completeProfile:true,specialFriendIds:this.config?.special_friend_ids});
  }
  async getHistoryBadges(id){
    this.requireConnected();const origin=this.session;
    const reply=await this.request('get_history_badge',{uid:id,widget:'UIDocumentMain'},'reply_get_history_badge',p=>String(p.info?.uid)===String(id));
    if(this.session!==origin)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    const permission=id===this.selfId?'self':(await this.getProfile(id,{fresh:true})).field_access.history_badges;
    if(this.session!==origin)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    // Policy: received badge records are displayed even when the target's
    // privacy setting hides them. Only unreadable disclosure stays refused.
    if(!['self','permitted'].includes(permission))throw new ApiError(409,'HISTORY_BADGES_PERMISSION_UNKNOWN','過去徽章の公開範囲を確認できません。');
    const records=reply.info?.info;
    if(reply.info?._high_version||!records||typeof records!=='object'||Array.isArray(records))throw new ApiError(502,'HISTORY_BADGES_FORMAT_UNSUPPORTED','過去徽章の応答形式を確認できません。');
    return {player_id:id,access:permission,records:clean(records)};
  }
  async getPersona(id,{characterId}={}){
    this.requireConnected();const origin=this.session;
    if(!/^[1-9]\d{0,19}$/.test(String(id))||!Number.isSafeInteger(characterId)||characterId<1||characterId>10000)throw new ApiError(400,'INVALID_INPUT','プレイヤーとキャラクターを指定してください。');
    // Same read used by the ranking's normal persona button. No alternate private-data RPC.
    const envelope=await this.request('get_data_from_cache',{db_name:'entities',key_lst:[String(id)],client_cb:'reply_get_genius_data',need_fields:[],ignore_fields:[]},'reply_get_data_from_cache');
    const reply=envelope.info??envelope;
    if(this.session!==origin)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    const latest=await this.getProfile(String(id),{fresh:true});
    if(this.session!==origin)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    const reported=latest.field_access?.persona;
    // Policy: a received persona loadout is displayed even when the target's
    // privacy setting hides it. Only unreadable disclosure stays refused.
    if(!['self','permitted','hidden'].includes(reported))throw new ApiError(409,'PERSONA_PERMISSION_UNKNOWN','人格の公開範囲を確認できません。');
    const access=reported;
    if(reply.db_name!=='entities'||reply.client_cb!=='reply_get_genius_data')throw new ApiError(502,'PERSONA_RESPONSE_UNVERIFIED','人格の応答を確認できません。');
    const dict=reply.info_dict,entity=dict&&typeof dict==='object'&&!Array.isArray(dict)?dict[String(id)]:null;
    if(!entity||entity._high_version||typeof entity!=='object'||Array.isArray(entity))throw new ApiError(502,'PERSONA_RESPONSE_UNVERIFIED','人格の応答を確認できません。');
    if(entity.players?.unique_id!=null&&String(entity.players.unique_id)!==String(id))throw new ApiError(502,'PERSONA_RESPONSE_UNVERIFIED','人格の応答を確認できません。');
    const receivedSetting=entity.players?.setting_show_info;
    if(Object.hasOwn(receivedSetting??{},'open_talent')&&![true,1,false,0].includes(receivedSetting.open_talent))
      throw new ApiError(409,'PERSONA_PERMISSION_UNKNOWN','人格の公開範囲を確認できません。');
    return {player_id:String(id),character_id:characterId,access,received_at:new Date().toISOString(),players:pick(entity.players??{},['pid_to_genius','pid_genius','civilian_data','butcher_data'])};
  }
  async fetchHistory(id){
    this.requireConnected();const self=id===this.selfId,origin=this.session;
    const load=()=>this.request(self?'request_self_battle_records':'request_friend_battle_records',self?{show_type:'self'}:{uid:id},self?'reply_request_self_battle_records':'reply_request_friend_battle_records');
    // Other players' permissions are rechecked; an old allowed response is never reused.
    const reply=self?await this.cached('history:'+id,15000,load):await load();
    if(this.session!==origin)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    const access=historyAccess(id,this.selfId,reply.info);
    return{access,info:access.allowed?reply.info:null};
  }
  async getHistoryAccess(id){return(await this.fetchHistory(id)).access;}
  async getMatchHistory(id,options){
    const {access,info}=await this.fetchHistory(id);
    if(!access.allowed){
      if(access.visibility==='private')throw new ApiError(403,'HISTORY_PRIVATE','このプレイヤーは戦績を非公開にしています。');
      throw new ApiError(409,'HISTORY_PERMISSION_UNKNOWN','戦績の閲覧許可を確認できないため表示しません。');
    }
    this.verified.add('matchHistory');return{...this.page(decodeRecords(info.battle_records),options),visibility:access.visibility,access};
  }
  async getRankings(options){
    this.requireConnected();const character=options.character_id??null;
    if(character!==null&&(!Number.isSafeInteger(character)||character<1||character>10000))throw new ApiError(400,'INVALID_CHARACTER','character_id が不正です。');
    const camp=character!==null?`rank_${character}`:options.kind==='hunter'?'rank_b':'rank_c';
    const reply=await this.cached('rank:'+camp,30000,()=>this.request('ask_rank_data',{show_tab:'2',show_camp:camp},'reply_rank_data',p=>p.info?.show_camp===camp));this.verified.add('rankings');
    const items=(reply.info?.rank_lst??[]).map((v,i)=>({position:i+1,player_id:String(v.unique_id??v.uid),...pick(v,['name','face_id','face_frame_id','part','part_lv','part_star','sum_star','lv','hm','season_id']),...(character!==null?{character_id:character,character_score:typeof(v.ladder_score??v.score)==='number'?(v.ladder_score??v.score):null}:{})}));
    return{...this.page(items,options),scope:'global',kind:options.kind,character_id:character,rank_percent:reply.info?.rank_percent??null};
  }
  async getUGCPlayHistory(){
    this.requireConnected();
    const records=await this.cached('ugc:own-play-history',30000,()=>this.requestUGCRead('get_ugc_play_record',[]));
    return {scope:'self',records:clean(records)};
  }
  async requestUGCRead(methodname,args){
    if(!['get_ugc_play_record','get_ugc_rank_week_maps','get_ugc_rank_month_maps','get_ugc_map_info','get_ugc_map_single_rank'].includes(methodname))throw new ApiError(400,'INVALID_UGC_READ','対応していない読み取り要求です。');
    this.requireConnected();this.genericCallbackSequence=(this.genericCallbackSequence??0)+1;const callbackid=this.genericCallbackSequence;
    const reply=await this.request('client_server_gen_rpc_method',{info:{callbackid,methodname,args,kwargs:{}}},'rpc_callback',p=>p.info?.callbackid===callbackid);
    const result=reply.info?.res;
    if(!Array.isArray(result)||result[0]!==0)throw new ApiError(502,'UGC_DATA_UNAVAILABLE','ペン先の空想のデータを取得できませんでした。');
    return result[1];
  }
  async getUGCRankings({period='week',tag=1000}={}){
    this.requireConnected();
    if(!['week','month'].includes(period)||(!Number.isInteger(tag)||!((tag>=1&&tag<=14)||tag===1000)))throw new ApiError(400,'INVALID_UGC_RANKING','期間または作品ジャンルが不正です。');
    const rows=await this.cached(`ugc:rank:${period}:${tag}`,60000,()=>this.requestUGCRead(`get_ugc_rank_${period}_maps`,[tag,null]));
    if(!Array.isArray(rows))throw new ApiError(502,'UGC_FORMAT_UNSUPPORTED','ペン先の空想のランキング形式を確認できませんでした。');
    return {period,tag,items:clean(rows),total_received:rows.length};
  }
  async getUGCMapRanking(id){
    this.requireConnected();
    if(typeof id!=='string'||!/^\d{1,20}$/.test(id))throw new ApiError(400,'INVALID_UGC_MAP','公開作品の数字IDを指定してください。');
    const originSession=this.session;
    ugcRankMetadata(await this.requestUGCRead('get_ugc_map_info',[id]),id);
    if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    const result=await this.requestUGCRead('get_ugc_map_single_rank',[id]);
    if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    // Do not reuse a cached permission after fetching the ranking.
    const map=ugcRankMetadata(await this.requestUGCRead('get_ugc_map_info',[id]),id);
    if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。再取得してください。');
    return presentUGCMapRanking(result,map);
  }
  async getRecruitments(options){
    this.requireConnected();const modes={normal:1,rank:2,custom:3};const mode=options.mode??'normal';
    if(!modes[mode])throw new ApiError(400,'INVALID_MODE','mode は normal / rank / custom を指定してください。');
    const reply=await this.cached('recruit:'+mode,10000,()=>this.request('request_recruit_info_lst',{info:{channel:1,select_cond:[1,5],cond_params:new Map([[1,[modes[mode]]]])}},'request_recruit_info_lst_cb'));
    this.verified.add('recruitments');const items=(reply.recruit_info_lst??[]).map(v=>({recruitment_id:v.r_id??v.rid,owner:{player_id:String(v.unique_id),name:v.player_name},...pick(v,['lv','butcher_part','civilian_part','start_tm','last_edit_tm','timeout_tm','team_num']),conditions:pick(v.client_data,['recruit_name','game_type','role','difficulty','usr_lv_restrict','usr_part_restrict','is_pc','mem_check','language','channel','map_name','leader_is_pc','language_select','quit_type'])}));return this.page(items,options);
  }
  async getGlobalChat(options){
    this.requireConnected();
    const province=options.room??this.chatRoom?.province_id??this.config.chat_province_id??this.selfInfo?.cur_province_id;
    if(options.room&&!this.chatRooms().rooms.some(r=>r.id===options.room))throw new ApiError(400,'INVALID_CHAT_ROOM','接続できるチャットルームを指定してください。');
    if(String(this.chatRoom?.province_id)!==String(province)){
      if(!province)throw new ApiError(409,'CHAT_REGION_REQUIRED','公開チャットの地域設定が必要です。');
      await this.request('request_enter_province_chatroom',{info:{province_id:String(province)}},'reply_enter_province_chatroom');
    }
    const publicChannels=this.publicChannels??new Set();
    const channel=options.channel;
    if(channel&&!publicChannels.has(String(channel)))throw new ApiError(400,'INVALID_CHANNEL','取得済みの公開チャットのchannelを指定してください。');
    const after=options.cursor===null||options.cursor===undefined?0:Number(options.cursor);if(!Number.isSafeInteger(after)||after<0)throw new ApiError(400,'INVALID_CURSOR','cursor が不正です。');
    const filtered=this.chat.filter(v=>publicChannels.has(v.channel)&&(!channel||v.channel===channel)&&(province==null||String(v.province_id)===String(province))&&v.sequence>after);
    const items=options.cursor!==null&&options.cursor!==undefined?filtered.slice(0,options.limit):filtered.slice(-options.limit);
    return{items,next_cursor:items.length?String(items.at(-1).sequence):String(after),buffered:true,truncated:after>0&&this.chat.length>0&&this.chat[0].sequence>after+1,channels:[...publicChannels],room:this.chatRoom??null};
  }
  chatRooms(){return {server:this.config.server??'asia',current_room:String(this.chatRoom?.province_id??this.config.chat_province_id??''),rooms:this.config.chat_rooms??[{id:String(this.config.chat_province_id??'3'),name:'現在のルーム'}]};}
  friendRecord(id){const pair=[...this.friends].find(([,f])=>String(f.unique_id)===String(id));return pair?{uid:pair[0],info:pair[1]}:null;}
  friendEntry(id){return this.friendRecord(id)?.info;}
  addFriendChat(raw,friendId){
    if(!raw||typeof raw!=='object')return;const id=String(friendId??this.friends.get(String(raw.uid??raw.friend_uid))?.unique_id??'');if(!this.friendEntry(id))return;
    const content=raw.message??raw.content;if(typeof content!=='string')return;
    const list=this.privateChats.get(id)??[],mark=String(raw.msg_uuid??raw.mark??'');if(mark&&list.some(m=>m.message_id===mark))return;
    const author=(raw.uid!==undefined&&String(raw.uid)===String(this.selfId))||raw.is_self_message===1?this.selfId:id;
    list.push({message_id:mark||null,channel:'friend',content,sent_at:typeof(raw.current_time??raw.time)==='number'?new Date((raw.current_time??raw.time)*1000).toISOString():null,author:{player_id:author,name:author===this.selfId?(this.selfInfo?.nickname??this.selfInfo?.name):this.friendEntry(id)?.name},sequence:++this.chatSequence});this.privateChats.set(id,list.slice(-500));
  }
  async getFriendChat(id,options={}){
    this.requireConnected();if(!this.friendEntry(id))throw new ApiError(404,'FRIEND_REQUIRED','フレンドとのチャットのみ利用できます。');
    const uid=this.friendRecord(id).uid;
    await this.cached('friend-chat:'+id,10000,async()=>{const reply=await this.request('fetch_friend_chat_info',{friend_uid:uid,need_base:true},'reply_fetch_friend_chat_from_server',v=>String(v.friend_uid)===String(uid));for(const raw of reply.info?.[uid]??[])this.addFriendChat(raw,id);return true;});
    const list=this.privateChats.get(id)??[],after=Number(options.cursor??0),items=list.filter(m=>m.sequence>after).slice(-(options.limit??50));return {items,next_cursor:items.length?String(items.at(-1).sequence):String(after),buffered:true};
  }
  async sendChat({friendId,content,room,clientMessageId}){
    const originSession=this.session;
    this.requireConnected();if(typeof content!=='string'||!content.trim()||[...content].length>500)throw new ApiError(400,'INVALID_MESSAGE','メッセージを1〜500文字で入力してください。');
    if(friendId&&!this.friendEntry(friendId))throw new ApiError(404,'FRIEND_REQUIRED','フレンドとのチャットのみ利用できます。');
    const targetRoom=friendId?null:String(room??this.chatRoom?.province_id??this.config.chat_province_id??this.selfInfo?.cur_province_id??'');
    if(!friendId){await this.getGlobalChat({room:targetRoom,limit:1});if(!Number.isFinite(Number(this.hostNum??this.selfInfo?.host_num)))throw new ApiError(409,'CHAT_HOST_UNAVAILABLE','送信先サーバー情報を取得できません。');}
    const mark=clientMessageId??randomUUID();if(!/^[a-zA-Z0-9-]{16,80}$/.test(mark))throw new ApiError(400,'INVALID_MESSAGE_ID','メッセージIDが不正です。');
    const fingerprint=JSON.stringify([friendId??null,targetRoom,content]);
    const duplicate=()=>{const previous=this.outgoing.get(mark);if(previous&&previous.fingerprint!==fingerprint)throw new ApiError(409,'MESSAGE_ID_CONFLICT','別の内容には新しいメッセージIDを指定してください。');return previous?.result;};
    const previous=duplicate();if(previous)return previous;
    if(this.queued>=20)throw new ApiError(429,'GAME_QUEUE_FULL','処理待ちが多いため、少し待ってください。');this.queued++;
    const run=()=>{this.requireConnected();if(this.session!==originSession)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が更新されました。送信先を確認してやり直してください。');const saved=duplicate();if(saved)return saved;if(Date.now()-(this.lastChatSentAt??0)<3000)throw new ApiError(429,'CHAT_SEND_COOLDOWN','続けて送信する場合は少し待ってください。');if(!friendId&&String(this.chatRoom?.province_id)!==targetRoom)throw new ApiError(409,'CHAT_ROOM_CHANGED','チャットルームが変わりました。送信先を確認して再送してください。');
      const friend=friendId?this.friendRecord(friendId):null;if(friendId&&!friend)throw new ApiError(404,'FRIEND_REQUIRED','フレンドとのチャットのみ利用できます。');
      const info=friendId?{uid:friend.uid,message:content,message_type:0,extra_info:{},chat_source_is_public:0,sp_key:null,mark}:{channel:4,content,host_num:Number(this.hostNum??this.selfInfo?.host_num),msg_uuid:mark,province_id:targetRoom};this.session.sendEntity(this.session.avatar,friendId?'friend_chat':'request_send_chat',{info});this.lastChatSentAt=Date.now();const result={client_message_id:mark,delivery:'submitted',server_confirmation:false};this.outgoing.set(mark,{fingerprint,result});if(this.outgoing.size>200)this.outgoing.delete(this.outgoing.keys().next().value);return result;};
    const pending=this.serial.then(run,run);this.serial=pending.catch(()=>{});return pending.finally(()=>{this.queued--;});
  }
  async pollPresence(ids){
    this.requireConnected();const result=[];
    const friendIds=new Set([...this.friends.values()].map(v=>String(v.unique_id)));
    if(ids.some(id=>friendIds.has(id)))await this.cached('friends:status',10000,()=>this.request('request_friend_status_info',{},'request_friend_status_info_cb'));
    const others=ids.filter(id=>!friendIds.has(id)),batch=[];
    for(let i=0;i<Math.min(5,others.length);i++)batch.push(others[((this.otherCursor??0)+i)%others.length]);this.otherCursor=((this.otherCursor??0)+batch.length)%Math.max(others.length,1);
    for(const id of ids){
      const entry=[...this.friends.values()].find(v=>String(v.unique_id)===id);
      if(!entry){if(batch.includes(id)){const profile=await this.getProfile(id);result.push({player_id:id,...profile.presence,observed_at:new Date().toISOString()});}continue;}
      result.push({player_id:id,...presenceOf(entry,this.selfId),observed_at:new Date().toISOString()});
    }
    return result;
  }
}
const configHost=config=>config?.host_num;
