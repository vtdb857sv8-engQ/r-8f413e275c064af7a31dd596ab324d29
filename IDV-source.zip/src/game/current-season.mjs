const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
const count=x=>Number.isSafeInteger(x)&&x>=0;
// cs_utils_personal.get_now_season_cnt subtracts all saved history counters
// from the cumulative counter. Missing inputs stay unknown here, unlike the
// game's get(key, 0) default: incomplete API data must not invent a zero.
export function currentSeasonStatistics(profile){
 if(!['self','permitted'].includes(profile.field_access?.statistics))return null;
 const result={};
 for(const [camp,key]of [['survivor','civilian_data'],['hunter','butcher_data']]){
  const data=profile[key];
  if(!object(data)||!count(data.season_id)||data.season_id===0){result[camp]=null;continue;}
  const history=data.history_season_data,validHistory=object(history)&&Object.entries(history).every(([id,row])=>/^[1-9]\d{0,4}$/.test(id)&&Number(id)<data.season_id&&object(row));
  const difference=key=>{
   if(!validHistory||!count(data[key]))return null;
   let prior=0;
   for(const row of Object.values(history)){if(!count(row[key]))return null;prior+=row[key];if(!count(prior))return null;}
   const value=data[key]-prior;return count(value)?value:null;
  };
  result[camp]={season_id:data.season_id,calculation:'cumulative_minus_received_history',history_seasons_count:validHistory?Object.keys(history).length:null,statistics:[['normal','通常戦'],['rank','ランク戦']].map(([mode,label])=>{
   const total=difference(`${mode}_battle_cnt`),wins=difference(`${mode}_battle_win_cnt`),losses=difference(`${mode}_battle_lose_cnt`);
   const coherent=row=>{const t=row[`${mode}_battle_cnt`],w=row[`${mode}_battle_win_cnt`],l=row[`${mode}_battle_lose_cnt`];return (!count(t)||!count(w)||w<=t)&&(!count(t)||!count(l)||l<=t)&&(!count(t)||!count(w)||!count(l)||w+l<=t);};
   const consistent=coherent(data)&&(!validHistory||Object.values(history).every(coherent))&&(total===null||wins===null||wins<=total)&&(total===null||losses===null||losses<=total)&&(total===null||wins===null||losses===null||wins+losses<=total);
   return {mode,label,total:consistent?total:null,wins:consistent?wins:null,losses:consistent?losses:null,consistent};
  })};
 }
 return result;
}
