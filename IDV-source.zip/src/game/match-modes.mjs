import {ApiError} from '../errors.mjs';
export const modeFilters=['all','multi','rank','duo','mojin','custom','other'];
export function modeFilter(value){const mode=value??'all';if(!modeFilters.includes(mode))throw new ApiError(400,'INVALID_MODE_FILTER','対応していないモードです。');return mode;}
export function matchesMode(record,mode='all'){
  const summary=record.summary??record,id=summary.mode_id,custom=summary.is_custom===true;
  if(mode==='custom')return custom;
  if(custom)return false;
  if(mode==='all')return true;
  if(mode==='multi')return [1,3,6,80,81,90].includes(id);
  if(mode==='rank')return [2,10].includes(id);
  if(mode==='duo')return [8,100].includes(id);
  if(mode==='mojin')return [102,103].includes(id);
  return ![1,3,6,80,81,90,2,10,8,100,102,103].includes(id);
}
