import {presentMojinCareers} from './mojin-careers.mjs';
import {presentMojinWeapons} from './mojin-weapons.mjs';
import {presentMojinStreak} from './mojin-streak.mjs';
const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
const number=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0?value:null;
const count=value=>Number.isSafeInteger(value)&&value>=0?value:null;
const sum=values=>values.every(x=>x!==null)?values.reduce((a,b)=>a+b,0):null;
const participationTotal=values=>values.every(x=>count(x)!==null)?count(sum(values)):null;
const tiers=['','一','二','三','四','五','六','七','八'],levels=['','I','II','III','IV','V'];

function rank(part,level,stars,table,seasonId){
  if(!Number.isInteger(part)||!Number.isInteger(level))return null;
  const row=table?.[part]?.[part>=7?-1:level];
  if(!row)return null;
  return {part,level,stars:number(stars),label:part>=7?(row.game_label??null):(tiers[part]??String(part))+'段'+(levels[level]??''),game_label:row.game_label??null,asset:row.asset??null,season_id:seasonId};
}
function currentRank(common,catalog){
  const season=count(common?.season_id),table=catalog.season_parts?.[season]??catalog.parts;
  if(season===null)return null;
  const part=common?.part,level=common?.part_lv,score=number(common?.part_star),maximum=table?.[7]?.[-1];
  if(score===null)return null;
  const displayPart=part===7&&maximum&&score>=maximum.star_slots*maximum.star_score?8:part;
  const row=table?.[displayPart]?.[part>=7?-1:level];
  return rank(displayPart,level,row?.star_score>0?Math.trunc(score/row.star_score):null,table,season);
}
function highestRank(common,catalog){
  const record=common?.max_part_record;if(!Array.isArray(record)||record.length<3)return null;
  const [part,level,stars]=record,maximum=catalog.parts?.[7]?.[-1];
  const displayPart=part===7&&number(stars)!==null&&maximum&&stars>=maximum.star_slots?8:part;
  // The game reads the first three values; no season is identified by this record.
  return rank(displayPart,level,stars,catalog.parts,null);
}
function scalar(data,key,scope,seasonId,parse=key==='win_cnt'||key==='lose_cnt'?count:number){
  if(!object(data))return null;
  const total=parse(data[key]);
  if(scope==='all')return total;
  const history=data.history_season_data;
  if(!object(history))return null;
  if(scope==='season')return parse(history[seasonId]?.[key]);
  const previous=Object.values(history).map(x=>parse(x?.[key]));
  const old=sum(previous);
  return total!==null&&old!==null&&total>=old?total-old:null;
}
const additionalFields=new Set(['total_kill_monster_count','total_kill_ai_survivor_count','total_put_panel_count','total_break_panel_count','total_kill_boss_count','total_bring_out_item_count','total_move_distance']);
function additionalStatistics(common,scope,seasonId,settings){
  return (settings.stat_fields??[]).filter(row=>additionalFields.has(row.field)&&typeof row.label==='string'&&row.label.trim()).map(({field,label})=>{
    const distance=field==='total_move_distance',value=scalar(common,field,scope,seasonId,distance?number:count);
    const format=settings.stat_distance_format;
    const display=value===null?null:distance?(typeof format==='string'&&format.split('%s').length===2?format.replace('%s',String(Math.trunc(value))):null):String(value);
    return {field,label,value,display_value:display};
  });
}
function statistics(common,survivor,hunter,scope,seasonId,settings){
  const sw=scalar(survivor,'win_cnt',scope,seasonId),sl=scalar(survivor,'lose_cnt',scope,seasonId),hw=scalar(hunter,'win_cnt',scope,seasonId),hl=scalar(hunter,'lose_cnt',scope,seasonId);
  const total=sum([sw,sl,hw,hl]),success=sum([sw,hw]),duration=scalar(common,'total_action_duration',scope,seasonId);
  return {scope,season_id:seasonId,total_actions:total,successful_actions:success,success_rate:total>0&&success!==null?success*100/total:null,total_deliver_value:scalar(common,'total_deliver_value',scope,seasonId),average_duration_seconds:total>0&&duration!==null?Math.trunc(duration/total):null,survivor:{successful:sw,failed:sl},hunter:{successful:hw,failed:hl},participation_counts:{label:settings.participation_counts_label??null,survivor:participationTotal([sw,sl]),hunter:participationTotal([hw,hl]),calculation:'sum_of_received_win_and_lose_counts'},additional_statistics:additionalStatistics(common,scope,seasonId,settings)};
}
export function presentMojinSelf(snapshot,catalog={}){
  const common=snapshot.common,survivor=snapshot.survivor,hunter=snapshot.hunter,settings=catalog.mojin??{},season=count(common?.season_id);
  const histories=new Set([common,survivor,hunter].flatMap(x=>object(x?.history_season_data)?Object.keys(x.history_season_data):[]).filter(x=>/^\d+$/.test(x)));
  const stats=[statistics(common,survivor,hunter,'all',null,settings)];
  if(season!==null)stats.push(statistics(common,survivor,hunter,'current',season,settings));
  for(const id of [...histories].map(Number).sort((a,b)=>b-a))stats.push(statistics(common,survivor,hunter,'season',id,settings));
  for(const row of stats){row.frequent_careers=presentMojinCareers(common,row.scope,row.season_id,settings);row.favorite_weapons=presentMojinWeapons(common,row.scope,row.season_id,settings);row.longest_success_streak=presentMojinStreak(common,row.scope,row.season_id,settings);}
  return {mode_name:'手記の加筆',scope:snapshot.scope==='public'?'public':'self',player_id:snapshot.player_id,source:snapshot.scope==='public'?'ask_player_gold_rush_data':'login_snapshot',received_at:snapshot.received_at??null,season_id:season,season_name:settings.seasons?.[season]?.name??null,current_rank:currentRank(common,settings),highest_rank:highestRank(common,settings),statistics:stats};
}
