import {matchPerformanceTitles} from './match-titles.mjs';
// PlayerInfoItemBase.set_result_action: camp-specific action IDs and original labels.
// Only modes whose Main/base display path was checked are exposed here.
export function matchActionDetails(player,mode,catalog={}){
 const camp=player.utype===1?'hunter':player.utype===2?'survivor':null;
 if(![1,2,4,8,9,100,101].includes(mode)||!camp)return null;
 const raw=player.action_recored,fields=catalog.match_action_fields?.[camp];
 if(!Array.isArray(fields))return null;
 const titles=matchPerformanceTitles(player,catalog);
 if(!raw||typeof raw!=='object'||Array.isArray(raw)||Object.keys(raw).length===0)return {status:'unavailable',items:[],...titles};
 const items=fields.filter(f=>Number.isInteger(f.id)&&typeof f.label==='string'&&f.label.length>0).map(f=>{
  const source=raw[f.record_key],valid=typeof source==='number'&&Number.isFinite(source)&&source>=0;
  const value=valid?(['percent','seconds'].includes(f.unit)?Math.trunc(source):source):null;
  return {action_id:f.id,record_key:f.record_key,label:f.label,value,unit:f.unit,display_value:value===null?null:String(value)+(f.unit==='percent'?'%':f.unit==='seconds'?'秒':''),value_source:valid?'received':'unavailable'};
 });
 return {status:'received',items,...titles};
}
