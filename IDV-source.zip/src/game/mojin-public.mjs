import {ApiError} from '../errors.mjs';
export function mojinAccess(info,key){
  const settings=info?.setting_show_info;
  if(!settings||typeof settings!=='object'||Array.isArray(settings))return 'unknown';
  if(!Object.hasOwn(settings,key))return 'permitted';
  const value=settings[key];return value===true||value===1?'hidden':value===false||value===0?'permitted':'unknown';
}
function permission(info,key){
  const access=mojinAccess(info,key);
  // Policy: received Mojin data is displayed even when the target's privacy
  // setting hides it. Only unreadable disclosure stays refused.
  if(access==='hidden')return;
  if(access!=='permitted')throw new ApiError(409,'MOJIN_PERMISSION_UNKNOWN','手記の加筆の公開範囲を確認できません。');
}
async function rpc(provider,methodname,args){
  provider.requireConnected();const session=provider.session,callbackid=provider.genericCallbackSequence=(provider.genericCallbackSequence??0)+1;
  const reply=await provider.request('client_server_gen_rpc_method',{info:{callbackid,methodname,args,kwargs:{}}},'rpc_callback',p=>p.info?.callbackid===callbackid);
  if(provider.session!==session)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。');
  const res=reply.info?.res;
  if(!Array.isArray(res)||res[0]!==0)throw new ApiError(502,'MOJIN_DATA_UNAVAILABLE','手記の加筆の情報を取得できませんでした。');
  return res[1];
}
async function profile(provider,id){
  const data=await rpc(provider,'ask_player_gold_rush_data',[id]);
  if(!data||typeof data!=='object'||Array.isArray(data)||data._high_version||String(data.unique_id)!==String(id))throw new ApiError(409,'MOJIN_PROFILE_FORMAT_UNSUPPORTED','手記の加筆のプロフィール形式を確認できません。');
  return data;
}
function sameSession(provider,session){if(provider.session!==session)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。');}
export async function publicMojinProfile(provider,id){
  if(id===provider.selfId)return provider.getMojinSelf();
  provider.requireConnected();const session=provider.session;
  const data=await profile(provider,id);sameSession(provider,session);permission(data,'gr_hide_personal_data');
  // Recheck the independent personal-data setting after acquiring the data.
  permission(await profile(provider,id),'gr_hide_personal_data');sameSession(provider,session);
  return {scope:'public',source:'ask_player_gold_rush_data',player_id:id,received_at:new Date().toISOString(),common:data.gold_rush_common_data,survivor:data.gold_rush_data,hunter:data.gold_rush_butcher_data};
}
export async function publicMojinHistory(provider,id){
  if(id===provider.selfId)return provider.getMojinHistory();
  provider.requireConnected();const session=provider.session;permission(await profile(provider,id),'gr_hide_battle_record');sameSession(provider,session);
  const data=await rpc(provider,'request_friend_gold_rush_records',[id]);
  const records=Array.isArray(data)?data:data?.records;
  if(!Array.isArray(records))throw new ApiError(502,'MOJIN_RECORD_FORMAT_UNSUPPORTED','手記の加筆の戦績形式を確認できません。');
  sameSession(provider,session);permission(await profile(provider,id),'gr_hide_battle_record');
  if(provider.session!==session)throw new ApiError(409,'GAME_SESSION_CHANGED','ゲーム接続が変更されました。');
  return {scope:'public',player_id:id,records,received_at:new Date().toISOString()};
}
