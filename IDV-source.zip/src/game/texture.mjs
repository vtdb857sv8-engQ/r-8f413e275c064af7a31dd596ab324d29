import {deflateSync,crc32} from 'node:zlib';
const chunk=(type,data)=>{const name=Buffer.from(type),size=Buffer.alloc(4),crc=Buffer.alloc(4);size.writeUInt32BE(data.length);crc.writeUInt32BE(crc32(Buffer.concat([name,data])));return Buffer.concat([size,name,data,crc]);};
const rgb=c=>[Math.round(((c>>11)&31)*255/31),Math.round(((c>>5)&63)*255/63),Math.round((c&31)*255/31),255];
export function texturePNG(source){
  const data=Buffer.from(source);if(data.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return data;
  let width,height,format,payload;
  if(data.subarray(0,8).toString()==='CompBlks'){format=({33777:'DXT1',33778:'DXT3',33779:'DXT5'})[data.readUInt16LE(8)];width=data.readUInt16LE(16);height=data.readUInt16LE(18);payload=data.subarray(28);}
  else if(data.subarray(0,4).toString()==='DDS '){width=data.readUInt32LE(16);height=data.readUInt32LE(12);format=data.subarray(84,88).toString();payload=data.subarray(128);}
  if(!['DXT1','DXT3','DXT5'].includes(format)||!width||!height||width>2048||height>2048)throw new Error('UNSUPPORTED_GAME_TEXTURE');
  const blockSize=format==='DXT1'?8:16,cols=Math.ceil(width/4),rows=Math.ceil(height/4);
  if(payload.length<cols*rows*blockSize)throw new Error('TRUNCATED_GAME_TEXTURE');
  const rgba=Buffer.alloc(width*height*4);
  for(let by=0;by<rows;by++)for(let bx=0;bx<cols;bx++){
    const offset=(by*cols+bx)*blockSize,color=offset+(format==='DXT1'?0:8),c0=payload.readUInt16LE(color),c1=payload.readUInt16LE(color+2),palette=[rgb(c0),rgb(c1)];
    if(c0>c1||format!=='DXT1'){palette.push(palette[0].map((v,i)=>i===3?255:Math.floor((2*v+palette[1][i])/3)));palette.push(palette[0].map((v,i)=>i===3?255:Math.floor((v+2*palette[1][i])/3)));}
    else{palette.push(palette[0].map((v,i)=>i===3?255:Math.floor((v+palette[1][i])/2)));palette.push([0,0,0,0]);}
    let alphaBits=0n;const alphas=[payload[offset],payload[offset+1]];
    if(format==='DXT5'){for(let i=0;i<6;i++)alphaBits|=BigInt(payload[offset+2+i])<<BigInt(i*8);if(alphas[0]>alphas[1])for(let i=1;i<=6;i++)alphas.push(Math.floor(((7-i)*alphas[0]+i*alphas[1])/7));else{for(let i=1;i<=4;i++)alphas.push(Math.floor(((5-i)*alphas[0]+i*alphas[1])/5));alphas.push(0,255);}}
    const indices=payload.readUInt32LE(color+4);
    for(let i=0;i<16;i++){const x=bx*4+i%4,y=by*4+Math.floor(i/4);if(x>=width||y>=height)continue;const pixel=[...palette[(indices>>>(2*i))&3]];if(format==='DXT5')pixel[3]=alphas[Number((alphaBits>>BigInt(3*i))&7n)];if(format==='DXT3')pixel[3]=((payload[offset+Math.floor(i/2)]>>((i%2)*4))&15)*17;rgba.set(pixel,(y*width+x)*4);}
  }
  const scan=Buffer.alloc((width*4+1)*height);for(let y=0;y<height;y++)rgba.copy(scan,y*(width*4+1)+1,y*width*4,(y+1)*width*4);
  const header=Buffer.alloc(13);header.writeUInt32BE(width);header.writeUInt32BE(height,4);header[8]=8;header[9]=6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(scan)),chunk('IEND',Buffer.alloc(0))]);
}
