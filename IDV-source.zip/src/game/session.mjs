import { createHash, randomBytes } from 'node:crypto';
import { encode, decode } from '@msgpack/msgpack';
import { Gateway } from './gateway.mjs';
import { protobuf, parseProtobuf } from './wire.mjs';
import { createRequire } from 'node:module';
import { pack } from './pack.mjs';
import {ApiError} from '../errors.mjs';
const require=createRequire(import.meta.url);
const rpcNames=require('./rpc-names.json');
const digestIndex=(name,salt)=>createHash('md5').update(name+salt).digest().readUInt32BE(12)&0x7fffffff;
const zigzag=n=>BigInt(n>=0?n*2:-n*2-1);
const unzigzag=n=>Number((n>>1n)^-(n&1n));
const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
function loginReplyCode(parameters){
  if(!object(parameters))return null;
  const positional=Object.hasOwn(parameters,'_'),named=Object.hasOwn(parameters,'info');
  if(positional===named)return null;
  const info=positional?(Array.isArray(parameters._)&&parameters._.length===1?parameters._[0]:null):parameters.info;
  return object(info)&&Object.hasOwn(info,'code')&&Number.isSafeInteger(info.code)&&info.code>=0&&info.code<=0x7fffffff?info.code:null;
}
export class GameSession {
  constructor(config){this.config=config;this.gateway=new Gateway();this.sendSalt='';this.receiveSalt='0';this.incomingNames=new Map(rpcNames.map(n=>[digestIndex(n,this.receiveSalt),n]));this.entities=new Map();this.authenticated=false;this.boot=null;this.avatar=null;this.loginSent=false;this.events=[];}
  decodeName(data){const p=parseProtobuf(data);const raw=p.get(1)?.[0];const index=p.get(2)?.[0];if(raw?.length)return raw.toString();if(index!==undefined)return this.incomingNames.get(unzigzag(index))??`index:${unzigzag(index)}`;return 'unknown';}
  sendEntity(id,name,parameters){
    const method=this.sendSalt?protobuf([[1,''],[2,zigzag(digestIndex(name,this.sendSalt))]]):protobuf([[1,name],[2,zigzag(-1)]]);
    this.gateway.send(3,protobuf([[2,id],[3,method],[4,pack(parameters)],[5,1]]));
  }
  async open(){
    await this.gateway.open(this.config.host,this.config.port);await this.gateway.handshake(this.config.public_key);
    const auth=Buffer.from(encode({compress_info:null}));
    this.gateway.send(2,protobuf([[2,0],[3,randomBytes(12).toString('hex')],[4,Buffer.alloc(0)],[5,auth]]));this.gateway.enableCompression();
  }
  async receive(timeoutMs=6000){
    const message=await this.gateway.next(timeoutMs),fields=parseProtobuf(message.payload);
    if(message.opcode===3){
      const typeData=fields.get(2)?.[0],type=this.decodeName(typeData),id=fields.get(3)?.[0],info=decode(fields.get(4)?.[0],{useBigInt64:true});
      this.entities.set(id.toString('hex'),{id,type,info});
      if(type==='ClientBoot')this.boot=id;if(type==='Avatar'){this.avatar=id;this.authenticated=true;}
      if(parseProtobuf(typeData).get(1)?.[0]?.length)this.sendEntity(id,'set_send_rpc_salt',{s:this.receiveSalt});
      return {kind:'entity_created',type,info};
    }
    if(message.opcode===5){
      const id=fields.get(2)?.[0];let name=this.decodeName(fields.get(3)?.[0]),parameters=decode(fields.get(4)?.[0],{useBigInt64:true});
      if(name==='set_send_rpc_salt')this.sendSalt=parameters.s;
      if(name==='reply_client_rpc'&&parameters.info?.func==='reply_get_history_badge'){
        const {func,tid,tid_params,tid_duration,...info}=parameters.info;
        name=func;parameters={info};
      }
      if(name==='server_client_gen_rpc_method'&&parameters.info?.methodname==='request_recruit_info_lst_cb'){
        const generic=parameters.info;parameters={...(generic.args?.[0]??{}),...(generic.kwargs??{})};name=generic.methodname;
        if(generic.callbackid!==null&&generic.callbackid!==undefined)this.sendEntity(id,'rpc_callback',{info:{callbackid:generic.callbackid,res:[0,true]}});
      }
      const event={kind:'rpc',name,parameters,entity_id:id};this.events.push(event);if(this.events.length>100)this.events.shift();
      return event;
    }
    if(message.opcode===2)return{kind:'connection',status:Number(fields.get(2)?.[0])};
    if(message.opcode===4)return{kind:'entity_destroyed'};
    return{kind:'frame',opcode:message.opcode};
  }
  async login(loginInfo){
    await this.open();const deadline=Date.now()+20000;
    while(Date.now()<deadline){
      const event=await this.receive();
      if(event.kind==='rpc'&&event.name==='become_player'&&!this.loginSent){
        if(!this.boot)throw new Error('BOOT_ENTITY_MISSING');
        this.sendEntity(this.boot,'sdk_login_gas3',{login_info:loginInfo});this.loginSent=true;
      }
      if(event.kind==='rpc'&&event.name==='on_login'){
        this.loginReply=event.parameters;const code=loginReplyCode(event.parameters);
        // Original ComuKeys.LOGIN_CODE: only 7 (LOGIN_OK) and 8 (RELOGIN_OK)
        // continue to Avatar creation. 6 is SAUTH_FAILED, without proving expiry.
        if(code!==7&&code!==8){
          const error=code===null?new ApiError(502,'GAME_LOGIN_RESPONSE_INVALID','ゲームのログイン応答を確認できませんでした。'):
            code===6?new ApiError(409,'SDK_AUTH_REJECTED','保存されたSDK認証がゲーム側で拒否されました。PC版でログインし直してから接続してください。'):
              new ApiError(409,'GAME_LOGIN_REJECTED','ゲーム側でログインが受け付けられませんでした。PC版でログインできるか確認してください。');
          error.serverLoginCode=code;throw error;
        }
      }
      if(event.kind==='rpc'&&event.name==='notify_role_online_confirm')return{authenticated:false,replace_login:true};
      if(event.kind==='rpc'&&event.name==='on_replace_login_cancel')return{authenticated:false,replace_login:true};
      if(this.authenticated)return{authenticated:true,avatar_info:this.entities.get(this.avatar.toString('hex'))?.info};
    }
    throw new Error('GAME_LOGIN_TIMEOUT');
  }
  close(){this.gateway.close();}
}
