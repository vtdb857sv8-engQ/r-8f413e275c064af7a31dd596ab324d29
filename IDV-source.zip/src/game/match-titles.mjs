const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
// These are per-match survivor performance titles, separate from profile badges.
// Match the received title threshold to the original config; never derive awards
// from action_recored numbers or from the wording of a player's name.
export function matchPerformanceTitles(player,catalog={}){
 if(player.utype!==2)return {titles_status:'not_applicable',titles:[],unverified_title_records:0};
 const raw=player.title_recored,fields=catalog.match_performance_titles;
 if(!object(raw)||!Array.isArray(fields))return {titles_status:'unavailable',titles:[],unverified_title_records:0};
 const titles=[],knownKeys=new Set(fields.map(x=>x.record_key));let unverified=0;
 for(const field of fields){
  if(!Object.hasOwn(raw,field.record_key)||raw[field.record_key]===null)continue;
  const value=raw[field.record_key];
  if(typeof value!=='number'||!Number.isFinite(value)||value!==field.condition_value||typeof field.label!=='string'||!field.label||typeof field.description!=='string'||!field.description){unverified++;continue;}
  titles.push({id:field.id,action_id:field.action_id,label:field.label,description:field.description,asset:field.asset??null,received_condition_value:value});
 }
 for(const [key,value]of Object.entries(raw))if(!knownKeys.has(key)&&value!==null)unverified++;
 return {titles_status:'received',titles,unverified_title_records:unverified};
}
