import {mojinPeriodDictionary} from './mojin-dictionary.mjs';
export function presentMojinWeapons(common,scope,seasonId,settings={}){
 const response=(status,items=[])=>({label:settings.weapon_kills_label??null,status,items});
 const selected=mojinPeriodDictionary(common,'weapon_kills',scope,seasonId);
 if(selected.status!=='available')return response(selected.status);
 const items=[...selected.values].filter(([,count])=>count>0).sort((a,b)=>b[1]-a[1]||Number(a[0])-Number(b[0])).slice(0,2).map(([id,recorded_count])=>({item_id:Number(id),name:settings.items?.[id]?.name??null,asset:settings.items?.[id]?.asset??null,recorded_count}));
 return response(items.some(x=>!x.name||!x.asset)?'partial':'available',items);
}
