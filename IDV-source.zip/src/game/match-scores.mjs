// Labels and icons are taken from the installed game's score configuration.
// A received sparse detail_score uses the game's get(category, 0) convention.
// Missing/malformed detail_score is not a received zero-score breakdown.
export function matchScoreBreakdown(player,mode,catalog={}){
  const camp=player.utype===1?'hunter':player.utype===2?'survivor':null,detail=player.detail_score;
  if(![1,2,4,8,100].includes(mode)||!camp||!detail||typeof detail!=='object'||Array.isArray(detail))return [];
  const fields=catalog.match_score_fields?.[camp];if(!Array.isArray(fields))return [];
  return fields.filter(f=>[1,2,3,4].includes(f.id)&&typeof f.label==='string'&&f.label.length>0).map(f=>{
    const received=Object.hasOwn(detail,String(f.id)),raw=received?detail[f.id]:0;
    const value=typeof raw==='number'&&Number.isFinite(raw)&&raw>=0?raw:null;
    return {category_id:f.id,label:f.label,asset:f.asset??null,value,value_source:!received?'game_default_zero':value===null?'unavailable':'received'};
  });
}
