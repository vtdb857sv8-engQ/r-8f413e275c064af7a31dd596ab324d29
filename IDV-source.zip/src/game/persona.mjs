import {ApiError} from '../errors.mjs';
const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
export function presentPersona(data,catalog={}){
  // Only the provider's post-receipt decision permits publishing a loadout.
  // Received loadouts are displayed even when the disclosure is hidden;
  // only unreadable access values stay refused.
  if(!['self','permitted','hidden'].includes(data.access))throw new ApiError(409,'PERSONA_PERMISSION_UNKNOWN','人格の公開範囲を確認できないため表示できません。');
  const character=catalog.characters?.[data.character_id];
  if(!character?.camp)throw new ApiError(400,'INVALID_CHARACTER','キャラクターを選択してください。');
  const player=data.players,base={player_id:data.player_id,access:data.access,character_id:data.character_id,character_name:character.name??null,character_asset:character.asset??null,camp:character.camp,received_at:data.received_at,source:'current_character_selection'};
  if(!object(player))return {...base,status:'unavailable',items:[]};
  const page=player.pid_to_genius?.[String(data.character_id)]??'1';
  if(!/^[1-9]\d{0,7}$/.test(String(page)))return {...base,status:'unavailable',items:[]};
  const n=Number(page),rules=catalog.persona?.page_rules;
  let selected;
  if(rules&&n<rules.recommended_start)selected=player[character.camp==='hunter'?'butcher_data':'civilian_data']?.genius?.[String(page)];
  else if(rules&&n>rules.character_recommended_start)selected=player.pid_genius?.[String(page)];
  // Recommended pages need a separate verified conversion. Never substitute another page.
  if(!object(selected?.genius_dict))return {...base,page_id:String(page),status:'unavailable',items:[]};
  const items=[];let unmapped=0,points=0;
  for(const [branch,values]of Object.entries(selected.genius_dict)){
    if(!['1','2','3','4'].includes(branch)){unmapped++;continue;}
    // The game restores each branch with dict(data), accepting serialized pairs.
    const pairs=object(values)?Object.entries(values):Array.isArray(values)&&values.every(v=>Array.isArray(v)&&v.length===2)?[...new Map(values)]:null;
    if(!pairs)return {...base,page_id:String(page),status:'unavailable',items:[]};
    for(const [id,level]of pairs){
      if(!/^\d+$/.test(String(id))||!Number.isSafeInteger(level)||level<0){unmapped++;continue;}
      if(level===0)continue;
      const definitions=catalog.persona?.[character.camp]?.[id],definition=definitions?.[level];
      if(!definition||String(definition.branch)!==branch){unmapped++;continue;}
      items.push({id:Number(id),level,branch:Number(branch),name:definition.name??null,asset:definition.asset??null,description:definition.description??null,layer:definition.layer,node_seq:definition.node_seq});
      // Each level's configuration specifies the additional cost for that level.
      for(let lv=1;lv<=level;lv++){const cost=definitions?.[lv]?.cost;if(!Number.isSafeInteger(cost)){points=null;break;}if(points!==null)points+=cost;}
    }
  }
  items.sort((a,b)=>a.branch-b.branch||a.layer-b.layer||a.node_seq-b.node_seq||a.id-b.id);
  return {...base,page_id:String(page),status:'received',items,unmapped_count:unmapped,used_points:unmapped?null:points};
}
