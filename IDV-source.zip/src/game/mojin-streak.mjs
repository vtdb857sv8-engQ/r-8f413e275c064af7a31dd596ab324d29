const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
// The game's _scalar_top reads each saved peak directly. It never subtracts
// or sums historical peaks. The total-period interpretation remains unverified.
export function presentMojinStreak(common,scope,seasonId,settings={}){
 const result=(status,value=null)=>({label:settings.longest_success_streak_label??null,status,value});
 if(!object(common))return result('unavailable');
 if(scope==='all')return result('unverified_period');
 let source;
 if(scope==='current'){
  if(!Number.isSafeInteger(seasonId)||seasonId<0||seasonId!==common.season_id)return result('unavailable');
  source=common;
 }else if(scope==='season'){
  if(!Number.isSafeInteger(seasonId)||seasonId<0)return result('unavailable');
  if(common.history_season_data===undefined)return result('unavailable');
  if(!object(common.history_season_data))return result('invalid');
  source=common.history_season_data[String(seasonId)];
 }else return result('invalid');
 if(source===undefined)return result('unavailable');
 if(!object(source))return result('invalid');
 const value=source.max_win_streak;
 if(value===undefined)return result('unavailable');
 return Number.isSafeInteger(value)&&value>=0?result('received',value):result('invalid');
}
