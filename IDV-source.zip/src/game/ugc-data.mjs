import {ApiError} from '../errors.mjs';

const unsupported=()=>new ApiError(502,'UGC_FORMAT_UNSUPPORTED','ペン先の空想のランキング形式を確認できません。');
export function ugcRankMetadata(doc,id){
  if(!doc||typeof doc!=='object'||Array.isArray(doc)||String(doc._id)!==id)throw unsupported();
  if(doc.open_rank===false||doc.open_rank===0)throw new ApiError(403,'UGC_RANKING_PRIVATE','この作品のランキングは公開されていません。');
  if(doc.open_rank!==true&&doc.open_rank!==1)throw new ApiError(409,'UGC_RANKING_PERMISSION_UNKNOWN','作品内ランキングの公開設定を確認できません。');
  return {map_id:id,name:typeof doc.name==='string'?doc.name:null};
}

const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
const assetId=value=>Number.isSafeInteger(value)&&value>=0?value:null;
const gameTime=seconds=>{
  const whole=Math.trunc(seconds),fraction=Math.trunc((seconds-whole)*100),pad=value=>String(value).padStart(2,'0');
  return `${pad(Math.floor(whole/60))}:${pad(whole%60)}.${pad(fraction)}`;
};
const member=value=>{
  if(!object(value))throw unsupported();
  return {player_id:/^\d{1,20}$/.test(String(value.uid??''))?String(value.uid):null,name:typeof value.name==='string'?value.name:null,face_id:assetId(value.face_id),face_frame_id:assetId(value.face_frame_id),face_vfx_id:assetId(value.face_vfx_id)};
};
export function presentUGCMapRanking(result,map){
  if(!Array.isArray(result)||result.length!==4)throw unsupported();
  const [rows,type,form,title]=result;
  if(!Array.isArray(rows)||![1,2,3,4].includes(type)||![1,2].includes(form)||typeof title!=='string')throw unsupported();
  const isTime=type===1||type===2;
  // The game's UI preserves server order and formats a time score in seconds.
  const items=rows.slice(0,1000).map((row,i)=>{
    if(!object(row)||typeof row.score!=='number'||!Number.isFinite(row.score))throw unsupported();
    if(form===2&&!Array.isArray(row.member))throw unsupported();
    const score=row.score;
    return {position:i+1,score,score_display:isTime&&score>=0?gameTime(score):String(score),members:(form===1?[row]:row.member).slice(0,1000).map(member)};
  });
  return {map,visibility:'public',rank_type:type,rank_form:form,rank_title:title,score_kind:isTime?'time':'event',score_unit:isTime?'seconds':null,order:type===1||type===4?'ascending':'descending',items,total_received:rows.length};
}
