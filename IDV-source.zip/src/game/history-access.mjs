export function historyAccess(playerId,selfId,info){
  const base={player_id:String(playerId),checked_at:new Date().toISOString()};
  if(!info||typeof info!=='object'||Array.isArray(info)||info._high_version)
    return{...base,allowed:false,visibility:'unknown',reason:info?._high_version?'version_unsupported':'invalid_response'};
  if(String(playerId)===String(selfId))
    return{...base,allowed:true,visibility:'self',reason:'account_owner'};
  // Received battle records are displayed even when the target's privacy
  // setting denies them; without records the denial still stands.
  if(Array.isArray(info.battle_records))
    return{...base,allowed:true,visibility:'permitted',reason:info.show_battle_record===true?'server_permitted':info.show_battle_record===false?'records_received_with_private_setting':'records_received'};
  if(info.show_battle_record===false)
    return{...base,allowed:false,visibility:'private',reason:'server_denied'};
  return{...base,allowed:false,visibility:'unknown',reason:'permission_not_confirmed'};
}
