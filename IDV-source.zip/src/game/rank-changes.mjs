const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
const number=x=>typeof x==='number'&&Number.isFinite(x);
// Match records attach this dictionary by public unique_id, never by an entity ID.
// Overall point changes across promotion and shield-card adjustments stay uncomputed.
export function rankChangeDetails(player,record,catalog={}){
  const id=player.unique_id!=null?String(player.unique_id):null;
  if(record.common_info?.match_type!==2||player.bot===true||!id||!/^[1-9]\d{0,19}$/.test(id)||!object(record.part_change_info)||!Object.hasOwn(record.part_change_info,id))return null;
  const change=record.part_change_info[id];if(!object(change)||![1,2].includes(player.utype)||change.unit_type!==player.utype)return null;
  const details=[];let unlabelled=0,invalid=0;
  const raw=object(change.score_detail)?change.score_detail:null;
  for(const [key,value]of Object.entries(raw??{})){
    const tuple=Array.isArray(value),points=tuple?value[0]:value;
    if(!number(points)||(tuple&&(value.length!==2||!number(value[1])))){invalid++;continue;}
    // This is the same visibility rule as the game's rank-score details panel.
    if(points===0&&(tuple||!['TID_DES_DRAW','TID_DES_INTERGRAL_BADBEAHVIOR'].includes(key)))continue;
    let label=catalog.rank_score_labels?.[key];if(typeof label!=='string'||!label){unlabelled++;continue;}
    if(tuple){
      const placeholders=label.match(/%s/g)??[];
      if(placeholders.length!==1||/%(?!s)/.test(label)){unlabelled++;continue;}
      const parameter=['TID_DES_GRADE_SUR','TID_DES_GRADE_HUNTER'].includes(key)?Math.trunc(value[1])+1:value[1];
      label=label.replace('%s',String(parameter));
    }else if(/%(?:\d+)?[sdif]/.test(label)){unlabelled++;continue;}
    const item={reason_key:key,label,points};
    if(['TID_BATTLE_END_WIN','TID_DES_VICTORY'].includes(key))details.unshift(item);else details.push(item);
  }
  return {before:object(change.old_rank)?change.old_rank:null,after:object(change.now_rank)?change.now_rank:null,details,details_received:raw!==null,unlabelled_reasons:unlabelled,invalid_reasons:invalid,source:'part_change_info'};
}
