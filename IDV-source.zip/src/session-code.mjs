import {ApiError} from './errors.mjs';
const invalid=()=>new ApiError(400,'SESSION_CODE_INVALID','PC用EXEで取得した接続コードを貼り付けてください。');
export function sessionCodeCredentials(input){
  if(typeof input!=='string')throw invalid();
  const code=input.trim();
  if(code.length>15000||!/^IDV1\.[A-Za-z0-9_-]+$/.test(code))throw invalid();
  let value;
  try{const raw=Buffer.from(code.slice(5),'base64url');if(raw.length>11000||raw.toString('base64url')!==code.slice(5))throw invalid();value=JSON.parse(raw.toString('utf8'));}catch{throw invalid();}
  if(value?.version!==1||!['asia','na-eu','china'].includes(value.server)||!Number.isFinite(Date.parse(value.issued_at)))throw invalid();
  const login=value.login_info,info=login?.info;let sdk;
  try{sdk=JSON.parse(info?.sauth_json);}catch{throw invalid();}
  if(!info||typeof info.sdkuid!=='string'||!info.sdkuid||typeof info.sessionid!=='string'||!info.sessionid||typeof info.full_uid!=='string'||!info.full_uid||!Number.isInteger(info.client_version)||info.client_version<=0||sdk?.sdkuid!==info.sdkuid||sdk?.sessionid!==info.sessionid||!Number.isInteger(login.pack_type)||login.pack_type<0)throw invalid();
  // Explicit whitelist: an imported code cannot set replacement or verification.
  return {credential_type:'netease-sdk-session',server:value.server,login_info:{info,log_info:{deviceid:typeof sdk.deviceid==='string'?sdk.deviceid:''},active_code:'',just_login:true,c_str:'',pack_type:login.pack_type,login_confirm:false},imported_at:new Date().toISOString(),captured_at:value.issued_at,verified:false};
}
