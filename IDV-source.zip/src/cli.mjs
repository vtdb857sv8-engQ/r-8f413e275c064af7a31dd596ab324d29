import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { WindowsVault } from './vault.mjs';
import { readFileSync,writeFileSync,mkdirSync } from 'node:fs';
import { networkInterfaces } from 'node:os';
const vault=new WindowsVault(path.resolve(process.env.IDV_DATA_DIR||'.data'));
const [command,resource]=process.argv.slice(2);
const baseUrl=process.env.IDV_API_URL||`http://127.0.0.1:${process.env.PORT||8787}`;
if(command==='connection-info'){
  const key=vault.get('api-key');if(!key?.token)throw new Error('先に npm run init を実行してください。');
  const addresses=Object.entries(networkInterfaces()).filter(([name])=>!/vEthernet|WSL|Loopback/i.test(name)).flatMap(([,rows])=>rows).filter(x=>x.family==='IPv4'&&!x.internal&&/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(x.address)).map(x=>`http://${x.address}:${process.env.PORT||8787}`);
  mkdirSync('.private',{recursive:true});const file=path.resolve('.private/iphone-connection.json');writeFileSync(file,JSON.stringify({urls:process.env.IDV_API_URL?[process.env.IDV_API_URL]:addresses,api_key:key.token},null,2));console.log(`iPhoneの接続情報をローカルファイルへ保存しました。\n${file}`);
}else if(command==='init'){
  if(vault.has('api-key'))console.log('API認証鍵は作成済みです。');
  else{vault.set('api-key',{token:randomBytes(32).toString('base64url')});console.log('API認証鍵をWindows DPAPIで暗号化して保存しました。値は表示しません。');}
}else if(command==='import-session-candidates'){
  const encrypted=readFileSync('.private/auth-candidates.dpapi');
  const candidates=JSON.parse(vault.crypt('unprotect',encrypted.toString('base64')));
  const session=candidates.find(x=>typeof x.sdkuid==='string'&&typeof x.sessionid==='string'&&x.gameid==='h55naxx2gb');
  if(!session)throw new Error('第五人格のSDKセッション候補がありません。');
  vault.set('game-session',{credential_type:'netease-sdk-session',server:'asia',source:'own-pc-session',sdk_login:session,imported_at:new Date().toISOString(),verified:false});
  console.log('第五人格のSDKセッション候補をDPAPIで暗号化保存しました。サーバーでの有効性は未検証です。');
}else if(command==='connect'||command==='disconnect'){
  const key=vault.get('api-key');if(!key?.token)throw new Error('先に npm run init を実行してください。');
  const response=await fetch(`${baseUrl}/v1/session/${command}`,{method:'POST',headers:{authorization:`Bearer ${key.token}`,'content-type':'application/json'},body:JSON.stringify({replace_existing:process.argv.includes('--replace-existing')}),signal:AbortSignal.timeout(45000)});
  console.log(JSON.stringify(await response.json(),null,2));if(!response.ok)process.exitCode=1;
}else if(command==='get'){
  if(!resource?.startsWith('/')||resource.startsWith('//'))throw new Error('ローカルAPIのパスを指定してください。');
  const key=vault.get('api-key');if(!key?.token)throw new Error('先に npm run init を実行してください。');
  const response=await fetch(new URL(resource,baseUrl),{headers:{authorization:`Bearer ${key.token}`},signal:AbortSignal.timeout(30000)});
  console.log(JSON.stringify(await response.json(),null,2));if(!response.ok)process.exitCode=1;
}else{console.log('node src/cli.mjs init\nnode src/cli.mjs connection-info\nnode src/cli.mjs connect [--replace-existing]\nnode src/cli.mjs disconnect\nnode src/cli.mjs get /v1/status');}
