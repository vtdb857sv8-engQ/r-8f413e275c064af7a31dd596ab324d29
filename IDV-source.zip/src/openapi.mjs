const output = { description:'JSON response', content:{'application/json':{schema:{type:'object'}}} };
const failure = { description:'Game session is not connected',content:{'application/json':{schema:{$ref:'#/components/schemas/Error'}}} };
const query = (name,type='string',required=false) => ({name,in:'query',required,schema:{type}});
const pathId = name => ({name,in:'path',required:true,schema:{type:'string'}});
const operation = (summary,parameters=[],schema) => ({summary,parameters,...(schema?{requestBody:{required:true,content:{'application/json':{schema}}}}:{}),responses:{200:output,400:{description:'Invalid input'},401:{description:'Authentication required'},503:failure}});
export const openapi = {
  openapi:'3.1.0',info:{title:'第五人格 Companion API',version:'0.1.0',description:'保存済みの自分のSDKセッションで独立接続する非公式API。Asia版で実データ確認済み。受信できた相手のデータは非公開設定でも表示する。未接続は503。'},
  servers:[{url:'http://127.0.0.1:8787'}],security:[{bearerAuth:[]}],
  components:{
    securitySchemes:{bearerAuth:{type:'http',scheme:'bearer'}},
    schemas:{Error:{type:'object',properties:{error:{type:'object',properties:{code:{type:'string'},message:{type:'string'}}}}}}
  },
  paths:{
    '/health':{get:{...operation('APIの稼働確認'),security:[]}},
    '/v1/status':{get:operation('接続状態と機能の対応状況。ログイン拒否はlast_error・session_recovery.login_failure.reason / server_codeで通知し、原本の認証情報は返さない')},
    '/v1/session/credentials':{put:operation('完全なSDK認証情報をDPAPIで保存（保存時は未検証）',[],{type:'object',required:['login_info','server'],properties:{login_info:{type:'object',writeOnly:true},server:{enum:['asia','na-eu','china']}}})},
    '/v1/session/connect':{post:{...operation('独立接続を開始。PC側から切り替える場合のみreplace_existingを指定',[],{type:'object',properties:{replace_existing:{type:'boolean',default:false}}}),responses:{200:output,400:{description:'Invalid input'},401:{description:'API authentication required'},409:{description:'SDK_AUTH_REJECTED, GAME_LOGIN_REJECTED, or another game login requires a decision'},502:{description:'Invalid login response or gateway error'},503:failure}}},
    '/v1/session/disconnect':{post:operation('ゲームセッションを終了')},
    '/v1/players':{get:operation('ID・名前でプレイヤーを検索',[query('query','string',true)])},
    '/v1/me':{get:operation('ログイン中の自分のID・プロフィール。累計と受信済み過去記録から算出する現シーズン統計を含む')},
    '/v1/players/{id}/persona':{get:{...operation('ランキングの人格ボタンと同じ通常要求で受信後、最新open_talent設定を確認。キャラクターに現在選択されたページのみ。受信できた内容は非公開設定でも返す。公開範囲不明は返さない',[query('character_id','integer',true)]),parameters:[{name:'id',in:'path',required:true,schema:{type:'string'}},query('character_id','integer',true)],responses:{200:output,409:{description:'Disclosure unknown or session changed'},502:{description:'Response unverified'},503:failure}}},
    '/v1/session/import':{post:{...operation('PC用EXEの接続コードを暗号化保存。取り込みだけではログインしない'),requestBody:{required:true,content:{'application/json':{schema:{type:'object',required:['code'],properties:{code:{type:'string',maxLength:15000}}}}}},responses:{200:output,400:{description:'Invalid session code'},401:{description:'Authentication required'}}}},
    '/v1/me/mojin':{get:{...operation('手記の加筆の自分の段位・累計／シーズン統計・陣営別参加回数。ログイン時の受信データのみ'),responses:{200:output,401:{description:'Authentication required'},409:{description:'Own mode data not received'},503:failure}}},
    '/v1/me/mojin/history':{get:{...operation('手記の加筆の自己戦績。専用RPCで返された範囲のみ。マップ・職業のゲーム内名と参加者'),responses:{200:output,401:{description:'Authentication required'},502:{description:'Game RPC error or unsupported shared record'},503:failure}}},
    '/v1/players/{id}/mojin':{get:{...operation('手記の加筆の段位・探索統計。通常プロフィールとは独立した公開設定を確認。受信できた内容は非公開設定でも返す'),parameters:[{name:'id',in:'path',required:true,schema:{type:'string'}}],responses:{200:output,409:{description:'Permission or format unknown'},503:failure}}},
    '/v1/players/{id}/mojin/history':{get:{...operation('手記の加筆の戦績。取得前後に公開設定を確認。受信できた内容は非公開設定でも返す'),parameters:[{name:'id',in:'path',required:true,schema:{type:'string'}}],responses:{200:output,409:{description:'Permission or format unknown'},502:{description:'Game RPC error or unsupported shared record'},503:failure}}},
    '/v1/players/{player_id}':{get:operation('プロフィール取得',[pathId('player_id')])},
    '/v1/players/{player_id}/history':{get:operation('過去戦績取得',[pathId('player_id'),query('mode'),query('limit','integer'),query('cursor')])},
    '/v1/players/{player_id}/history/access':{get:operation('戦績の取得・表示条件を確認。戦績が受信できない場合は表示しない',[pathId('player_id')])},
    '/v1/players/{player_id}/analysis':{get:operation('受信戦績からモード別・直近10/20/50戦・連勝連敗・本人の得点/MVP・終了時刻別成績を計算。allはカスタム除外。timezoneはIANA名（既定Asia/Tokyo）',[pathId('player_id'),query('mode'),query('timezone')])},
    '/v1/players/{player_id}/presence':{get:operation('最後に観測した状態・ログイン・ログアウト時刻',[pathId('player_id')])},
    '/v1/rankings':{get:operation('現シーズンの段位ランキング・キャラ別認知ランキング取得',[query('kind'),query('character_id','integer'),query('limit','integer'),query('cursor')])},
    '/v1/friends':{get:operation('フレンド一覧取得')},
    '/v1/catalog':{get:operation('ゲーム内素材と表示名のカタログ')},
    '/v1/players/{id}/badges/history':{get:operation('公開設定を再確認したキャラ別過去徽章。受信できた徽章は非公開設定でも返す')},
    '/v1/ugc/play-history':{get:operation('ペン先の空想で自分が遊んだ作品の履歴（通常戦績とは別）')},
    '/v1/ugc/rankings':{get:operation('ペン先の空想の週間・月間作品ランキング',[query('period'),query('tag','integer')])},
    '/v1/ugc/maps/{map_id}/rankings':{get:{...operation('作品内ランキング。取得前後に作品の公開設定を確認',[pathId('map_id')]),responses:{200:output,400:{description:'Invalid public map id'},403:{description:'Ranking is private'},409:{description:'Permission unknown or game session changed'},502:{description:'Unsupported response or game RPC error'},503:failure}}},
    '/v1/assets/{key}.png':{get:{...operation('オリジナルのゲーム内素材',[pathId('key')]),responses:{200:{description:'Original game texture converted to PNG',content:{'image/png':{schema:{type:'string',format:'binary'}}}}}}},
    '/v1/chat/rooms':{get:operation('接続先のチャットチャンネル一覧')},
    '/v1/chat/global':{get:operation('全体チャット取得',[query('room'),query('channel'),query('cursor'),query('limit','integer')]),post:{...operation('全体チャット送信。受信確認とは別に送信受付を返す',[],{type:'object',required:['content'],properties:{content:{type:'string',minLength:1,maxLength:500},room:{type:'string'},client_message_id:{type:'string'}}}),responses:{202:output,400:{description:'Invalid message'},409:{description:'Room changed'},429:{description:'Send cooldown'}}}},
    '/v1/friends/{player_id}/chat':{get:operation('フレンドチャットの取得',[pathId('player_id'),query('cursor'),query('limit','integer')]),post:{...operation('フレンドへメッセージを送信',[pathId('player_id')],{type:'object',required:['content'],properties:{content:{type:'string',minLength:1,maxLength:500},client_message_id:{type:'string'}}}),responses:{202:output,404:{description:'Friend required'}}}},
    '/v1/notifications/settings':{get:operation('通知条件'),put:operation('通知する公開状態の変化を選択',[],{type:'object',additionalProperties:{type:'boolean'}})},
    '/v1/recruitments':{get:operation('募集一覧取得',[query('mode'),query('cursor'),query('limit','integer')])},
    '/v1/watches':{get:operation('状態を取得するプレイヤーの登録一覧')},
    '/v1/watches/{player_id}':{put:operation('取得対象と通知設定を保存',[pathId('player_id')],{type:'object',required:['notify'],properties:{notify:{type:'boolean'}}}),delete:operation('対象登録を削除',[pathId('player_id')])},
    '/v1/events':{get:operation('状態変化の履歴を取得',[query('after','integer'),query('limit','integer'),query('player_id')])},
    '/v1/events/stream':{get:{...operation('状態変化のSSE配信',[query('after','integer')]),responses:{200:{description:'id付きpresenceイベント。Last-Event-IDによる再開に対応。',content:{'text/event-stream':{schema:{type:'string'}}}},401:{description:'Authentication required'}}}},
    '/v1/devices':{post:operation('IPAのAPNsデバイストークンを暗号化して登録',[],{type:'object',required:['device_id','token','environment'],properties:{device_id:{type:'string'},token:{type:'string',writeOnly:true},environment:{enum:['sandbox','production']}}})},
    '/v1/devices/{device_id}':{delete:operation('APNsデバイス登録を削除',[pathId('device_id')])}
  }
};
