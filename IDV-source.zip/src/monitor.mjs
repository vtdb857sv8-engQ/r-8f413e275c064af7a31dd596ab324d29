import { EventEmitter } from 'node:events';
import {SessionRecovery} from './session-recovery.mjs';
export const states = new Set(['online','offline','idle','busy','in_match','in_team','matching','reserved','custom_room','visiting','spectating','recruiting','unknown']);
export class Monitor extends EventEmitter {
  constructor({ store, provider, apns = null, vault = null, intervalMs = 30000,autoReconnect=false }) {
    super(); this.store=store;this.provider=provider;this.apns=apns;this.vault=vault;this.intervalMs=intervalMs;this.connected=false;this.lastSuccess=null;this.lastError=null;this.running=false;
    this.recovery=new SessionRecovery({provider,store,vault,automatic:autoReconnect,onConnected:async()=>{this.connected=true;this.lastError=null;await this.tick();},onDisconnected:detail=>{this.lastError=detail.code;this.connected=false;}});
    provider.on?.('presence',item=>{
      if(this.connected&&this.store.watches().some(w=>w.player_id===item.player_id))this.record(item);
    });
  }
  status() {return {connected:this.connected,last_success_at:this.lastSuccess,last_error:this.lastError,poll_interval_seconds:this.intervalMs/1000,push_configured:Boolean(this.apns),game_capabilities:this.provider.capabilities(),session_recovery:this.recovery.status()};}
  async connect(credentials,options) {
    await this.recovery.connect(credentials,options);
  }
  async disconnect() {try{await this.recovery.disconnect();}finally{this.connected=false;}}
  async restore() {return this.recovery.restore();}
  async tick() {
    if(this.running)return;this.running=true;
    try {
      if(this.connected&&this.provider.capabilities().presence){
        const ids=this.store.watches().map(x=>x.player_id);
        if(ids.length){
          try{
            const observations=await this.provider.pollPresence(ids);
            // Validate the full batch before writing, so partial or malformed responses do not create false transitions.
            const seen=new Set();
            for(const item of observations){
              if(!ids.includes(item.player_id)||seen.has(item.player_id)||!states.has(item.state)||!Number.isFinite(Date.parse(item.observed_at))||Date.parse(item.observed_at)>Date.now()+60000)throw new Error('Invalid observation');
              seen.add(item.player_id);
            }
            for(const item of observations)this.record(item);
            this.lastSuccess=new Date().toISOString();this.lastError=null;
          }catch{this.lastError='PRESENCE_FETCH_FAILED';}
        }
      }
      await this.deliver();
    }finally{this.running=false;}
  }
  record(item){
    const time=Date.parse(item.observed_at),before=this.store.presence(item.player_id);
    if(!states.has(item.state)||!Number.isFinite(time)||time>Date.now()+60000||before&&time<=Date.parse(before.observed_at))return;
    const event=this.store.observe(item.player_id,item.state,new Date(item.observed_at).toISOString(),'game',item);if(event)this.emit('presence',event);
  }
  async deliver() {
    if(!this.apns)return;
    for(const delivery of this.store.pendingDeliveries()){
      if(!this.store.notificationAllowed(delivery)){this.store.delivered(delivery.event_id,delivery.device_id,'cancelled');continue;}
      let result;
      try{
        const token=this.vault.crypt('unprotect',delivery.token);
        result=await this.apns.send(token,delivery.environment,{id:delivery.event_id,...delivery});
      }catch{result={status:503};}
      if(result.status===200)this.store.delivered(delivery.event_id,delivery.device_id,'sent');
      else if(result.status===410){this.store.deleteDevice(delivery.device_id);}
      else if(result.status===429||result.status>=500){
        const expired=Date.now()-Date.parse(delivery.observed_at)>3600000;
        this.store.delivered(delivery.event_id,delivery.device_id,expired||delivery.attempts>=8?'failed':'pending',Date.now()+Math.min(300000,1000*2**delivery.attempts));
      }else this.store.delivered(delivery.event_id,delivery.device_id,'failed');
    }
  }
  start() {if(this.timer)return;this.timer=setInterval(()=>this.tick().catch(()=>{this.lastError='MONITOR_FAILED';}),this.intervalMs);this.timer.unref();}
  async stop() {clearInterval(this.timer);this.timer=null;try{await this.recovery.stop();}finally{this.connected=false;this.apns?.close();}}
}
