import {ApiError} from './errors.mjs';
export const defaultNotificationRules=Object.freeze({login:true,logout:true,match_start:false,match_end:false,visibility:true,team:false,matching:false,spectating:false,busy:false,other_state:false});
export function notificationRules(value,base=defaultNotificationRules){
  if(!value||typeof value!=='object'||Array.isArray(value))throw new ApiError(400,'INVALID_NOTIFICATION_RULES','通知条件を指定してください。');
  for(const [key,enabled] of Object.entries(value))if(!Object.hasOwn(defaultNotificationRules,key)||typeof enabled!=='boolean')throw new ApiError(400,'INVALID_NOTIFICATION_RULES','通知条件は対応する項目に true / false を指定してください。');
  return {...base,...value};
}
const active=s=>typeof s==='string'&&!['offline','unknown'].includes(s);
export function eventTypes(event){
  const before=event.previous_state,after=event.state,types=[];
  // Also reject older queued observations whose public visibility was unknown,
  // even if a previous API version retained an online/offline state for them.
  if(event.previous_visibility==='unknown'||event.visibility==='unknown')return types;
  if(event.previous_visibility==='hidden'||event.visibility==='hidden'){
    if(['visible','hidden'].includes(event.previous_visibility)&&['visible','hidden'].includes(event.visibility)&&event.previous_visibility!==event.visibility)types.push('visibility');
    return types;
  }
  if(before==='offline'&&active(after))types.push('login');
  if(active(before)&&after==='offline')types.push('logout');
  if(active(before)&&before!=='in_match'&&after==='in_match')types.push('match_start');
  if(before==='in_match'&&active(after)&&after!=='in_match')types.push('match_end');
  if(['visible','hidden'].includes(event.previous_visibility)&&['visible','hidden'].includes(event.visibility)&&event.previous_visibility!==event.visibility)types.push('visibility');
  for(const [state,type]of [['in_team','team'],['matching','matching'],['spectating','spectating'],['busy','busy']])if(active(before)&&active(after)&&before!==after&&(before===state||after===state))types.push(type);
  if(before!==after&&!types.length&&active(before)&&active(after))types.push('other_state');
  return types;
}
export const shouldNotify=(event,rules)=>eventTypes(event).some(type=>rules[type]===true);
