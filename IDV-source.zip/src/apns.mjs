import http2 from 'node:http2';
import { createPrivateKey, sign } from 'node:crypto';
import { readFileSync } from 'node:fs';
const base64 = value => Buffer.from(JSON.stringify(value)).toString('base64url');
export class Apns {
  constructor({ keyId, teamId, topic, privateKey }) {
    this.keyId = keyId; this.teamId = teamId; this.topic = topic;
    this.key = createPrivateKey(privateKey); this.sessions = new Map(); this.jwt = null; this.issuedAt = 0;
    if (this.key.asymmetricKeyType !== 'ec' || this.key.asymmetricKeyDetails?.namedCurve !== 'prime256v1') throw new Error('APNs requires a P-256 key.');
  }
  static fromEnvironment(env = process.env) {
    if (![env.APNS_KEY_ID, env.APNS_TEAM_ID, env.APNS_TOPIC, env.APNS_KEY_FILE].every(Boolean)) return null;
    return new Apns({ keyId:env.APNS_KEY_ID,teamId:env.APNS_TEAM_ID,topic:env.APNS_TOPIC,privateKey:readFileSync(env.APNS_KEY_FILE,'utf8') });
  }
  authorization() {
    const now = Math.floor(Date.now()/1000);
    if (!this.jwt || now-this.issuedAt>=3000) {
      const input = `${base64({alg:'ES256',kid:this.keyId})}.${base64({iss:this.teamId,iat:now})}`;
      this.jwt = `${input}.${sign('sha256', Buffer.from(input), {key:this.key,dsaEncoding:'ieee-p1363'}).toString('base64url')}`;
      this.issuedAt = now;
    }
    return `bearer ${this.jwt}`;
  }
  session(environment) {
    let session = this.sessions.get(environment);
    if (!session || session.closed || session.destroyed) {
      const host = environment==='production' ? 'https://api.push.apple.com' : 'https://api.sandbox.push.apple.com';
      session = http2.connect(host, {minVersion:'TLSv1.2'});
      session.on('error', () => { if(this.sessions.get(environment)===session)this.sessions.delete(environment); session.destroy(); });
      session.on('goaway', () => { if(this.sessions.get(environment)===session)this.sessions.delete(environment); session.close(); });
      this.sessions.set(environment,session);
    }
    return session;
  }
  async send(token,environment,event) {
    if(!/^[a-f0-9]{32,512}$/i.test(token)||!['sandbox','production'].includes(environment))throw new Error('Invalid APNs target');
    const labels={online:'オンライン',offline:'オフライン',in_match:'対戦中',in_team:'チーム参加中',matching:'マッチング中',reserved:'予約中',custom_room:'カスタムルーム',visiting:'訪問中',spectating:'観戦中',idle:'待機中',busy:'取り込み中',recruiting:'募集中',unknown:'不明'};
    const visibilityLabels={visible:'表示',hidden:'非表示',unknown:'公開状態不明'};
    const visibilityOnly=event.previous_state===event.state&&event.previous_visibility!==event.visibility;
    const text=visibilityOnly?`${visibilityLabels[event.previous_visibility]??'不明'} → ${visibilityLabels[event.visibility]??'不明'}`:`${labels[event.previous_state]} → ${labels[event.state]}`;
    const payload=JSON.stringify({aps:{alert:{title:'第五人格の状態更新',body:`${event.player_id}: ${text}`},sound:'default'},event_id:event.id,player_id:event.player_id,observed_at:event.observed_at,visibility:event.visibility});
    return new Promise((resolve,reject)=>{
      let status=0,body='';
      const request=this.session(environment).request({':method':'POST',':path':`/3/device/${token}`,authorization:this.authorization(),'apns-topic':this.topic,'apns-push-type':'alert','apns-priority':'10','apns-expiration':String(Math.floor(Date.now()/1000)+3600),'content-type':'application/json',[http2.sensitiveHeaders]:['authorization',':path']});
      request.setTimeout(10000,()=>request.destroy(new Error('APNs timeout')));
      request.on('response',h=>{status=Number(h[':status']);});
      request.on('data',b=>{if(body.length<4096)body+=b;});
      request.on('error',()=>reject(new Error('APNs transport error')));
      request.on('end',()=>{let reason;try{reason=JSON.parse(body).reason;}catch{}resolve({status,reason});});
      request.end(payload);
    });
  }
  close() { for(const s of this.sessions.values())s.destroy();this.sessions.clear(); }
}
