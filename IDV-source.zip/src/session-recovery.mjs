import {ApiError} from './errors.mjs';

// Every automatic login explicitly declines replacement of an existing game login.
export class SessionRecovery {
  constructor({provider,store,vault,automatic=false,retryDelaysMs=[1000,3000,10000,30000,60000],retryLimit=5,onConnected=async()=>{},onDisconnected=()=>{}}){
    Object.assign(this,{provider,store,vault,automatic,retryDelaysMs,retryLimit,onConnected,onDisconnected});
    this.wanted=false;this.connecting=false;this.closed=false;this.intent=0;this.serial=Promise.resolve();this.timer=null;this.nextAt=null;this.failures=0;this.attempts=[];this.pausedReason=null;this.lastDisconnect=null;this.loginFailure=null;
    provider.on?.('disconnected',detail=>{
      this.lastDisconnect=detail??{code:'GAME_DISCONNECTED',retryable:false};const failure=detail?.login_failure;this.loginFailure=['sdk_auth_failed','login_rejected','unverified_reply'].includes(failure?.reason)?{reason:failure.reason,server_code:Number.isSafeInteger(failure.server_code)&&failure.server_code>=0&&failure.server_code<=0x7fffffff?failure.server_code:null}:null;this.onDisconnected(this.lastDisconnect);
      if(!this.connecting&&this.wanted&&!this.closed){if(this.lastDisconnect.retryable)this.schedule();else this.pausedReason=this.lastDisconnect.code;}
    });
  }
  status(){return {automatic:this.automatic,desired:this.wanted,connecting:this.connecting,retry_at:this.nextAt?new Date(this.nextAt).toISOString():null,paused_reason:this.pausedReason,last_disconnect_code:this.lastDisconnect?.code??null,login_failure:this.loginFailure?{...this.loginFailure}:null};}
  enqueue(fn){const work=this.serial.then(fn,fn);this.serial=work.catch(()=>{});return work;}
  clearTimer(){clearTimeout(this.timer);this.timer=null;this.nextAt=null;}
  cancelled(version){return this.closed||!this.wanted||version!==this.intent;}
  cancellation(){return new ApiError(409,'SESSION_OPERATION_CANCELLED','接続操作が取り消されました。');}
  async connect(credentials,options={}){
    if(this.closed)throw this.cancellation();
    const version=++this.intent;this.wanted=true;this.clearTimer();this.failures=0;this.attempts=[];this.pausedReason=null;this.store?.setting('game_connection_desired','1');
    return this.enqueue(()=>this.attempt(credentials,options,version));
  }
  async attempt(credentials,options,version){
    if(this.cancelled(version))throw this.cancellation();
    this.connecting=true;this.loginFailure=null;let retry=false;
    try{
      await this.provider.connect(credentials,options);
      if(this.cancelled(version)){await this.provider.disconnect();throw this.cancellation();}
      this.failures=0;this.pausedReason=null;this.loginFailure=null;
      await this.onConnected();
      retry=!this.provider.connected&&this.lastDisconnect?.retryable===true;
    }catch(error){
      if(!this.cancelled(version)){
        retry=(error.code==='GAME_LOGIN_FAILED'&&this.provider.lastDisconnect?.retryable===true)||['GATEWAY_NETWORK_ERROR','GATEWAY_CLOSED','GATEWAY_RESPONSE_TIMEOUT'].includes(error.code);
        if(!retry)this.pausedReason=error.code??'GAME_LOGIN_FAILED';
      }
      throw error;
    }finally{this.connecting=false;if(retry&&!this.cancelled(version))this.schedule();}
  }
  schedule(){
    if(!this.automatic||!this.wanted||this.closed||this.timer)return;
    this.attempts=this.attempts.filter(at=>Date.now()-at<300000);
    if(this.attempts.length>=this.retryLimit){this.pausedReason='RECONNECT_LIMIT_REACHED';return;}
    const delay=this.retryDelaysMs[Math.min(this.failures++,this.retryDelaysMs.length-1)],version=this.intent;
    this.nextAt=Date.now()+delay;
    this.timer=setTimeout(async()=>{
      this.timer=null;this.nextAt=null;if(this.cancelled(version))return;
      try{
        const credentials=this.vault?.get('game-session');if(!credentials){this.pausedReason='CREDENTIALS_REQUIRED';return;}
        this.attempts.push(Date.now());
        await this.enqueue(()=>this.attempt(credentials,{replaceExisting:false},version));
      }catch(error){if(!this.cancelled(version)&&!this.pausedReason&&!this.timer)this.pausedReason=error.code??'CREDENTIALS_UNAVAILABLE';}
    },delay);this.timer.unref?.();
  }
  async restore(){
    if(!this.automatic||this.store?.setting('game_connection_desired')==='0')return false;
    const credentials=this.vault?.get('game-session');if(!credentials)return false;
    try{await this.connect(credentials,{replaceExisting:false});return this.provider.connected;}catch{return false;}
  }
  async disconnect(){
    this.wanted=false;this.intent++;this.clearTimer();this.pausedReason='MANUAL_DISCONNECT';this.store?.setting('game_connection_desired','0');
    await this.enqueue(()=>this.provider.disconnect());
  }
  async stop(){
    this.closed=true;this.wanted=false;this.intent++;this.clearTimer();
    await this.enqueue(()=>this.provider.disconnect());
  }
}
